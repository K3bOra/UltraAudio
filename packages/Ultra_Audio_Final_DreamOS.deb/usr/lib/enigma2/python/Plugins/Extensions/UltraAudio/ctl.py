# -*- coding: utf-8 -*-
"""Audio/video actions are ordered on the Enigma2 main thread."""
from __future__ import division
import threading
import time

from . import dvbaudio, store
from . import tvchannel
from .i18n import T
from . import engine as engine_mod
from .engine import Engine, log, main_call, init_main_dispatcher, stop_main_dispatcher
from .compat import UNIDENTIFIED, connect_timer, integer_types, is_main_thread, monotonic, native, service_key, to_text, user_input_idle
from .vdelay import VideoDelay

_instance = None
_ilock = threading.Lock()


def get():
    global _instance
    with _ilock:
        if _instance is None:
            _instance = Controller()
        return _instance


class Controller(object):
    def __init__(self):
        self.engine = Engine(on_change=self._engine_changed)
        self.engine.on_busy = lambda n: main_call(self._busy, n)
        self.engine.on_acquired = lambda: main_call(self._acquired)
        self.engine.free_steps = self._free_steps
        self.engine.on_refused = self._refresh_link
        self._last_refresh = {}            # source folder id -> when its playlist was last fetched for a fresh token
        self._zap_key, self._zap_since, self._zap_done = None, 0.0, True
        self._restore_s, self._restore_timer = 0.0, None
        self._restore_deadline = 0.0
        self.video = VideoDelay()
        self.video.on_seek = self._mute_later
        self.video.on_before_timeshift = self._arm_timeshift_audio
        self.video.on_manual_delay = self._manual_picture_changed
        self.session = None
        self._muted_by_us = False
        self._mute_before = None
        self._guard_timer = None
        self._connections = []
        self._playing_service = None
        self._audio_requested_ms = self._audio_compensation_ms = 0
        self._buffer_sync = False
        self._last_video_state = "off"
        self._closed = False
        self._hook_ib = None
        self._dvb_muted = False
        self._dvb_stamp = 0.0
        self._dvb_warned = False
        self._no_qpip = False
        self._target_audio_key = None
        self._target_audio_warned = False
        self._svc_released = False
        self._dvb_stopped = False
        self._sys_hold = False
        self._idle_done = False
        self._card_timer = None
        self._prep_timer = None
        self._prep_target = None
        self._prep_phase = None
        self._prep_video_s = 0.0
        self._prep_until = self._prep_started = 0.0
        self._prep_sample = self._prep_stable = None
        self._play_timer = None
        self._pending_play = None
        self._mute_timer = None
        self._followup_timer = None
        self._mute_target = None
        self._mute_pcm_recovery = False
        self._restore_target = None
        self._muting = False
        self._mute_service = None
        self._last_dvb_sig = ()
        self._last_frozen = False
        self._ts_pos_watch = None
        self._active_dvb_flush = False
        self._last_active_flush_at = 0.0
        self._tv_info = tvchannel.snapshot('', '')
        self._memory_off = None            # TV service whose saved sync the owner removed: not remembered again until a new play
        self._key_source = None
        self._key_fail_at = None
        self._unid_logged = None

    def _timer(self, callback):
        from enigma import eTimer
        timer = eTimer()
        connect_timer(timer, callback, self._connections)   # DreamOS: timeout.connect; others: callback list
        return timer

    @staticmethod
    def _patch_slider_overflow():
        """Handle only overflowing Progress updates; leave VariableValue untouched.

        Normal updates (including clear notifications and negative sentinel
        values) keep the image's own behavior. Only a failed 32-bit slider
        update is retried using proportionally scaled display coordinates.
        """
        try:
            from Components.Renderer.Progress import Progress
            if Progress.__dict__.get('_ultraaudio_overflow_only', False):
                return
            original = Progress.changed

            def changed(widget, *args, **kwargs):
                try:
                    return original(widget, *args, **kwargs)
                except OverflowError:
                    source = getattr(widget, 'source', None)
                    extent = getattr(source, 'range', None)
                    position = getattr(source, 'position', None)
                    if not isinstance(extent, integer_types + (float,)) or not isinstance(position, integer_types + (float,)):
                        raise
                    if not store.isfinite(extent) or not store.isfinite(position) or extent <= 0:
                        raise
                    limit = 0x7FFFFFFF
                    value = max(0, min(limit, int((position / float(extent)) * limit)))
                    widget.range = (0, limit)
                    widget.value = value
            Progress.changed = changed
            Progress._ultraaudio_overflow_only = True
        except Exception as exc:
            log('Progress overflow guard unavailable: %r' % exc)

    def attach(self, session):
        init_main_dispatcher()
        self.session = session
        self._closed = False
        self._patch_slider_overflow()
        self._refresh_tv_info()
        if self._guard_timer is None:
            self._guard_timer = self._timer(self._guard)
        self._guard_timer.start(500, False)

    def _service_key(self, explain=False):
        """Identity of the tuned TV service. DreamOS (OE2.5) may report no playing service through the navigation
        object; compat.service_key then reads the channel list / last service, and as a last resort returns
        UNIDENTIFIED so playback still starts (per-channel memory ignores that key)."""
        try:
            nav = self.session.nav
        except Exception:
            nav = None
        key, source, notes = service_key(nav, fallback=True, placeholder=True)
        try:
            if key:
                self._key_fail_at = None
                now = monotonic()
                unid = key == UNIDENTIFIED
                # Unidentified: explain again at a play and every 5 minutes (the InfoBar does not exist yet at
                # session start, so the first explanation alone says little).
                if source != self._key_source or (unid and self._unid_logged is None):
                    self._key_source = source
                    if unid:
                        self._unid_logged = now
                        log("TV service identity unavailable (%s); playing without per-channel memory"
                            % ("; ".join(notes) or "no details"))
                    else:
                        log("TV service identity via %s: %s" % (source, key))
            else:
                now = monotonic()
                if self._key_fail_at is None or now - self._key_fail_at > 30.0:
                    self._key_fail_at = now
                    log("TV service identity unavailable: %s" % ("; ".join(notes) or "no details"))
        except Exception:
            pass
        return key

    @staticmethod
    def _memorable(service):
        """Per-channel memory only for a real channel identity."""
        return bool(service) and service != UNIDENTIFIED

    def _refresh_tv_info(self, key=None):
        """Called only by attach/guard on the Enigma2 main thread."""
        key = (self._service_key() if key is None else key) or ''
        if key == UNIDENTIFIED:
            key = ''
        if key == self._tv_info['reference'] and self._tv_info['name']:
            return
        if key and key == getattr(self, '_tv_skipped', None):
            return                       # the same bouquet / folder reference as last time: nothing to look up again
        name = ''
        if key:
            try:
                service = self.session.nav.getCurrentService()
                info = service.info() if service is not None else None
                name = info.getName() if info is not None else ''
            except Exception:
                pass
            if not name:
                try:
                    from enigma import eServiceCenter
                    ref = self.session.nav.getCurrentlyPlayingServiceReference()
                    info = eServiceCenter.getInstance().info(ref)
                    name = info.getName(ref) if info is not None else ''
                except Exception:
                    pass
            if not name:
                try:   # identity came from the channel list / last service, not from the navigation object
                    from enigma import eServiceCenter, eServiceReference
                    ref = eServiceReference(native(key))
                    info = eServiceCenter.getInstance().info(ref)
                    name = info.getName(ref) if info is not None else ''
                except Exception:
                    pass
        self._tv_info = tvchannel.snapshot(key, name)
        self._tv_skipped = key if key and not self._tv_info['reference'] else None

    @staticmethod
    def _on_main(fn, *args):
        """Run fn on the Enigma2 main thread and return its result (service calls are not thread-safe)."""
        if is_main_thread():
            return fn(*args)
        box, done, cancelled = [], threading.Event(), threading.Event()

        def run():
            try:
                if not cancelled.is_set():
                    box.append(fn(*args))
            finally:
                done.set()
        main_call(run)
        if not done.wait(2.0):
            cancelled.set()
        return box[0] if box else False

    def _arm_timeshift_audio(self):
        # Run before start/activateTimeshift reconstructs the native decoder.
        if (not self._closed and self.engine.status()["state"] in ("starting", "playing", "retrying")
                and self._playing_service == self._service_key()
                and store.get_settings()["mute_mode"] in ("decoder", "track")):
            self._service_audio(False)
            self._set_mute(True, force=True)

    def _service_audio(self, enabled):
        """Drop / restore the audio of the current Enigma2 service when setQpipMode is supported."""
        try:
            service = self.session.nav.getCurrentService()
            setter = getattr(service, "setQpipMode", None)
            if callable(setter):
                setter(False, bool(enabled))
                released = True
            else:
                if service is not None and not self._no_qpip:
                    self._no_qpip = True
                    log("this Enigma2 service has no setQpipMode; using DVB audio/demux isolation")
                released = False
            if enabled:
                try:
                    tracks = service.audioTracks()
                    count = tracks.getNumberOfTracks()
                    if count > 0:
                        cur = tracks.getCurrentTrack()
                        tracks.selectTrack(cur if 0 <= cur < count else 0)
                except Exception as e:
                    log("restoring the audio track failed: %r" % e)
            return released
        except Exception as e:
            if not self._target_audio_warned:
                self._target_audio_warned = True
                log("service audio %s unavailable: %r" % ("restore" if enabled else "suppression", e))
            return False

    def _timeshift_playing(self):
        ib = self.video._infobar()
        ts = self.video._timeshift(ib) if ib is not None else None
        fn = getattr(ts, "isTimeshiftActive", None)
        if callable(fn):
            try:
                if fn():
                    return True
            except Exception:
                pass
        return ib is not None and self.video._enabled(ib)

    def _stop_decoder_for_audio(self):
        """Isolate the DVB audio decoder and its demux PES filter (DMX_STOP + AUDIO_SOURCE_MEMORY + AUDIO_STOP)."""
        return dvbaudio.set_mute(True)

    @staticmethod
    def _release_alsa_singleton():
        """Some images keep an eAlsaOutput open next to the DVB decoder; close it before we open the card."""
        try:
            from enigma import eAlsaOutput
            out = eAlsaOutput.getInstance()
            if out is not None:
                for name in ("stop", "close"):
                    method = getattr(out, name, None)
                    if callable(method):
                        method()
                log("eAlsaOutput released")
        except ImportError:
            pass
        except Exception as e:
            log("eAlsaOutput not available: %r" % e)

    def _free_steps(self):
        """What the engine may try (in this order) when the TV side still holds the sound card."""
        method = store.get_settings()["mute_mode"]
        if self._closed or method not in ("decoder", "track"):     # shutting down: the main thread is busy
            return []

        gen = self.engine.gen

        def guarded(fn):
            def run():
                if (not self._closed and self.engine.gen == gen
                        and (self._playing_service is None or self._playing_service == self._service_key())):
                    return fn()
                return False
            return self._on_main(run)

        def decoder_stop():
            if not self._dvb_stopped and not str(self.engine.device or "").startswith("dvb"):
                self._dvb_stopped = self._stop_decoder_for_audio()
                if self._dvb_stopped:
                    self._mute_service = self._service_key()
            return self._dvb_stopped

        # Never include system volume mute here: it shares the hardware mixer with ALSA/DVB output and mutes commentary.
        steps = [("service audio release", lambda: guarded(self._service_audio_flag))]
        if method == "decoder":
            steps.insert(0, ("decoder stop (AUDIO_STOP)", lambda: guarded(decoder_stop)))
        return steps

    def _service_audio_flag(self):
        if not self._svc_released:
            self._svc_released = self._service_audio(False)
            if self._svc_released:
                self._mute_service = self._service_key()
        return self._svc_released

    def _busy(self, n):
        """The sound card was busy again; the engine's step ladder runs before the next try, nothing more to do here."""
        log("sound card busy (#%d)" % n)

    def _acquired(self):
        if self._sys_hold:
            self._sys_hold = False
            if not self._closed:
                self._system_mute(False)
                log("system mute lifted: the commentary holds the sound card")

    # Called only on the main thread. No toggle calls: a repeated guard is idempotent.
    def _set_mute(self, on, force=False):
        if self._muting:
            return
        self._muting = True
        try:
            self._set_mute_inner(on, force)
        finally:
            self._muting = False

    def _set_mute_inner(self, on, force=False):
        key = self._service_key()
        if self._mute_service is not None and key != self._mute_service:
            # The old service closed its decoder during a zap. Its restore
            # flags must never issue AUDIO_PLAY/track changes on the new one.
            self._dvb_muted = self._svc_released = self._dvb_stopped = False
            self._mute_service = None
            self._target_audio_key = None
        settings = store.get_settings()
        method = settings["mute_mode"]
        isolate = on and method in ("track", "decoder") and (force or not self._dvb_muted)
        is_dvb_out = isolate and (settings.get("output") == "dvb"
                                  or str(self.engine.device or "").startswith("dvb") or not engine_mod.alsa_cards())
        frozen = isolate and self._picture_frozen()
        if on and method == "track":
            if not self._dvb_muted or force:
                ts_busy = self._timeshift_playing() or self.video.state != "off"
                if (frozen or ts_busy) and self._svc_released:
                    released = True
                else:
                    released = self._service_audio(False) if (force or not self._svc_released) else True
                stopped = False if (released or is_dvb_out) else self._stop_decoder_for_audio()
                if is_dvb_out and self._dvb_muted and force:
                    dvbaudio.keep_dvb_commentary_unmuted(open_device=True)
                log("TV sound muted: audio track off=%s, decoder fallback=%s" % (released, stopped))
                if released or stopped:
                    self._svc_released = self._svc_released or bool(released)
                    self._dvb_stopped = self._dvb_stopped or bool(stopped)
                    self._dvb_muted, self._dvb_stamp = True, monotonic()
                    self._mute_service = key
                    self._last_dvb_sig = dvbaudio.borrowed_signature()
                    if not self._sys_hold:
                        self._system_mute(False)
                    return
                if not self._dvb_warned:
                    self._dvb_warned = True
                    log("native audio isolation unavailable; shared mixer fallback is restricted to live TV")
                self._dvb_muted = False
            elif self._dvb_muted:
                return
            if not self._timeshift_playing():
                self._system_mute(True, force)
            return
        if on and method == "decoder":
            now = monotonic()
            if not self._dvb_muted or force:
                if is_dvb_out:
                    st_state = self.engine.status()["state"]
                    if self._dvb_muted and force and st_state in ("playing", "starting", "retrying"):
                        # Commentary is already playing on /dev/dvb/adapter0/audio0: do NOT call AUDIO_CLEAR_BUFFER or AUDIO_STOP!
                        ts_busy = self._timeshift_playing() or self.video.state != "off"
                        released = True if ((frozen or ts_busy) and self._svc_released) else self._service_audio(False)
                        dvbaudio.keep_dvb_commentary_unmuted(open_device=True)
                        stopped = self._dvb_stopped
                    else:
                        dvbaudio.prepare_dvb_sink()
                        ts_busy = self._timeshift_playing() or self.video.state != "off"
                        released = True if ((frozen or ts_busy) and self._svc_released) else (
                            self._service_audio(False) if (force or not self._svc_released) else True)
                        stopped = False if released else self._stop_decoder_for_audio()
                        dvbaudio.prepare_dvb_sink()
                else:
                    # Prefer dropping the service audio PID (setQpipMode) first so timeshift pause/unpause never
                    # restarts TV audio or stalls ALSA; when setQpipMode already released the service, do not re-call
                    # setQpipMode while frozen (Vu+ unfreezes video), but ALWAYS run _stop_decoder_for_audio when
                    # setQpipMode is absent (DreamOS) even while frozen so AUDIO_PAUSE is cleared immediately!
                    ts_busy = self._timeshift_playing() or self.video.state != "off"
                    if frozen and self._svc_released:
                        released = True
                        if dvbaudio.borrowed_fds():
                            dvbaudio.set_mute(True, borrowed_only=True)
                        stopped = False
                    else:
                        released = self._service_audio(False) if (force or not self._svc_released) else True
                        if released and ts_busy and dvbaudio.borrowed_fds():
                            dvbaudio.set_mute(True, borrowed_only=True)
                        stopped = self._stop_decoder_for_audio() if not released else False
                if not self._dvb_muted:
                    self._release_alsa_singleton()
                log("TV sound muted: decoder stop=%s, service release=%s" % (stopped, released))
                done = stopped or released
                if done:
                    self._dvb_stopped = (self._dvb_stopped or bool(stopped)) and not released
                    self._svc_released = self._svc_released or bool(released)
                    self._dvb_muted, self._dvb_stamp = True, now
                    self._mute_service = key
                    self._last_dvb_sig = dvbaudio.borrowed_signature()
                    if not self._sys_hold:
                        self._system_mute(False)    # never keep the (shared-mixer) system mute on top of it
                    return
                if not self._dvb_warned:
                    self._dvb_warned = True
                    log("decoder isolation unavailable; shared mixer fallback is restricted to live TV")
                self._dvb_muted = False
            elif self._dvb_muted:
                return
            if not self._timeshift_playing():
                self._system_mute(True, force)
            return
        if self._dvb_muted or self._svc_released or self._dvb_stopped or (self._target_audio_key is not None and self._target_audio_key == key):
            if self._svc_released or (self._target_audio_key is not None and self._target_audio_key == key):
                self._service_audio(True)
            if self._dvb_stopped:
                dvbaudio.set_mute(False)
            self._dvb_muted = False
            self._svc_released = False
            self._dvb_stopped = False
            self._mute_service = None
        if not on:
            self._sys_hold = False
        self._system_mute(on and method == "system", force)

    def _system_mute(self, on, force=False):
        try:
            from enigma import eDVBVolumecontrol
            volume = eDVBVolumecontrol.getInstance()
            if on:
                if self._mute_before is None:
                    self._mute_before = bool(volume.isMuted())
                if not volume.isMuted() or force:
                    volume.volumeMute()
                    self._muted_by_us = self._muted_by_us or not self._mute_before
            elif self._mute_before is not None:
                before = self._mute_before
                if self._muted_by_us:
                    if before and not volume.isMuted():
                        volume.volumeMute()
                    elif not before and volume.isMuted():
                        volume.volumeUnMute()
                self._muted_by_us, self._mute_before = False, None
        except Exception as e:
            log("mute failed: %r" % e)

    def _engine_changed(self, state):
        # Read the current state when dispatched, not an obsolete queued notification.
        main_call(self._sync_output)

    def _hook_play_state(self):
        ib = self.video._infobar()
        if ib is self._hook_ib:
            return
        if self._hook_ib is not None:
            callbacks = getattr(self._hook_ib, "onPlayStateChanged", [])
            if self._play_state_changed in callbacks:
                callbacks.remove(self._play_state_changed)
        self._hook_ib = ib
        callbacks = getattr(ib, "onPlayStateChanged", None)
        if callbacks is not None and self._play_state_changed not in callbacks:
            callbacks.append(self._play_state_changed)

    def _play_state_changed(self, *args):
        if not self._closed and not self._muting:
            self._mute_later()
            self._log_card_later()

    def _mute_later(self, pcm_recovery=False):
        st = self.engine.status()
        if st.get("preparing"):
            return                       # re-mute once, after the buffer settles and before PCM starts
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        target = (st["stream_id"], self._service_key())
        self._mute_pcm_recovery = pcm_recovery or (self._mute_target == target and self._mute_pcm_recovery)
        self._mute_target = target
        if self._mute_timer is None:
            self._mute_timer = self._timer(self._mute_now)
        self._mute_timer.start(250, True)
        # DreamOS eDVBServicePlay::switchToTimeshift() may rebuild eDVBAudio asynchronously 400-900ms later:
        # check at 900ms and only reopen PCM if the DVB descriptor signature actually changed.
        if self._followup_timer is None:
            self._followup_timer = self._timer(self._mute_followup)
        self._followup_timer.start(900, True)

    def _mute_followup(self):
        st = self.engine.status()
        if (not self._closed and st["state"] in ("starting", "playing", "retrying")
                and self._playing_service == self._service_key()):
            cur_sig = dvbaudio.borrowed_signature()
            if cur_sig != self._last_dvb_sig:
                self._mute_target = (st["stream_id"], self._service_key())
                self._mute_pcm_recovery = True
                self._mute_now()
            elif self._keep_pcm_through_adjustment(st, cur_sig):
                # A decoder transition can leave the existing ALSA handle in
                # XRUN even though the stream still reports playing.
                if engine_mod.alsa_xrun(self.engine.procs):
                    self.engine.reset_pcm_output()
            else:
                dvbaudio.keep_timeshift_isolated(active_flush=False)

    def _keep_pcm_through_adjustment(self, status, signature=None):
        return (status["state"] == "playing" and status.get("output_flowing", status.get("sync_ready"))
                and self.video.adjusting_buffer()
                and self._dvb_muted and self._svc_released and not self._dvb_stopped
                and self._mute_service is not None and self._mute_service == self._playing_service
                and not str(self.engine.device or "").startswith("dvb")
                and self._last_dvb_sig == (dvbaudio.borrowed_signature() if signature is None else signature))

    def _mute_now(self):
        st = self.engine.status()
        target, self._mute_target = self._mute_target, None
        pcm_recovery, self._mute_pcm_recovery = self._mute_pcm_recovery, False
        if (not self._closed and target == (st["stream_id"], self._service_key())
                and st["state"] in ("starting", "playing", "retrying")):
            frozen = self._picture_frozen()
            self._last_frozen = frozen
            if not pcm_recovery and self._keep_pcm_through_adjustment(st):
                log("picture: keeping ALSA output open during timeshift adjustment")
                return
            log("TV transition: frozen=%s picture=%s output=%s device=%s qpip_missing=%s decoder_stopped=%s" % (
                frozen, self.video.info().get("state"), self.engine.mode, self.engine.device,
                self._no_qpip, self._dvb_stopped))
            # Always pass force=True: _set_mute_inner already avoids re-calling setQpipMode when frozen and
            # _svc_released is True (Vu+), while on DreamOS (no setQpipMode) force=True is mandatory so
            # AUDIO_PAUSE from eDVBAudio::freeze() is cleared immediately via AUDIO_CONTINUE + AUDIO_STOP!
            self._set_mute(True, force=True)
            try:
                is_dvb_dev = str(self.engine.device or "").startswith("dvb")
                dvbaudio.keep_dvb_commentary_unmuted(open_device=is_dvb_dev)
                if store.get_settings().get("mute_mode") != "system" and not self._sys_hold:
                    from enigma import eDVBVolumecontrol
                    vol_ctrl = eDVBVolumecontrol.getInstance()
                    if vol_ctrl is not None and vol_ctrl.isMuted():
                        vol_ctrl.volumeUnMute()
            except Exception:
                pass
            if not str(self.engine.device or "").startswith("dvb") and (pcm_recovery or engine_mod.alsa_xrun(self.engine.procs)):
                self.engine.reset_pcm_output()

    def _maintain_timeshift_audio(self):
        """Called every 500ms from _guard() while commentary is active to keep timeshift video & audio flowing."""
        if self._closed or store.get_settings().get("mute_mode") not in ("decoder", "track"):
            return
        cur_sig = dvbaudio.borrowed_signature()
        if cur_sig != self._last_dvb_sig:
            self._last_dvb_sig = cur_sig
            if cur_sig and self._dvb_muted:
                log("TV audio decoder rebuilt during playback/timeshift; re-isolating")
                self._set_mute(True, force=True)
                self._mute_later(pcm_recovery=True)
        frozen = self._picture_frozen()
        if frozen != self._last_frozen:
            self._last_frozen = frozen
            self._mute_later()
        ts_active = self._timeshift_playing() or self.video.state != "off"
        if not ts_active:
            self._ts_pos_watch = None
            self._active_dvb_flush = False
            return
        try:
            if store.get_settings().get("mute_mode") != "system" and not self._sys_hold:
                from enigma import eDVBVolumecontrol
                vol_ctrl = eDVBVolumecontrol.getInstance()
                if vol_ctrl is not None and vol_ctrl.isMuted():
                    vol_ctrl.volumeUnMute()
        except Exception:
            pass
        if str(self.engine.device or "").startswith("dvb"):
            dvbaudio.keep_dvb_commentary_unmuted(open_device=True)
            return
        if self._svc_released:
            return
        now = monotonic()
        ib = self.video._infobar()
        pl = self.video._pos_len(ib) if (ib is not None and not frozen) else None
        need_flush = False
        if pl is not None:
            pos, length = pl
            watch = self._ts_pos_watch
            if watch is None or abs(pos - watch[1]) > 0.03 or length < watch[2]:
                self._ts_pos_watch = (now, pos, length)
            elif now - watch[0] >= 1.8 and length - watch[2] >= 0.7:
                log("timeshift PVR audio FIFO backpressure detected (pos=%.2f len=%.2f); flushing DVB audio RAVE buffer"
                    % (pos, length))
                self._ts_pos_watch = (now, pos, length)
                need_flush = True
        else:
            self._ts_pos_watch = None
        dvbaudio.keep_timeshift_isolated(active_flush=need_flush)
        if need_flush:
            self.engine.reset_pcm_output()

    def _picture_frozen(self):
        try:
            ib = self.video._infobar()
            return ib is not None and self.video._paused(ib) is True
        except Exception:
            return False

    def _sync_output(self, st=None, key=None):
        if self._closed:
            return
        state = (self.engine.status() if st is None else st)["state"]
        # Never mute the TV service while state == "stopping" (e.g. during a channel zap).
        if state in ("starting", "playing", "retrying"):
            self._idle_done = False
            cur_key = self._service_key() if key is None else key
            if self._playing_service is None or self._playing_service == cur_key:
                self._set_mute(True)
        elif state in ("idle", "error"):
            if self._idle_done:
                return
            self._idle_done = True
            self._ts_pos_watch = None
            self._active_dvb_flush = False
            if self.video.state != "off":
                self.video.release()
            self._set_mute(False)

    def _guard(self):
        if self._closed or (not user_input_idle(0.55) and not self._pending_play):
            return
        try:
            key = self._service_key()
            self._refresh_tv_info(key=key)
            from . import receiverguide
            receiverguide.tick()
            st = self.engine.status()
            self.video.set_audio_context(
                st.get("sync_ready", False) and not self._pending_play and self._playing_service == key,
                (st.get("generation"), st.get("output_epoch")))
            if st["state"] in ("starting", "playing", "retrying", "stopping"):
                if self._playing_service is not None and self._playing_service != key:
                    # Immediately detach from the previous channel without issuing decoder commands on the new channel.
                    self._dvb_muted = self._svc_released = self._dvb_stopped = False
                    self._mute_service = None
                    self._target_audio_key = None
                    self._last_dvb_sig = ()
                    self._ts_pos_watch = None
                    self._active_dvb_flush = False
                    self.video.on_service_changed()
                    self._stop_main(save=False)
                    self._zap_seen(key)
                    return
                if st["state"] != "stopping":
                    self._hook_play_state()
                    self._maintain_timeshift_audio()
            elif st["state"] in ("idle", "error"):
                self._maybe_resume(key)
            self._sync_output(st=st, key=key)
            picture = self.video.info()
            self._sync_buffer_audio(st, picture)
            state = picture["state"]
            if self._last_video_state == "paused" and state == "running" and self.video.target > 0:
                self._remember_sync(video_s=self._picture_delay())
            self._last_video_state = state
        except Exception as e:
            log("playback guard failed: %r" % e)

    def play(self, sid):
        stream = store.get_stream(sid)
        if stream is None:
            raise KeyError(sid)
        if store.needs_radio_url(stream):
            raise ValueError(T("This radio needs a direct streaming URL. Edit it on the Web page."))
        main_call(self._queue_play_main, stream)
        return True

    def _queue_play_main(self, stream):
        if self._closed:
            return
        try:
            from . import receivertime
            receivertime.cancel()
        except Exception as exc:
            log('receiver time cancel before playback: %s' % exc)
        self._cancel_delayed()
        self.video.set_audio_context(False, None)
        self._pending_play = stream
        if self._play_timer is None:
            self._play_timer = self._timer(self._flush_play)
        self._play_timer.start(10, True)

    def _flush_play(self):
        stream, self._pending_play = self._pending_play, None
        if stream is not None:
            fresh = store.get_stream(stream["id"])
            if fresh is not None:
                self._play_main(fresh)

    def _cancel_delayed(self, pending=False):
        for name in ("_restore_timer", "_prep_timer", "_mute_timer", "_followup_timer", "_card_timer"):
            timer = getattr(self, name, None)
            if timer is not None:
                timer.stop()
        self._restore_s, self._restore_target, self._mute_target = 0.0, None, None
        self._restore_deadline = 0.0
        self._prep_target, self._prep_phase = None, None
        if pending:
            if self._play_timer is not None:
                self._play_timer.stop()
            self._pending_play = None

    def _play_main(self, stream, audio_ms=None, video_s=None, auto_restore_video=True):
        """Play commentary and apply delays strictly for the current receiver TV channel (never from the audio stream)."""
        if self._closed:
            return
        try:
            from . import receivertime
            receivertime.cancel()
        except Exception as exc:
            log('receiver time cancel before audio start: %s' % exc)
        st = self.engine.status()
        cur_service = self._service_key(explain=True)
        same_picture = (st["state"] in ("starting", "playing", "retrying") and not st.get("preparing")
                        and self._playing_service is not None and self._playing_service == cur_service)
        if self.video._service is not None and self.video._service != cur_service:
            self.video.on_service_changed()
        self._cancel_delayed(pending=True)
        self._playing_service = cur_service
        self._memory_off = None
        saved = store.recall_channel(self._playing_service) if self._memorable(self._playing_service) else None
        if audio_ms is None:
            if same_picture:
                audio_ms = self._audio_requested_ms
            elif saved is not None:
                audio_ms = int(saved.get("audio_ms") or 0)
            else:
                audio_ms = 0
        # Picture delay belongs strictly to this TV channel (self._playing_service), never to the audio stream.
        if video_s is not None:
            remembered_video = float(video_s or 0.0)
        elif same_picture and self._picture_delay() > 0:
            remembered_video = self._picture_delay()
        elif saved is not None and float(saved.get("video_s") or 0.0) > 0:
            remembered_video = float(saved["video_s"])
        else:
            remembered_video = 0.0
        self._zap_seen(self._playing_service, done=True)
        self._set_mute(True, force=True)
        self._audio_requested_ms = max(0, min(engine_mod.MAX_DELAY_MS, int(audio_ms)))
        if not same_picture:
            self._audio_compensation_ms = 0
            self._buffer_sync = bool(saved and saved.get("buffer_sync"))
        self._audio_compensation_ms = min(self._audio_compensation_ms, engine_mod.MAX_DELAY_MS - self._audio_requested_ms)
        self.engine.play(stream, self._audio_requested_ms + self._audio_compensation_ms)
        if auto_restore_video and remembered_video > 0 and self.video.info()["state"] == "off":
            self._restore_s = remembered_video
            self._restore_target = (stream["id"], self._playing_service)
            self._restore_deadline = monotonic() + 4.0
            if self._restore_timer is None:
                self._restore_timer = self._timer(self._restore_picture)
            self._restore_timer.start(150, True)
        self._hook_play_state()
        self._last_video_state = self.video.info()["state"]
        self._remember_sync(video_s=remembered_video)

    def stop(self):
        """The owner stopped the commentary: this channel must not bring it back by itself."""
        main_call(self._stop_by_owner)

    def _stop_by_owner(self):
        service = self._service_key()
        # An explicit stop cancels this TV channel's automatic commentary and delays.
        # Suppress any final playback callback before removing the persisted record.
        self._memory_off = service
        store.delete_channel(service)
        self._zap_seen(service, done=True)
        self._stop_main(save=False)
        # Test3: a manual stop gives the receiver back to normal live TV: close the timeshift too, whoever opened it.
        try:
            self.video.force_close()
        except Exception as e:
            log("closing timeshift on stop failed: %r" % e)

    def save_channel_sync(self, sid=None, generation=None, service=None):
        """Save and persist the current TV service's and commentary's offsets to disk."""
        st = self.engine.status()
        result = self._on_main(self._save_channel_sync, st["stream_id"] if sid is None else sid,
                               self._playing_service if service is None else service)
        return result if isinstance(result, tuple) else (False, T("Start the commentary before saving TV sync"))

    def _save_channel_sync(self, sid, expected_service):
        st, service = self.engine.status(), self._service_key()
        if service == UNIDENTIFIED:
            return False, T("The TV channel could not be identified; its sync cannot be saved")
        if (not service or service != self._playing_service or (expected_service and service != expected_service)
                or (sid and sid != st["stream_id"]) or st.get("preparing")
                or st["state"] not in ("starting", "playing", "retrying") or not st.get("stream_id")):
            return False, T("Start the commentary before saving TV sync")
        memo = store.recall_channel(service)
        cur_pic = self._picture_delay()
        if cur_pic <= 0 and self._restore_s > 0:
            cur_pic = self._restore_s
        elif cur_pic <= 0 and self.video.state == "off" and memo and memo.get("video_s", 0) > 0:
            cur_pic = float(memo["video_s"])
        self._memory_off = None
        store.remember_channel(service, st["stream_id"], cur_pic, self._audio_requested_ms, auto=True,
                               pinned=True, buffer_sync=self._buffer_sync)
        log("TV sync saved for %s: %s, picture %.1fs, audio %dms" % (service, st["stream_id"], cur_pic, self._audio_requested_ms))
        return True, T("Sync saved for this TV channel")

    def forget_channel_sync(self, service=None):
        """Remove this TV channel's saved sync for good: it no longer starts its commentary by itself."""
        result = self._on_main(self._forget_channel_sync, service)
        return result if isinstance(result, tuple) else (False, T("Could not remove the saved sync"))

    def _forget_channel_sync(self, service):
        key = service or self._playing_service or self._service_key()
        if not key:
            return False, T("Could not remove the saved sync")
        store.delete_channel(key)
        if key == self._playing_service:
            self._memory_off = key          # keep playing, but do not write it back while this playback lasts
        self._zap_seen(key, done=True)
        log("saved sync removed for %s" % key)
        return True, T("Saved sync removed for this TV channel")

    def _remember_sync(self, video_s=None):
        """Persist the current commentary and offsets for the receiver TV service.

        Both receiver and web actions use this path. A first play creates the
        channel record; later commentary or delay changes update that channel
        only. Explicit removal suppresses writes until the next manual play.
        """
        st, service = self.engine.status(), self._service_key()
        if (not self._memorable(service) or service != self._playing_service or not st.get("stream_id")
                or st["state"] not in ("starting", "playing", "retrying") or service == self._memory_off):
            return
        memo = store.recall_channel(service)
        if video_s is not None:
            picture = float(video_s)
        else:
            req = getattr(self.video, "requested", 0.0)
            cur_pic = req if req > 0 else self._picture_delay()
            picture = cur_pic if cur_pic > 0 else (memo["video_s"] if memo else 0.0)
        store.remember_channel(service, st["stream_id"], picture, self._audio_requested_ms,
                               auto=True, buffer_sync=self._buffer_sync)

    # ---- channel memory
    def _restore_picture(self):
        if self._closed or self._restore_s <= 0:
            return
        st = self.engine.status()
        if (self._restore_target != (st["stream_id"], self._playing_service)
                or st["state"] not in ("starting", "playing", "retrying")
                or self._playing_service != self._service_key()):
            self._restore_s, self._restore_target = 0.0, None
            return
        # Let a recently closed buffer settle before re-opening timeshift.
        if monotonic() - self.video._released_at < 1.5 and monotonic() < self._restore_deadline:
            self._restore_timer.start(300, True)
            return
        s, self._restore_s = self._restore_s, 0.0
        self._restore_target = None
        log("channel memory: restoring previously requested picture delay %.1fs" % s)
        self.video.start(s)
        picture = self.video.info()
        self._sync_buffer_audio(self.engine.status(), picture)
        if picture["state"] != "error":
            self._remember_sync(video_s=s)

    def _picture_delay(self):
        v = self.video.info()
        if v["state"] in ("filling", "running"):
            return (v.get("sync_requested_s") if self._buffer_sync else None) or v["target_s"]
        if v["state"] == "paused":
            return v["current_s"] if v["current_s"] is not None else v["target_s"]
        return 0.0

    def _manual_picture_changed(self, seconds):
        self._buffer_sync = False
        self._remember_sync(video_s=seconds)

    def _zap_seen(self, key, done=False):
        if key != self._zap_key or done:
            self._zap_key, self._zap_since, self._zap_done = key, monotonic(), done

    def _maybe_resume(self, key):
        """Back on a channel that had a commentary when it was left: start it again with its delays, once the channel
        has settled."""
        self._zap_seen(key)
        if (self._pending_play is not None or self._zap_done or not key
                or monotonic() - self._zap_since < 0.9):
            return
        self._zap_done = True
        memo = store.recall_channel(key)
        if not memo or not memo.get("auto", True):
            return
        stream = store.get_stream(memo["sid"])
        if stream is None:
            return                       # the TV sync still applies if another commentary is chosen manually
        log("channel memory: resuming %s on %s (audio %dms; picture %.1fs)" %
            (stream["name"], key, memo["audio_ms"], memo.get("video_s", 0)))
        self._play_main(stream, memo["audio_ms"], memo.get("video_s", 0), auto_restore_video=True)

    # ---- fresh token
    def _refresh_link(self, stream):
        """The link refused us (expired token?): fetch its source playlist again (no pruning) and tell whether this
        channel got a new link. Once per source every 90 s at most; never called on the main thread."""
        from . import importer
        fid = importer.source_folder_of(stream)
        if not fid:
            return False
        now = monotonic()
        if now - self._last_refresh.get(fid, -1e9) < 90:
            return False
        self._last_refresh[fid] = now
        log("link of %s refused: refreshing its source playlist" % stream.get("name"))
        importer.refresh_folder(fid, prune=False)
        fresh = store.get_stream(stream["id"])
        renewed = bool(fresh and fresh.get("url") != stream.get("url"))
        log("source refreshed: %s" % ("new link found" if renewed else "the link did not change"))
        return renewed

    def _stop_main(self, save=True):
        self._cancel_delayed(pending=True)
        self._buffer_sync = False
        self._audio_compensation_ms = 0
        self.video.set_audio_context(False, None)
        self.engine.stop()
        self._playing_service = None
        # Unmuting waits for the engine's idle callback after process teardown.

    def shutdown(self):
        self._cancel_delayed(pending=True)
        self._closed = True
        if self._guard_timer:
            self._guard_timer.stop()
        self.engine.stop(wait=True)
        self.video.release()
        self._set_mute(False)
        stop_main_dispatcher()
        if self._hook_ib is not None:
            callbacks = getattr(self._hook_ib, "onPlayStateChanged", [])
            if self._play_state_changed in callbacks:
                callbacks.remove(self._play_state_changed)
            self._hook_ib = None

    def adjust_video(self, direction):
        main_call(self._adjust_video, direction)

    def _adjust_video(self, direction):
        if (self.engine.status()["state"] not in ("starting", "playing", "retrying")
                or self._playing_service != self._service_key()):
            return
        step = float(store.get_settings()["step_video_s"]) * (1 if direction >= 0 else -1)
        self._set_video_delay(round(max(0.0, self._picture_delay() + step), 1))

    def set_video_delay(self, seconds, sid=None, generation=None):
        """Picture delay to an exact value (the screen and web page gather rapid presses and apply them once)."""
        st = self.engine.status()
        main_call(self._set_video_delay, float(seconds), st["stream_id"] if sid is None else sid,
                  st.get("generation") if generation is None else generation)

    def _set_video_delay(self, seconds, sid=None, generation=None):
        st = self.engine.status()
        if (st["state"] not in ("starting", "playing", "retrying")
                or self._playing_service != self._service_key()
                or (sid is not None and sid != st["stream_id"])
                or (generation is not None and generation != st.get("generation"))):
            return
        if self._restore_timer is not None:
            self._restore_timer.stop()
        self._restore_s, self._restore_target = 0.0, None
        if seconds <= 0:
            # An in-flight startup must not restore the old picture delay after reset.
            self._prep_video_s = 0.0
        self.video.start(seconds)
        picture = self.video.info()
        self._buffer_sync = seconds > 0 and picture["state"] != "error"
        self._sync_buffer_audio(st, picture)
        if picture["state"] != "error":
            self._remember_sync(video_s=self.video.requested)
        self._mute_later()

    def reset_picture(self, sid=None, generation=None):
        """Explicit picture reset closes timeshift while commentary keeps its own timing."""
        st = self.engine.status()
        main_call(self._reset_picture, st["stream_id"] if sid is None else sid,
                  st.get("generation") if generation is None else generation)

    def _reset_picture(self, sid=None, generation=None):
        st = self.engine.status()
        if (st["state"] not in ("starting", "playing", "retrying")
                or self._playing_service != self._service_key()
                or (sid is not None and sid != st["stream_id"])
                or (generation is not None and generation != st.get("generation"))):
            return
        if self._restore_timer is not None:
            self._restore_timer.stop()
        self._restore_s, self._restore_target = 0.0, None
        if self._prep_timer is not None:
            self._prep_timer.stop()
        self._prep_video_s = 0.0
        # Seeking to the buffer edge can still leave decoder latency. Leave
        # timeshift altogether, using the same TV-only close path as manual Stop.
        self.video.force_close()
        self._buffer_sync = False
        self._sync_buffer_audio(st, self.video.info())
        self._remember_sync(video_s=0.0)
        if st.get("preparing"):
            self._finish_preparation()  # start deferred audio without opening another buffer
        else:
            self._prep_target, self._prep_phase = None, None
        self._mute_later()

    def toggle_pause(self):
        main_call(self._toggle_pause)

    def _toggle_pause(self):
        if self.engine.status()["state"] not in ("starting", "playing", "retrying"):
            return
        if self._restore_timer is not None:
            self._restore_timer.stop()
        self._restore_s, self._restore_target = 0.0, None
        self.video.toggle_pause()
        picture = self.video.info()
        if picture["state"] != "paused":
            self._buffer_sync = False
        self._sync_buffer_audio(self.engine.status(), picture)
        if picture["state"] == "running" and self.video.target > 0:
            self._remember_sync(video_s=self.video.target)
        self._mute_later()
        self._log_card_later()

    def _prepare_later(self):
        if self._prep_timer is None:
            self._prep_timer = self._timer(self._prepare_now)
        self._prep_timer.start(1, True)

    def _prepare_now(self):
        st = self.engine.status()
        if (self._closed or self._prep_target != (st["stream_id"], st.get("generation"), self._service_key())
                or not st.get("preparing")):
            return
        now = monotonic()
        if self._prep_phase == "open":
            # Wait for the previous commentary's device to close before touching the TV decoder.
            if self.engine.pipeline_lock.locked():
                if now >= self._prep_until:
                    log("output cleanup is slow; starting without pre-opening timeshift")
                    return self._finish_preparation()
                self._prep_timer.start(100, True)
                return
            try:
                if self._prep_video_s > 0:
                    self.video.start(self._prep_video_s)
                    if self.video.info().get("state") == "error":
                        # Service may still be descrambling right after a zap: schedule a gentle retry while audio plays
                        self._restore_s = self._prep_video_s
                        self._restore_target = (st["stream_id"], self._playing_service)
                        self._restore_deadline = monotonic() + 4.0
                        if self._restore_timer is None:
                            self._restore_timer = self._timer(self._restore_picture)
                        self._restore_timer.start(1000, True)
                elif self.video.prepare() is False:
                    self._prep_timer.start(300, True)
                    return
            except Exception as e:
                log("timeshift preparation failed: %r" % e)
                return self._finish_preparation()
            if self._prep_video_s > 0:
                log("restoring %.1fs picture delay; starting commentary while the buffer fills" % self._prep_video_s)
                return self._finish_preparation()
            self._prep_phase, self._prep_started = "settle", monotonic()
            self._prep_until = self._prep_started + 2.5
            self._prep_sample = self._prep_stable = None
            self._prep_timer.start(250, True)
            return
        state = self.video.preparation_state()
        elapsed = now - self._prep_started
        if state is None:                 # no usable timeshift on this service: play audio without it
            return self._finish_preparation()
        ready = False
        if self.video.info()["state"] != "filling":
            pos = state["position"]
            if self.video.info()["state"] == "paused":
                ready = elapsed >= 1.0    # an explicit Freeze while preparing stays paused
            elif state["paused"] is not True:
                if pos is None:
                    ready = elapsed >= 2.0
                else:
                    if self._prep_sample is not None and pos > self._prep_sample + 0.05:
                        if self._prep_stable is None:
                            self._prep_stable = now
                        ready = elapsed >= 1.0 and now - self._prep_stable >= 0.5
                    else:
                        self._prep_stable = None
                    self._prep_sample = pos
        if ready or now >= self._prep_until:
            log("timeshift preparation finished after %.1fs (%s)" % (elapsed, "stable" if ready else "settle timeout"))
            return self._finish_preparation()
        self._prep_timer.start(250, True)

    def _finish_preparation(self):
        target, self._prep_target = self._prep_target, None
        self._prep_phase = None
        st = self.engine.status()
        if (self._closed or target != (st["stream_id"], st.get("generation"), self._service_key())
                or not st.get("preparing")):
            return
        if self._mute_timer is not None:
            self._mute_timer.stop()
        self._mute_target = None
        self._set_mute(True, force=True)   # timeshift may have restarted TV audio; do this BEFORE opening PCM
        self.engine.start_prepared(target[1])
        self._sync_buffer_audio(self.engine.status(), self.video.info())

    def _log_card_later(self):
        """Write the sound-card state a moment after a freeze / resume, so the log shows what the commentary's card did."""
        if self._card_timer is None:
            self._card_timer = self._timer(lambda: log("card after freeze/resume: %s" % engine_mod.alsa_summary()[:140]))
        self._card_timer.start(2500, True)

    def _buffer_audio_extra(self, picture):
        """Picture delay never alters or injects silence into the commentary audio delay."""
        return 0

    def _apply_audio_timing(self, requested, extra):
        extra = max(0, min(extra, engine_mod.MAX_DELAY_MS - requested))
        applied = requested + extra
        if applied != self.engine.audio_delay_ms:
            self.engine.set_audio_delay(applied)
        if extra != self._audio_compensation_ms:
            log("picture buffer compensation: %dms (manual audio=%dms)" % (extra, requested))
        self._audio_requested_ms, self._audio_compensation_ms = requested, extra

    def _sync_buffer_audio(self, status, picture):
        if picture and picture.get("state") in ("off", "error"):
            self._buffer_sync = False
        if (status["state"] not in ("starting", "playing", "retrying")
                or status.get("preparing") or self._pending_play is not None
                or (not self._buffer_sync and not self._audio_compensation_ms)):
            return
        with self.engine.lock:
            if status.get("generation") != self.engine.gen:
                return
            if self.engine.live_delay:
                extra = self._buffer_audio_extra(picture)
            elif (self._audio_compensation_ms and status.get("audio_delay_supported")
                  and (not self._buffer_sync or (picture["state"] != "paused"
                                                and picture.get("sync_requested_s") is None))):
                extra = 0  # Output fell back after compensation was applied.
            else:
                return
            self._apply_audio_timing(self._audio_requested_ms, extra)

    def adjust_audio(self, direction):
        step = int(store.get_settings()["step_audio_ms"]) * (1 if direction >= 0 else -1)
        st = self.engine.status()
        main_call(self._set_audio_delay, step, st["stream_id"], st.get("generation"), True)

    def set_audio_delay(self, ms, sid=None, generation=None):
        st = self.engine.status()
        main_call(self._set_audio_delay, int(ms), st["stream_id"] if sid is None else sid,
                  st.get("generation") if generation is None else generation)

    def _set_audio_delay(self, ms, sid=None, generation=None, relative=False):
        st = self.engine.status()
        if (self._closed or st["state"] not in ("starting", "playing", "retrying")
                or not st["audio_delay_supported"] or self._playing_service != self._service_key()
                or (sid is not None and sid != st["stream_id"])
                or (generation is not None and generation != st.get("generation"))):
            return
        if relative:
            ms += self._audio_requested_ms
        requested = max(0, min(engine_mod.MAX_DELAY_MS, ms))
        picture = self.video.info()
        extra = self._buffer_audio_extra(picture) if st.get("audio_delay_live") else self._audio_compensation_ms
        try:
            self._apply_audio_timing(requested, extra)
            self.video.suspend_monitor()
            self._remember_sync()
        except ValueError as error:
            log(to_text(error))

    def test_tone(self):
        # Native decoder calls stay on the main loop. A new playback request
        # during the tone takes ownership of the mute and must not be unmuted
        # by this test's eventual cleanup.
        def hold():
            if (self._closed or self.engine.status()["state"] not in ("idle", "error")
                    or store.get_settings()["mute_mode"] not in ("decoder", "track")):
                return False
            self._idle_done = False
            self._set_mute(True)
            return True

        held = self._on_main(hold)
        if held:
            time.sleep(0.2)
        try:
            return self.engine.test_tone()
        finally:
            def release():
                if self.engine.status()["state"] in ("idle", "error"):
                    self._acquired()
                    if held:
                        self._set_mute(False)
            self._on_main(release)

    def control_status(self):
        st = self.engine.status()
        picture = st["video"] = self.video.info()
        st["tv_service"] = self._playing_service
        if st["state"] in ("starting", "playing", "retrying"):
            st["audio_applied_delay_ms"] = st["audio_delay_ms"]
            st["audio_delay_ms"] = self._audio_requested_ms
            requested = picture.get("sync_requested_s")
            if self._buffer_sync and requested is not None and (st.get("audio_delay_live") or self._audio_compensation_ms):
                picture["buffer_target_s"], picture["buffer_current_s"] = picture["target_s"], picture["current_s"]
                picture["target_s"] = requested
                if picture["state"] == "running" and not picture.get("busy") and picture["current_s"] is not None:
                    picture["current_s"] = max(0.0, round(picture["current_s"] - self._audio_compensation_ms / 1000.0, 1))
                else:
                    picture["current_s"] = requested
                if self._audio_compensation_ms:
                    picture["note"] = T("Automatic picture sync")
        return st

    def status(self):
        st = self.control_status()
        st['tv_channel'] = dict(self._tv_info)
        memo = store.recall_channel(self._playing_service) if self._memorable(self._playing_service) else None
        st["sync_saved"] = bool(memo)             # any record = this TV channel is saved (and resumes by itself)
        return st
