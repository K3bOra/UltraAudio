# -*- coding: utf-8 -*-
"""Read-only ALSA discovery, including older Broadcom receiver kernels."""
from __future__ import division
import glob
import os
import re


def playback_devices(asound="/proc/asound", snd="/dev/snd"):
    """Return (card, device) pairs without opening or claiming any audio device."""
    found = set()
    for path in glob.glob(os.path.join(asound, "card*", "pcm*p")):
        match = re.search(r"/card(\d+)/pcm(\d+)p$", path)
        if match:
            found.add(tuple(int(x) for x in match.groups()))
    try:
        with open(os.path.join(asound, "pcm")) as handle:
            for line in handle:
                match = re.match(r"\s*(\d+)-(\d+):", line)
                if match and re.search(r"\bplayback\s+[1-9]\d*", line):
                    found.add(tuple(int(x) for x in match.groups()))
    except EnvironmentError:
        pass
    for path in glob.glob(os.path.join(snd, "pcmC*D*p")):
        match = re.search(r"/pcmC(\d+)D(\d+)p$", path)
        if match:
            found.add(tuple(int(x) for x in match.groups()))
    return sorted(found)
