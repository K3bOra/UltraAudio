# -*- coding: utf-8 -*-
"""On-disk copies of the same validated backup used by the web interface."""
from __future__ import division
import datetime
import json
import os
import tempfile

from . import store
from .compat import makedirs, open_text, replace, to_bytes
from .i18n import T

MAX_BACKUP = 40 * 1024 * 1024
SUBDIR = os.path.join("UltraAudio", "Backups")
_VOLATILE = ("tmpfs", "ramfs", "overlay", "rootfs", "squashfs", "proc", "sysfs", "devtmpfs")


def _mounts():
    mounts = []
    try:
        with open_text("/proc/mounts") as handle:
            for line in handle:
                parts = line.split()
                if len(parts) >= 3:
                    path = parts[1].replace("\\040", " ").replace("\\134", "\\")
                    mounts.append((os.path.realpath(path), parts[2]))
    except EnvironmentError:
        pass
    return mounts


def _on_disk(path, mounts=None):
    """A /media or /mnt volume, never an unmounted directory on flash/RAM."""
    path = os.path.realpath(path)
    try:
        if not os.path.isdir(path) or os.stat(path).st_dev == os.stat("/").st_dev:
            return False
        matches = [(p, fs) for p, fs in (_mounts() if mounts is None else mounts)
                   if path == p or path.startswith(p.rstrip("/") + "/")]
        return bool(matches and max(matches, key=lambda m: len(m[0]))[1] not in _VOLATILE)
    except EnvironmentError:
        return False


def volumes():
    mounts = _mounts()
    candidates = ["/media/hdd", "/media/usb"]
    candidates.extend(p for p, fs in mounts if p.startswith(("/media/", "/mnt/")))
    found, seen = [], set()
    for path in candidates:
        actual = os.path.realpath(path)
        if actual not in seen and _on_disk(path, mounts):
            found.append(path)
            seen.add(actual)
    return found


def save():
    disks = volumes()
    if not disks:
        raise ValueError(T("Connect a hard disk or USB drive first. Nothing was saved to receiver flash."))
    folder = os.path.join(disks[0], SUBDIR)
    makedirs(folder)
    if not _on_disk(folder):
        raise ValueError(T("The backup disk is no longer available."))
    data = store.make_backup()
    # Use to_bytes() so both Python 2 and Python 3 serialize Unicode and UTF-8 bytes cleanly.
    raw = to_bytes(json.dumps(data, ensure_ascii=False, indent=2))
    if len(raw) > MAX_BACKUP:
        raise ValueError(T("Backup is too large (maximum 40 MB)."))
    name = "UltraAudio-backup-%s.json" % datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")
    target = os.path.join(folder, name)
    fd, temp = tempfile.mkstemp(prefix=".backup-", dir=folder)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        replace(temp, target)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return target


def backups():
    files = []
    for disk in volumes():
        folder = os.path.join(disk, SUBDIR)
        try:
            for name in os.listdir(folder):
                path = os.path.join(folder, name)
                if name.startswith("UltraAudio-backup-") and name.endswith(".json") and os.path.isfile(path):
                    files.append((os.path.getmtime(path), path))
        except EnvironmentError:
            continue
    return [path for stamp, path in sorted(files, reverse=True)[:100]]


def read(path):
    if not _on_disk(os.path.dirname(path)):
        raise ValueError(T("The backup disk is no longer available."))
    with open(path, "rb") as handle:
        raw = handle.read(MAX_BACKUP + 1)
    if len(raw) > MAX_BACKUP:
        raise ValueError(T("Backup is too large (maximum 40 MB)."))
    try:
        data = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeError):
        raise ValueError(T("This file is not an Ultra Audio backup"))
    store.validate_backup(data)
    return data
