# -*- coding: utf-8 -*-
"""One-time, offline Turkish radio library seed; preserve subsequent user edits."""
import json
import os

from . import store
from .compat import new_id, open_text

VERSION = 1
CATALOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'presets', 'TurkishRadio.json')


def install():
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        if markers.get('radio_turkish') == VERSION:
            return {'skipped': True, 'added': 0}
        root = next((f for f in lib['folders'] if f.get('preset') == 'radio_root'), None)
        if root is None:
            return {'skipped': True, 'added': 0, 'error': 'Radio root missing'}
        # Read and validate before mutating the library, even in memory.
        with open_text(CATALOG) as handle:
            stations = json.load(handle)['stations']
        if not stations or any(not s.get('name') or not store.valid_url(s.get('url')) for s in stations):
            raise ValueError('Invalid bundled Turkish radio catalog')
        ids = set(x['id'] for x in lib['folders'] + lib['streams'])

        def unique_id():
            while True:
                value = new_id()
                if value not in ids:
                    ids.add(value)
                    return value

        folder = next((f for f in lib['folders'] if f.get('preset') == 'radio_turkish'), None)
        if folder is None:
            folder = {'id': unique_id(), 'parent': root['id'], 'name': 'Turkish',
                      'provider': 'radio', 'source': None, 'updated': 0, 'preset': 'radio_turkish', 'order_auto': True}
            lib['folders'].append(folder)
        # Only match this folder; never move or rewrite the user's imported channels.
        existing = set(s.get('url') for s in lib['streams'] if s.get('folder') == folder['id'])
        added = 0
        for index, station in enumerate(stations):
            if station['url'] in existing:
                continue
            entry = store._normalize({'name': station['name'], 'url': station['url'],
                                      'provider': 'radio', 'kind': 'radio'})
            entry.update(id=unique_id(), folder=folder['id'], preset='radio_turkish',
                         kind='radio', order=index * 10)
            lib['streams'].append(entry)
            existing.add(station['url'])
            added += 1
        markers['radio_turkish'] = VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'added': added, 'folder': folder['id']}
