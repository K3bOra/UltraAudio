# -*- coding: utf-8 -*-
"""Shared text, file, network, UI and process helpers for Python 2.7 and Python 3.x receivers (DreamOS & Open-Alliance)."""
from __future__ import division
import base64
import binascii
from collections import OrderedDict
import errno
import functools
import io
import math
import os
import re
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] >= 3

if PY2:
    string_types = (str, unicode)
    text_type = unicode
    binary_type = str
    integer_types = (int, long)
    import httplib as http_client
    import Queue as queue
    from urllib2 import urlopen, Request, HTTPError, URLError, HTTPRedirectHandler, build_opener
    from urlparse import urlparse, urlsplit, parse_qsl
    from urllib import unquote, urlencode
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from HTMLParser import HTMLParser
else:
    string_types = (str,)
    text_type = str
    binary_type = bytes
    integer_types = (int,)
    import http.client as http_client
    import queue
    from urllib.request import urlopen, Request, HTTPRedirectHandler, build_opener
    from urllib.error import HTTPError, URLError
    from urllib.parse import urlparse, urlsplit, parse_qsl, unquote, urlencode
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from html.parser import HTMLParser

try:
    from http.server import ThreadingHTTPServer
except ImportError:
    class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True

try:
    from time import monotonic
except ImportError:
    _mono_lock = threading.Lock()
    _mono_state = [time.time(), 0.0]

    def monotonic():
        now = time.time()
        with _mono_lock:
            last, off = _mono_state
            if now < last or now - last > 3600.0:
                off += (last - now) + 0.001
            _mono_state[0] = now
            _mono_state[1] = off
            return now + off

try:
    DEVNULL = subprocess.DEVNULL
except AttributeError:
    DEVNULL = open(os.devnull, "r+b")

try:
    TimeoutExpired = subprocess.TimeoutExpired
except AttributeError:
    class TimeoutExpired(Exception):
        def __init__(self, cmd, timeout, output=None, stderr=None):
            Exception.__init__(self, "Command '%s' timed out after %s seconds" % (cmd, timeout))
            self.cmd = cmd
            self.timeout = timeout
            self.output = output
            self.stderr = stderr

replace = getattr(os, "replace", os.rename)


def which(cmd):
    if hasattr(shutil, "which"):
        res = shutil.which(native(cmd) if PY2 else to_text(cmd))
        if res:
            return to_text(res)
    cmd_str = to_text(cmd)
    if os.path.dirname(cmd_str):
        return cmd_str if (os.path.isfile(cmd_str) and os.access(cmd_str, os.X_OK)) else None
    path_dirs = to_text(os.environ.get("PATH", "")).split(os.pathsep)
    for extra in ("/usr/local/sbin", "/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"):
        if extra not in path_dirs:
            path_dirs.append(extra)
    for d in path_dirs:
        if not d:
            continue
        p = os.path.join(d, cmd_str)
        if os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def lru_cache(maxsize=128):
    if hasattr(functools, "lru_cache"):
        return functools.lru_cache(maxsize=maxsize)

    def decorator(fn):
        cache = OrderedDict()
        lock = threading.RLock()

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            key = (args, tuple(sorted(kwargs.items()))) if kwargs else args
            with lock:
                if key in cache:
                    val = cache.pop(key)
                    cache[key] = val
                    return val
            val = fn(*args, **kwargs)
            with lock:
                if key in cache:
                    cache.pop(key)
                elif maxsize is not None and len(cache) >= maxsize:
                    cache.popitem(last=False)
                cache[key] = val
            return val

        def cache_clear():
            with lock:
                cache.clear()

        wrapper.cache_clear = cache_clear
        return wrapper

    return decorator


def fullmatch(pattern, string, flags=0):
    if hasattr(re, "fullmatch"):
        if hasattr(pattern, "fullmatch"):
            return pattern.fullmatch(string)
        return re.fullmatch(pattern, string, flags)
    if hasattr(pattern, "match"):
        m = pattern.match(string)
        return m if (m is not None and m.end() == len(string)) else None
    return re.match(u"(?:" + to_text(pattern) + u")\\Z", string, flags)


def native(value):
    """Text suitable for Enigma2 C++ SWIG widgets (UTF-8 str on Py2, unicode str on Py3); preserve None."""
    if value is None:
        return None
    return to_bytes(value) if PY2 else to_text(value)


def to_text(value):
    if isinstance(value, text_type):
        return value
    if isinstance(value, (bytes, bytearray)):
        return bytes(value).decode("utf-8", "replace")
    try:
        return text_type(value)
    except UnicodeDecodeError:
        return bytes(value).decode("utf-8", "replace")


def to_bytes(value):
    if isinstance(value, binary_type):
        return value
    if isinstance(value, bytearray):
        return binary_type(value)
    return to_text(value).encode("utf-8")


def new_id():
    """Twelve random hex digits without loading a separate UUID library."""
    return binascii.hexlify(os.urandom(6)).decode("ascii")


def zeros(n):
    return b"\x00" * max(0, int(n))


def b64decode(data):
    try:
        return base64.b64decode(data, validate=False)
    except TypeError:
        return base64.b64decode(to_bytes(data))


def isfinite(value):
    try:
        return not (math.isnan(value) or math.isinf(value))
    except TypeError:
        return False


def open_text(path, mode="r"):
    return io.open(path, mode, encoding="utf-8", errors="replace" if "r" in mode else "strict")


def makedirs(path):
    try:
        os.makedirs(path)
    except OSError:
        if not os.path.isdir(path):
            raise


def mtime_sig(path):
    st = os.stat(path)
    return (st.st_ino, getattr(st, "st_mtime_ns", st.st_mtime), st.st_size)


def copytree_merge(src, dst):
    """Copy missing files without overwriting an existing receiver library."""
    makedirs(dst)
    for name in os.listdir(src):
        source, target = os.path.join(src, name), os.path.join(dst, name)
        if os.path.isdir(source):
            copytree_merge(source, target)
        elif not os.path.exists(target):
            shutil.copy2(source, target)


def start_thread(target, args=(), name=None):
    thread = threading.Thread(target=target, args=tuple(args), name=name)
    thread.daemon = True
    thread.start()
    return thread


def acquire(lock, timeout):
    try:
        return lock.acquire(True, timeout)
    except TypeError:
        deadline = monotonic() + float(timeout)
        while True:
            if lock.acquire(False):
                return True
            if monotonic() >= deadline:
                return False
            time.sleep(0.02)


_MAIN_THREAD = threading.current_thread()


def is_main_thread():
    if hasattr(threading, "main_thread"):
        return threading.current_thread() is threading.main_thread()
    cur = threading.current_thread()
    return cur is _MAIN_THREAD or cur.name == "MainThread"


_last_user_input_at = [0.0]


def mark_user_input():
    """Record the latest remote-control press so background workers yield to UI navigation."""
    _last_user_input_at[0] = monotonic()


def user_input_idle(window=0.55):
    """True when no remote key has been pressed within the last `window` seconds."""
    return (monotonic() - _last_user_input_at[0]) >= window


def yield_to_ui(pause_on_input=True, sleep_s=0.002):
    """Release the Python GIL on background threads and pause while remote navigation is active."""
    if is_main_thread():
        return
    if pause_on_input:
        waited = 0.0
        while (monotonic() - _last_user_input_at[0]) < 0.55 and waited < 3.0:
            time.sleep(0.04)
            waited += 0.04
    time.sleep(sleep_s)


def popen(argv, stdin=None, stdout=None, stderr=None, bufsize=-1):
    """Launch a separate process session without inheriting Enigma2's open DVB/socket descriptors."""
    argv_native = [native(a) for a in argv]
    kwargs = {"stdin": stdin, "stdout": stdout, "stderr": stderr, "bufsize": bufsize, "close_fds": True}
    if PY3 and hasattr(subprocess, "Popen"):
        try:
            return subprocess.Popen(argv_native, start_new_session=True, **kwargs)
        except TypeError:
            pass
    kwargs["preexec_fn"] = os.setsid
    return subprocess.Popen(argv_native, **kwargs)


def wait(process, timeout=None):
    if timeout is None:
        return process.wait()
    try:
        return process.wait(timeout=timeout)
    except TypeError:
        deadline = monotonic() + float(timeout)
        while process.poll() is None:
            if monotonic() >= deadline:
                raise TimeoutExpired(getattr(process, "args", "?"), timeout)
            time.sleep(0.04)
        return process.returncode


def communicate(process, input_data=None, timeout=8):
    try:
        return process.communicate(input_data, timeout=timeout)
    except TypeError:
        box = {}

        def talk():
            try:
                box["out"] = process.communicate(input_data)
            except Exception as exc:
                box["err"] = exc

        thread = start_thread(talk)
        thread.join(timeout)
        if thread.is_alive():
            try:
                process.kill()
            except OSError:
                pass
            thread.join(2)
            raise TimeoutExpired(getattr(process, "args", "?"), timeout)
        if "err" in box:
            raise box["err"]
        return box.get("out", (b"", b""))


class _Result(object):
    def __init__(self, returncode, stdout, stderr):
        self.returncode, self.stdout, self.stderr = returncode, stdout, stderr


def run(argv, timeout=8):
    """Capture tool output with a deadline, including inherited output pipes."""
    process = popen(argv, stdin=DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = communicate(process, None, timeout=timeout)
    return _Result(process.returncode, to_text(out or b""), to_text(err or b""))


try:
    _ConnRefused = ConnectionRefusedError
    _TimeoutErr = (TimeoutError, socket.timeout)
except NameError:
    _ConnRefused = socket.error
    _TimeoutErr = (socket.timeout,)


def refused(error):
    if getattr(error, "errno", None) == errno.ECONNREFUSED:
        return True
    reason = getattr(error, "reason", None)
    if getattr(reason, "errno", None) == errno.ECONNREFUSED:
        return True
    if PY3 and isinstance(error, _ConnRefused):
        return True
    return "connection refused" in to_text(error).lower()


def timed_out(error):
    if getattr(error, "errno", None) == errno.ETIMEDOUT:
        return True
    reason = getattr(error, "reason", None)
    if getattr(reason, "errno", None) == errno.ETIMEDOUT:
        return True
    return isinstance(error, _TimeoutErr) or "timed out" in to_text(error).lower()


# ------------------------------------------------------------------ HTTPS with an outdated image certificate store
CA_BUNDLE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "certs", "cacert.pem")
_bundle_ctx = []
_unverified_ctx = []
_bundle_hosts = set()
_unverified_hosts = set()


def bundle_context():
    """SSL context that verifies against the bundled Mozilla CA store (Python 2.7.9+ / 3.4+), else None."""
    if not _bundle_ctx:
        ctx = None
        try:
            import ssl
            if os.path.isfile(CA_BUNDLE) and hasattr(ssl, "create_default_context"):
                ctx = ssl.create_default_context(cafile=CA_BUNDLE)
        except Exception:
            ctx = None
        _bundle_ctx.append(ctx)
    return _bundle_ctx[0]


def unverified_context():
    """Fallback SSL context for OpenSSL 1.0.2 (opendreambox 2.5) where cross-signed chains fail even with a fresh CA bundle."""
    if not _unverified_ctx:
        ctx = None
        try:
            import ssl
            if hasattr(ssl, "_create_unverified_context"):
                ctx = ssl._create_unverified_context()
            elif hasattr(ssl, "create_default_context"):
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
        except Exception:
            ctx = None
        _unverified_ctx.append(ctx)
    return _unverified_ctx[0]


def cert_error(exc):
    """True for a failed certificate verification (the image's CA store or OpenSSL 1.0.2 chain check failed)."""
    text = to_text(getattr(exc, "reason", None) or exc)
    return "CERTIFICATE_VERIFY_FAILED" in text or "certificate verify failed" in text.lower() or "ssl:" in text.lower()


def _host_of(req):
    try:
        url = req.get_full_url() if hasattr(req, "get_full_url") else to_text(req)
        return (urlsplit(url).hostname or "").lower()
    except Exception:
        return ""


def urlopen_verified(req, timeout=20):
    """urlopen that tries: (1) system CA store, (2) bundled Mozilla CA store, (3) unverified context on old OpenSSL 1.0.2."""
    host = _host_of(req)
    if host in _unverified_hosts and unverified_context() is not None:
        return urlopen(req, timeout=timeout, context=unverified_context())
    if host in _bundle_hosts and bundle_context() is not None:
        try:
            return urlopen(req, timeout=timeout, context=bundle_context())
        except HTTPError:
            raise
        except Exception as exc:
            if not cert_error(exc) or unverified_context() is None:
                raise
            _unverified_hosts.add(host)
            return urlopen(req, timeout=timeout, context=unverified_context())
    try:
        return urlopen(req, timeout=timeout)
    except HTTPError:
        raise
    except Exception as exc:
        if not cert_error(exc):
            raise
        if bundle_context() is not None:
            try:
                _bundle_hosts.add(host)
                return urlopen(req, timeout=timeout, context=bundle_context())
            except HTTPError:
                raise
            except Exception as exc2:
                if not cert_error(exc2) or unverified_context() is None:
                    raise
        if unverified_context() is not None:
            _unverified_hosts.add(host)
            return urlopen(req, timeout=timeout, context=unverified_context())
        raise


def https_handlers(url):
    """Extra opener handlers (bundled CA store or unverified fallback on OpenSSL 1.0.2) for a host."""
    host = (urlsplit(url).hostname or "").lower()
    if host in _unverified_hosts and unverified_context() is not None:
        ctx = unverified_context()
    elif host in _bundle_hosts and bundle_context() is not None:
        ctx = bundle_context()
    else:
        return []
    try:
        from urllib.request import HTTPSHandler
    except ImportError:
        from urllib2 import HTTPSHandler
    return [HTTPSHandler(context=ctx)]


def remember_cert_failure(url, unverified=False):
    host = (urlsplit(url).hostname or "").lower()
    if unverified:
        _unverified_hosts.add(host)
    else:
        _bundle_hosts.add(host)


# ------------------------------------------------------------------ DreamOS / Enigma2 UI helpers
_skin_scale_supported = None


def skin_scale_attr():
    """Return ' scale="1"' only on images whose skin parser supports the 'scale' attribute (omit on DreamOS)."""
    global _skin_scale_supported
    if _skin_scale_supported is None:
        supported = False
        try:
            import skin
            for attr_name in ("attributeParser", "SingleAttrib", "Attrib", "WidgetAttrib"):
                obj = getattr(skin, attr_name, None)
                if isinstance(obj, dict) and "scale" in obj:
                    supported = True
                    break
            if not supported:
                for cls_name in ("AttributeParser", "SkinParser"):
                    cls_obj = getattr(skin, cls_name, None)
                    if cls_obj is not None and hasattr(cls_obj, "scale"):
                        supported = True
                        break
            if not supported:
                src_file = getattr(skin, "__file__", "") or ""
                if src_file.endswith((".pyc", ".pyo")) and os.path.isfile(src_file[:-1]):
                    src_file = src_file[:-1]
                if os.path.isfile(src_file):
                    with open(src_file, "rb") as f:
                        raw = f.read(131072)
                    if b"def scale(" in raw or b'"scale"' in raw or b"'scale'" in raw or b"\x05scale" in raw:
                        supported = True
            if not supported:
                from enigma import eTimer
                t = eTimer()
                if hasattr(t, "callback") and not hasattr(t, "timeout"):
                    supported = True
        except Exception:
            supported = False
        _skin_scale_supported = bool(supported)
    return ' scale="1"' if _skin_scale_supported else ""


_skin_attr_cache = {}


def skin_attr(name, value):
    """' name="value"' only when this image's skin parser knows the attribute; DreamOS aborts on unknown ones."""
    if name not in _skin_attr_cache:
        supported = False
        try:
            import skin
            for attr_name in ("attributeParser", "SingleAttrib", "Attrib", "WidgetAttrib"):
                obj = getattr(skin, attr_name, None)
                if isinstance(obj, dict) and name in obj:
                    supported = True
                    break
            if not supported:
                parser = getattr(skin, "AttributeParser", None)
                if parser is not None and callable(getattr(parser, name, None)):
                    supported = True
            if not supported:
                src_file = getattr(skin, "__file__", "") or ""
                if src_file.endswith((".pyc", ".pyo")) and os.path.isfile(src_file[:-1]):
                    src_file = src_file[:-1]
                if src_file.endswith(".py") and os.path.isfile(src_file):
                    with open(src_file, "rb") as f:
                        raw = f.read()
                    token = to_bytes(name)
                    if (b"def " + token + b"(") in raw or (b'"' + token + b'"') in raw or (b"'" + token + b"'") in raw:
                        supported = True
        except Exception:
            supported = False
        _skin_attr_cache[name] = bool(supported)
    return ' %s="%s"' % (name, value) if _skin_attr_cache[name] else ""


def connect_timer(timer, callback, connections=None):
    """Connect an eTimer callback on both DreamOS (timeout.connect) and Open-Alliance (callback.append)."""
    if hasattr(timer, "timeout") and hasattr(timer.timeout, "connect"):
        try:
            conn = timer.timeout.connect(callback)
            if isinstance(connections, list):
                connections.append(conn)
            return conn
        except Exception:
            pass
    if hasattr(timer, "callback"):
        timer.callback.append(callback)
    return None


def _ref_text(ref, notes, label):
    """Text of a service reference without relying on the truthiness of SWIG objects (DreamOS)."""
    if ref is None:
        notes.append("%s: None" % label)
        return None
    if isinstance(ref, string_types) or isinstance(ref, (bytes, bytearray)):
        return to_text(ref).strip() or None
    valid = getattr(ref, "valid", None)
    if callable(valid):
        try:
            if not valid():
                notes.append("%s: invalid reference" % label)
                return None
        except Exception as exc:
            notes.append("%s: valid() %r" % (label, exc))
    to_string = getattr(ref, "toString", None)
    if not callable(to_string):
        notes.append("%s: no toString()" % label)
        return None
    try:
        text = to_text(to_string()).strip()
    except Exception as exc:
        notes.append("%s: toString() %r" % (label, exc))
        return None
    if not text:
        notes.append("%s: empty reference" % label)
    return text or None


UNIDENTIFIED = "tv:unidentified"


_HEX_PART = re.compile(r"^[0-9A-Fa-f]+$")


def _normal_ref(text):
    """Canonical service reference: the 10 id fields and the path, without the display name that some APIs append
    ("1:0:19:283D:3FB:1:C00000:0:0:0::Das Erste" -> "1:0:19:283D:3FB:1:C00000:0:0:0:"), so the same channel read from
    navigation, the channel list or the last-service setting gives the same key. IPTV paths are kept (they are what
    tells two stream channels apart). Other strings are returned unchanged."""
    text = to_text(text or "").strip()
    parts = text.split(":")
    if len(parts) >= 10 and parts[0].isdigit() and all(_HEX_PART.match(p) for p in parts[1:10]):
        path = parts[10] if len(parts) > 10 else ""
        return ":".join(parts[:10]) + ":" + path
    return text


def _playable_ref(key):
    """A tunable service, not a bouquet / directory (flags & 7) or a marker (flags & 64) the channel list cursor may be on."""
    parts = to_text(key or "").split(":")
    if len(parts) < 10:
        return False
    try:
        flags = int(parts[1])
    except ValueError:
        return False
    return not (flags & 7) and not (flags & 64)


def _fallback_key(nav, notes):
    """Last-resort sources used only when the navigation object reports no playing service at all (seen on
    opendreambox 2.5): the global navigation instance, the last zapped TV service (config.tv.lastservice, saved on
    every zap) and finally the channel list's current entry."""
    try:
        from NavigationInstance import instance as global_nav
    except Exception as exc:
        global_nav = None
        notes.append("NavigationInstance: %r" % (exc,))
    if global_nav is not None and global_nav is not nav:
        for name in ("getCurrentlyPlayingServiceReference", "getCurrentlyPlayingServiceOrGroup"):
            fn = getattr(global_nav, name, None)
            if not callable(fn):
                continue
            try:
                key = _ref_text(fn(), notes, "NavigationInstance." + name)
            except Exception as exc:
                notes.append("NavigationInstance.%s: %r" % (name, exc))
                continue
            if key:
                return _normal_ref(key), "NavigationInstance." + name
    try:
        from Screens.InfoBar import InfoBar
        ib = InfoBar.instance
    except Exception as exc:
        ib = None
        notes.append("InfoBar: %r" % (exc,))
    if ib is None:
        notes.append("InfoBar.instance: None")
    else:
        # The InfoBar's own session may hold another navigation object than the one given to the plugin.
        ib_nav = getattr(getattr(ib, "session", None), "nav", None)
        if ib_nav is not None and ib_nav is not nav and ib_nav is not global_nav:
            fn = getattr(ib_nav, "getCurrentlyPlayingServiceReference", None)
            try:
                key = _ref_text(fn() if callable(fn) else None, notes, "InfoBar.session.nav")
                if key:
                    return _normal_ref(key), "InfoBar.session.nav"
            except Exception as exc:
                notes.append("InfoBar.session.nav: %r" % (exc,))
        elif ib_nav is None:
            notes.append("InfoBar.session.nav: missing")
    try:
        from Components.config import config
        mode = ""
        try:
            mode = to_text(config.servicelist.lastmode.value or "")
        except Exception:
            pass
        sections = ("radio", "tv") if mode == "radio" else ("tv",)
        for section in sections:
            try:
                key = to_text(getattr(config, section).lastservice.value or "").strip()
            except Exception as exc:
                notes.append("config.%s.lastservice: %r" % (section, exc))
                continue
            if _playable_ref(key):
                return _normal_ref(key), "config.%s.lastservice" % section
            notes.append("config.%s.lastservice: %s" % (section, ("not a service: %r" % key[:60]) if key else "empty"))
        if mode:
            notes.append("servicelist mode: %s" % mode)
    except Exception as exc:
        notes.append("config: %r" % (exc,))
    try:
        servicelist = getattr(ib, "servicelist", None)
        if servicelist is None:
            notes.append("channel list: %s" % ("no InfoBar yet" if ib is None else "not on %s" % type(ib).__name__))
        else:
            for label, getter in (("channel list current", lambda: servicelist.servicelist.getCurrent()),
                                  ("channel list selection", lambda: servicelist.getCurrentSelection()),
                                  ("servicelist.getCurrent", lambda: servicelist.getCurrent()),
                                  ("servicelist.l.getCurrentSelection", lambda: servicelist.servicelist.l.getCurrentSelection())):
                try:
                    ref = getter()
                    if ref is not None and hasattr(ref, "ref"):   # ServiceReference wrapper
                        ref = ref.ref
                    key = _ref_text(ref, notes, label)
                except Exception as exc:
                    notes.append("%s: %r" % (label, exc))
                    continue
                if key and _playable_ref(key):
                    return _normal_ref(key), label
    except Exception as exc:
        notes.append("channel list: %r" % (exc,))
    try:
        if os.path.isfile("/etc/enigma2/settings"):
            sig = mtime_sig("/etc/enigma2/settings")
            if getattr(_fallback_key, "_sig", None) != sig:
                found_val = None
                with open("/etc/enigma2/settings", "rb") as f:
                    for raw_line in f:
                        line = to_text(raw_line).strip()
                        if line.startswith("config.tv.lastservice="):
                            val = line.split("=", 1)[1].strip()
                            if _playable_ref(val):
                                found_val = _normal_ref(val)
                                break
                _fallback_key._sig = sig
                _fallback_key._val = found_val
            if getattr(_fallback_key, "_val", None):
                return _fallback_key._val, "/etc/enigma2/settings(tv)"
    except Exception as exc:
        notes.append("settings file: %r" % (exc,))
    return None, None


def service_key(nav, fallback=False, placeholder=False):
    """Identity of the tuned TV service as (key, source, notes).

    Tries every API that Enigma2 and DreamOS (OE2.5/2.6) expose, so playback does not depend on one of them being
    present. `notes` explains each failed probe and is only used for the log.

    With fallback=True the channel list / last-service setting are consulted when the navigation object knows no
    service. With placeholder=True the shared key UNIDENTIFIED is returned as a final resort instead of None, so
    commentary can still start (per-channel memory ignores that key). The default stays strict."""
    key, source, notes = _service_key_nav(nav)
    if key or not (fallback or placeholder):
        return key, source, notes
    key, source = _fallback_key(nav, notes)
    if key:
        return key, source, notes
    if placeholder:
        return UNIDENTIFIED, "unidentified", notes
    return None, None, notes


def _service_key_nav(nav):
    notes = []
    if nav is None:
        return None, None, ["no navigation object"]
    for name, call in (("getCurrentlyPlayingServiceReference", True), ("currentlyPlayingServiceReference", False),
                       ("getCurrentlyPlayingServiceOrGroup", True), ("currentlyPlayingServiceOrGroup", False)):
        if not hasattr(nav, name):
            notes.append("%s: missing" % name)
            continue
        try:
            attr = getattr(nav, name)
            ref = attr() if (call and callable(attr)) else attr
        except Exception as exc:
            notes.append("%s: %r" % (name, exc))
            continue
        key = _ref_text(ref, notes, name)
        if key:
            return _normal_ref(key), name, notes
    try:
        service = nav.getCurrentService()
    except Exception as exc:
        notes.append("getCurrentService: %r" % (exc,))
        return None, None, notes
    if service is None:
        notes.append("getCurrentService: None")
        return None, None, notes
    try:
        info = service.info()
        from enigma import iServiceInformation
        key = _ref_text(info.getInfoString(iServiceInformation.sServiceref), notes, "sServiceref")
        if key and key.count(":") >= 9:
            return _normal_ref(key), "sServiceref", notes
        ids = []
        for field in ("sONID", "sTSID", "sSID"):
            value = info.getInfo(getattr(iServiceInformation, field))
            ids.append(value if isinstance(value, integer_types) and value > 0 else 0)
        name = to_text(info.getName() or "").strip()
        if any(ids) or name:
            return "svc:%x:%x:%x:%s" % (ids[0], ids[1], ids[2], name), "service-info", notes
        notes.append("service info: no ids or name")
    except Exception as exc:
        notes.append("service info: %r" % (exc,))
    return None, None, notes


def _png_size(path):
    try:
        with open(path, "rb") as f:
            hdr = f.read(24)
        if len(hdr) >= 24 and hdr[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", hdr[16:24])
    except EnvironmentError:
        pass
    return None


@lru_cache(maxsize=512)
def ui_pixmap_path(path, width=None, height=None):
    """Resolve the best matching pre-sized PNG for (width, height), avoiding unscaled crop/overflow on DreamOS."""
    if not path or not os.path.isfile(path) or not width or not height:
        return path
    w, h = max(1, int(width)), max(1, int(height))
    sz = _png_size(path)
    if sz == (w, h):
        return path
    folder, fname = os.path.split(path)
    stem, ext = os.path.splitext(fname)
    base_stem = re.sub(r"(?:@(?:hd|wqhd|2x|4x)|_\d+x\d+|_\d+)$", "", stem)
    full_stem = re.sub(r"@(?:hd|wqhd|2x|4x)$", "", stem)      # keeps a size in the name: panel_480x812@hd.png
    candidates = [
        os.path.join(folder, "%s_%dx%d%s" % (full_stem, w, h, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (base_stem, w, h, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (full_stem, w, h + 1, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (base_stem, w, h + 1, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (full_stem, w, max(1, h - 1), ext)),
        os.path.join(folder, "%s_%dx%d%s" % (base_stem, w, max(1, h - 1), ext)),
        os.path.join(folder, "%s_%dx%d%s" % (full_stem, w + 1, h, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (base_stem, w + 1, h, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (full_stem, max(1, w - 1), h, ext)),
        os.path.join(folder, "%s_%dx%d%s" % (base_stem, max(1, w - 1), h, ext)),
        os.path.join(folder, "%s_%d%s" % (base_stem, w, ext)),
        os.path.join(folder, "%s_%d%s" % (base_stem, w + 1, ext)),
        os.path.join(folder, "%s_%d%s" % (base_stem, max(1, w - 1), ext)),
        os.path.join(folder, "%s@wqhd%s" % (full_stem, ext)),
        os.path.join(folder, "%s@wqhd%s" % (base_stem, ext)),
        os.path.join(folder, "%s@hd%s" % (full_stem, ext)),
        os.path.join(folder, "%s@hd%s" % (base_stem, ext)),
        os.path.join(folder, "%s%s" % (base_stem, ext)),
        os.path.join(folder, "%s@2x%s" % (full_stem, ext)),
        os.path.join(folder, "%s@2x%s" % (base_stem, ext)),
        os.path.join(folder, "%s@4x%s" % (base_stem, ext)),
    ]
    best_path = path
    best_dist = (abs(sz[0] - w) + abs(sz[1] - h)) if sz else 10 ** 9
    for cand in candidates:
        if os.path.isfile(cand):
            csz = _png_size(cand)
            if csz == (w, h):
                return cand
            if csz:
                dist = abs(csz[0] - w) + abs(csz[1] - h)
                if dist < best_dist:
                    best_path, best_dist = cand, dist
    return best_path


def mc_pixmap(pos, size, png, flags=0):
    """MultiContentEntryPixmapAlphaBlend wrapper compatible with all DreamOS and Open-Alliance versions."""
    try:
        from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
        try:
            return MultiContentEntryPixmapAlphaBlend(pos=pos, size=size, png=png, flags=flags)
        except TypeError:
            return MultiContentEntryPixmapAlphaBlend(pos=pos, size=size, png=png)
    except ImportError:
        from enigma import eListboxPythonMultiContent
        kind = getattr(eListboxPythonMultiContent, "TYPE_PIXMAP_ALPHABLEND",
                       getattr(eListboxPythonMultiContent, "TYPE_PIXMAP_ALPHATEST", 2))
        return (kind, pos[0], pos[1], size[0], size[1], png, None, None)
