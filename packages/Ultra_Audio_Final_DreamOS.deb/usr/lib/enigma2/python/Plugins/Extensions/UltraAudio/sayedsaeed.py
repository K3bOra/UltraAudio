# -*- coding: utf-8 -*-
"""Sayed Saeed recordings, verified as MP3 on 27 October 2026.

Yusuf 56:18 is the user-selected recording from HolyQuran4u.
Other links: Way2Quran's published Alsaid Saeed / Hafs catalogue.
After the three pinned recordings, SURAH groups follow the listening counters
on Nourelquran's reader 168 pages (snapshot 27 October 2026). These counters
rank the source's surah pages, not these particular MP3 encodings. Recordings
without a matching public counter follow in Quran order; no counts are invented.
"""
from __future__ import division, unicode_literals   # Arabic titles are text on Python 2 too
RECORDINGS = (
    ('سورة يوسف — 56:18', 'https://www.holyquran4u.com/apiv3/sound/getStream/2653843/'),
    ('ما تيسر من سورة المائدة — 58:26', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/005-001.mp3'),
    ('ما تيسر من سورة مريم — 50:20', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/019-001.mp3'),
    ('ما تيسر من سورة البقرة — تلاوة 1 — 27:14', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/002-001.mp3'),
    ('ما تيسر من سورة البقرة — تلاوة 2 — 57:18', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/002-002.mp3'),
    ('سورة القمر — 23:57', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/054.mp3'),
    ('ما تيسر من سورة طه — 28:56', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/020-001.mp3'),
    ('ما تيسر من سورة ق — تلاوة 1 — 27:31', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/050-001.mp3'),
    ('سورة ق — تلاوة 2 — 27:31', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/050.mp3'),
    ('ما تيسر من سورة آل عمران — تلاوة 1 — 37:52', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/003-001.mp3'),
    ('ما تيسر من سورة آل عمران — تلاوة 2 — 53:43', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/003-002.mp3'),
    ('ما تيسر من سورة إبراهيم — 55:26', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/014-001.mp3'),
    ('ما تيسر من سورة الأنعام — 29:17', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/006-002.mp3'),
    ('سورة القيامة — 17:22', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/075.mp3'),
    ('ما تيسر من سورة يس — 28:31', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/036-001.mp3'),
    ('ما تيسر من سورة الرحمن — 11:08', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/055-001.mp3'),
    ('ما تيسر من سورة النبأ — 9:19', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/078-001.mp3'),
    ('ما تيسر من سورة الأحزاب — 58:21', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/033-001.mp3'),
    ('سورة الطارق — 7:30', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/086.mp3'),
    ('ما تيسر من سورة المؤمنون — 12:54', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/023-001.mp3'),
    ('سورة التحريم — 28:12', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/066.mp3'),
    ('سورة المزمل — 12:21', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/073.mp3'),
    ('سورة الحجرات — 27:09', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/049.mp3'),
    ('ما تيسر من سورة القصص — 50:49', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/028-001.mp3'),
    ('ما تيسر من سورة الفرقان — 48:01', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/025-001.mp3'),
    ('ما تيسر من سورة الرعد — 18:33', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/013-001.mp3'),
    ('سورة الأعلى — 5:24', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/087.mp3'),
    ('ما تيسر من سورة النساء — 37:23', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/004-001.mp3'),
    ('سورة الفاتحة — 1:31', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/001.mp3'),
    ('ما تيسر من سورة النحل — 59:36', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/016-001.mp3'),
    ('ما تيسر من سورة الإسراء — 57:26', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/017-001.mp3'),
    ('ما تيسر من سورة الكهف — 3:24', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/018-001.mp3'),
    ('ما تيسر من سورة الأنبياء — 29:09', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/021-001.mp3'),
    ('ما تيسر من سورة الروم — تلاوة 1 — 27:31', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/030-001.mp3'),
    ('ما تيسر من سورة الروم — تلاوة 2 — 27:48', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/030-002.mp3'),
    ('سورة لقمان — 35:43', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/031.mp3'),
    ('سورة السجدة — 22:22', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/032.mp3'),
    ('سورة فاطر — 54:30', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/035.mp3'),
    ('سورة الحشر — 21:14', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/059.mp3'),
    ('سورة الحاقة — 27:52', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/069.mp3'),
    ('سورة النازعات — 17:22', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/079.mp3'),
    ('سورة الانفطار — 9:26', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/082.mp3'),
    ('سورة البروج — 9:03', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/085.mp3'),
    ('سورة الغاشية — 5:48', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/088.mp3'),
    ('سورة الفجر — 7:06', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/089.mp3'),
    ('سورة البلد — 3:55', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/090.mp3'),
    ('سورة الشمس — 3:35', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/091.mp3'),
    ('سورة الضحى — 1:37', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/093.mp3'),
    ('سورة العلق — 5:29', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/096.mp3'),
    ('سورة القدر — 2:06', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/097.mp3'),
    ('سورة الزلزلة — 4:40', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/099.mp3'),
    ('سورة قريش — 4:57', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/106.mp3'),
    ('سورة الكوثر — 1:53', 'https://media.way2quran.com/alsaid-saeed/hafs-an-asim/108.mp3'),
)
