#!/bin/sh
# Ultra Audio Final V1: detect this image (DreamOS DEB / Enigma2 OPKG, Python 2 & Python 3),
# install only missing feed components, then verify imports and decode actual AAC/MP3 samples to PCM.
set -u
export LC_ALL=C
export DEBIAN_FRONTEND=noninteractive
ROOT=$(cd "$(dirname "$0")" && pwd) || exit 2
LOG=${ULTRAAUDIO_DEPS_LOG:-/tmp/ultraaudio-deps.log}
MODE=${1:---install}
case "$MODE" in --check|--list|--install|--wait) ;; *) echo 'Usage: deps.sh [--check|--list|--install|--wait]'; exit 64 ;; esac
: >> "$LOG" 2>/dev/null || LOG=/dev/null
say() { printf '%s\n' "$*"; printf '%s\n' "$*" >> "$LOG" 2>/dev/null || :; }
fail() { say "RESULT: missing: $*"; exit 2; }

find_python() {
    if command -v pidof >/dev/null 2>&1; then
        for pid in $(pidof enigma2 2>/dev/null); do
            if [ -r "/proc/$pid/maps" ]; then
                if grep -q 'libpython2\.' "/proc/$pid/maps" 2>/dev/null; then
                    for p in python2 python2.7 python; do
                        command -v "$p" >/dev/null 2>&1 && { command -v "$p"; return 0; }
                    done
                elif grep -q 'libpython3\.' "/proc/$pid/maps" 2>/dev/null; then
                    for p in python3 python; do
                        command -v "$p" >/dev/null 2>&1 && { command -v "$p"; return 0; }
                    done
                fi
            fi
        done
    fi
    for p in python3 python2 python2.7 python; do
        command -v "$p" >/dev/null 2>&1 && { command -v "$p"; return 0; }
    done
    return 1
}

PYTHON=$(find_python) || fail 'Python interpreter (Python 2 or Python 3) is unavailable'
PYVER=$("$PYTHON" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null) || fail 'Python could not be queried'
PYMAJ=$("$PYTHON" -c 'import sys; print(sys.version_info[0])' 2>/dev/null) || PYMAJ=3

PKG_MGR=''
if command -v apt-get >/dev/null 2>&1 && command -v dpkg >/dev/null 2>&1; then
    PKG_MGR=apt
elif command -v opkg >/dev/null 2>&1; then
    PKG_MGR=opkg
else
    fail 'Neither APT/DPKG nor OPKG is available on this receiver'
fi

[ -r "$ROOT/components.map" ] && [ -r "$ROOT/components.py" ] || fail 'component map/probe is missing'
say "[CHECK] Ultra Audio Final V1 | Python $PYVER | PkgMgr $PKG_MGR | CPU $(uname -m 2>/dev/null || echo unknown)"

WORK=''
OWN_LOCK=0
LOCK=${ULTRAAUDIO_DEPS_LOCK:-/tmp/ultraaudio-components.lock}
cleanup() {
    [ -z "$WORK" ] || rm -rf "$WORK"
    if [ "$OWN_LOCK" = 1 ]; then rm -f "$LOCK/pid"; rmdir "$LOCK" 2>/dev/null || :; fi
}
trap cleanup 0
trap 'exit 2' 1 2 15

pkg_busy() {
    pidof dpkg apt-get apt aptitude opkg opkg-cl >/dev/null 2>&1
}

if [ "$MODE" = --install ] || [ "$MODE" = --wait ]; then
    if ! mkdir "$LOCK" 2>/dev/null; then
        owner=$(cat "$LOCK/pid" 2>/dev/null || :)
        case "$owner" in ''|*[!0-9]*) owner=0 ;; esac
        if [ "$owner" -gt 1 ] && kill -0 "$owner" 2>/dev/null; then fail 'another UltraAudio component setup is running'; fi
        rm -f "$LOCK/pid"; rmdir "$LOCK" 2>/dev/null || fail 'component setup lock cannot be recovered'
        mkdir "$LOCK" 2>/dev/null || fail 'component setup lock is busy'
    fi
    OWN_LOCK=1
    echo "$$" > "$LOCK/pid"
    attempt=0
    while pkg_busy; do
        attempt=$((attempt+1))
        [ "$attempt" -lt 90 ] || fail 'Package manager still busy after three minutes; retry setup after it exits'
        sleep 2
    done
    MODE=--install
fi

WORK=$(mktemp -d /tmp/ultraaudio-components.XXXXXX) || fail 'cannot allocate component workspace'
AVAILABLE="$WORK/feed"
FEED_READY=0
CHANGED=''
ATTEMPTED=' '

installed() {
    if [ "$PKG_MGR" = apt ]; then
        dpkg -s "$1" 2>/dev/null | grep -q '^Status:.* installed'
    else
        opkg status "$1" 2>/dev/null | grep -q '^Status:.* installed'
    fi
}

feed_has() {
    if [ "$PKG_MGR" = apt ]; then
        apt-cache show "$1" >/dev/null 2>&1
    else
        awk -v wanted="$1" '$1 == wanted && $2 == "-" {found=1; exit} END {exit !found}' "$AVAILABLE"
    fi
}

ensure_feed() {
    [ "$FEED_READY" = 0 ] || return 0
    FREE_KB=$(df -k /usr 2>/dev/null | awk 'NR==2 {print $4}')
    case "$FREE_KB" in ''|*[!0-9]*) ;; *) [ "$FREE_KB" -ge 8192 ] || fail 'less than 8 MiB free for missing components' ;; esac
    fresh=$("$PYTHON" - <<'PYFEED'
import os, time
paths = ['/var/lib/apt/lists', '/var/lib/opkg/lists', '/var/cache/opkg/lists']
try:
    stamps = [os.stat(os.path.join(p, f)).st_mtime for p in set(paths) if os.path.isdir(p)
              for f in os.listdir(p) if os.path.isfile(os.path.join(p, f)) and not f.startswith('.') and f != 'lock']
    print('yes' if stamps and 0 <= time.time() - min(stamps) < 900 else 'no')
except Exception:
    print('no')
PYFEED
)
    if [ "${ULTRAAUDIO_FEED_UPDATED:-0}" != 1 ] && [ "$fresh" != yes ]; then
        say '[FEED] Refreshing the current image package lists once...'
        if [ "$PKG_MGR" = apt ]; then
            apt-get update >> "$LOG" 2>&1 || say '[WARN] Feed refresh failed; checking existing lists.'
        else
            opkg update >> "$LOG" 2>&1 || say '[WARN] Feed refresh failed; checking existing lists.'
        fi
    else
        say '[FEED] Reusing package lists already refreshed by the package manager.'
    fi
    if [ "$PKG_MGR" = opkg ]; then
        opkg list > "$AVAILABLE" 2>> "$LOG" || :
    fi
    FEED_READY=1
}

install_one() {
    pkg=$1
    case "$pkg" in ''|*[!A-Za-z0-9+._-]*) return 1 ;; esac
    case "$ATTEMPTED" in *" $pkg "*) return 1 ;; esac
    feed_has "$pkg" || return 1
    ATTEMPTED="$ATTEMPTED$pkg "
    if installed "$pkg"; then
        say "[REPAIR] Reinstalling the required image component: $pkg"
        if [ "$PKG_MGR" = apt ]; then
            if apt-get install -y --reinstall "$pkg" >> "$LOG" 2>&1; then CHANGED="$CHANGED $pkg(repaired)"; return 0; fi
        else
            if opkg install --force-reinstall "$pkg" >> "$LOG" 2>&1; then CHANGED="$CHANGED $pkg(repaired)"; return 0; fi
        fi
    else
        say "[INSTALL] Required image component: $pkg"
        if [ "$PKG_MGR" = apt ]; then
            if apt-get install -y "$pkg" >> "$LOG" 2>&1; then CHANGED="$CHANGED $pkg"; return 0; fi
        else
            if opkg install "$pkg" >> "$LOG" 2>&1; then CHANGED="$CHANGED $pkg"; return 0; fi
        fi
    fi
    say "[WARN] Installation failed for $pkg; details in $LOG"
    return 1
}

install_candidates() {
    say "[MISSING] $1"
    for dep_candidate in $(printf '%s' "$2" | tr ',' ' '); do
        install_one "$dep_candidate" && return 0
    done
    return 1
}

module_ok() { "$PYTHON" -c 'import sys; __import__(sys.argv[1])' "$1" >/dev/null 2>&1; }

PROBE=$("$PYTHON" "$ROOT/components.py" --imports 2>&1) || :
say "$PROBE"
printf '%s\n' "$PROBE" | grep -q '^imports:' || fail 'Python import probe could not run'
if printf '%s\n' "$PROBE" | grep -q '^missing:'; then
    if [ "$MODE" = --install ]; then
        ensure_feed
        while IFS='|' read -r module candidates; do
            case "$module" in ''|\#*) continue ;; esac
            if ! "$PYTHON" -c '
import sys
name = sys.argv[1]
aliases = {"socketserver":"SocketServer","http.client":"httplib","http.server":"BaseHTTPServer","urllib.request":"urllib2","urllib.error":"urllib2","urllib.parse":"urlparse","queue":"Queue","html.parser":"HTMLParser"}
__import__(aliases.get(name, name) if sys.version_info[0] == 2 else name)
' "$module" >/dev/null 2>&1; then
                candidates=$("$PYTHON" "$ROOT/components.py" --candidates "$module") || fail "no package mapping for $module"
                install_candidates "Python $module" "$candidates" || :
            fi
        done < "$ROOT/components.map"
        PROBE=$("$PYTHON" "$ROOT/components.py" --imports 2>&1) || :
        say "$PROBE"
    fi
    printf '%s\n' "$PROBE" | grep -q '^imports:ok$' || fail 'required Python imports unavailable; see missing: lines above'
fi

ENVIRONMENT=$("$PYTHON" "$ROOT/components.py" --environment 2>&1) || { say "$ENVIRONMENT"; fail 'interpreter/image environment mismatch'; }
say "$ENVIRONMENT"
say '[CHECK] Testing decoder, transport support, PCM conversion and available output tools...'
AUDIO=$("$PYTHON" "$ROOT/components.py" --audio 2>&1) || :
say "$AUDIO"
if ! printf '%s\n' "$AUDIO" | grep -Eq '^pipeline:(ffmpeg|gstreamer)$'; then
    if [ "$MODE" = --install ]; then
        ensure_feed
        if ! command -v ffmpeg >/dev/null 2>&1; then install_one ffmpeg || :; fi
        AUDIO=$("$PYTHON" "$ROOT/components.py" --audio 2>&1) || :
        if ! printf '%s\n' "$AUDIO" | grep -Eq '^pipeline:(ffmpeg|gstreamer)$' &&
           printf '%s\n' "$AUDIO" | grep -q '^need:alsa-library|'; then
            install_candidates 'ALSA PCM writer' 'libasound2,alsa-lib' || :
        fi
        round=0
        while [ "$round" -lt 3 ]; do
            round=$((round+1))
            AUDIO=$("$PYTHON" "$ROOT/components.py" --audio 2>&1) || :
            printf '%s\n' "$AUDIO" | grep -Eq '^pipeline:(ffmpeg|gstreamer)$' && break
            NEEDS=$(printf '%s\n' "$AUDIO" | sed -n 's/^need://p')
            [ -n "$NEEDS" ] || break
            while IFS='|' read -r capability packages; do
                [ -z "$capability" ] || install_candidates "$capability" "$packages" || :
            done <<EOF_NEEDS
$NEEDS
EOF_NEEDS
        done
        AUDIO=$("$PYTHON" "$ROOT/components.py" --audio 2>&1) || :
        say "$AUDIO"
    fi
    printf '%s\n' "$AUDIO" | grep -Eq '^pipeline:(ffmpeg|gstreamer)$' || fail 'no verified decoder/PCM output pipeline; review audio: and need: lines above'
fi

if [ "$MODE" = --install ] && printf '%s\n' "$AUDIO" | grep -q '^recommend:'; then
    ensure_feed || :
    RECS=$(printf '%s\n' "$AUDIO" | sed -n 's/^recommend://p')
    while IFS='|' read -r capability packages; do
        [ -z "$capability" ] || install_candidates "$capability" "$packages" || :
    done <<EOF_RECS
$RECS
EOF_RECS
fi

PROBE=$("$PYTHON" "$ROOT/components.py" --imports 2>&1) || :
printf '%s\n' "$PROBE" | grep -q '^imports:ok$' || { say "$PROBE"; fail 'Python recheck failed'; }
RUNTIME=$("$PYTHON" "$ROOT/components.py" --runtime 2>&1) || { say "$RUNTIME"; fail 'plugin runtime imports failed'; }
say "$RUNTIME"
say "installed:${CHANGED:- nothing}"
if [ "$MODE" = --install ]; then printf 'ready\n' > /tmp/ultraaudio-setup.status; fi
say 'RESULT: ok (imports and sample-to-PCM verified; receiver speaker output still requires playback testing)'
exit 0
