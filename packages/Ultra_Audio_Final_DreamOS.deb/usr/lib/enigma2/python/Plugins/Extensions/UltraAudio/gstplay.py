# -*- coding: utf-8 -*-
"""External GStreamer player for explicit audio-track selection and DVB hardware sink control (never runs inside Enigma2)."""
from __future__ import print_function, division

import argparse
import fcntl
import os
import re
import signal
import sys
import threading
import time

AUDIO_CONTINUE = 0x6F04
AUDIO_SET_MUTE = 0x6F06
AUDIO_SET_AV_SYNC = 0x6F07
_DVB_NODE = re.compile(r"^/dev/dvb/adapter\d+/audio\d+$")
_monotonic = getattr(time, "monotonic", time.time)


def load():
    import gi
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst
    Gst.init(None)
    return Gst


def _disable_dvb_av_sync():
    """Turn off hardware PCR/STC A/V sync and mute on any open /dev/dvb/adapterN/audioM in this process."""
    try:
        names = os.listdir("/proc/self/fd")
    except EnvironmentError:
        return False
    applied = False
    for name in names:
        try:
            target = os.readlink("/proc/self/fd/" + name)
        except EnvironmentError:
            continue
        if _DVB_NODE.match(target):
            fd = int(name)
            for req, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0), (AUDIO_CONTINUE, 0)):
                try:
                    fcntl.ioctl(fd, req, arg)
                except EnvironmentError:
                    pass
            applied = True
    return applied


def _configure_dvb_sink(Gst, sink_element):
    """Disable clock sync on dvbaudiosink, strip buffer PTS/DTS, and clear hardware AV_SYNC after set_caps()."""
    if sink_element is None:
        return
    for prop in ("sync", "async"):
        try:
            if sink_element.find_property(prop):
                sink_element.set_property(prop, False)
        except Exception:
            pass
    pad = sink_element.get_static_pad("sink")
    if pad is None:
        return
    seen = [0]

    def _delayed_unsync():
        for delay in (0.05, 0.2, 0.6, 1.5):
            time.sleep(delay)
            _disable_dvb_av_sync()

    def _on_buf(pad_obj, info):
        count = seen[0] + 1
        seen[0] = count
        try:
            buf = info.get_buffer()
            if buf is not None:
                buf.pts = Gst.CLOCK_TIME_NONE
                buf.dts = Gst.CLOCK_TIME_NONE
        except Exception:
            pass
        if count in (1, 2, 5, 15, 40):
            _disable_dvb_av_sync()
            if count == 1:
                t = threading.Thread(target=_delayed_unsync)
                t.daemon = True
                t.start()
        return Gst.PadProbeReturn.OK

    pad.add_probe(Gst.PadProbeType.BUFFER, _on_buf)


def _dvb_sink_pipeline_desc(Gst, kind, rate, channels):
    """Build a GStreamer pipeline description reading from fd=0 and outputting to dvbaudiosink."""
    def has(name):
        return Gst.ElementFactory.find(name) is not None

    if kind in ("mpegaudioparse", "mp2", "mp3"):
        chain = ["fdsrc fd=0 do-timestamp=true", "mpegaudioparse", "dvbaudiosink name=ua_sink"]
    elif kind in ("aacparse", "aac"):
        chain = ["fdsrc fd=0 do-timestamp=true", "aacparse", "dvbaudiosink name=ua_sink"]
    elif kind in ("ac3parse", "ac3"):
        chain = ["fdsrc fd=0 do-timestamp=true", "ac3parse", "dvbaudiosink name=ua_sink"]
    elif kind == "mpegts-mp2":
        chain = ["fdsrc fd=0 do-timestamp=true", "tsdemux", "mpegaudioparse", "dvbaudiosink name=ua_sink"]
    elif kind == "mpegts-aac":
        chain = ["fdsrc fd=0 do-timestamp=true", "tsdemux", "aacparse", "dvbaudiosink name=ua_sink"]
    else:
        base, _, raw_sub = kind.partition(":")
        if raw_sub == "raw" or (base == "raw") or (not raw_sub and has("rawaudioparse") and base != "wav" and base != "caps"):
            src = ("fdsrc fd=0 do-timestamp=true ! rawaudioparse use-sink-caps=false format=pcm pcm-format=s16le "
                   "sample-rate=%d num-channels=%d ! audioconvert ! audioresample" % (rate, channels))
        elif raw_sub == "wav" or base in ("wav", "decodebin") and has("wavparse"):
            src = "fdsrc fd=0 do-timestamp=true ! wavparse ignore-length=true ! audioconvert ! audioresample"
        else:
            src = ("fdsrc fd=0 blocksize=4096 do-timestamp=true ! "
                   "audio/x-raw,format=S16LE,rate=%d,channels=%d,layout=interleaved ! audioconvert ! audioresample" % (rate, channels))
        enc_map = {
            "gst-mp2": "avenc_mp2 bitrate=192000 ! mpegaudioparse",
            "gst-twolame": "twolamemp2enc bitrate=192 ! mpegaudioparse",
            "gst-mp3": "lamemp3enc target=bitrate bitrate=192 cbr=true ! mpegaudioparse",
            "gst-aac": "avenc_aac bitrate=128000 ! aacparse",
            "gst-faac": "faac bitrate=128000 ! aacparse",
            "gst-voaac": "voaacenc bitrate=128000 ! aacparse",
            "gst-fdkaac": "fdkaacenc bitrate=128000 ! aacparse",
            "gst-ac3": "avenc_ac3 bitrate=192000 ! ac3parse",
        }
        if base in enc_map:
            chain = [src, enc_map[base], "dvbaudiosink name=ua_sink"]
        else:
            chain = [src, "dvbaudiosink name=ua_sink"]
    return " ! ".join(chain)


def run_dvb_sink(Gst, opts):
    if not Gst.ElementFactory.find("dvbaudiosink"):
        print('gstplay: no element "dvbaudiosink"', file=sys.stderr)
        return 2
    desc = _dvb_sink_pipeline_desc(Gst, opts.dvb_sink, opts.rate, opts.channels)
    pipeline = None
    stopping = [False]

    def _on_sig(signum, frame_obj):
        stopping[0] = True
        if pipeline is not None:
            try:
                pipeline.set_state(Gst.State.NULL)
            except Exception:
                pass
        sys.exit(0)

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _on_sig)
        except Exception:
            pass

    try:
        pipeline = Gst.parse_launch(desc)
        sink_el = pipeline.get_by_name("ua_sink")
        _configure_dvb_sink(Gst, sink_el)
        bus = pipeline.get_bus()
        if pipeline.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
            raise RuntimeError("could not start GStreamer dvbaudiosink pipeline")
        _disable_dvb_av_sync()
        while not stopping[0]:
            msg = bus.timed_pop_filtered(200 * Gst.MSECOND, Gst.MessageType.ERROR | Gst.MessageType.EOS)
            if msg is not None:
                if msg.type == Gst.MessageType.ERROR:
                    error, debug = msg.parse_error()
                    raise RuntimeError("%s (%s)" % (error.message, debug or ""))
                return 0
        return 0
    except Exception as exc:
        if not stopping[0]:
            print("gstplay: %s" % exc, file=sys.stderr)
            return 1
        return 0
    finally:
        if pipeline is not None:
            try:
                pipeline.set_state(Gst.State.NULL)
            except Exception:
                pass


def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--dvb-sink")
    parser.add_argument("--rate", type=int, default=48000)
    parser.add_argument("--channels", type=int, default=2)
    parser.add_argument("--url")
    parser.add_argument("--user-agent", default="UltraAudio")
    parser.add_argument("--track", type=int, default=0)
    parser.add_argument("--volume", type=float, default=1.0)
    parser.add_argument("--device")
    parser.add_argument("--buffer-ms", type=int, default=500)
    opts = parser.parse_args(argv)
    try:
        Gst = load()
    except Exception as exc:
        print("gstplay: Python GStreamer bindings unavailable: %s" % exc, file=sys.stderr)
        return 2
    if opts.check:
        return 0 if Gst.ElementFactory.find("playbin") else 2
    if opts.dvb_sink:
        return run_dvb_sink(Gst, opts)
    if not opts.url or not 0 <= opts.track <= 15:
        return 2
    player = Gst.ElementFactory.make("playbin", "ua_player")
    if player is None:
        print('gstplay: no element "playbin"', file=sys.stderr)
        return 2
    selected = [False]
    failure = []
    try:
        is_dvb = opts.device in ("dvb", "dvb-raw", "dvb-pes") or (opts.device or "").startswith("dvb:")
        if is_dvb and opts.device == "dvb" and abs(opts.volume - 1.0) <= 0.001:
            parts = ["dvbaudiosink name=ua_sink"]
        else:
            parts = ["audioconvert", "audioresample"]
            if not is_dvb:
                parts.append("audio/x-raw,format=S16LE,rate=48000,channels=2,layout=interleaved")
            if abs(opts.volume - 1.0) > 0.001 and Gst.ElementFactory.find("volume"):
                parts.append("volume volume=%.4f" % max(0.0, min(2.0, opts.volume)))
            if is_dvb and opts.device == "dvb":
                for enc_el, enc_desc in (
                    ("avenc_mp2", "avenc_mp2 bitrate=192000 ! mpegaudioparse"),
                    ("twolamemp2enc", "twolamemp2enc bitrate=192 ! mpegaudioparse"),
                    ("lamemp3enc", "lamemp3enc target=bitrate bitrate=192 cbr=true ! mpegaudioparse"),
                    ("avenc_aac", "avenc_aac bitrate=128000 ! aacparse"),
                ):
                    if Gst.ElementFactory.find(enc_el):
                        parts.append(enc_desc)
                        break
            if is_dvb:
                parts.append("dvbaudiosink name=ua_sink")
            else:
                parts.append("alsasink name=ua_sink" if opts.device else "fdsink name=ua_sink fd=1 sync=false")
        sink = Gst.parse_bin_from_description(" ! ".join(parts), True)
        output = sink.get_by_name("ua_sink")
        if is_dvb:
            _configure_dvb_sink(Gst, output)
        elif opts.device:
            if output.find_property("device"):
                output.set_property("device", opts.device)
            if output.find_property("buffer-time"):
                output.set_property("buffer-time", max(100, min(5000, opts.buffer_ms)) * 1000)
        player.set_property("flags", 2)
        player.set_property("audio-sink", sink)

        def source_setup(playbin, source):
            if source.find_property("user-agent"):
                source.set_property("user-agent", opts.user_agent)
            if source.find_property("timeout"):
                source.set_property("timeout", 15)

        def choose(playbin, *unused):
            try:
                selected[0] = False
                if playbin.get_property("n-audio") > opts.track:
                    playbin.set_property("current-audio", opts.track)
                    selected[0] = playbin.get_property("current-audio") == opts.track
            except Exception as exc:
                failure.append(str(exc))

        def gate(pad, info):
            return Gst.PadProbeReturn.OK if selected[0] else Gst.PadProbeReturn.DROP

        sink.get_static_pad("sink").add_probe(Gst.PadProbeType.BUFFER, gate)
        player.connect("source-setup", source_setup)
        player.connect("audio-changed", choose)
        player.set_property("uri", opts.url)
        bus = player.get_bus()
        if player.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
            raise RuntimeError("could not start GStreamer")
        deadline = _monotonic() + 20
        while True:
            msg = bus.timed_pop_filtered(200 * Gst.MSECOND, Gst.MessageType.ERROR | Gst.MessageType.EOS)
            if msg is not None:
                if msg.type == Gst.MessageType.ERROR:
                    error, debug = msg.parse_error()
                    raise RuntimeError("%s (%s)" % (error.message, debug or ""))
                if not selected[0]:
                    raise RuntimeError("selected audio track %d matches no streams" % opts.track)
                return 0
            if failure:
                raise RuntimeError(failure[0])
            if not selected[0] and _monotonic() >= deadline:
                raise RuntimeError("selected audio track %d matches no streams or discovery timed out" % opts.track)
    except Exception as exc:
        print("gstplay: %s" % exc, file=sys.stderr)
        return 1
    finally:
        player.set_state(Gst.State.NULL)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
