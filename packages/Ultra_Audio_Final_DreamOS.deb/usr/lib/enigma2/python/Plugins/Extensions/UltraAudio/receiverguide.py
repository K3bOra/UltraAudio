# -*- coding: utf-8 -*-
"""Read cached receiver EPG in small main-loop batches; never tune a service."""
from __future__ import division
from collections import deque
import time

from .compat import is_main_thread, monotonic, native, to_text

ROOT = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'


class ReceiverGuide(object):
    def __init__(self):
        self.next_scan = 0.0
        self.bouquets = deque()
        self.services = deque()
        self.seen = set()
        self.events = {}
        self.scanned = 0
        self.current = {}
        self.published = {}
        self.current_at = -99.0
        self.error_at = -99.0

    def _note_error(self, where, error):
        now = monotonic()
        if now - self.error_at < 60:
            return
        self.error_at = now
        try:
            from .engine import log
            log("receiver EPG %s: %s: %s" % (where, type(error).__name__, to_text(error)[:160]))
        except Exception:
            pass

    def _read_current(self):
        # DreamOS may not expose a usable bouquet/cache listing. The event on
        # the tuned service is independently available; this never tunes/zaps.
        now = monotonic()
        if now - self.current_at < 2.0:
            return
        self.current_at, self.current = now, {}
        try:
            from Screens.InfoBar import InfoBar
            from . import guide
            ib = InfoBar.instance
            if ib is None:
                return
            service = ib.session.nav.getCurrentService()
            info = service.info() if service is not None else None
            if info is None:
                return
            key = guide.channel_key(to_text(info.getName()))
            if not key:
                return
            rows = []
            wall = guide.now()
            for which in (0, 1):
                try:
                    event = info.getEvent(which)
                    if event is None:
                        continue
                    begin, duration = int(event.getBeginTime()), int(event.getDuration())
                    title = to_text(event.getEventName())
                    if title and 0 < duration <= 86400 and begin + duration > wall:
                        rows.append((title, '', begin, begin + duration, None))
                except Exception as error:
                    self._note_error("current event", error)
            if rows:
                self.current[key] = tuple(rows)
        except Exception as error:
            self._note_error("current service", error)

    def _publish(self):
        from . import guide
        merged = dict(self.published)
        merged.update(self.events)
        merged.update(self.current)
        guide._GUIDE.receiver_snapshot(merged)

    def tick(self):
        # Enigma2 service and EPG APIs are used exclusively on its main loop.
        if not is_main_thread():
            return
        self._read_current()
        self._publish()
        try:
            from enigma import eServiceCenter, eServiceReference, eEPGCache
            from . import guide
            now = monotonic()
            if not self.bouquets and not self.services:
                if now < self.next_scan:
                    return
                self.next_scan = now + 120
                center = eServiceCenter.getInstance()
                listing = center.list(eServiceReference(native(ROOT)))
                self.bouquets = deque((listing.getContent('S', True) or [])[:128]) if listing is not None else deque()
                self.seen, self.events, self.scanned = set(), {}, 0
                if not self.bouquets:
                    return
            if not self.services and self.bouquets:
                listing = eServiceCenter.getInstance().list(eServiceReference(native(self.bouquets.popleft())))
                if listing is not None:
                    self.services.extend((listing.getContent('SN', True) or [])[:5000])
            cache = eEPGCache.getInstance()
            wall = guide.now()
            for unused in range(24):
                if not self.services or self.scanned >= 12000:
                    break
                item = self.services.popleft()
                self.scanned += 1
                if not isinstance(item, (tuple, list)) or len(item) != 2:
                    continue
                reference, name = item
                if reference in self.seen:
                    continue
                self.seen.add(reference)
                key = guide.channel_key(to_text(name))
                if not key:
                    continue
                # Keep at most one unambiguous current guide per channel key.
                if any(e[2] <= wall < e[3] for e in self.events.get(key, ())):
                    continue
                try:
                    rows = cache.lookupEvent(['BDT', (native(reference), 0, -1, 180)]) or []
                except Exception as error:
                    self._note_error("cache query", error)
                    continue
                events = []
                for row in rows[:64]:
                    try:
                        begin, duration, title = row
                        begin, duration = int(begin), int(duration)
                        if title and 0 < duration <= 86400 and begin + duration > wall:
                            events.append((to_text(title), '', begin, begin + duration, None))
                    except (ValueError, TypeError, OverflowError):
                        continue
                if events:
                    self.events[key] = tuple(events)
            if self.scanned >= 12000:
                self.bouquets.clear()
                self.services.clear()
            # Publish copies: HTTP workers never call the native EPG APIs.
            if not self.bouquets and not self.services:
                self.published = dict(self.events)
            self._publish()
        except Exception as error:
            # Missing APIs/data cannot prevent audio or the rest of the UI.
            self._note_error("bouquet scan", error)
            self.bouquets.clear()
            self.services.clear()
            self.next_scan = monotonic() + 120


_reader = ReceiverGuide()
tick = _reader.tick
