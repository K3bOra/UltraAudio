# -*- coding: utf-8 -*-
"""Dependency rescue UI: only Enigma2 built-ins and Python core imports."""
from __future__ import division
import os
import re
from Screens.Screen import Screen
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.ActionMap import ActionMap
from enigma import eConsoleAppContainer
from .compat import native, to_text
from .uifont import face as ui_face

ROOT = os.path.dirname(os.path.abspath(__file__))


def _scaled_skin(template):
    try:
        from enigma import getDesktop
        w = getDesktop(0).size().width()
        k = (w / 1920.0) if w > 1920 else 1.0
    except Exception:
        k = 1.0
    if abs(k - 1.0) <= 0.01:
        return template
    n = lambda v: max(1, int(round(int(v) * k)))
    out = re.sub(r'(position|size)="(\d+),(\d+)"', lambda m: '%s="%d,%d"' % (m.group(1), n(m.group(2)), n(m.group(3))), template)
    out = re.sub(r'font="([^";]+);(\d+)"', lambda m: 'font="%s;%d"' % (m.group(1), n(m.group(2))), out)
    return out


class ComponentRepairScreen(Screen):
    skin = '''<screen name="UltraAudioComponentRepair" position="center,center" size="900,570" title="Ultra Audio Final V1 - Component repair">
        <widget name="info" position="25,20" size="850,90" font="Regular;23"/>
        <widget name="log" position="25,120" size="850,370" font="Regular;19"/>
        <widget name="green" position="25,510" size="550,45" font="Regular;23" foregroundColor="#75F5AA"/>
        <widget name="red" position="650,510" size="225,45" font="Regular;23" foregroundColor="#FF7070"/>
    </screen>'''

    def __init__(self, session, pending=False, error=''):
        self.skin = native(_scaled_skin(self.skin).replace('font="Regular;', 'font="%s;' % ui_face()))
        Screen.__init__(self, session)
        self.running = False
        self.passed = False
        self.output = u''
        self.container = None
        self.connections = []
        self['info'] = Label(native(u'إصلاح مكونات Ultra Audio / Component repair\n'
                                    u'فحص وتثبيت الناقص من مستودع الصورة الحالية / Check this image and install missing components'))
        initial = (u'التثبيت الأول قد يكون مستمرًا؛ انتظر اكتماله. / Initial setup may still be running.\n' if pending else u'')
        self['log'] = ScrollLabel(native(initial + to_text(error) + u'\n\n'
                                         u'اضغط الأخضر للفحص والإصلاح. / Press GREEN to check and repair.\n'
                                         u'Log: /tmp/ultraaudio-deps.log'))
        self['green'] = Label(native(u'أخضر: فحص وإصلاح / GREEN: Check and repair'))
        self['red'] = Label(native(u'رجوع / Back'))
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions'], {
            'ok': self.repair, 'green': self.repair, 'cancel': self.leave, 'red': self.leave,
            'up': self['log'].pageUp, 'down': self['log'].pageDown}, -1)
        self.onClose.append(self._disconnect)

    def _connect(self, signal, callback):
        if hasattr(signal, 'connect'):
            try:
                self.connections.append(signal.connect(callback))
                return
            except Exception:
                pass
        if hasattr(signal, 'append'):
            signal.append(callback)

    def repair(self):
        if self.running:
            return
        if self.passed:
            from Screens.Standby import TryQuitMainloop
            self.session.open(TryQuitMainloop, 3)
            return
        self.running = True
        self.output = u''
        self['green'].setText(native(u'جارٍ الفحص والإصلاح... / Checking and repairing...'))
        self['red'].setText(native(u'انتظر / Please wait'))
        self['log'].setText(native(u'Ultra Audio Final V1\n'))
        self.container = eConsoleAppContainer()
        self._connect(self.container.dataAvail, self._data)
        self._connect(self.container.appClosed, self._done)
        # Fixed bundled script; no user input is interpolated into this command.
        command = native('/bin/sh "' + os.path.join(ROOT, 'deps.sh') + '" --install')
        try:
            if self.container.execute(command):
                self._data(u'Could not start component repair.\n')
                self._done(127)
        except Exception as error:
            self._data(to_text(error) + u'\n')
            self._done(127)

    def _data(self, data):
        text = to_text(data)
        self.output = (self.output + text)[-24000:]
        self['log'].setText(native(self.output))
        try:
            self['log'].lastPage()
        except Exception:
            pass

    def _done(self, code):
        if not self.running:
            return
        self.running = False
        lines = self.output.splitlines()
        self.passed = code == 0 and any(line.startswith(u'RESULT: ok') for line in lines)
        self['red'].setText(native(u'رجوع / Back'))
        if self.passed:
            self._data(u'\nنجح فحص المكونات. أعد تشغيل الواجهة ثم جرّب الصوت.\n'
                       u'Component checks passed. Restart GUI, then test receiver sound.\n')
            self['green'].setText(native(u'أخضر: إعادة تشغيل الواجهة / GREEN: Restart GUI'))
        else:
            self._data(u'\nلم يكتمل الإصلاح؛ راجع السجل والإنترنت ومستودع الصورة ثم أعد المحاولة.\n'
                       u'Repair incomplete. Check the log, internet and image feed, then retry.\n')
            self['green'].setText(native(u'أخضر: إعادة المحاولة / GREEN: Retry'))

    def leave(self):
        if not self.running:
            self.close()

    def _disconnect(self):
        self.connections = []
        self.container = None
