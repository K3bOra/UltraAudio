# -*- coding: utf-8 -*-
from __future__ import division
__version__ = "V1"
PACKAGE_VERSION = "1.0.13-dreamos"
VERSION_SCHEME = "parallel-v1"
RELEASE_NAME = "Ultra Audio Final V1"
