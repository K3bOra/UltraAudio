# -*- coding: utf-8 -*-
"""UltraAudio child-process records. Check process start times before cleanup.

Older pid-only records are deliberately not signalled; a recycled PID could belong
to an unrelated process. This module uses only the Python standard library.
"""
from __future__ import division
import os
import signal
import stat
import sys
import tempfile

PIDFILE = os.environ.get("ULTRAAUDIO_PIDS", "/tmp/ultraaudio.pids")
_HERE = os.path.dirname(os.path.abspath(__file__))
PCM_WRITER = os.path.realpath(os.path.join(_HERE, "pcmplay.py")).decode("utf-8", "replace") if isinstance(_HERE, bytes) else os.path.realpath(os.path.join(_HERE, "pcmplay.py"))
GST_WRITER = os.path.realpath(os.path.join(_HERE, "gstplay.py")).decode("utf-8", "replace") if isinstance(_HERE, bytes) else os.path.realpath(os.path.join(_HERE, "gstplay.py"))
ALLOWED = (u"ffmpeg", u"aplay", u"gst-launch", u"gst-launch-1.0")


def _start_ticks(pid):
    """Linux /proc/PID/stat field 22; the comm field can contain spaces."""
    try:
        with open("/proc/%d/stat" % pid, "rb") as f:
            line = f.read()
        end = line.rfind(b") ")
        if end < 0:
            return None
        fields = line[end + 2:].split()   # state = field 3
        return fields[19].decode("ascii") if len(fields) > 19 else None
    except (EnvironmentError, ValueError):
        return None


def _our_command(pid):
    try:
        with open("/proc/%d/cmdline" % pid, "rb") as f:
            argv = [a for a in f.read().split(b"\0") if a]
        if not argv:
            return False
        first = os.path.basename(argv[0].decode("utf-8", "replace"))
        if first in ALLOWED:
            return True
        if first.startswith(u"python"):
            for arg in argv[1:6]:
                arg_text = arg.decode("utf-8", "replace")
                try:
                    real = os.path.realpath(arg_text)
                except Exception:
                    real = arg_text
                if real in (PCM_WRITER, GST_WRITER):
                    return True
    except (EnvironmentError, ValueError):
        pass
    return False


def _trusted_file(filename):
    try:
        st = os.lstat(filename)
        return stat.S_ISREG(st.st_mode) and st.st_uid == os.geteuid() and not (st.st_mode & 0o022)
    except EnvironmentError:
        return False


def remember(procs, filename=PIDFILE):
    """Atomically write pid and process start time. Never follow a /tmp symlink."""
    entries = []
    for p in procs:
        try:
            pid = int(p.pid)
            ticks = _start_ticks(pid)
            if pid > 1 and ticks and _our_command(pid):
                entries.append("%d %s\n" % (pid, ticks))
        except (TypeError, ValueError, AttributeError):
            continue
    path = None
    try:
        fd, path = tempfile.mkstemp(prefix=".ultraaudio-pids-", dir=os.path.dirname(filename) or ".")
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as f:
            f.writelines(entries)
        os.rename(path, filename)
        path = None
    except EnvironmentError:
        pass
    finally:
        if path:
            try:
                os.unlink(path)
            except EnvironmentError:
                pass


def cleanup(filename=PIDFILE):
    """Kill only verifiably recorded children and their process groups; skip pid-only legacy records."""
    if not _trusted_file(filename):
        return 0
    try:
        with open(filename, "r") as f:
            lines = f.readlines()[:100]
    except EnvironmentError:
        return 0
    n = 0
    for line in lines:
        parts = line.split()
        if len(parts) != 2 or not all(x.isdigit() for x in parts):
            continue
        pid = int(parts[0])
        if pid <= 1 or pid == os.getpid() or pid == os.getppid():
            continue
        if _start_ticks(pid) != parts[1] or not _our_command(pid):
            continue
        try:
            # Check both values again immediately before signalling.
            if _start_ticks(pid) == parts[1] and _our_command(pid):
                try:
                    os.killpg(pid, signal.SIGTERM)
                except EnvironmentError:
                    pass
                os.kill(pid, signal.SIGTERM)
                n += 1
        except (EnvironmentError, ValueError):
            pass
    try:
        # Do not delete a different file that replaced our record meanwhile.
        if _trusted_file(filename):
            os.unlink(filename)
    except EnvironmentError:
        pass
    return n


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--cleanup":
        cleanup(sys.argv[2])
