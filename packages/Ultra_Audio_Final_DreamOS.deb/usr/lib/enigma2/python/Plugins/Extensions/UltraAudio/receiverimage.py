# -*- coding: utf-8 -*-
"""Small, cached receiver image label for the on-box header."""
from .compat import lru_cache, to_text


def _clean(value):
    return ' '.join(to_text(value or '').replace('\x00', '').split())[:80]


def _read_fields(path):
    fields = {}
    try:
        with open(path, 'rb') as handle:
            for line in handle.read(16384).decode('utf-8', 'replace').splitlines():
                line = line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                fields[key.strip().lower()] = value.strip().strip('\"\'')
    except EnvironmentError:
        pass
    return fields


def _label(name, version):
    name, version = _clean(name), _clean(version)
    known = {'openatv': 'OpenATV', 'openbh': 'OpenBH', 'openpli': 'OpenPLi',
             'openvix': 'OpenViX', 'opendreambox': 'DreamOS', 'dreamos': 'DreamOS',
             'openvision': 'OpenVision', 'openhdf': 'OpenHDF'}
    name = known.get(name.lower(), name)
    if not name:
        return ''
    if version and version.lower() not in name.lower():
        return name + ' ' + version
    return name


@lru_cache(maxsize=1)
def receiver_image_label():
    """Prefer image-provided branding; read metadata files without running commands."""
    name = version = ''
    try:
        from Components.SystemInfo import BoxInfo
        name = BoxInfo.getItem('displaydistro') or BoxInfo.getItem('distro') or ''
        version = BoxInfo.getItem('imageversion') or BoxInfo.getItem('imgversion') or ''
    except Exception:
        pass
    if not name or not version:
        try:
            import boxbranding
            name = name or boxbranding.getImageDistro()
            version = version or boxbranding.getImageVersion()
        except Exception:
            pass
    if name and version:
        return _label(name, version)
    image = _read_fields('/etc/image-version')
    system = _read_fields('/etc/os-release')
    name = name or image.get('distro') or image.get('imagename') or system.get('name') or system.get('id') or ''
    version = version or image.get('imageversion') or image.get('imgversion') or system.get('version_id') or ''
    # Older image-version files use a timestamp in "version"; only accept a
    # dotted release number here, never show a build timestamp as the image version.
    if not version:
        candidate = image.get('version', '')
        if '.' in candidate and all(c.isdigit() or c == '.' for c in candidate):
            version = candidate
    return _label(name, version)
