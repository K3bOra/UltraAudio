# -*- coding: utf-8 -*-
"""Read-only selected-row football popover (beIN Sports Match Center style). GUI code never does network IO."""
import os
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import ePoint
from . import store, themes
from .compat import native
from .livefootball import SCORES
from .engine import log
from .scorerticker import ScorerTicker

CARD_X = 656
CARD_W = 470
CARD_H = 155

UI_DIR = os.path.join(store.ASSETS, 'ui')

PIXMAP_NAMES = (
    'football_panel',
    'football_home',
    'football_away',
    'football_left_yc_bg',
    'football_left_rc_bg',
    'football_right_yc_bg',
    'football_right_rc_bg',
    'football_left_ball',
    'football_right_ball',
)

LABEL_NAMES = (
    'football_clock',
    'football_ht',
    'football_score',
    'football_stage',
    'football_comp',
    'football_left_name',
    'football_right_name',
    'football_left_yc',
    'football_left_rc',
    'football_right_yc',
    'football_right_rc',
    'football_left_scorers',
    'football_right_scorers',
)

NAMES = PIXMAP_NAMES + LABEL_NAMES

# Tight, asymmetric-FHD broadcast card.  All primary content is visible
# without large dead zones, while an occasional goal/card still has room.
REL_POS = {
    'football_panel': (0, 0),
    'football_home': (36, 13),
    'football_away': (372, 13),
    'football_clock': (164, 7),
    'football_ht': (166, 29),
    'football_score': (166, 48),
    'football_stage': (150, 98),
    'football_comp': (150, 120),
    'football_left_name': (10, 78),
    'football_right_name': (346, 78),
    # Badges sit in the space between crests and score, not in a new row.
    'football_left_yc_bg': (125, 68),
    'football_left_yc': (125, 68),
    'football_left_rc_bg': (144, 68),
    'football_left_rc': (144, 68),
    'football_right_yc_bg': (326, 68),
    'football_right_yc': (326, 68),
    'football_right_rc_bg': (307, 68),
    'football_right_rc': (307, 68),
    # Match-event notes live under each team name if available.
    'football_left_ball': (11, 117),
    'football_right_ball': (442, 117),
    'football_left_scorers': (10, 109),
    'football_right_scorers': (342, 109),
}

LOGO_SIZE = 65
CARD_BADGE_SIZE = (18, 22)
BALL_SIZE = 16


def _asset_pixmap(filename, w, h, k):
    n = lambda v: max(1, int(round(v * k)))
    path = os.path.join(UI_DIR, filename)
    try:
        from .compat import ui_pixmap_path
        return ui_pixmap_path(path, n(w), n(h)), ''
    except ImportError:
        return path, ' scale="1"'


def skin_parts(k, th):
    n = lambda v: max(1, int(round(v * k)))

    def box(x, y, w, h):
        return 'position="%d,%d" size="%d,%d"' % (n(x), n(y), n(w), n(h))

    parts = []
    # Correct theme-specific rounded-glass background, no old diagonal texture
    panel_path = themes.pic(th, 'football_panel.png')
    try:
        from .compat import ui_pixmap_path
        panel_path = ui_pixmap_path(panel_path, n(CARD_W), n(CARD_H))
        scale = ''
    except ImportError:
        scale = ' scale="1"'
    parts.append('<widget name="football_panel" %s pixmap="%s" alphatest="blend"%s zPosition="8"/>'
                 % (box(CARD_X, 74, CARD_W, CARD_H), panel_path, scale))

    # Left & Right team logos (65x65)
    for name in ('football_home', 'football_away'):
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s alphatest="blend"%s transparent="1" zPosition="9"/>'
                     % (name, box(CARD_X + dx, 74 + dy, LOGO_SIZE, LOGO_SIZE), scale))

    # Yellow & Red card badge pixmaps
    yc_path, yc_scale = _asset_pixmap('card_yellow.png', CARD_BADGE_SIZE[0], CARD_BADGE_SIZE[1], k)
    rc_path, rc_scale = _asset_pixmap('card_red.png', CARD_BADGE_SIZE[0], CARD_BADGE_SIZE[1], k)
    for name, p_path, p_scale in (
        ('football_left_yc_bg', yc_path, yc_scale),
        ('football_right_yc_bg', yc_path, yc_scale),
        ('football_left_rc_bg', rc_path, rc_scale),
        ('football_right_rc_bg', rc_path, rc_scale),
    ):
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s pixmap="%s" alphatest="blend"%s transparent="1" zPosition="10"/>'
                     % (name, box(CARD_X + dx, 74 + dy, *CARD_BADGE_SIZE), p_path, p_scale))

    # Soccer ball icon pixmaps
    ball_path, ball_scale = _asset_pixmap('football_ball.png', BALL_SIZE, BALL_SIZE, k)
    for name in ('football_left_ball', 'football_right_ball'):
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s pixmap="%s" alphatest="blend"%s transparent="1" zPosition="10"/>'
                     % (name, box(CARD_X + dx, 74 + dy, BALL_SIZE, BALL_SIZE), ball_path, ball_scale))

    font_face = themes.face('UltraAudioUI')

    # Center labels: clock (green), HT score, main score, stage, competition
    center_specs = (
        ('football_clock', 142, 26, 23, '#00DA7F'),
        ('football_ht', 138, 20, 15, '#E2EAE6'),
        ('football_score', 138, 49, 40, '#FFFFFF'),
        ('football_stage', 170, 24, 17, '#FFFFFF'),
        ('football_comp', 170, 21, 12, '#A8B5B0'),
    )
    for name, w, h, fsize, color in center_specs:
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s font="%s;%d" foregroundColor="%s" backgroundColor="transparent" '
                     'transparent="1" noWrap="1" halign="center" valign="center" zPosition="9"/>'
                     % (name, box(CARD_X + dx, 74 + dy, w, h), font_face, n(fsize), color))

    # Team name labels
    for name in ('football_left_name', 'football_right_name'):
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s font="%s;%d" foregroundColor="#FFFFFF" backgroundColor="transparent" '
                     'transparent="1" noWrap="1" halign="center" valign="center" zPosition="9"/>'
                     % (name, box(CARD_X + dx, 74 + dy, 118, 26), font_face, n(17)))

    # Card count labels on top of badge pixmaps
    for name, color in (
        ('football_left_yc', '#111111'),
        ('football_right_yc', '#111111'),
        ('football_left_rc', '#FFFFFF'),
        ('football_right_rc', '#FFFFFF'),
    ):
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s font="%s;%d" foregroundColor="%s" backgroundColor="transparent" '
                     'transparent="1" noWrap="1" halign="center" valign="center" zPosition="11"/>'
                     % (name, box(CARD_X + dx, 74 + dy, *CARD_BADGE_SIZE), font_face, n(17), color))

    # Goal scorer labels
    for name, align in (('football_left_scorers', 'left'), ('football_right_scorers', 'right')):
        dx, dy = REL_POS[name]
        parts.append('<widget name="%s" %s font="%s;%d" foregroundColor="#E6ECEA" backgroundColor="transparent" '
                     'transparent="1" halign="%s" valign="top" zPosition="9"/>'
                     % (name, box(CARD_X + dx, 74 + dy, 118, 36), font_face, n(12), align))

    return '\n'.join(parts)


class FootballCard(object):
    def __init__(self, screen):
        self.screen = screen
        self._shown = None
        self._pixmaps = {}
        self._ui_error = None
        self._badges = None
        SCORES.logger = log
        log('LiveMatch: enhanced beIN match card initialized')
        for name in NAMES:
            screen[name] = ScorerTicker() if name.endswith('_scorers') else (Label('') if name in LABEL_NAMES else Pixmap())

    def hide(self):
        self._shown = None
        for name in NAMES:
            self.screen[name].hide()

    def refresh(self):
        s = self.screen
        try:
            if s.grid or s.menu.is_open or not getattr(s, '_marker_visible', False) or not getattr(s, 'execing', True):
                return self.hide()
            # Rebuild visible rows only when a confirmed-live badge changes.
            first = (s._index() // 9) * 9
            badges = tuple(SCORES.is_live(e.get('event')) for e in s.entries[first:first+9])
            if badges != self._badges:
                self._badges = badges
                s._shown = None
            idx = s._index()
            entry = s.entries[idx] if 0 <= idx < len(s.entries) else {}
            event = entry.get('event')
            if entry.get('payload', ('',))[0] != 'stream' or not event:
                return self.hide()
            SCORES.ensure(event)
            result = SCORES.view(event)
            if result is None:
                return self.hide()
            if len(result) == 5:
                ident, score, clock, paths, extra = result
            else:
                ident, score, clock, paths = result[:4]
                extra = {}
            signature = (
                idx, ident, score, clock, paths,
                extra.get('left_name', ''), extra.get('right_name', ''),
                extra.get('ui_language', ''),
                extra.get('ht_text', ''), extra.get('stage', ''), extra.get('competition', ''),
                extra.get('left_yc', 0), extra.get('left_rc', 0),
                extra.get('right_yc', 0), extra.get('right_rc', 0),
                extra.get('left_scorers', ''), extra.get('right_scorers', ''),
            )
            if signature != self._shown:
                # Follow the selected row and clamp cleanly above the bottom dock bar (1015).
                y = min(1010 - CARD_H, 74 + (idx % 9) * 104)
                for name in NAMES:
                    dx, dy = REL_POS[name]
                    s[name].instance.move(ePoint(int(round((CARD_X + dx) * s.k)), int(round((y + dy) * s.k))))
                for name, path in zip(('football_home', 'football_away'), paths):
                    try:
                        from .compat import ui_pixmap_path
                        path = ui_pixmap_path(path, max(1, int(round(LOGO_SIZE * s.k))), max(1, int(round(LOGO_SIZE * s.k))))
                    except ImportError:
                        pass
                    if path not in self._pixmaps:
                        pix = LoadPixmap(native(path))
                        if pix is None:
                            return self.hide()
                        if len(self._pixmaps) >= 16:
                            self._pixmaps.clear()
                        self._pixmaps[path] = pix
                    s[name].instance.setPixmap(self._pixmaps[path])
                s['football_clock'].setText(native(clock))
                s['football_ht'].setText(native(extra.get('ht_text', '')))
                s['football_score'].setText(native(score))
                s['football_stage'].setText(native(extra.get('stage', '')))
                s['football_comp'].setText(native(extra.get('competition', '')))
                s['football_left_name'].setText(native(extra.get('left_name', '')))
                s['football_right_name'].setText(native(extra.get('right_name', '')))
                s['football_left_scorers'].setText(native(extra.get('left_scorers', '')))
                s['football_right_scorers'].setText(native(extra.get('right_scorers', '')))
                self._shown = signature

            # Base card widgets always visible when card is shown
            for name in (
                'football_panel', 'football_home', 'football_away',
                'football_clock', 'football_ht', 'football_score',
                'football_stage', 'football_comp',
                'football_left_name', 'football_right_name',
            ):
                s[name].show()

            # Conditional yellow/red card badges
            for prefix, yc_key, rc_key in (
                ('football_left', 'left_yc', 'left_rc'),
                ('football_right', 'right_yc', 'right_rc'),
            ):
                yc = int(extra.get(yc_key, 0) or 0)
                if yc > 0:
                    s[prefix + '_yc'].setText(native(str(yc)))
                    s[prefix + '_yc_bg'].show()
                    s[prefix + '_yc'].show()
                else:
                    s[prefix + '_yc_bg'].hide()
                    s[prefix + '_yc'].hide()

                rc = int(extra.get(rc_key, 0) or 0)
                if rc > 0:
                    s[prefix + '_rc'].setText(native(str(rc)))
                    s[prefix + '_rc_bg'].show()
                    s[prefix + '_rc'].show()
                else:
                    s[prefix + '_rc_bg'].hide()
                    s[prefix + '_rc'].hide()

            # Conditional goal scorer rows & soccer ball icons
            for prefix, sc_key in (
                ('football_left', 'left_scorers'),
                ('football_right', 'right_scorers'),
            ):
                sc_text = extra.get(sc_key, '') or ''
                if sc_text:
                    s[prefix + '_ball'].hide()
                    s[prefix + '_scorers'].show()
                else:
                    s[prefix + '_ball'].hide()
                    s[prefix + '_scorers'].hide()
        except Exception as exc:
            # An optional card must never take down the playback screen.
            message = '%s: %s' % (type(exc).__name__, exc)
            if message != self._ui_error:
                self._ui_error = message
                log('LiveMatch: card render error: ' + message)
            self.hide()
