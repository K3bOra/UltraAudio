# -*- coding: utf-8 -*-
"""Shared broadcast match card for live matches only."""
import os
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import ePoint, eTimer
from . import store, themes
from .compat import native, monotonic, ui_pixmap_path, skin_scale_attr, user_input_idle
from .i18n import lang
from .livefootball import SCORES
from .engine import log

CARD_W, CARD_H = 650, 112
VIDEO_LEFT, VIDEO_RIGHT = 640, 1880
CARD_X, CARD_Y = (VIDEO_LEFT + VIDEO_RIGHT - CARD_W) // 2, 74
CARD_SETTLE_MS = 350
LOGO_SIZE = 78
ASSETS = os.path.join(store.ASSETS, 'matchcard')
PIXMAP_NAMES = ('football_panel', 'football_home', 'football_away')
LABEL_NAMES = ('football_live', 'football_clock', 'football_score', 'football_left_name', 'football_right_name')
NAMES = PIXMAP_NAMES + LABEL_NAMES
REL_POS = {'football_panel':(0,0), 'football_home':(18,17), 'football_away':(554,17),
           'football_live':(302,2), 'football_clock':(265,82), 'football_score':(265,34),
           'football_left_name':(102,28), 'football_right_name':(386,28)}
_PIXMAP_CACHE = {}


def skin_parts(k, th):
    n = lambda v: int(round(v*k))
    def box(name, w, h):
        x,y = REL_POS[name]
        return 'position="%d,%d" size="%d,%d"' % (n(CARD_X+x),n(CARD_Y+y),max(1,n(w)),max(1,n(h)))
    path = ui_pixmap_path(themes.pic(th, 'matchcard_panel.png'),n(CARD_W),n(CARD_H))
    parts = ['<widget name="football_panel" %s pixmap="%s" alphatest="blend"%s transparent="1" zPosition="8"/>' % (box('football_panel',CARD_W,CARD_H),path,skin_scale_attr())]
    for name in ('football_home','football_away'):
        parts.append('<widget name="%s" %s alphatest="blend"%s transparent="1" zPosition="9"/>' % (name,box(name,LOGO_SIZE,LOGO_SIZE),skin_scale_attr()))
    face = themes.face('UltraAudioUI')
    for name,w,h,size,color,wrap in (
        ('football_live',62,28,20,themes.LIVE_RED,1), ('football_clock',120,26,21,th['pal']['accent'],1),
        ('football_score',120,46,32,'#FFFFFF',1), ('football_left_name',162,54,23,'#FFFFFF',0),
        ('football_right_name',162,54,23,'#FFFFFF',0)):
        parts.append('<widget name="%s" %s font="%s;%d" foregroundColor="%s" transparent="1" noWrap="%d" halign="center" valign="center" zPosition="10"/>' % (name,box(name,w,h),face,max(1,n(size)),color,wrap))
    return '\n'.join(parts)


class FootballCard(object):
    def __init__(self, screen):
        self.screen = screen
        self._shown, self._selection, self._card_y = None,None,None
        self._closed, self._settled = False,False
        self._due = 0.0
        self._visible_set, self._widget_texts, self._widget_pix = set(),{},{}
        self._last_ensure_key, self._last_ensure_at = None,0.0
        self._pixmaps = _PIXMAP_CACHE
        SCORES.target_logo_size = max(16, int(round(LOGO_SIZE * getattr(screen, 'k', 1.0))))
        for name in NAMES:
            screen[name] = Label('') if name in LABEL_NAMES else Pixmap()
        self._settle_timer = eTimer()
        self._settle_connection = None
        if hasattr(self._settle_timer,'callback'):
            self._settle_timer.callback.append(self._settle)
        else:
            self._settle_connection = self._settle_timer.timeout.connect(self._settle)
        screen.onClose.append(self.close)
        SCORES.logger = log
        SCORES.on_update = self._on_scores_updated
        SCORES.warm_up()

    def _visible(self,name,on):
        if on:
            if name not in self._visible_set:
                self.screen[name].show()
                self._visible_set.add(name)
        elif name in self._visible_set:
            self.screen[name].hide()
            self._visible_set.discard(name)

    def _hide_widgets(self):
        if self._shown is None and getattr(self, '_widgets_hidden', False) and not self._visible_set:
            return
        self._shown = None
        for name in NAMES:
            self.screen[name].hide()
        self._visible_set.clear()
        self._widgets_hidden = True

    def hide(self):
        self._settle_timer.stop()
        self._selection,self._settled = None,False
        self._hide_widgets()

    def close(self):
        self._closed = True
        if getattr(SCORES, 'on_update', None) == self._on_scores_updated:
            SCORES.on_update = None
        self.hide()

    def _on_scores_updated(self):
        if self._closed:
            return
        if not user_input_idle(0.45) or not self._settled:
            if self._selection is not None:
                self._due = monotonic() + CARD_SETTLE_MS / 1000.0
                self._settle_timer.start(CARD_SETTLE_MS, True)
            return
        self.refresh()

    def _settle(self):
        if self._closed:
            return
        if not user_input_idle(0.32):
            self._due = monotonic() + 0.25
            self._settle_timer.start(250, True)
            return
        remaining = self._due-monotonic()
        if remaining>0.001:
            self._settle_timer.start(max(20,int(round(remaining*1000))),True)
            return
        self._settled = True
        self.refresh()

    def selection_changed(self):
        s = self.screen
        if self._closed:
            return
        if s.grid or s.menu.is_open or not getattr(s, 'execing', True) or not getattr(s, '_marker_visible', False):
            return self.hide()
        if not s._guide_streams:
            if self._selection is not None:
                self.hide()
            return
        idx = s._index()
        entries = s.entries
        entry = entries[idx] if entries else {}
        selection = (s.cwd, idx, entry.get('event'))
        if selection == self._selection:
            return
        self._selection = selection
        self._hide_widgets()
        self._settled = False
        first = (idx // s.per_page) * s.per_page
        if any(e.get('event') for e in entries[first:first + s.per_page]):
            # Let remote-key repeats move the list before resolving scores or loading logos.
            self._due = monotonic() + CARD_SETTLE_MS / 1000.0
            self._settle_timer.start(CARD_SETTLE_MS, True)
        else:
            self._settle_timer.stop()

    def refresh(self):
        self.selection_changed()
        if self._settled and not self._closed:
            self._refresh_card()

    def _refresh_card(self):
        s = self.screen
        try:
            idx=s._index();first=(idx//9)*9
            page=s.entries[first:first+9]
            badges=tuple(SCORES.is_live(e.get('event')) for e in page)
            s.refresh_match_rows(first, badges)
            entry=s.entries[idx] if 0<=idx<len(s.entries) else {}
            event=entry.get('event');now=monotonic()
            key = (getattr(s, 'cwd', ''), first, tuple(e.get('event') for e in page))
            if key!=self._last_ensure_key or now-self._last_ensure_at>=12.0:
                self._last_ensure_key,self._last_ensure_at=key,now
                raw_events=[e.get('event') for e in page if e.get('payload',('',))[0]=='stream' and e.get('event')]
                if raw_events:
                    SCORES.ensure_page(event if entry.get('payload',('',))[0]=='stream' else None, raw_events)
            if entry.get('payload',('',))[0]!='stream' or not event or not SCORES.is_live(event):
                return self._hide_widgets()
            result=SCORES.view(event)
            if result is None:
                return self._hide_widgets()
            ident,score,clock,paths=result[:4]
            extra=result[4] if len(result)>4 else {}
            self._render(idx,ident,score.replace(' - ',' : '),clock,paths,
                         (extra.get('left_name',''),extra.get('right_name','')))
        except Exception as exc:
            log('LiveMatch: shared card: %s' % exc)
            self._hide_widgets()

    def _render(self,idx,ident,score,clock,paths,names):
        sig=(idx,ident,score,clock,paths,names,lang())
        if sig==self._shown:
            return
        self._shown=sig;s=self.screen;k=s.k
        y=CARD_Y
        if y!=self._card_y:
            self._card_y=y
            for name in NAMES:
                dx,dy=REL_POS[name]
                s[name].instance.move(ePoint(int(round((CARD_X+dx)*k)),int(round((y+dy)*k))))
        panel_was_visible='football_panel' in self._visible_set
        pix_changed=False
        for name,path in zip(('football_home','football_away'),paths):
            resolved=path if (path and os.path.isfile(path)) else ''
            pix=self._pixmaps.get(resolved) if resolved else None
            if pix is None and resolved:
                pix=LoadPixmap(native(resolved))
                if pix is not None:
                    if len(self._pixmaps)>96:self._pixmaps.clear()
                    self._pixmaps[resolved]=pix
            if pix is not None:
                if self._widget_pix.get(name) is not pix:
                    self._widget_pix[name]=pix;s[name].instance.setPixmap(pix);pix_changed=True
                self._visible(name,True)
            else:
                self._visible(name,False)
        values={'football_live':'مباشر' if lang()=='ar' else 'CANLI' if lang()=='tr' else 'LIVE',
                'football_clock':clock,'football_score':score,'football_left_name':names[0],
                'football_right_name':names[1]}
        for name,value in values.items():
            if self._widget_texts.get(name)!=value:
                self._widget_texts[name]=value;s[name].setText(native(value))
            self._visible(name,True)
        self._visible('football_panel',True)
        if panel_was_visible and pix_changed and hasattr(s['football_panel'].instance,'invalidate'):
            try:
                s['football_panel'].instance.invalidate()
            except Exception:
                pass
