# -*- coding: utf-8 -*-
"""One preloaded playback marker; never rebuilds list rows or touches sound devices."""
from __future__ import division
FRAME_MS = 125


def visible_row(entries, selected, stream_id, rows=9):
    if not stream_id or not entries:
        return None
    page = selected // rows
    for index, entry in enumerate(entries):
        payload = entry.get('payload')
        if (payload and payload[0] == 'stream' and payload[1].get('id') == stream_id
                and index // rows == page):
            return index % rows
    return None


class PlaybackMarker(object):
    def __init__(self, timer_factory, frames, still, status, paint, move, show, hide):
        self.frames = tuple(frames)
        self.still = still
        self.status = status
        self.paint, self.move, self.show, self.hide = paint, move, show, hide
        self.timer = timer_factory(self.tick)
        self.running = False
        self.target = None
        self.frame = 0
        self.position = None
        self.painted = None
        self.closed = False

    def _paint(self, pixmap):
        if pixmap is not None and pixmap is not self.painted:
            self.paint(pixmap)
            self.painted = pixmap

    def stop(self):
        if self.running:
            self.timer.stop()
        self.running = False
        self.target = None
        self.hide()

    def update(self, row, state, stream_id, visible=True):
        if self.closed or not visible or row is None or state in ('idle', 'stopping'):
            return self.stop()
        if row != self.position:
            self.move(row)
            self.position = row
        self.show()
        if state != 'playing' or not self.frames:
            if self.running:
                self.timer.stop()
            self.running, self.target = False, None
            self._paint(self.still)
            return
        if self.target != stream_id or not self.running:
            self.target = stream_id
            self.frame = 0
            self._paint(self.frames[0])
            self.running = True
            self.timer.start(FRAME_MS, False)

    def tick(self):
        if self.closed or not self.running:
            return
        state = self.status()
        if state is None:
            return
        if state.get('state') != 'playing' or state.get('stream_id') != self.target:
            return self.stop()
        self.frame = (self.frame + 1) % len(self.frames)
        self._paint(self.frames[self.frame])

    def close(self):
        self.closed = True
        self.stop()
