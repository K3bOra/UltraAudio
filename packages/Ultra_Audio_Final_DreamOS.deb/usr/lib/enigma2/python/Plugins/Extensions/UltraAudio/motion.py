# -*- coding: utf-8 -*-
"""One preloaded playback marker; never rebuilds list rows or touches sound devices."""
from __future__ import division
from .compat import user_input_idle
FRAME_MS = 125


def visible_row(entries, selected, stream_id, rows=9):
    if not stream_id or not entries:
        return None
    first = (selected // rows) * rows
    for row, entry in enumerate(entries[first:first + rows]):
        payload = entry.get('payload')
        if payload and payload[0] == 'stream' and payload[1].get('id') == stream_id:
            return row
    return None


class PlaybackMarker(object):
    def __init__(self, timer_factory, frames, still, status, paint, move, show, hide):
        self.frames = tuple(frames)
        self.still = still
        self.status = status
        self.paint, self.move, self.show, self.hide = paint, move, show, hide
        self.timer = timer_factory(self.tick)
        self.running = False
        self.target = None
        self.frame = 0
        self.position = None
        self.painted = None
        self._shown = False
        self.closed = False

    def _paint(self, pixmap):
        if pixmap is not None and pixmap is not self.painted:
            self.paint(pixmap)
            self.painted = pixmap

    def _set_visible(self, on):
        if on:
            if not self._shown:
                self._shown = True
                self.show()
        else:
            if self._shown:
                self._shown = False
                self.hide()

    def stop(self):
        if self.running:
            self.timer.stop()
        self.running = False
        self.target = None
        self._set_visible(False)

    def update(self, row, state, stream_id, visible=True):
        if self.closed or not visible or row is None or state in ('idle', 'stopping'):
            return self.stop()
        if row != self.position:
            self.move(row)
            self.position = row
        self._set_visible(True)
        if state != 'playing' or not self.frames:
            if self.running:
                self.timer.stop()
            self.running, self.target = False, None
            self._paint(self.still)
            return
        if self.target != stream_id or not self.running:
            self.target = stream_id
            self.frame = 0
            self._paint(self.frames[0])
            self.running = True
            self.timer.start(FRAME_MS, False)

    def tick(self):
        if self.closed or not self.running or not user_input_idle(0.35):
            return
        state = self.status()
        if state is None:
            return
        if state.get('state') != 'playing' or state.get('stream_id') != self.target:
            return self.stop()
        self.frame = (self.frame + 1) % len(self.frames)
        self._paint(self.frames[self.frame])

    def close(self):
        self.closed = True
        self.stop()
