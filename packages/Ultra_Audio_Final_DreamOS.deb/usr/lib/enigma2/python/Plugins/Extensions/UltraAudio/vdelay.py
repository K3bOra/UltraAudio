# -*- coding: utf-8 -*-
"""Main-thread timeshift control. Borrow existing buffers; stop only our own."""
from __future__ import division
import math
import os
import time
from collections import deque

from .compat import UNIDENTIFIED, connect_timer, isfinite, monotonic, service_key, to_text
from .engine import log
from .i18n import T
from .syncguard import DelayGuard

PTS = 90000.0
READY_TIMEOUT = 12.0
WINDOW = 12.0            # seconds of length samples used to find the true live edge of the buffer
SETTLE_TOL = 0.8         # after a seek the delay may be off by this much (key-frame granularity) before we correct it
SETTLE_TRIES = 2
SETTLE_WAIT = 0.65
QUIET = 3.0              # seconds during which the receiver's own banner is kept from popping up after our seek / pause
_now = monotonic


def timeshift_on_disk():
    """False when the timeshift folder is missing or lies on the root file system (the receiver's own flash): opening a
    buffer there ahead of time would wear it out for nothing. Outside Enigma2 / unknown config: True (old behaviour)."""
    try:
        from Components.config import config
        path = to_text(config.usage.timeshift_path.value)
    except Exception:
        return True
    try:
        return os.path.isdir(path) and os.stat(path).st_dev != os.stat("/").st_dev
    except EnvironmentError:
        return False


class VideoDelay(object):
    def __init__(self):
        self.target = 0.0
        self.requested = 0.0
        self.state = "off"
        self.note = ""
        self.on_seek = None
        self.on_before_timeshift = None
        self.on_manual_delay = None
        self._timer = None
        self._connection = None
        self._cur = None
        self._ib = None
        self._service = None
        self._owned = False
        self._borrowed = None
        self._deadline = None
        self._missing_since = None
        self._released_at = -99.0         # when we last closed a buffer: a new one is not opened right behind it
        self._samples = deque()          # retained for compatibility
        self._fix_left, self._fix_at = 0, 0.0
        self._drift = DelayGuard()
        self._audio_ready, self._audio_epoch = False, None
        self._raw, self._edge = None, None
        self._prev_pl = None
        self._length_seen = None
        self._pause_init_ln = None
        self._settle_until = 0.0
        self._meter_ok = False
        self._drift_cand = None
        self._manual_seek = False
        self._quiet_saved, self._quiet_timer, self._quiet_conn = None, None, None
        self._pause_started = None
        self._pause_base = 0.0
        self._fill_until = None
        self._actual_delay = 0.0
        self._seek_check = None
        self._reanchor_at = None
        self._reanchor_deadline = None
        self._seek_broken_service = None

        self._resume_until = 0.0
        self._resume_check = None
        self._progress_watch = None

    @staticmethod
    def _infobar():
        try:
            from Screens.InfoBar import InfoBar
            return InfoBar.instance
        except Exception:
            return None

    @staticmethod
    def _service_key(ib):
        try:
            # Same identity as the controller (DreamOS: channel list / last service when navigation reports None).
            return service_key(ib.session.nav, fallback=True, placeholder=True)[0]
        except Exception:
            return None

    @staticmethod
    def _timeshift(ib):
        fn = getattr(ib, "getTimeshift", None)
        return fn() if callable(fn) else None

    @classmethod
    def _enabled(cls, ib):
        # Support DreamOS (OE2.5/OE2.6), OpenBH, OpenATV and OpenPLi timeshift state APIs.
        fn = getattr(ib, "timeshiftEnabled", None)
        if callable(fn):
            try:
                return bool(fn())
            except Exception:
                pass
        ts = cls._timeshift(ib)
        if ts is not None:
            for mname in ("isTimeshiftEnabled", "isTimeshiftActive"):
                m = getattr(ts, mname, None)
                if callable(m):
                    try:
                        if m():
                            return True
                    except Exception:
                        pass
        flag = getattr(ib, "timeshift_enabled", False)
        return bool(flag() if callable(flag) else flag)

    @staticmethod
    def _paused(ib):
        try:
            return ib.seekstate == ib.SEEK_STATE_PAUSE
        except Exception:
            return None

    def _notify_seek(self):
        if callable(self.on_seek):
            try:
                self.on_seek()
            except Exception:
                pass

    def _pause(self, ib):
        self._quiet(ib)
        self._resume_until = 0.0
        self._resume_check = None
        self._progress_watch = None
        ts = self._timeshift(ib)
        if ts is not None and callable(getattr(ts, "isTimeshiftActive", None)) and not ts.isTimeshiftActive():
            # On DreamOS / GP4, activating timeshift automatically pauses the service and enters timeshift mode!
            fn = getattr(ib, "activateTimeshiftEndAndPause", None)
            if callable(fn):
                try:
                    fn()
                except Exception:
                    pass
            if not ts.isTimeshiftActive() and callable(getattr(ts, "activateTimeshift", None)):
                try:
                    ts.activateTimeshift()
                except Exception:
                    pass
        if self._paused(ib) is not True:
            try:
                ib.pauseService()
            except Exception:
                pass
            if self._paused(ib) is not True and callable(getattr(ib, "setSeekState", None)) and hasattr(ib, "SEEK_STATE_PAUSE"):
                try:
                    ib.setSeekState(ib.SEEK_STATE_PAUSE)
                except Exception:
                    pass
        # Always notify the controller even when startTimeshift / activateTimeshiftEndAndPause already set SEEK_STATE_PAUSE!
        self._notify_seek()

    def _resume(self, ib):
        self._quiet(ib)
        if self._resume_check is None:
            self._resume_check = {"at": _now(), "pos": self._pos_only(ib), "tries": 0}
        self._resume_until = self._resume_check["at"] + 2.0
        # NEVER call ts.activateTimeshift() inside _resume(): on DreamOS / GP4, activateTimeshift() pauses the picture!
        # Call ib.unPauseService() FIRST so InfoBarTimeshift / GP4 PTS state machine unpauses properly, then also
        # ensure SEEK_STATE_PLAY and native service.pause().unpause().
        if self._paused(ib) is not False and callable(getattr(ib, "unPauseService", None)):
            try:
                ib.unPauseService()
            except Exception:
                pass
        if callable(getattr(ib, "setSeekState", None)) and hasattr(ib, "SEEK_STATE_PLAY"):
            try:
                ib.setSeekState(ib.SEEK_STATE_PLAY)
            except Exception:
                pass
        if self._paused(ib) is not False and callable(getattr(ib, "unPauseService", None)):
            try:
                ib.unPauseService()
            except Exception:
                pass
        try:
            svc = ib.session.nav.getCurrentService()
            p = svc.pause() if svc is not None and callable(getattr(svc, "pause", None)) else None
            if p is not None and callable(getattr(p, "unpause", None)):
                p.unpause()
        except Exception:
            pass
        self._notify_seek()

    def _verify_resume(self, ib, now):
        check = self._resume_check
        if check is None:
            return True
        pos = self._pos_only(ib)
        paused = self._paused(ib)
        if paused is False and pos is not None and check["pos"] is not None and pos > check["pos"] + 0.05:
            log("picture: resume verified, position %.3f -> %.3f" % (check["pos"], pos))
            self._resume_check = None
            self._resume_until = 0.0
            return True
        if now - check["at"] < 1.5:
            return True
        if pos is None and paused is False:
            log("picture: resume reports PLAY; position unavailable for verification")
            self._resume_check = None
            return True
        if check["pos"] is None and pos is not None and paused is False:
            check["pos"], check["at"] = pos, now
            return True
        if check["tries"] >= 2:
            self._resume_check = None
            self._fail(T("Timeshift did not resume; restoring live TV"))
            return False
        check["tries"] += 1
        check["at"], check["pos"] = now, pos
        log("picture: resume retry %d; paused=%s position=%s" % (check["tries"], paused, pos))
        self._resume(ib)
        return True

    def _watch_playback_progress(self, ib, now):
        # PLAY is only a GUI state. Verify that PTS advances while the recorded
        # buffer grows; a stopped audio-owned demux can otherwise look healthy.
        if (self._resume_check is not None or self._manual_seek or self._seek_check is not None
                or self._paused(ib) is not False
                or getattr(ib, "seekstate", None) != getattr(ib, "SEEK_STATE_PLAY", None)):
            self._progress_watch = None
            return
        pl = self._pos_len(ib)
        if pl is None:
            self._progress_watch = None
            return
        pos, length = pl
        watch = self._progress_watch
        if watch is None or abs(pos - watch[1]) > 0.05 or length < watch[2]:
            self._progress_watch = (now, pos, length)
            return
        if now - watch[0] >= 1.2 and length - watch[2] >= 0.4 and len(watch) < 4:
            # Flush the DVB audio RAVE CDB buffer immediately before a PVR demux backpressure stall can freeze video
            try:
                from . import dvbaudio
                dvbaudio.keep_timeshift_isolated(active_flush=True)
            except Exception:
                pass
            self._progress_watch = (watch[0], watch[1], watch[2], True)
            self._notify_seek()
            return
        if now - watch[0] >= 3.0 and length - watch[2] >= 1.0:
            log("picture: playback stalled while buffer grows; position=%.3f length=%.3f for %.1fs" % (
                pos, length, now - watch[0]))
            try:
                from . import dvbaudio
                dvbaudio.keep_timeshift_isolated(active_flush=True)
            except Exception:
                pass
            self._progress_watch = None
            self._resume(ib)  # _verify_resume has a finite retry budget and safe live-TV fallback

    def _seek_live(self, ib):
        self._quiet(ib)
        # Seek positions use 64-bit PTS. The separate GUI slider guard scales
        # its 32-bit display; clipping the seek itself strands long recordings.
        target_pts = None
        try:
            seek = ib.getSeek()
            ln = seek.getLength() if seek is not None else None
            if ln and not ln[0] and ln[1] > 0:
                target_pts = int(ln[1])
        except Exception:
            pass
        if target_pts is None:
            raise RuntimeError(T("The live edge is not available yet; try again"))
        ib.doSeek(target_pts)
        self._notify_seek()

    @classmethod
    def _pos_only(cls, ib):
        try:
            seek = cls._seek_obj(ib)
            if seek is None:
                return None
            pos = seek.getPlayPosition()
            if not pos or pos[0] or pos[1] < 0:
                return None
            return pos[1] / PTS
        except Exception:
            return None

    @classmethod
    def _pos_len(cls, ib):
        try:
            seek = cls._seek_obj(ib)
            if seek is None:
                return None
            ln, pos = seek.getLength(), seek.getPlayPosition()
            if (not ln or not pos or ln[0] or pos[0]
                    or not isfinite(ln[1]) or not isfinite(pos[1])
                    or ln[1] <= 0 or pos[1] < 0):
                return None
            return pos[1] / PTS, ln[1] / PTS
        except Exception:
            return None

    @staticmethod
    def _seek_obj(ib):
        try:
            seek = ib.getSeek() if callable(getattr(ib, "getSeek", None)) else None
            if seek is not None:
                return seek
            service = ib.session.nav.getCurrentService()
            return service.seek() if service is not None and callable(getattr(service, "seek", None)) else None
        except Exception:
            return None

    def _measure_buffer(self, ib, now=None):
        """Measure actual timeshift offset (length - position) from the image's seek interface.
        Bridges short (<1.8s) inter-GOP .ap flush intervals during normal 1x play to avoid sawtooth
        jitter while immediately reflecting real stream stalls, skips, or external seeks."""
        now = _now() if now is None else now
        pl = self._pos_len(ib) if ib else None
        if not pl:
            self._raw = None
            return None
        pos, ln = pl
        self._raw = pl
        if self.state == "filling" and self._pause_init_ln is None:
            self._pause_init_ln = ln
        if pos > ln + 0.5:
            return None
        # A stopped index is not a new live-edge measurement. In particular,
        # do not turn its decreasing length-position into a real drift value.
        if self._length_seen is None or ln != self._length_seen[1]:
            self._length_seen = (now, ln)
        if (self.state == "running" and self._paused(ib) is not True
                and now - self._length_seen[0] > 1.8):
            return None
        prev = self._prev_pl
        self._prev_pl = (now, pos, ln)
        pos_jumped = False
        if prev is not None:
            dt = now - prev[0]
            dp = pos - prev[1]
            if 0.0 < dt <= 2.5 and abs(dp - dt) > 0.35:
                pos_jumped = True
        if self._edge is None or len(self._edge) < 3 or ln != self._edge[1] or pos_jumped:
            self._edge = (now, ln, pos)
        edge_t, edge_ln, edge_pos = self._edge
        stale = now - edge_t
        if stale > 8.0:
            return None
        if (self.state == "running" and not pos_jumped and stale <= 1.8
                and self._paused(ib) is not True and pos >= edge_pos):
            return max(0.0, edge_ln - edge_pos)
        return max(0.0, ln - pos)

    def _quantize_delay(self, value):
        try:
            from . import store
            step_cfg = float(store.get_settings().get("step_video_s") or 1.0)
        except Exception:
            step_cfg = 1.0
        unit = min(1.0, step_cfg) if step_cfg > 0 else 1.0
        if abs(round(self.target / unit) * unit - self.target) > 0.05:
            unit = 0.1
        return round(max(0.0, min(600.0, round(value / unit) * unit)), 1), unit

    def _sync_running_delay(self, ib, now, measured=None):
        """Synchronize plugin delay readout and control target with the image's actual timeshift
        when channel drift/shift occurs, without issuing unwanted automatic seeks."""
        if now < self._settle_until or self._seek_check is not None or self._manual_seek:
            self._drift_cand = None
            return
        if measured is None:
            measured = self._measure_buffer(ib, now)
        if measured is None:
            self._drift_cand = None
            return
        if not isfinite(measured) or measured < 0:
            self._drift_cand = None
            return
        # Trust stable observations, not closeness to the saved request: a
        # genuine shift may be 10 -> 1, 0 or 25 seconds before calibration.
        # Use distinct, consecutive timer observations spanning at least 0.5s.
        # Anchor the candidate so a steadily moving/broken index cannot pass
        # merely by staying close to the immediately previous sample.
        cand = self._drift_cand
        if (cand is not None and 0 < now - cand[3] <= 2.5
                and abs(measured - cand[0]) <= 0.35):
            anchor, count, since = cand[0], cand[1] + 1, cand[2]
        elif cand is not None and now == cand[3]:
            return
        else:
            anchor, count, since = measured, 1, now
        first_pos = cand[4] if cand is not None and count > 1 and len(cand) > 4 else (
            self._raw[0] if self._raw is not None else None)
        self._drift_cand = (anchor, count, since, now, first_pos)
        if count < 3 or now - since < 0.5:
            return
        if (first_pos is None or self._raw is None or self._raw[0] <= first_pos + 0.05):
            self._drift_cand = None
            return
        self._meter_ok = True
        snapped, unit = self._quantize_delay(measured)
        threshold = max(0.55, unit * 0.55)
        if (abs(measured - self._actual_delay) >= threshold
                and abs(snapped - self._actual_delay) >= max(0.1, unit - 0.01)):
            prev_delay = self._actual_delay
            self._actual_delay = snapped
            self.target = snapped
            self._cur = snapped
            # requested remains the viewer's saved preference. Observation
            # never seeks, pauses, restarts audio or writes channel memory.
            log("picture: synced plugin delay with image timeshift (%.1fs -> %.1fs, measured=%.2fs)"
                % (prev_delay, snapped, measured))
        self._drift_cand = None

    def _ensure_timer(self):
        if self._timer is None:
            from enigma import eTimer
            self._timer = eTimer()
            self._connection = connect_timer(self._timer, self._tick)
        self._timer.start(250, False)

    def current(self):
        """Delay of the picture behind live, in seconds."""
        ib = self._infobar()
        now = _now()
        measured = self._measure_buffer(ib, now) if ib else None
        if not ib:
            self._raw = None
        if self.state == "paused" and self._pause_started is not None:
            return max(0.0, self._pause_base + (now - self._pause_started))
        if self.state == "filling":
            if self._reanchor_at is not None:
                return 0.0
            if self._pause_started is not None:
                return min(self.target, max(0.0, self._pause_base + (now - self._pause_started)))
            return 0.0
        if self.state == "running":
            if self._manual_seek and measured is not None:
                return measured
            if self._actual_delay > 0:
                return self._actual_delay
            if self.target > 0:
                return self.target
        return measured

    def _quiet(self, ib):
        """Keep the receiver's own big timeshift banner from popping up over our screen after a seek / pause / resume
        (InfoBarSeek shows it by itself); the normal show / hide behaviour comes back a few seconds later."""
        try:
            if self._quiet_saved is not None and self._quiet_saved[0] is not ib:
                self._unquiet()
            if self._quiet_saved is None:
                self._quiet_saved = (ib, [])
            for name in ("showAfterSeek", "doShow"):
                if callable(getattr(ib, name, None)) and name not in ib.__dict__:
                    setattr(ib, name, lambda *a, **k: None)
                    self._quiet_saved[1].append(name)
            if self._quiet_timer is None:
                from enigma import eTimer
                self._quiet_timer = eTimer()
                self._quiet_conn = connect_timer(self._quiet_timer, self._unquiet)
            self._quiet_timer.start(int(QUIET * 1000), True)
        except Exception as e:
            log("quiet failed: %s" % e)
            self._unquiet()

    def _unquiet(self):
        if self._quiet_timer is not None:
            try:
                self._quiet_timer.stop()
            except Exception:
                pass
        saved, self._quiet_saved = self._quiet_saved, None
        if not saved:
            return
        ib, names = saved
        for name in names:
            try:
                ib.__dict__.pop(name, None)
            except Exception:
                pass
        try:
            hide = getattr(ib, "hide", None)
            if callable(hide) and getattr(ib, "shown", False) and self._ib is ib and self._same_service(ib):
                hide()
        except Exception:
            pass

    def _forget(self):
        if self._timer:
            self._timer.stop()
        self._unquiet()
        self.target, self.requested, self._cur = 0.0, 0.0, None
        self.state, self.note = "off", ""
        self._ib, self._service = None, None
        self._owned, self._borrowed = False, None
        self._deadline, self._missing_since = None, None
        self._samples.clear()
        self._fix_left = 0
        self._raw, self._edge = None, None
        self._prev_pl = None
        self._length_seen = None
        self._pause_init_ln = None
        self._settle_until = 0.0
        self._meter_ok = False
        self._drift_cand = None
        self._manual_seek = False
        self._audio_ready, self._audio_epoch = False, None
        self._pause_started = None
        self._pause_base = 0.0
        self._fill_until = None
        self._actual_delay = 0.0
        self._seek_check = None
        self._reanchor_at = None
        self._reanchor_deadline = None
        self._seek_broken_service = None
        self._drift.reset(_now(), clear_budget=True)

        self._resume_until = 0.0
        self._resume_check = None
        self._progress_watch = None

    def on_service_changed(self):
        """Immediately detach from the previous TV service when zapping away."""
        self._forget()

    def set_audio_context(self, ready, epoch):
        """The controller supplies output liveness; never touch audio here."""
        ready = bool(ready)
        if epoch != self._audio_epoch or ready != self._audio_ready:
            self._drift.reset(_now())
        self._audio_ready, self._audio_epoch = ready, epoch

    def suspend_monitor(self):
        """Manual edits and pause/resume must settle before automatic work."""
        self._drift.reset(_now())

    def _monitor(self, ib, now):
        # Do not issue automatic seeks based on getLength() - getPlayPosition():
        # on OpenATV / Dreambox PTS clocks, length-position diverges from wall-clock
        # pause offsets and causes unwanted jumps away from the user's sync.
        return

    def _same_service(self, ib):
        # Never treat two unknown references as the same tuned television service.
        return (self._ib is ib and bool(self._service)
                and self._service == self._service_key(ib))

    def _acquire(self, ib):
        if callable(self.on_before_timeshift):
            self.on_before_timeshift()
        key = self._service_key(ib)
        if not key:
            raise RuntimeError(T("The TV channel is not ready; try again"))
        if self._ib is not None and not self._same_service(ib):
            # Never seek/stop the new service using the previous service's state.
            self._forget()
        if self._ib is None:
            enabled = self._enabled(ib)
            self._ib, self._service = ib, key
            self._owned = not enabled
            self._borrowed = None if self._owned else {
                "delay": self.current(), "paused": self._paused(ib),
                "time": monotonic(),
            }
        if not self._enabled(ib):
            if callable(getattr(ib, "getTimeshift", None)) and self._timeshift(ib) is None:
                if key == UNIDENTIFIED:
                    # DreamOS reported no playing service at all: say so instead of blaming the channel.
                    raise RuntimeError(T("The receiver reports no playing TV channel; timeshift is not possible"))
                raise RuntimeError(T("This channel does not offer timeshift"))
            ib.startTimeshift()
            if not self._enabled(ib):
                # DreamOS: the InfoBar call may only arm timeshift; start it on the service itself.
                ts = self._timeshift(ib)
                if ts is not None and callable(getattr(ts, "startTimeshift", None)):
                    try:
                        ts.startTimeshift()
                    except Exception:
                        pass
            if not self._enabled(ib):
                raise RuntimeError(T("Could not start timeshift; check the storage path and free space"))
        ts = self._timeshift(ib)
        if ts is not None and callable(getattr(ts, "isTimeshiftActive", None)) and not ts.isTimeshiftActive():
            # Only activate here on images whose activateTimeshiftEnd accepts False (OpenBH/OpenATV).
            # On DreamOS / GP4, activateTimeshiftEnd() takes no args and pauses immediately, so _pause() activates it when needed.
            fn = getattr(ib, "activateTimeshiftEnd", None)
            if callable(fn):
                try:
                    fn(False)
                except TypeError:
                    pass

    def _seek_delay(self, ib, current, target):
        delta = current - target
        if abs(delta) >= 0.05:
            self._quiet(ib)
            ib.doSeekRelative(int(round(delta * PTS)))
            self._notify_seek()

    def _native_seek_relative(self, ib, delta_s):
        try:
            seek = ib.getSeek()
            if seek is None or not callable(getattr(seek, "seekRelative", None)):
                return -1
            pts = int(round(abs(delta_s) * PTS))
            if pts <= 0:
                return 0
            direction = 1 if delta_s >= 0 else -1
            self._quiet(ib)
            res = seek.seekRelative(direction, pts)
            self._notify_seek()
            return 0 if res is None else int(res)
        except Exception as e:
            log("picture: native seekRelative exception: %s" % e)
            return -1

    @classmethod
    def _stop_timeshift_to_live(cls, ib):
        if hasattr(ib, "switchToLive"):
            ib.switchToLive = True
        if getattr(ib, "save_current_timeshift", False):
            ib.stopTimeshift()
            return
        fn = (getattr(ib, "stopTimeshiftcheckTimeshiftRunningCallback", None)
              or getattr(ib, "stopTimeshiftConfirmed", None))
        if callable(fn):
            try:
                fn(True)
            except Exception as e:
                if "iterable" in to_text(e) or isinstance(e, TypeError):
                    try:
                        # DreamOS OE2.5/2.6: stopTimeshiftConfirmed(result) unpacks a (confirmed, action) tuple!
                        fn((True, "jumpToLive"))
                    except Exception:
                        ts = cls._timeshift(ib)
                        if ts is not None and callable(getattr(ts, "stopTimeshift", None)):
                            ts.stopTimeshift()
                        else:
                            ib.stopTimeshift()
                else:
                    ib.stopTimeshift()
        else:
            ib.stopTimeshift()

    def _close_buffer_to_live(self, ib):
        self._quiet(ib)
        try:
            self._resume(ib)
        except Exception:
            pass
        if callable(getattr(ib, "doSeek", None)):
            try:
                self._seek_live(ib)
            except Exception:
                pass
        try:
            self._stop_timeshift_to_live(ib)
        except Exception as e:
            log("picture: InfoBar could not stop timeshift for re-anchor: %s" % e)
        try:
            if self._enabled(ib):
                ts = self._timeshift(ib)
                if ts is not None and callable(getattr(ts, "stopTimeshift", None)):
                    ts.stopTimeshift()
        except Exception as e:
            log("picture: service timeshift still open during re-anchor: %s" % e)
        self._notify_seek()

    def _reanchor_from_live(self, ib, target, now=None):
        """Fallback for receivers (e.g. Dreambox DM900 / Broadcom on OpenATV) where seekRelative returns -1
        in live timeshift buffers without flushed .ap index entries: return to live TV and pause for target."""
        now = _now() if now is None else now
        self._seek_check = None
        self._fix_left = 0
        self.target = target
        self._actual_delay = 0.0
        self._pause_base = 0.0
        self._pause_started = None
        self._pause_init_ln = None
        self._fill_until = None
        self._drift_cand = None
        self._meter_ok = False
        self._close_buffer_to_live(ib)
        self._reanchor_at = now + 0.65
        self._reanchor_deadline = now + 3.0
        self.state = "filling"
        self._deadline = now + target + READY_TIMEOUT + 3.0
        self._ensure_timer()

    def _settle(self):
        self._fix_left = 0

    def _fail(self, note):
        self.release()
        self.state, self.note = "error", note
        log(note)

    def start(self, seconds):
        value = float(seconds)
        if not isfinite(value):
            raise ValueError(T("Invalid picture delay"))
        self.suspend_monitor()
        self._manual_seek = False
        target = max(0.0, min(600.0, value))
        self.requested = target
        if target <= 0:
            self._seek_check = None
            self._reanchor_at = self._reanchor_deadline = None
            self._actual_delay = 0.0
            self._drift_cand = None
            self._meter_ok = False
            if self._ib is None:
                return
            if self._owned:
                # Back to live, but the buffer we opened stays: closing it and opening another straight away hangs the receiver.
                ib = self._infobar()
                if ib and self._same_service(ib):
                    try:
                        self._seek_live(ib)
                    except Exception as e:
                        log("returning to live failed: %s" % e)
                    try:
                        self._resume(ib)
                    except Exception as e:
                        log("resume failed: %s" % e)
                    if self._timer:
                        self._timer.stop()
                    self.target, self._cur = 0.0, None
                    self.state, self.note = "off", ""
                    self._deadline = self._missing_since = None
                    self._pause_started = self._fill_until = None
                    self._pause_init_ln = None
                    self._pause_base = 0.0
                    self._fix_left = 0
                else:
                    self._forget()
                return
            # A zero offset returns to live but keeps a borrowed buffer intact.
            ib = self._infobar()
            if ib and self._same_service(ib):
                try:
                    self._seek_live(ib)
                    self._resume(ib)
                    self.target, self._cur = 0.0, None
                    self.state, self.note = "running", ""
                    self._deadline = self._missing_since = None
                    self._pause_started = self._fill_until = None
                    self._pause_init_ln = None
                    self._pause_base = 0.0
                    self._settle_until = _now() + 1.2
                except Exception as e:
                    self._fail(T("Returning to live failed: %s", e))
            else:
                self._forget()
            return
        ib = self._infobar()
        if ib is None:
            self._fail(T("InfoBar is not available"))
            return
        try:
            prev_state = self.state
            prev_target = self.target
            now = monotonic()
            if prev_state == "filling" and self._reanchor_at is not None and self._same_service(ib):
                # Still waiting for live TV to settle before starting the re-anchored pause: just update target.
                self.target, self.note = target, ""
                self._deadline = now + target + READY_TIMEOUT + 3.0
                self._ensure_timer()
                return
            self._acquire(ib)
            now = monotonic()
            phys_cur = None
            if prev_state == "paused":
                eff_cur = max(0.0, self._pause_base + (now - self._pause_started)) if self._pause_started is not None else prev_target
            elif prev_state == "filling" and self._pause_started is not None:
                eff_cur = max(0.0, self._pause_base + (now - self._pause_started))
            elif prev_state == "running":
                if self._seek_check is not None:
                    pos_now = self._pos_only(ib)
                    chk = self._seek_check
                    if pos_now is not None and chk.get("pos") is not None:
                        dt = max(0.0, now - chk["t"])
                        jumped = max(0.0, (pos_now - chk["pos"]) - dt)
                        eff_cur = max(0.0, chk["from_delay"] - jumped)
                    else:
                        eff_cur = chk["from_delay"]
                else:
                    # Only the timer's confirmed observations may change the
                    # control base; one transient seek/index sample must not.
                    if self._actual_delay > 0:
                        eff_cur = self._actual_delay
                    elif prev_target > 0:
                        eff_cur = prev_target
                    else:
                        eff_cur = None
            elif not self._owned and self._borrowed and self._borrowed.get("delay") is not None and self._borrowed["delay"] > 0.5:
                phys_cur = float(self._borrowed["delay"])
                eff_cur = round(phys_cur, 1)
            else:
                eff_cur = None
            self.target, self.note = target, ""
            self._cur = eff_cur if eff_cur is not None else 0.0
            self._missing_since = None
            self._deadline = now + target + READY_TIMEOUT
            self._drift_cand = None
            if eff_cur is not None and eff_cur >= target:
                delta = eff_cur - target
                if delta < 0.05:
                    self._resume(ib)
                    self._pause_started = self._fill_until = None
                    self._pause_init_ln = None
                    self._actual_delay = target
                    self._cur = target
                    self._seek_check = None
                    self._fix_left = 0
                    self._settle_until = now + 1.2
                    self.state, self._deadline = "running", None
                elif self._seek_broken_service is not None and self._seek_broken_service == self._service:
                    log("picture: relative seek unsupported on this service (%.2fs -> %.2fs); re-anchoring from live"
                        % (eff_cur, target))
                    self._reanchor_from_live(ib, target, now)
                else:
                    if self._seek_check is not None and prev_target > target:
                        step_from = prev_target
                        from_delay = self._seek_check["from_delay"]
                        t0 = self._seek_check["t"]
                        pos0 = self._seek_check["pos"]
                    else:
                        step_from = phys_cur if (phys_cur is not None and phys_cur > target) else eff_cur
                        from_delay = step_from
                        t0 = now
                        pos0 = self._pos_only(ib)
                    log("picture: user changed %.2fs -> %.2fs; relative request=%+.2fs (total=%+.2fs) pos=%s paused=%s"
                        % (step_from, target, step_from - target, from_delay - target,
                           "NA" if pos0 is None else "%.2f" % pos0, self._paused(ib)))
                    self._seek_delay(ib, step_from, target)
                    self._resume(ib)
                    self._pause_started = self._fill_until = None
                    self._pause_init_ln = None
                    self._cur = target
                    self.state, self._deadline = "running", None
                    self._fix_left = 0
                    self._seek_check = {
                        "t": t0,
                        "pos": pos0,
                        "from_delay": from_delay,
                        "target": target,
                        "retried": False,
                    }
                    self._fix_at = now + SETTLE_WAIT
            elif prev_state == "filling" and self._pause_started is not None:
                # Already paused and filling: update target and extend/shorten _fill_until without resetting _pause_started!
                self._seek_check = None
                self._pause(ib)
                self._fill_until = self._pause_started + max(0.1, target - self._pause_base)
                self.state = "filling"
            else:
                base = eff_cur if eff_cur is not None else 0.0
                phys_base = phys_cur if (phys_cur is not None and 0.0 <= phys_cur < target) else base
                self._seek_check = None
                self._pause(ib)
                pl = self._pos_len(ib)
                self._pause_init_ln = pl[1] if pl is not None else None
                self._pause_base = base
                self._pause_started = now
                self._fill_until = now + max(0.1, target - phys_base)
                self.state = "filling"
            self._ensure_timer()
        except Exception as e:
            self._fail(T("Timeshift failed: %s", e))

    def prepare(self):
        """Open the timeshift buffer now, while the picture is still live and nothing is delayed."""
        if self.state != "off":
            return True
        ib = self._infobar()
        if ib is None:
            return True
        if monotonic() - self._released_at < 3.0:
            return False                     # a buffer was closed a moment ago: wait, the caller asks again
        try:
            if self._enabled(ib):
                return True
            self._quiet(ib)
            self._acquire(ib)
            self._resume(ib)                 # starting a buffer pauses the picture on some images: back to live at once
        except Exception as e:
            log("timeshift buffer could not be opened ahead: %s" % e)
            self.release()
        return True

    def adjust(self, delta):
        if self.state == "paused":
            cur = self.current()
            base = cur if cur is not None else self.target
        elif self.state == "filling" and self.target > 0:
            base = self.target
        elif self.state == "running":
            cur = self.current()
            base = cur if cur is not None else self.target
        else:
            cur = self.current()
            base = cur if cur is not None else 0.0
        self.start(round(max(0.0, min(600.0, base + float(delta))), 1))

    def preparation_state(self):
        """Main-thread observation used before starting audio: is the new buffer playing and advancing?"""
        try:
            ib = self._infobar()
            if ib is None or not self._enabled(ib):
                return None
            position = self._pos_len(ib)
            return {"paused": self._paused(ib), "position": position[0] if position is not None else None}
        except Exception as e:
            log("timeshift readiness is unavailable: %r" % e)
            return None

    def toggle_pause(self):
        self.suspend_monitor()
        ib = self._infobar()
        if ib is None:
            return
        try:
            active = self._ib is not None and self._same_service(ib)
            if active and self._paused(ib) is True:
                cur = self.current()
                self._resume(ib)
                self._pause_started = None
                self._fill_until = None
                self._pause_init_ln = None
                self._seek_check = None
                if cur is not None and cur > 0:
                    self.target = round(cur, 1)
                    self.requested = self.target
                self._actual_delay = self.target
                self._cur = self.target
                self._settle_until = monotonic() + 1.2
                self._meter_ok = False
                self._drift_cand = None
                self.state, self.note = "running", ""
                self._deadline = self._missing_since = None
                if callable(self.on_manual_delay) and self.target > 0:
                    try:
                        self.on_manual_delay(self.target)
                    except Exception as e:
                        log("remembering manual freeze delay failed: %s" % e)
            else:
                base = self.current() if active else 0.0
                if base is None:
                    base = self._actual_delay if (active and self._actual_delay > 0) else (
                        self.target if (active and self.state in ("running", "filling")) else 0.0)
                self._acquire(ib)
                self._pause(ib)
                self._seek_check = None
                self._reanchor_at = self._reanchor_deadline = None
                self._pause_base = max(0.0, float(base or 0.0))
                self._pause_started = monotonic()
                self._fill_until = None
                self._pause_init_ln = None
                self._drift_cand = None
                self.state, self.note = "paused", ""
                self._missing_since = None
                self._ensure_timer()
        except Exception as e:
            self._fail(T("Freezing failed: %s", e))

    def release(self):
        if self._owned:
            self._released_at = monotonic()
        ib = self._infobar()
        same = ib is not None and self._same_service(ib)
        owned, borrowed = self._owned, self._borrowed
        self._forget()
        if not same:
            return
        try:
            if not self._enabled(ib):
                return
            if borrowed is not None:
                # Restore the previous playback state, without closing its buffer.
                cur, target = self.current(), borrowed["delay"]
                if target is not None and cur is not None:
                    if borrowed["paused"]:
                        target += monotonic() - borrowed["time"]
                    self._seek_delay(ib, cur, target)
                if borrowed["paused"]:
                    self._pause(ib)
                else:
                    self._resume(ib)
            elif owned:
                # activateTimeshiftEnd() is not a "go live" call on OpenBH.
                self._resume(ib)
                if callable(getattr(ib, "doSeek", None)):
                    try:
                        self._seek_live(ib)
                    except Exception:
                        pass
                # Respect any save the user requested after we started the buffer.
                self._stop_timeshift_to_live(ib)
        except Exception as e:
            log("release failed: %s" % e)

    def force_close(self):
        """Manual STOP: back to live and close the timeshift buffer, also one this plugin no longer tracks
        (after a zero delay, a channel memory restore or a buffer the image opened). Main thread only."""
        ib = self._infobar()
        self._released_at = monotonic()
        self._forget()
        if ib is None:
            return
        try:
            if not self._enabled(ib):
                return
        except Exception:
            return
        log("stop: closing timeshift and returning to live TV")
        try:
            self._resume(ib)
        except Exception as e:
            log("stop: resume failed: %s" % e)
        if callable(getattr(ib, "doSeek", None)):
            try:
                self._seek_live(ib)
            except Exception:
                pass
        try:
            self._stop_timeshift_to_live(ib)
        except Exception as e:
            log("stop: InfoBar could not stop timeshift: %s" % e)
        try:
            if self._enabled(ib):
                ts = self._timeshift(ib)
                if ts is not None and callable(getattr(ts, "stopTimeshift", None)):
                    ts.stopTimeshift()
                    log("stop: timeshift closed on the service directly")
        except Exception as e:
            log("stop: timeshift is still open: %s" % e)
        self._unquiet()

    def _tick(self):
        if self.state not in ("filling", "running", "paused"):
            return
        ib = self._infobar()
        if ib is None or not self._same_service(ib):
            self.on_service_changed()
            self.note = T("The channel changed; the picture delay was cancelled")
            return
        try:
            now = monotonic()
            if self.state == "running":
                if not self._verify_resume(ib, now):
                    return
                self._watch_playback_progress(ib, now)
            if self._reanchor_at is not None:
                if now < self._reanchor_at:
                    return
                ts = self._timeshift(ib)
                still_active = bool(ts is not None and callable(getattr(ts, "isTimeshiftActive", None)) and ts.isTimeshiftActive())
                if (self._enabled(ib) and still_active) and self._reanchor_deadline is not None and now < self._reanchor_deadline:
                    self._close_buffer_to_live(ib)
                    self._reanchor_at = now + 0.4
                    return
                self._reanchor_at = None
                self._reanchor_deadline = None
                self._owned = True
                self._acquire(ib)
                now = monotonic()
                self._pause(ib)
                pl = self._pos_len(ib)
                self._pause_init_ln = pl[1] if pl is not None else None
                self._pause_base = 0.0
                self._pause_started = now
                self._fill_until = now + max(0.1, self.target)
                self._deadline = now + self.target + READY_TIMEOUT
                self._missing_since = None
                self.state = "filling"
                self._cur = 0.0
                log("picture: re-anchored from live; pausing %.2fs for requested delay" % self.target)
                return
            if not self._enabled(ib):
                self._forget()
                self.note = T("Timeshift was closed")
                return
            self._cur = self.current()
            if self._cur is None:
                if self._missing_since is None:
                    self._missing_since = now
                if self.state in ("filling", "paused") and now - self._missing_since >= READY_TIMEOUT:
                    self._fail(T("Could not measure the timeshift; stopped waiting and restored playback"))
                    return
            else:
                self._missing_since = None
            seekstate = getattr(ib, "seekstate", None)
            normal = getattr(ib, "SEEK_STATE_PLAY", None)
            if self.state == "running" and normal is not None and seekstate != normal and self._paused(ib) is not True:
                # Fast-forward / rewind / slow motion belong to the viewer.
                if isinstance(seekstate, (tuple, list)) and len(seekstate) >= 3 and (seekstate[1] or seekstate[2]):
                    self._manual_seek = True
                self._fix_left = 0
                self._seek_check = None
                self.suspend_monitor()
                return
            if self._manual_seek and self.state == "running" and seekstate == normal:
                if self._cur is None:
                    self.suspend_monitor()
                    return
                self._manual_seek = False
                self.target = round(self._cur, 1)
                self.requested = self.target
                self._actual_delay = self.target
                self._settle_until = now + 1.0
                self.suspend_monitor()
                if callable(self.on_manual_delay):
                    try:
                        self.on_manual_delay(self.target)
                    except Exception as e:
                        log("remembering manual picture delay failed: %s" % e)
            if self.state == "filling":
                wall_delay = (self._pause_base + (now - self._pause_started)) if self._pause_started is not None else 0.0
                if (self._fill_until is not None and now >= self._fill_until) or wall_delay >= self.target:
                    pl = self._raw
                    ln_grew = (pl is not None and self._pause_init_ln is not None and pl[1] > self._pause_init_ln + 0.5)
                    wait_limit = (self._fill_until or now) + min(1.5, max(0.4, self.target * 0.25))
                    raw_buf = max(0.0, pl[1] - pl[0]) if pl is not None and pl[1] >= pl[0] else None
                    if ln_grew and raw_buf is not None and raw_buf < self.target - 0.1 and now < wait_limit:
                        return
                    self._resume(ib)
                    self._pause_started = None
                    self._fill_until = None
                    self._pause_init_ln = None
                    self._actual_delay = self.target
                    self._cur = self.target
                    self._seek_check = None
                    self._settle_until = now + 1.2
                    self._meter_ok = False
                    self._drift_cand = None
                    self.state, self._deadline = "running", None
                elif self._deadline is not None and now >= self._deadline:
                    self._fail(T("Timeshift did not reach the requested delay; playback restored"))
            elif self.state == "paused" and self._paused(ib) is False:
                self.suspend_monitor()
                if self._cur is not None and self._cur > 0:
                    self.target = round(self._cur, 1)
                    self.requested = self.target
                self._actual_delay = self.target
                self._pause_started = None
                self._pause_init_ln = None
                self._seek_check = None
                self._settle_until = now + 1.2
                self._meter_ok = False
                self._drift_cand = None
                self.state = "running"
                if callable(self.on_manual_delay) and self.target > 0:
                    try:
                        self.on_manual_delay(self.target)
                    except Exception as e:
                        log("remembering unpaused picture delay failed: %s" % e)
            elif self.state == "running" and self._paused(ib) is True:
                if self._resume_check is not None:
                    return  # bounded DreamOS resume verification owns this transition
                self.suspend_monitor()
                self._pause_base = self._actual_delay if self._actual_delay > 0 else (
                    self._cur if self._cur is not None else self.target)
                self._pause_started = now
                self._pause_init_ln = None
                self._seek_check = None
                self.state = "paused"
            elif self.state == "running" and self._seek_check is not None and now >= self._fix_at:
                chk = self._seek_check
                wanted = max(0.0, chk["from_delay"] - self.target)
                if wanted < 0.1:
                    self._actual_delay = self.target
                    self._seek_check = None
                    self._settle_until = now + 1.2
                    self._meter_ok = False
                else:
                    pos_now = self._pos_only(ib)
                    pos0 = chk.get("pos")
                    if pos_now is not None and pos0 is not None:
                        dt = max(0.0, now - chk["t"])
                        got = (pos_now - pos0) - dt
                        threshold = max(0.35, wanted * 0.4)
                        if got >= threshold:
                            log("picture: relative seek verified (wanted=+%.2fs got=%+.2fs -> %.2fs)"
                                % (wanted, got, self.target))
                            self._actual_delay = self.target
                            self._seek_check = None
                            self._settle_until = now + 1.2
                            self._meter_ok = False
                        else:
                            remaining = max(0.1, wanted - max(0.0, got))
                            if not chk.get("retried"):
                                res = self._native_seek_relative(ib, remaining)
                                log("picture: InfoBar relative seek did not move enough (wanted=+%.2fs got=%+.2fs); native seekRelative=%s"
                                    % (wanted, got, res))
                                if res < 0:
                                    self._seek_broken_service = self._service
                                    log("picture: native seekRelative rejected (%s); re-anchoring from live to %.2fs"
                                        % (res, self.target))
                                    self._reanchor_from_live(ib, self.target, now)
                                else:
                                    chk["retried"] = True
                                    self._fix_at = now + SETTLE_WAIT
                            else:
                                self._seek_broken_service = self._service
                                log("picture: native retry did not move position (wanted=+%.2fs got=%+.2fs); re-anchoring from live to %.2fs"
                                    % (wanted, got, self.target))
                                self._reanchor_from_live(ib, self.target, now)
                    else:
                        res = self._native_seek_relative(ib, wanted)
                        if res < 0:
                            self._seek_broken_service = self._service
                            log("picture: play position unavailable and native seekRelative=%s; re-anchoring from live to %.2fs"
                                % (res, self.target))
                            self._reanchor_from_live(ib, self.target, now)
                        else:
                            self._actual_delay = self.target
                            self._seek_check = None
                            self._settle_until = now + 1.2
                            self._meter_ok = False
            elif self.state == "running" and self._seek_check is None:
                self._sync_running_delay(ib, now)
        except Exception as e:
            self._fail(T("Timeshift monitoring failed: %s", e))

    def info(self):
        if self.state != "off" and self._ib is not None:
            ib = self._infobar()
            if ib is None or not self._same_service(ib):
                self.on_service_changed()
        cur = self._cur
        if self.state in ("paused", "filling") and self._pause_started is not None:
            paused_cur = max(0.0, self._pause_base + (_now() - self._pause_started))
            if self.state == "filling":
                paused_cur = min(self.target, paused_cur)
            cur = paused_cur
        elif self.state == "filling" and self._reanchor_at is not None:
            cur = 0.0
        elif self.state == "running":
            cur = self._actual_delay
        return {"state": self.state, "target_s": round(self.target, 1),
                # still building / correcting the delay (the screen shows it green until it is done)
                "busy": self.state == "filling" or (self.state == "running" and (self._fix_left > 0 or self._seek_check is not None)),
                "current_s": (0.0 if self.state == "off" else
                              None if cur is None else round(cur, 1)),
                "note": self.note}
