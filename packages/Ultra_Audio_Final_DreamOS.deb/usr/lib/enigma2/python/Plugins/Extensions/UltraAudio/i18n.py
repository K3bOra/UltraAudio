# -*- coding: utf-8 -*-
"""UltraAudio interface languages (English / Arabic / Turkish).

* The source text in the code IS the English text:  T("Settings"), T("%d channels", n).
* Every other language is one JSON pack, locale_packs/<code>.json:
      {"_meta": {"schema": 1, "code": "ar", "complete": true}, "translations": {"Settings": "...", ...}}
  A pack is only offered when it is marked complete. A text missing from a pack falls back to English, never to an
  empty string. Provider / channel names are never translated.
* The language is the "language" setting (the MENU card and the web page both change it).
"""
from __future__ import division
import json
import os
import threading

from .compat import mtime_sig, open_text, to_text

PACK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locale_packs")
PACK_SCHEMA = 1
LANGUAGES = (("en", u"English"), ("ar", u"العربية"), ("tr", u"Türkçe"))
LANGS = tuple(c for c, _n in LANGUAGES)
LANG_NAMES = dict(LANGUAGES)
RTL = frozenset(("ar",))

_lock = threading.RLock()
_packs = {}
_sig = None
_cache = "en"


def _load_pack(code):
    with _lock:
        if code in _packs:
            return _packs[code]
    data = {}
    try:
        with open_text(os.path.join(PACK_DIR, "%s.json" % code)) as f:
            raw = json.load(f)
        meta = raw.get("_meta") or {}
        if meta.get("schema") == PACK_SCHEMA and meta.get("code") == code and meta.get("complete") is True:
            tr = raw.get("translations")
            if isinstance(tr, dict):
                data = dict((to_text(k), to_text(v)) for k, v in tr.items() if v not in (None, ""))
    except (EnvironmentError, ValueError):
        data = {}
    with _lock:
        _packs[code] = data
    return data


def available(code):
    return code == "en" or bool(_load_pack(code))


def invalidate():
    """Forget the cached language (set_settings calls this: some flash file systems keep a coarse mtime)."""
    global _sig
    with _lock:
        _sig = None


def lang():
    global _sig, _cache
    try:
        from . import store
        sig = mtime_sig(store.SETTINGS_FILE)
    except (EnvironmentError, ImportError):
        sig = None
    with _lock:
        if sig is not None and sig == _sig:
            return _cache
    code = "en"
    try:
        from . import store
        code = store.get_settings().get("language", "en")
    except Exception:
        pass
    if code not in LANGS or not available(code):
        code = "en"
    with _lock:
        _sig, _cache = sig, code
    return code


def T(text, *args):
    """Translate an English source text; with arguments it is %-formatted afterwards."""
    text = u"" if text is None else to_text(text)
    args = tuple(to_text(a) if isinstance(a, bytes) else a for a in args)
    code = lang()
    if code != "en" and text:
        text = _load_pack(code).get(text) or text
    if args:
        try:
            return text % args
        except (TypeError, ValueError):
            return text
    return text


_ = T


def direction(code=None):
    return "rtl" if (code or lang()) in RTL else "ltr"


def web_bundle():
    """What the web page needs: language, direction and the whole pack (English = empty, the page text is English)."""
    code = lang()
    return {"lang": code, "dir": direction(code), "strings": _load_pack(code) if code != "en" else {},
            "languages": [list(x) for x in LANGUAGES if available(x[0])]}
