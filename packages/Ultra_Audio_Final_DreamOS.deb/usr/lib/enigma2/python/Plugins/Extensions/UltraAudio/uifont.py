# -*- coding: utf-8 -*-
"""Private UI font; never replace a receiver skin's global Regular alias."""
from __future__ import division
import os
from .compat import native

FONTS = (
    ('skin', 'Image default', '', 'Regular'),
    ('shahid', 'Shahid', 'Shahid.ttf', 'UltraAudioShahid'),
    ('amiri', 'Amiri', 'Amiri.ttf', 'UltraAudioAmiri'),
    ('osama', 'Osama', 'Osama.otf', 'UltraAudioOsama'),
    ('cocon', 'Cocon', 'Cocon.otf', 'UltraAudioCocon'),
    ('xbzar', 'XB Zar', 'XBZar.ttf', 'UltraAudioXBZar'),
    ('yakout', 'Yakout Bold', 'YakoutBold.ttf', 'UltraAudioYakout'),
)
FONT_IDS = tuple(item[0] for item in FONTS)
_registered = set()


def selected():
    try:
        from . import store
        key = store.get_settings().get('ui_font', 'skin')
    except Exception:
        key = 'skin'
    return key if key in FONT_IDS else 'skin'


def label(key):
    return next((item[1] for item in FONTS if item[0] == key), FONTS[0][1])


def face():
    key = selected()
    unused, unused_label, filename, alias = next(item for item in FONTS if item[0] == key)
    if key == 'skin':
        return 'Regular'
    if key not in _registered:
        try:
            from enigma import addFont
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets', 'fonts', filename)
            if not os.path.isfile(path):
                return 'Regular'
            try:
                addFont(native(path), native(alias), 100, 0)
            except TypeError:
                addFont(native(path), native(alias), 100, 0, 0)
            _registered.add(key)
        except Exception:
            # The independent repair screen must stay usable on broken installs.
            return 'Regular'
    return alias
