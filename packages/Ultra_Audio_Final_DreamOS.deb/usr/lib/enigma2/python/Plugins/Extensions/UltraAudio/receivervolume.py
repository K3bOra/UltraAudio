# -*- coding: utf-8 -*-
"""Receiver master volume; callers dispatch these operations to Enigma2's main loop."""
from __future__ import division


def snapshot():
    try:
        from enigma import eDVBVolumecontrol
        control = eDVBVolumecontrol.getInstance()
        return {"available": True, "value": max(0, min(100, int(control.getVolume()))),
                "muted": bool(control.isMuted())}
    except Exception:
        return {"available": False, "value": None, "muted": False}


def apply(value):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 100:
        raise ValueError("Volume must be an integer between 0 and 100")
    try:
        from enigma import eDVBVolumecontrol
        control = eDVBVolumecontrol.getInstance()
        control.setVolume(value, value)
        # Keep the receiver's normal volume setting in step with the hardware.
        # Leave mute ownership and playback processes untouched.
        try:
            from Components.config import config
            config.audio.volume.value = value
        except (ImportError, AttributeError):
            pass
        return snapshot()
    except Exception:
        return {"available": False, "value": None, "muted": False}
