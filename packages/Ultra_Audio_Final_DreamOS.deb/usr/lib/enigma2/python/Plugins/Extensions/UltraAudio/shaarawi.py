# -*- coding: utf-8 -*-
"""Published Shaarawi audio sources; catalogue checked on 27 October 2026.

Live: Quran University / EDC's published Shaarawi interpretation radio.
Recordings: Internet Archive item tafseer-quran--by-alsha3rawy-sound-vocal--full.
This archival edition uses low bitrate speech audio. Many files combine several
lessons; the last two combine surah ranges. Titles describe source groupings,
without claiming this is a complete verse-by-verse interpretation.
Links are bundled locally; no web scraping runs during receiver startup.
"""
from __future__ import division, unicode_literals   # Arabic titles are text on Python 2 too
LIVE_NAME = u"إذاعة الشعراوي — مباشر"
LIVE_URL = "https://serverkw.quran-uni.com:8202/;*.mp3"
RECORDINGS = (
    ('مقدمة التفسير', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/000_Intro.mp3'),
    ('تفسير سورة الفاتحة', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/001_Al-Fatihah.mp3'),
    ('تفسير سورة البقرة', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/002_Al-Baqarah.mp3'),
    ('تفسير سورة آل عمران', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/003_Al-Imran.mp3'),
    ('تفسير سورة النساء', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/004_An-Nisa.mp3'),
    ('تفسير سورة المائدة', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/005_Al-Maidah.mp3'),
    ('تفسير سورة الأنعام', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/006_Al-Anam.mp3'),
    ('تفسير سورة الأعراف', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/007_Al-Araf.mp3'),
    ('تفسير سورة الأنفال', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/008_Al-Anfal.mp3'),
    ('تفسير سورة التوبة', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/009_At-Taubah.mp3'),
    ('تفسير سورة يونس', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/010_Yunus.mp3'),
    ('تفسير سورة هود', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/011_Hud.mp3'),
    ('تفسير سورة يوسف', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/012_Yusuf.mp3'),
    ('تفسير سورة الرعد', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/013_Ar-Rad.mp3'),
    ('تفسير سورة إبراهيم', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/014_Ibrahim.mp3'),
    ('تفسير سورة الحجر', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/015_Al-Hijr.mp3'),
    ('تفسير سورة النحل', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/016_An-Nahl.mp3'),
    ('تفسير سورة الإسراء', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/017_Al-Isra.mp3'),
    ('تفسير سورة الكهف', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/018_Al-Kahf.mp3'),
    ('تفسير سورة مريم', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/019_Maryam.mp3'),
    ('تفسير سورة طه', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/020_Ta-Ha.mp3'),
    ('تفسير سورة الأنبياء', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/021_Al-Anbiya.mp3'),
    ('تفسير سورة الحج', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/022_Al-Haj.mp3'),
    ('تفسير سورة المؤمنون', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/023_Al-Muminen.mp3'),
    ('تفسير سورة النور', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/024_An-Nur.mp3'),
    ('تفسير سورة الفرقان', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/025_Al-Furqan.mp3'),
    ('تفسير سورة الشعراء', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/026_Ash-Shuara.mp3'),
    ('تفسير سورة النمل', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/027_An-Naml.mp3'),
    ('تفسير سورة القصص', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/028_Al-Qasas.mp3'),
    ('تفسير سورة العنكبوت', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/029_Al-Ankabot.mp3'),
    ('تفسير سورة الروم', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/030_Ar-Rum.mp3'),
    ('تفسير سورة لقمان', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/031_Luqman.mp3'),
    ('تفسير سورة السجدة', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/032_As-Sajdah.mp3'),
    ('تفسير سورة الأحزاب', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/033_Al-Ahzab.mp3'),
    ('تفسير سورة سبأ', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/034_Saba.mp3'),
    ('تفسير سورة فاطر', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/035_Fatir.mp3'),
    ('تفسير سورة يس', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/036_Ya-Sen.mp3'),
    ('تفسير سورة الصافات', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/037_As-Saffat.mp3'),
    ('تفسير سورة ص', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/038_Sad.mp3'),
    ('تفسير سورة الزمر', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/039_Az-Zumar.mp3'),
    ('تفسير سورة غافر', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/040_Ghafir.mp3'),
    ('تفسير سورة فصلت', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/041_Fussilat.mp3'),
    ('تفسير سورة الشورى', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/042_Ash-Shura.mp3'),
    ('تفسير سورة الزخرف', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/043_Az-Zukhruf.mp3'),
    ('تفسير سورة الدخان', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/044_Ad-Dukhan.mp3'),
    ('تفسير سورة الجاثية', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/045_Al-Jathiya.mp3'),
    ('تفسير سورة الأحقاف', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/046_Al-Ahqaf.mp3'),
    ('تفسير سورة محمد', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/047_Muhammad.mp3'),
    ('تفسير سورة الفتح', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/048_Al-Fath.mp3'),
    ('تفسير سورة الحجرات', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/049_Al-Hujurat.mp3'),
    ('تفسير سورة ق', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/050_Qaf.mp3'),
    ('تفسير من الذاريات إلى الممتحنة — ملف مجمع', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/051_a_060.mp3'),
    ('تفسير من الصف إلى الناس — ملف مجمع', 'https://archive.org/download/tafseer-quran--by-alsha3rawy-sound-vocal--full/061_a_114.mp3'),
)
