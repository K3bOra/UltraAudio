# -*- coding: utf-8 -*-
"""Owner-approved default orders. Display policy only: never rename or rewrite links."""
import re
from .compat import to_text

ANIS_CHANNEL_ORDER = (
    tuple("Anis Sport %d" % n for n in range(1, 10))
    + tuple("Anis Xtra %d" % n for n in range(1, 3))
    + tuple("Anis EN %d" % n for n in range(1, 3))
    + tuple("Anis FR %d" % n for n in range(1, 3))
    + tuple("Anis Italy %d" % n for n in range(1, 3))
    + tuple("Anis DE %d" % n for n in range(1, 3))
    + tuple("Anis Thm8h %d" % n for n in range(1, 4))
    + ("Anis Shasha", "Anis Shahid")
    + tuple("Anis Al Kass %d" % n for n in range(1, 3))
    + tuple("Anis Max %d" % n for n in range(1, 7))
    + tuple("Anis Max %d Low" % n for n in range(1, 7))
)
FOX_CHANNEL_ORDER = (
    tuple("FoX FM %d" % n for n in range(1, 10))
    + tuple("FoX FM Xtra %d" % n for n in range(1, 4))
    + tuple("FoX FM EN %d" % n for n in range(1, 3))
    + tuple("FoX FM FR %d" % n for n in range(1, 3))
    + tuple("FoX FM StarzPlay %d" % n for n in range(1, 3))
    + tuple("FoX FM Shasha %d" % n for n in range(1, 3))
    + tuple("FoX FM Thmanyah %d" % n for n in range(1, 4))
    + tuple("FoX FM Shahid %d" % n for n in range(1, 3))
    + tuple("FoX FM Alkass %d" % n for n in range(5, 9))
    + tuple("FoX FM Live %d" % n for n in range(1, 5))
)
RADIO_FOLDER_ORDER = ("radio_ar", "radio_turkish", "radio_quran", "radio_sayed_saeed", "radio_shaarawi")
RADIO_FOLDER_RANK = dict((key, n) for n, key in enumerate(RADIO_FOLDER_ORDER))


def _compact(name):
    value = re.sub(r"[\W_]+", "", to_text(name).lower(), flags=re.UNICODE)
    if value.startswith(u"انيس"):
        value = "anis" + value[len(u"انيس"):]
    if value.startswith("anissports"):
        value = "anissport" + value[len("anissports"):]
    for alias in ("anisthmanyah", "anisthamanyah", "anisthmanyeh"):
        if value.startswith(alias):
            value = "anisthm8h" + value[len(alias):]
            break
    return value


_ANIS_RANK = dict((_compact(name), n) for n, name in enumerate(ANIS_CHANNEL_ORDER))
_FOX_RANK = dict((_compact(name), n) for n, name in enumerate(FOX_CHANNEL_ORDER))
_ANIS_RANK["anisshasha1"] = _ANIS_RANK["anisshasha"]
_ANIS_RANK["anisshahid1"] = _ANIS_RANK["anisshahid"]


def channel_rank(name, provider=""):
    key, source = _compact(name), _compact(provider)
    if key.startswith("anis") or source == "anis":
        if not key.startswith("anis"):
            key = _compact("anis " + to_text(name))
        return _ANIS_RANK.get(key, len(ANIS_CHANNEL_ORDER))
    if key.startswith("foxfm") or source in ("foxfm", "fox"):
        if not key.startswith("foxfm"):
            key = _compact("foxfm " + to_text(name))
        return _FOX_RANK.get(key, len(FOX_CHANNEL_ORDER))
    return None
