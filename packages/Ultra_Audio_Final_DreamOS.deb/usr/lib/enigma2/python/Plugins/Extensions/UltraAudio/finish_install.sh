#!/bin/sh
# Runs after DPKG/APT or OPKG has released its lock; logs progress to /tmp/ultraaudio-install.log.
set -u
export LC_ALL=C
export DEBIAN_FRONTEND=noninteractive
ROOT=/usr/lib/enigma2/python/Plugins/Extensions/UltraAudio
LOG=/tmp/ultraaudio-install.log
DEPS_LOG=/tmp/ultraaudio-deps.log
LOCK=/tmp/ultraaudio-finalize.lock
RUN_RC=/tmp/ultraaudio-run-$$.status
SOURCE_PKG=${1:-}
SOURCE_STAT=${2:-}
PKG_TMP_DIR=/tmp

if ! mkdir "$LOCK" 2>/dev/null; then
    previous=$(cat "$LOCK/pid" 2>/dev/null || :)
    case "$previous" in ''|*[!0-9]*) previous=0 ;; esac
    if [ "$previous" -gt 1 ] && kill -0 "$previous" 2>/dev/null; then
        printf '[INFO] UltraAudio setup is already running.\n'
        exit 0
    fi
    rm -f "$LOCK/pid" 2>/dev/null || :
    rmdir "$LOCK" 2>/dev/null || exit 1
    mkdir "$LOCK" 2>/dev/null || exit 1
fi
echo "$$" > "$LOCK/pid"
cleanup() { rm -f "$RUN_RC" "$LOCK/pid" 2>/dev/null; rmdir "$LOCK" 2>/dev/null || :; }
trap cleanup 0
trap 'exit 1' 1 2 15
: > "$LOG"
print() { printf '%s\n' "$*"; printf '%s\n' "$*" >> "$LOG" 2>/dev/null || :; }
fail() { printf 'failed\n' > /tmp/ultraaudio-setup.status; print "[ERROR] $*"; print "[INFO] Review $LOG and $DEPS_LOG"; exit 1; }

run_logged() {
    rm -f "$RUN_RC" 2>/dev/null || :
    ( "$@"; printf '%s\n' "$?" > "$RUN_RC" ) 2>&1 | tee -a "$LOG"
    rc=$(cat "$RUN_RC" 2>/dev/null || :)
    rm -f "$RUN_RC" 2>/dev/null || :
    case "$rc" in ''|*[!0-9]*) return 1 ;; *) return "$rc" ;; esac
}

find_python() {
    if command -v pidof >/dev/null 2>&1; then
        for pid in $(pidof enigma2 2>/dev/null); do
            if [ -r "/proc/$pid/maps" ]; then
                if grep -q 'libpython2\.' "/proc/$pid/maps" 2>/dev/null; then
                    for p in python2 python2.7 python; do
                        command -v "$p" >/dev/null 2>&1 && { command -v "$p"; return 0; }
                    done
                elif grep -q 'libpython3\.' "/proc/$pid/maps" 2>/dev/null; then
                    for p in python3 python; do
                        command -v "$p" >/dev/null 2>&1 && { command -v "$p"; return 0; }
                    done
                fi
            fi
        done
    fi
    for p in python3 python2 python2.7 python; do
        command -v "$p" >/dev/null 2>&1 && { command -v "$p"; return 0; }
    done
    return 1
}

# Wait until parent dpkg / apt-get / opkg has exited and released its lock.
count=0
while pidof dpkg apt-get apt aptitude opkg opkg-cl >/dev/null 2>&1; do
    count=$((count + 1))
    [ "$count" -le 180 ] || fail 'Package manager remained busy for over six minutes.'
    sleep 2
done

PYTHON=$(find_python) || fail 'Python interpreter (2.7 or 3.x) is unavailable.'

installed_pkg_version() {
    if command -v dpkg >/dev/null 2>&1 && [ -f /var/lib/dpkg/status ]; then
        dpkg -s enigma2-plugin-extensions-ultraaudio 2>/dev/null | sed -n 's/^Version: //p' | head -n 1
    elif command -v opkg >/dev/null 2>&1; then
        opkg status enigma2-plugin-extensions-ultraaudio 2>/dev/null | sed -n 's/^Version: //p' | head -n 1
    fi
}

package_metadata() {
    local_pkg=$1
    "$PYTHON" -E -s "$ROOT/updater.py" --control "$local_pkg" 2>/dev/null
}

package_matches() {
    local_pkg=$1
    [ -f "$local_pkg" ] && [ ! -L "$local_pkg" ] || return 1
    case "$local_pkg" in "$PKG_TMP_DIR"/*.deb|"$PKG_TMP_DIR"/*.ipk) ;; *) return 1 ;; esac
    metadata=$(package_metadata "$local_pkg") || return 1
    printf '%s\n' "$metadata" | grep -qx 'Package: enigma2-plugin-extensions-ultraaudio' || return 1
    file_version=$(printf '%s\n' "$metadata" | sed -n 's/^Version: //p' | head -n 1)
    [ -n "$file_version" ] && [ "$file_version" = "$installed_version" ]
}

cleanup_source_pkg() {
    installed_version=$(installed_pkg_version)
    [ -n "$installed_version" ] || return 0
    if [ -n "$SOURCE_PKG" ] && [ -n "$SOURCE_STAT" ] && package_matches "$SOURCE_PKG"; then
        current_stat=$(stat -c '%d:%i:%s:%Y' "$SOURCE_PKG" 2>/dev/null || :)
        if [ "$current_stat" = "$SOURCE_STAT" ] && rm -f -- "$SOURCE_PKG" 2>/dev/null; then
            print "[CLEANUP] Installed package removed from /tmp: ${SOURCE_PKG##*/}"
            return 0
        fi
    fi
    sole=''
    count=0
    for p in "$PKG_TMP_DIR"/*.deb "$PKG_TMP_DIR"/*.ipk; do
        [ -e "$p" ] || continue
        if package_matches "$p"; then
            sole=$p
            count=$((count + 1))
            [ "$count" -le 1 ] || break
        fi
    done
    if [ "$count" -eq 1 ] && rm -f -- "$sole" 2>/dev/null; then
        print "[CLEANUP] Installed package removed from /tmp: ${sole##*/}"
    fi
}

print '======================================================'
print '                Ultra Audio Final V1'
print '                 Ahmed L-HadarY'
print '======================================================'
print '[1/5] Package configured; package manager has finished.'
print '[2/5] Detecting receiver environment and Enigma2 Python...'
PYVER=$("$PYTHON" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null) || fail 'Python could not be detected.'
print "[OK] Installed Ultra Audio Final V1 | Python $PYVER"

print '[3/5] Detecting image feed and Python-compatible component commands.'
print '[4/5] Checking Python modules and audio libraries...'
[ -f "$ROOT/deps.sh" ] || fail 'Embedded component checker is missing.'
if run_logged env ULTRAAUDIO_DEPS_LOG="$DEPS_LOG" \
    /bin/sh "$ROOT/deps.sh" --install; then
    print '[OK] Required components verified.'
else
    print '[ERROR] Component setup failed; automatic GUI restart cancelled.'
    fail 'Use Settings > Install components after fixing the receiver feed.'
fi

cleanup_source_pkg

print '[5/5] Completing installation...'
print '======================================================'
printf 'ready\n' > /tmp/ultraaudio-setup.status
print '              Ultra Audio Final V1'
print '                SETUP SUCCESSFUL'
print '======================================================'
sync 2>/dev/null || :
if [ "${ULTRAAUDIO_ONLINE_UPDATE:-0}" = 1 ]; then
    print '[OK] Online update complete; GUI restart is controlled by Enigma2.'
    exit 0
fi

if pidof enigma2 >/dev/null 2>&1; then
    print '[OK] Enigma2 GUI restart scheduled in 5 seconds.'
    (
        sleep 5
        if command -v systemctl >/dev/null 2>&1 && systemctl is-active enigma2 >/dev/null 2>&1; then
            systemctl restart enigma2 >/dev/null 2>&1 || killall -9 enigma2 >/dev/null 2>&1 || kill -9 $(pidof enigma2) >/dev/null 2>&1 || :
        elif command -v killall >/dev/null 2>&1; then
            killall -9 enigma2 >/dev/null 2>&1 || :
        else
            kill -9 $(pidof enigma2) >/dev/null 2>&1 || :
        fi
    ) </dev/null >/dev/null 2>&1 &
else
    print '[INFO] Enigma2 is not active; GUI restart is unnecessary.'
fi
exit 0
