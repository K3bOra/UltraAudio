# -*- coding: utf-8 -*-
"""Pixel-measured guide lines and compact delay controls; no receiver imports."""
from __future__ import unicode_literals
import unicodedata


def guide_lines(text, measure, width):
    words = text.split()
    lines, line = [], ''
    for word in words:
        candidate = (line + ' ' + word).strip()
        if measure(candidate) <= width:
            line = candidate
            continue
        if line:
            lines.append(line)
            line = ''
        if measure(word) <= width:
            line = word
            continue
        clusters = []
        for char in word:
            if clusters and unicodedata.combining(char):
                clusters[-1] += char
            else:
                clusters.append(char)
        for cluster in clusters:
            if line and measure(line + cluster) > width:
                lines.append(line)
                line = ''
            line += cluster
    if line:
        lines.append(line)
    return tuple(lines)


def guide_page(lines, elapsed, page_seconds=4.5):
    pages = max(1, (len(lines) + 1) // 2)
    start = (max(0, int(elapsed / page_seconds)) % pages) * 2
    return (lines[start] if start < len(lines) else '',
            lines[start + 1] if start + 1 < len(lines) else '')


def delay_positions(center, text_width, scale):
    n = lambda v: max(1, int(round(v * scale)))
    width = max(n(50), min(n(124), int(text_width) + n(6)))
    value_x = int(round(center * scale)) - width // 2
    return value_x - n(42), value_x, width, value_x + width + n(6)
