# -*- coding: utf-8 -*-
"""One-shot receiver time recovery when UltraAudio opens.

Original implementation of the SNTP wire format (RFC 4330). Network work
runs off the GUI thread; native DVB APIs and clock writes stay on its loop.
Never execute a time-setting command at import or installation time.
"""
from __future__ import division
import os
import socket
import struct
import time

from .compat import connect_timer, is_main_thread, monotonic, start_thread, to_text

SERVERS = ('time.cloudflare.com', 'time.google.com', '0.pool.ntp.org')
EPOCH_DELTA = 2208988800
ERA = 4294967296
MIN_TIME, MAX_TIME = 1767225600, 4102444800  # 2026 through 2099
NETWORK_LIMIT, DVB_LIMIT = 12.0, 60.0


def plausible(value):
    return MIN_TIME <= value < MAX_TIME


def _stamp(raw):
    seconds, fraction = struct.unpack('!II', raw)
    if seconds == 0 and fraction == 0:
        raise ValueError('empty NTP timestamp')
    for era in (0, 1):
        value = seconds + era * ERA - EPOCH_DELTA + fraction / ERA
        if plausible(value):
            return value
    raise ValueError('NTP date outside supported range')


def decode_reply(packet, request, elapsed):
    if len(packet) < 48 or not 0 <= elapsed <= 3:
        raise ValueError('short or delayed NTP reply')
    flags, stratum = struct.unpack('!BB', packet[:2])
    if flags >> 6 == 3 or (flags >> 3) & 7 not in (3, 4) or flags & 7 != 4:
        raise ValueError('NTP server not synchronized or invalid reply mode')
    if not 1 <= stratum <= 15 or packet[24:32] != request[40:48]:
        raise ValueError('invalid NTP stratum or request identity')
    if struct.unpack('!I', packet[8:12])[0] / 65536.0 > 5:
        raise ValueError('NTP server uncertainty too large')
    received, sent = _stamp(packet[32:40]), _stamp(packet[40:48])
    processing = sent - received
    if not 0 <= processing <= elapsed + 0.05:
        raise ValueError('invalid NTP processing interval')
    return sent + max(0, elapsed - processing) / 2.0


def query(server, deadline):
    # A connected UDP socket accepts replies only from this resolved peer.
    addresses = socket.getaddrinfo(server, 123, 0, socket.SOCK_DGRAM)
    addresses.sort(key=lambda row: row[0] != socket.AF_INET)
    error = 'no usable address'
    for family, kind, protocol, unused, address in addresses[:2]:
        remaining = deadline - monotonic()
        if remaining <= 0:
            break
        sock = None
        try:
            sock = socket.socket(family, kind, protocol)
            sock.settimeout(min(2.0, remaining))
            sock.connect(address)
            seconds = (int(time.time()) + EPOCH_DELTA) % ERA
            request = b'\x23' + b'\x00' * 39 + struct.pack('!I', seconds) + os.urandom(4)
            started = monotonic()
            sock.send(request)
            reply = sock.recv(512)
            finished = monotonic()
            value = decode_reply(reply, request, finished - started)
            return {'epoch': value, 'tick': finished, 'rtt': finished-started,
                    'server': server, 'peer': address[0]}
        except Exception as exc:
            error = to_text(exc)
        finally:
            if sock is not None:
                sock.close()
    raise ValueError('%s: %s' % (server, error))


def consensus(deadline):
    samples, errors = [], []
    for server in SERVERS:
        if monotonic() >= deadline:
            break
        try:
            sample = query(server, deadline)
            tick = monotonic()
            for previous in samples:
                # Require two distinct peers as well as two server names.
                if previous['peer'] == sample['peer']:
                    continue
                a = previous['epoch'] + tick - previous['tick']
                b = sample['epoch'] + tick - sample['tick']
                if abs(a-b) <= 2:
                    return min((previous, sample), key=lambda item: item['rtt'])
            samples.append(sample)
        except Exception as exc:
            errors.append(to_text(exc))
    raise ValueError('no two NTP servers agreed; ' + '; '.join(errors)[:240])


def write_clock(value):
    """Only called by the receiver main loop after busy/age/consensus checks."""
    if not plausible(value):
        raise ValueError('refusing invalid receiver date')
    if hasattr(time, 'clock_settime'):
        time.clock_settime(time.CLOCK_REALTIME, value)
        return
    # Python 2 on DreamOS: use its Linux/glibc time ABI, without shell commands.
    import ctypes
    libc = ctypes.CDLL('libc.so.6', use_errno=True)
    seconds = int(value)
    if seconds > (1 << (ctypes.sizeof(ctypes.c_long)*8-1))-1:
        raise ValueError('date cannot be represented by this receiver time_t')
    class Timespec(ctypes.Structure):
        _fields_ = [('seconds', ctypes.c_long), ('nanoseconds', ctypes.c_long)]
    entry = libc.clock_settime
    entry.argtypes, entry.restype = [ctypes.c_int, ctypes.POINTER(Timespec)], ctypes.c_int
    stamp = Timespec(seconds, min(999999999, int((value-seconds)*1000000000)))
    if entry(0, ctypes.byref(stamp)) != 0:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))


class TimeRecovery(object):
    def __init__(self):
        self.state, self.error, self.source = 'idle', '', ''
        self._generation, self._next = 0, 0.0
        self._timer, self._connections = None, []
        self._dvb, self._dvb_previous = None, None
        self._session, self._until = None, 0.0

    def _log(self, message):
        try:
            from .engine import log
            log('receiver time: ' + message)
        except Exception:
            pass

    def _busy(self, reference=None):
        try:
            from . import ctl
            controller = ctl._instance
            if controller is None or controller._closed:
                return True
            if (controller.engine.status()['state'] != 'idle'
                    or controller.video.state != 'off' or controller._timeshift_playing()
                    or getattr(controller, '_pending_play', None) is not None):
                return True
            nav = self._session.nav
            if nav.getRecordings():
                return True
            record_timer = nav.RecordTimer
            for timer in getattr(record_timer, 'timer_list', ()):
                if getattr(timer, 'disabled', False):
                    continue
                if getattr(timer, 'justplay', False):
                    continue
                check_time = self._reference() if reference is None else reference
                if (timer.isRunning() or not plausible(check_time)
                        or min(abs(timer.begin-time.time()), abs(timer.begin-check_time)) < 120):
                    return True
            return False
        except Exception:
            return True  # unknown receiver state cannot authorize a clock write

    def _reference(self):
        from . import guide
        return guide.now()

    def start(self, session):
        if not is_main_thread() or self.state in ('ntp', 'dvb') or monotonic() < self._next:
            return
        self._session = session
        if self._busy():
            self._log('deferred: audio, timeshift or recording active/unknown')
            return
        self._generation += 1
        generation = self._generation
        try:
            from enigma import eTimer
            self._timer = eTimer()
            self._connections = []
            connect_timer(self._timer, self._poll, self._connections)
            if not self._connections and not getattr(self._timer, 'callback', ()):
                raise ValueError('receiver timer callback unavailable')
            self.state, self.error, self.source = 'ntp', '', ''
            self._until = monotonic() + NETWORK_LIMIT
            self._timer.start(250, False)
            start_thread(self._network, (generation, self._until-1), 'UltraAudioTime')
            self._log('checking NTP in background')
        except Exception as exc:
            self._finish(False, to_text(exc))

    def _network(self, generation, deadline):
        from .engine import main_call
        try:
            sample, error = consensus(deadline), ''
        except Exception as exc:
            sample, error = None, to_text(exc)
        main_call(self._network_done, generation, sample, error)

    def _network_done(self, generation, sample, error):
        if not is_main_thread() or generation != self._generation or self.state != 'ntp':
            return
        if self._busy():
            return self.cancel()
        if monotonic() >= self._until or sample is None:
            return self._fallback(error or 'NTP deadline exceeded')
        try:
            age = monotonic() - sample['tick']
            if not 0 <= age <= NETWORK_LIMIT:
                raise ValueError('stale NTP result')
            target = sample['epoch'] + age
            if not plausible(target):
                raise ValueError('invalid NTP target')
            if self._busy(reference=target):
                return self.cancel()
            if abs(time.time()-target) > 1:
                write_clock(target)
            if abs(time.time()-target) > 2:
                raise ValueError('receiver clock did not accept NTP update')
            self.source = 'ntp:' + sample['server']
            self._finish(True, '')
        except Exception as exc:
            self._fallback(to_text(exc))

    def _fallback(self, reason):
        self.error = reason
        self._log('NTP unavailable; trying current DVB channel: ' + reason)
        try:
            from enigma import eDVBLocalTimeHandler
            handler = eDVBLocalTimeHandler.getInstance()
            previous = handler.getUseDVBTime()
            handler.ready()  # require observation API before enabling native recovery
            self._dvb, self._dvb_previous = handler, previous
            self._before_wall, self._before_tick = time.time(), monotonic()
            self.state, self._until = 'dvb', monotonic()+DVB_LIMIT
            if not previous:
                handler.setUseDVBTime(True)
        except Exception as exc:
            self._finish(False, reason + '; DVB: ' + to_text(exc))

    def _poll(self):
        try:
            if self.state not in ('ntp', 'dvb'):
                return
            if self._busy():
                return self.cancel()
            tick = monotonic()
            if self.state == 'ntp':
                if tick >= self._until:
                    self._generation += 1  # ignore a DNS/UDP worker returning after its deadline
                    self._fallback('NTP timeout')
                return
            wall = time.time()
            advanced = self._before_wall + tick-self._before_tick
            # An already-ready handler alone is not proof it supplied valid time.
            changed = abs(wall-advanced) > 2
            from . import guide
            anchored = guide._CLOCK.diagnostics()['source'] == 'official_http_date'
            agrees = anchored and abs(wall-guide.now()) <= 300
            if self._dvb.ready() and plausible(wall) and (agrees if anchored else changed):
                self.source = 'dvb'
                return self._finish(True, '')
            if tick >= self._until:
                self._finish(False, self.error + '; current channel supplied no verified time')
        except Exception as exc:
            self._finish(False, to_text(exc))

    def _restore_dvb(self):
        if self._dvb is not None:
            try:
                if self._dvb.getUseDVBTime() != self._dvb_previous:
                    self._dvb.setUseDVBTime(self._dvb_previous)
            except Exception as exc:
                self._log('restore DVB time policy: ' + to_text(exc))
        self._dvb, self._dvb_previous = None, None

    def _finish(self, success, error):
        self._restore_dvb()
        if self._timer is not None:
            self._timer.stop()
        self.state, self.error = ('ok' if success else 'failed'), error
        self._next = monotonic() + (600 if success else 60)
        if success:
            if self.source.startswith('ntp:'):
                try:
                    from Tools.DreamboxHardware import setRTCtime
                    setRTCtime(int(time.time()))
                except Exception as exc:
                    self._log('system time verified; RTC update unavailable: ' + to_text(exc))
            try:
                from enigma import eEPGCache
                eEPGCache.getInstance().timeUpdated()
            except Exception:
                pass
        self._log(('verified ' + self.source) if success else ('failed: ' + error))

    def cancel(self):
        if self.state in ('ntp', 'dvb'):
            self._generation += 1
            self._restore_dvb()
            if self._timer is not None:
                self._timer.stop()
            self.state, self.error = 'deferred', 'receiver playback/recording started'
            self._next = monotonic() + 5
            self._log(self.error)

    def status(self):
        return {'state': self.state, 'source': self.source, 'error': self.error}


_RECOVERY = TimeRecovery()
start = _RECOVERY.start
cancel = _RECOVERY.cancel
status = _RECOVERY.status


def guide_notice():
    if _RECOVERY.state in ('ntp', 'dvb'):
        return 'Synchronizing receiver time...'
    if _RECOVERY.state == 'failed' or not plausible(time.time()):
        return 'Set receiver time'
    return ''
