# -*- coding: utf-8 -*-
"""MENU overlay of the on-box screen (it opens on the same screen, no new screen).

Same settings card as the plugin's premium settings screen: the 560x680 glass card, a round icon tile with the title, a hair
line, six 66px option rows with the green pointer on the focused one, ON/OFF switches, ‹ value › choices, and the help
text under the lower hair line. It sits at the far right, its bottom edge 2px above the bottom key bar; the TV picture
stays visible around it."""
from __future__ import division
import os
import sys
from . import uifont

from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import ePoint, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, RT_WRAP, eListboxPythonMultiContent, gFont

try:
    from enigma import BT_ALIGN_CENTER, BT_KEEP_ASPECT_RATIO, BT_SCALE
    _PIX_FLAGS = BT_SCALE | BT_KEEP_ASPECT_RATIO | BT_ALIGN_CENTER
except ImportError:  # old images / DreamOS
    _PIX_FLAGS = 0

from . import __version__, PACKAGE_VERSION, RELEASE_NAME, ctl, store, themes, webui
from .compat import (connect_timer, mark_user_input, mc_pixmap, monotonic, native, queue, run as run_tool,
                     skin_attr, skin_scale_attr, start_thread, to_text, ui_pixmap_path, user_input_idle)
from .engine import (alsa_candidates, alsa_cards, alsa_summary, available_modes, ffmpeg_has_alsa, ffmpeg_pcm_ok, gst_missing,
                     live_delay_info, main_call, missing_text, python_bin, which)
from .i18n import LANG_NAMES, LANGS, T, lang
from .updateui import UpdateOverlay, skin_parts as update_skin

MENU = os.path.join(store.ASSETS, "menu")
C_WHITE, C_CELL_NAME, C_MINT, C_SECOND = 0xFFFFFF, 0xFFFFFF, 0x00DA7F, 0x00DA7F
BAR_RIGHT, DOCK_Y = 1880, 1015
# Premium card geometry (560x680 at 1340,380), moved so its right edge meets the bars' right edge and its
# bottom edge sits 2px above the bottom key bar.
CARD_W, CARD_H, ROWS = themes.CARD_W, themes.CARD_H, themes.CARD_ROWS
CARD_X, CARD_Y = BAR_RIGHT - CARD_W, DOCK_Y - 2 - CARD_H
ROW_W, ROW_H = CARD_W - 60, 66
Z = 10

_pix = {}
_session_update_checked = [False]

# Header boxes, relative to the card's top-left corner (x, y, w, h). The pictures are drawn at this size.
# The header is the card's first line (no "Settings" title or gear tile any more).
BRAND_BOX = (30, 20, 260, 50)        # assets/menu/set_brand_260x50.png: plugin icon + ULTRAAUDIO + "VERSION ·" (1:1 on FHD)
VERSION_BOX = (148, 46, 120, 22)     # the version number, just right of "VERSION ·"
SIGN_BOX = (CARD_W - 30 - 247, 15, 250, 58)   # set_sign_250x58.png: its ink ends 30px inside the card's right edge,
                                              # its baseline on the version's baseline
BRAND_PNG = os.path.join(MENU, "set_brand_260x50.png")
SIGN_PNG = os.path.join(MENU, "set_sign_250x58.png")


def _rel(m, b):
    return (m["panel"][0] + b[0], m["panel"][1] + b[1], b[2], b[3])


def version_text():
    """Show the base version; package metadata retains any local build suffix."""
    return PACKAGE_VERSION.split("-")[0]


def _pixmap(path, w=None, h=None):
    resolved = ui_pixmap_path(path, w, h) if (w and h) else path
    if resolved not in _pix:
        _pix[resolved] = LoadPixmap(native(resolved)) if (resolved and os.path.isfile(resolved)) else None
    return _pix[resolved]


def skin_parts(k, th=None):
    """Widgets of the card, in FHD design coordinates multiplied by k. They start hidden (see MenuOverlay.bind)."""
    m = (th or themes.get("classic"))["menu"]
    faces = (th or {}).get("faces") or {}
    body = themes.face(faces["body"] if faces else "UltraAudioUI")
    title = themes.face(faces["title"] if faces else "UltraAudioUI")
    sz, col = m["sizes"], m["labels"]
    scale_attr = skin_scale_attr()
    wrap_attr = skin_attr("noWrap", "0")

    def n(v):
        return int(round(v * k))

    def box(b):
        x, y, w, h = b
        return 'position="%d,%d" size="%d,%d"' % (n(x), n(y), max(1, n(w)), max(1, n(h)))

    def pic(name, z):
        return '<widget name="%s" %s alphatest="blend"%s transparent="1" zPosition="%d"/>' % (
            name, box(m[name[2:]]), scale_attr, z)

    def shadow(off):
        return ""

    # Neon: the card's soft outer light, under everything (z 0); Classic has none, its widget simply stays empty
    glow_box = m.get("glow") or (m["panel"][0], m["panel"][1], 1, 1)
    return "\n".join([
        '<widget name="m_glow" %s alphatest="blend"%s transparent="1" zPosition="0"/>' % (box(glow_box), scale_attr),
        pic("m_panel", Z),
        # Header: ULTRAAUDIO wordmark with "VERSION ·" under it (one picture), the version number right after it,
        # and on the right "CRAFTED BY" over the hand-written signature (one picture). Panel-relative, scaled by k.
        '<widget name="m_brand" %s alphatest="blend"%s transparent="1" zPosition="%d"/>'
        % (box(_rel(m, BRAND_BOX)), scale_attr, Z + 3),
        '<widget name="m_desc" %s font="%s;%d" halign="left" valign="center" foregroundColor="#FFFFFF" transparent="1" '
        'zPosition="%d" noWrap="1"/>' % (box(_rel(m, VERSION_BOX)), body, n(15), Z + 4),
        '<widget name="m_sign" %s alphatest="blend"%s transparent="1" zPosition="%d"/>'
        % (box(_rel(m, SIGN_BOX)), scale_attr, Z + 3),
        pic("m_hair1", Z + 2),
        pic("m_hair2", Z + 2),
        '<widget name="m_focus" %s alphatest="blend"%s transparent="1" zPosition="%d"/>'
        % (box(m["list"][:3] + (ROW_H,)), scale_attr, Z + 2),
        '<widget name="m_list" position="%d,%d" size="%d,%d" foregroundColor="%s" foregroundColorSelected="%s" '
        'scrollbarMode="showNever" transparent="1" zPosition="%d"/>'
        % (n(m["list"][0]), n(m["list"][1]), n(m["list"][2]), ROWS * n(ROW_H) + 4, col["title"], col["title"], Z + 3),
        '<widget name="m_help" %s font="%s;%d" halign="left" valign="top" foregroundColor="%s"%s%s '
        'transparent="1" zPosition="%d"/>' % (box(m["help"]), body, n(sz["help"]), col["help"], wrap_attr, shadow("2,2"), Z + 3),
    ]) + '\n' + update_skin(k, th)


def _speed_text(st):
    if st.get("feed_rate") is None:
        return T("measured after 10 s of playback")
    return T("%.2fx real time, %d underruns in 10 s", st["feed_rate"], st.get("underruns") or 0)


# --------------------------------------------------------------------------------------------- items
STEP_VIDEO = (0.1, 0.2, 0.5, 1.0, 2.0)
STEP_AUDIO = (20, 50, 100, 200, 500)
OUTPUTS = ("auto", "alsa", "aplay", "pcm", "gst", "dvb")
MUTES = ("decoder", "track", "system", "none")
BAR_KEYS = ("0", "2")


def _nearest(values, v):
    return min(range(len(values)), key=lambda i: abs(values[i] - v))


def item_title(key):
    return {"language": lambda: T("Language"), "ui_font": lambda: T("UI font"), "theme": lambda: T("Theme"), "web_port": lambda: T("Web page port"),
            "mute": lambda: T("Mute original sound"), "volume": lambda: T("Commentary volume"),
            "output": lambda: T("Audio output"), "step_video": lambda: T("Picture step"),
            "step_audio": lambda: T("Audio step"),
            "timeshift": lambda: T("Prepare timeshift"),
            "long_audio": lambda: T("Long AUDIO opens Ultra Audio"),
            "bar_key": lambda: T("Mini card key"),
            "foxfm": lambda: T("Add FoX FM"),
            "update_sources": lambda: T("Update sources"),
            "backup": lambda: T("Backup to disk"), "restore": lambda: T("Restore from disk"),
            "deps": lambda: T("Install missing components"),
            "online_update": lambda: T("Online update"),
            "info": lambda: T("System info")}[key]()


def item_help(key, ip=""):
    return {"language": lambda: T("Language of the on-screen menus and of the web page."),
            "ui_font": lambda: T("Choose the image font or a bundled Arabic/English font. Changes apply to this plugin only, without a GUI restart."),
            "theme": lambda: T("Look of this screen: Classic, Neon, Smoked Glass, or Midnight Titanium."),
            "web_port": lambda: T("Port of the web page. Open it from your phone at http://%s:%d", ip, webui.PORT),
            "mute": lambda: T("Decoder stops the channel's audio decoder. Audio track turns the channel's audio off but keeps the decoder running (try it if the commentary cuts). System uses the receiver's volume mute."),
            "volume": lambda: T("Volume of the commentary only (100% = unchanged)."),
            "output": lambda: T("Auto selects ALSA or DVB. Dreambox without an ALSA device: choose DVB. Audio delay needs PCM/relay; direct GST has no audio delay."),
            "step_video": lambda: T("How many seconds one press of 1 / 3 moves the picture. 0 returns to live."),
            "timeshift": lambda: T("ON opens the timeshift buffer when a commentary starts, so the first freeze is instant. Only on a disk or USB, never on the receiver's own flash."),
            "long_audio": lambda: T("Hold the AUDIO key while watching TV to open Ultra Audio. OFF gives the key back its own long press."),
            "bar_key": lambda: T("Remote key (0 or 2) that opens the mini playback card while commentary is playing."),
            "foxfm": lambda: T("Add missing FoX FM channels. Existing links, delays and icons are kept."),
            "update_sources": lambda: T("Refresh all saved source links to get their latest channels."),
            "backup": lambda: T("Save channels, folders, settings and custom icons to UltraAudio/Backups on the hard disk or USB drive."),
            "restore": lambda: T("Choose a backup from the hard disk or USB drive to restore channels, folders, settings and custom icons."),
            "step_audio": lambda: T("How many milliseconds one press of 4 / 6 moves the commentary. BLUE puts it back to 0."),
            "deps": lambda: T("Check and install only missing components from the current image feed."),
            "online_update": lambda: T("Check for a newer version; verify SHA-256 and confirm before installation."),
            "info": lambda: T("Version, web address, ffmpeg and audio output found on this receiver.")}[key]()


ITEMS = (  # key, kind
    ("language", "choice"), ("ui_font", "choice"), ("theme", "choice"), ("web_port", "input"), ("mute", "choice"), ("volume", "choice"), ("output", "choice"),
    ("step_video", "choice"), ("step_audio", "choice"), ("long_audio", "bool"), ("bar_key", "choice"),
    ("backup", "action"), ("restore", "action"), ("foxfm", "action"), ("update_sources", "action"),
    ("online_update", "action"), ("deps", "action"), ("info", "action"))


def current_value(key, st=None):
    st = st or store.get_settings()
    if key == "ui_font":
        return T(uifont.label(st.get("ui_font", "skin"))), False
    if key == "language":
        return LANG_NAMES[lang()], False
    if key == "theme":
        return themes.title(st.get("theme") if st.get("theme") in themes.THEMES else "classic"), False
    if key == "web_port":
        return str(webui.PORT), False
    if key == "mute":
        return {"decoder": T("Decoder"), "track": T("Audio track"), "system": T("System")}.get(st["mute_mode"], T("OFF")), False
    if key == "volume":
        return "%d%%" % st["volume"], False
    if key == "output":
        return (T("Auto") if st["output"] == "auto" else str(st["output"]).upper()), False
    if key == "step_video":
        return T("%.1f s", st["step_video_s"]), False
    if key == "step_audio":
        return T("%d ms", st["step_audio_ms"]), False
    if key == "timeshift":
        return "", bool(st.get("timeshift_ahead", True))
    if key == "long_audio":
        return "", bool(st.get("long_audio", True))
    if key == "bar_key":
        val = str(st.get("bar_key", "0"))
        return (val if val in BAR_KEYS else "0"), False
    return "", False


def next_value(key, direction, st=None):
    st = st or store.get_settings()
    if key == "ui_font":
        current = st.get("ui_font", "skin")
        index = uifont.FONT_IDS.index(current) if current in uifont.FONT_IDS else 0
        return {"ui_font": uifont.FONT_IDS[(index + direction) % len(uifont.FONT_IDS)]}
    if key == "language":
        i = (LANGS.index(lang()) + direction) % len(LANGS)
        return {"language": LANGS[i]}
    if key == "theme":
        cur = st.get("theme") if st.get("theme") in themes.THEMES else "classic"
        return {"theme": themes.THEMES[(themes.THEMES.index(cur) + direction) % len(themes.THEMES)]}
    if key == "mute":
        i = (MUTES.index(st["mute_mode"]) if st["mute_mode"] in MUTES else 0) + direction
        return {"mute_mode": MUTES[i % len(MUTES)]}
    if key == "timeshift":
        return {"timeshift_ahead": not st.get("timeshift_ahead", True)}
    if key == "long_audio":
        return {"long_audio": not st.get("long_audio", True)}
    if key == "bar_key":
        cur = str(st.get("bar_key", "0"))
        cur = cur if cur in BAR_KEYS else "0"
        return {"bar_key": BAR_KEYS[(BAR_KEYS.index(cur) + direction) % len(BAR_KEYS)]}
    if key == "volume":
        v = int(round(st["volume"] / 5.0)) * 5 + 5 * direction
        return {"volume": max(0, min(200, v))}
    if key == "output":
        cur = OUTPUTS.index(st["output"]) if st["output"] in OUTPUTS else 0
        return {"output": OUTPUTS[(cur + direction) % len(OUTPUTS)]}
    if key == "step_video":
        i = (_nearest(STEP_VIDEO, st["step_video_s"]) + direction) % len(STEP_VIDEO)
        return {"step_video_s": STEP_VIDEO[i]}
    if key == "step_audio":
        i = (_nearest(STEP_AUDIO, st["step_audio_ms"]) + direction) % len(STEP_AUDIO)
        return {"step_audio_ms": STEP_AUDIO[i]}
    return {}


_WIDGETS = ("m_glow", "m_panel", "m_brand", "m_desc", "m_sign", "m_hair1", "m_hair2", "m_focus", "m_list", "m_help")


class MenuOverlay(object):
    """The card, driven by the main screen: it calls the key methods while `is_open` is true."""

    def __init__(self, screen, ip="RECEIVER-IP"):
        self.s = screen
        self.k = screen.k
        self.ip = ip
        self.is_open = False
        self._backup_busy = False
        self._deps_busy = False
        self._deps_timer = None
        self._deps_result = None
        self._update_busy = False
        self._update_meta = None
        self._restart_timer = None
        self._connections = []
        self._update_started = 0.0
        self._update_timer = None
        self._update_job = None
        self._update_progress = None
        self._auto_timer = None
        self._auto_started = False
        self._auto_meta = None
        self.update = UpdateOverlay(screen, self.online_update_confirmed, getattr(screen, "th", None))
        self._backup_screen_closed = False
        screen.onClose.append(self._backup_closed)
        self.idx = 0
        self._rows = self._row_settings = None
        self._page_start = self._focus_at = None
        self._custom_focus = False
        self._row_variants = {}
        th = getattr(screen, "th", None) or themes.get("classic")
        self.m = th["menu"]
        self.row_w = self.m["row_w"]
        faces = th.get("faces") or {}
        body = themes.face(faces["body"] if faces else "UltraAudioUI")
        for name in ("m_glow", "m_panel", "m_hair1", "m_hair2", "m_brand", "m_sign", "m_focus"):
            screen[name] = Pixmap()
        for name in ("m_desc", "m_help"):
            screen[name] = Label(native(""))
        screen["m_list"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        lst = screen["m_list"].l
        f21 = gFont(native(body), int(24 * self.k))
        f22 = gFont(native(body), int(22 * self.k))
        lst.setFont(0, f21)
        lst.setFont(1, f22)
        lst.setFont(21, f21)
        lst.setFont(22, f22)
        lst.setItemHeight(int(round(ROW_H * self.k)))

    def bind(self):
        """Load the card pictures while hidden. Build the rows only when opened."""
        self._visible(False)
        for name in ("m_panel", "m_hair1", "m_hair2"):
            try:
                key = name[2:]
                w = max(1, int(round(self.m[key][2] * self.k)))
                h = max(1, int(round(self.m[key][3] * self.k)))
                px = _pixmap(self._file(key), w, h)
                if px is not None:
                    if hasattr(self.s[name].instance, "setScale"):
                        try:
                            self.s[name].instance.setScale(1)
                        except Exception:
                            pass
                    self.s[name].instance.setPixmap(px)
            except Exception:
                pass
        for name, path, box_ in (("m_brand", BRAND_PNG, BRAND_BOX), ("m_sign", SIGN_PNG, SIGN_BOX)):
            try:
                t_cand = os.path.join(self.m["dir"], os.path.basename(path))
                use_p = t_cand if os.path.isfile(t_cand) else path
                px = _pixmap(use_p, max(1, int(round(box_[2] * self.k))), max(1, int(round(box_[3] * self.k))))
                if px is not None:
                    if hasattr(self.s[name].instance, "setScale"):
                        try:
                            self.s[name].instance.setScale(1)
                        except Exception:
                            pass
                    self.s[name].instance.setPixmap(px)
            except Exception:
                pass
        try:
            focus = _pixmap(self._file("row_sel"), int(round(self.row_w * self.k)), int(round(ROW_H * self.k)))
            if focus is not None:
                if hasattr(self.s["m_focus"].instance, "setScale"):
                    try:
                        self.s["m_focus"].instance.setScale(1)
                    except Exception:
                        pass
                self.s["m_focus"].instance.setPixmap(focus)
                self.s["m_list"].instance.setSelectionEnable(0)
                self._custom_focus = True
        except Exception:
            pass
        self.s["m_desc"].setText(native(version_text()))
        self.update.bind()
        self._schedule_auto_update()

    def _visible(self, on):
        for name in _WIDGETS:
            try:
                self.s[name].show() if on and (name != "m_focus" or self._custom_focus) else self.s[name].hide()
            except Exception:
                pass

    def open(self):
        self.is_open = True
        self.idx = min(self.idx, len(ITEMS) - 1)
        self.redraw()
        self._visible(True)
        self.s.football.hide()
        self.say("")

    def close(self):
        if self.update.is_open:
            return self.update.close()
        self.is_open = False
        self._visible(False)
        self.s.menu_closed()

    def toggle(self):
        self.close() if self.is_open else self.open()

    def say(self, text):
        self.s._text("kok", text)

    def paint_keys(self):
        if self.update.is_open:
            return self.update.paint_keys()
        key, kind = ITEMS[self.idx]
        s = self.s
        s._text("kred", T("Close"))
        s._text("kgreen", {"action": T("Run"), "input": T("Edit")}.get(kind, T("Change")))
        s._text("kyellow", "")
        s._text("kblue", "")
        s.audio_keys(False)

    def _file(self, what):
        fn = self.m["files"][what]
        p = os.path.join(self.m["dir"], fn)
        return p if os.path.isfile(p) else os.path.join(MENU, fn)

    def _row(self, key, kind, selected, st):
        k = self.k
        n = lambda v: int(round(v * k))
        ROW_W = self.row_w
        C = self.m["colors"]
        bg = None if selected else _pixmap(self._file("row"), n(ROW_W), n(ROW_H))
        value, on = current_value(key, st)
        cells = [key]
        if bg is not None:
            cells.append(mc_pixmap(pos=(0, 0), size=(n(ROW_W), n(ROW_H)), png=bg, flags=_PIX_FLAGS))
        # names left, values right; the two boxes may overlap a little, a short value leaves the name the room
        title_w = ROW_W - 12 - (64 + 16 if kind == "bool" else 150) - 12
        cells.append(MultiContentEntryText(pos=(n(12), n(6)), size=(n(title_w), n(54)), font=21,
                                           flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP, text=native(item_title(key)),
                                           color=C["sel"] if selected else C["name"], color_sel=C["sel"] if selected else C["name"]))
        if kind == "bool":
            sw = _pixmap(self._file("sw_on" if on else "sw_off"), n(64), n(32))
            if sw is not None:
                cells.append(mc_pixmap(pos=(n(ROW_W - 12 - 64), n(17)), size=(n(64), n(32)),
                                       png=sw, flags=_PIX_FLAGS))
        elif value:
            text = u"\u2039  %s  \u203a" % to_text(value) if kind == "choice" else to_text(value)
            value_color = (C.get("value_sel", C["value"]) if selected     # the focused row's value lights up (Neon)
                           else C["value"] if kind == "choice" else C["second"])
            cells.append(MultiContentEntryText(pos=(n(ROW_W - 12 - 200), n(8)), size=(n(200), n(50)), font=22,
                                               flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER | RT_WRAP, text=native(text),
                                               color=value_color, color_sel=value_color))
        return cells

    def _cached_row(self, index):
        selected = index == self.idx
        cache_key = (index, selected)
        if cache_key not in self._row_variants:
            key, kind = ITEMS[index]
            self._row_variants[cache_key] = self._row(key, kind, selected, self._row_settings)
        return self._row_variants[cache_key]

    def refresh(self):
        if not self.update.is_open:
            settings = store.get_settings()
            if settings != self._row_settings:
                return self.redraw(settings=settings)
        self.paint_keys()

    def redraw(self, previous=None, settings=None):
        s = self.s
        listing = s["m_list"]
        first = (self.idx // ROWS) * ROWS
        row = self.idx - first
        if previous is None:
            self._row_settings = store.get_settings() if settings is None else settings
            self._row_variants.clear()
        repaint_page = previous is None or first != self._page_start
        if not repaint_page and previous != self.idx:
            try:
                for i in (previous, self.idx):
                    self._rows[i - first] = self._cached_row(i)
                for i in (previous, self.idx):
                    listing.l.invalidateEntry(i - first)
            except Exception:
                repaint_page = True
        if repaint_page:
            self._rows = [self._cached_row(i) for i in range(first, min(first + ROWS, len(ITEMS)))]
            listing.setList(self._rows)
            self._page_start = first
        if self._custom_focus:
            if row != self._focus_at:
                x, y = self.m["list"][:2]
                s["m_focus"].instance.move(ePoint(int(round(x * self.k)), int(round(y * self.k))
                                                  + row * int(round(ROW_H * self.k))))
                self._focus_at = row
        else:
            listing.moveToIndex(row)
        key, kind = ITEMS[self.idx]
        s._text("m_help", item_help(key, self.ip))
        self.paint_keys()

    def move(self, d):
        mark_user_input()
        if self.update.is_open:
            return self.update.scroll(d)
        previous = self.idx
        self.idx = (previous + d) % len(ITEMS)
        self.say("")
        self.redraw(previous)

    def step(self, d):
        """LEFT / RIGHT change the focused value (OK too)."""
        mark_user_input()
        if self.update.is_open:
            return self.update.scroll(d)
        key, kind = ITEMS[self.idx]
        if kind in ("choice", "bool"):
            self.apply(key, d)

    def page(self, d):
        """CH+ / CH-: flip a page of the card (ROWS rows), keeping the cursor on the same line of the page and
        wrapping from the last page to the first."""
        mark_user_input()
        if self.update.is_open:
            return self.update.scroll(d)
        pages = (len(ITEMS) + ROWS - 1) // ROWS
        if pages < 2:
            return
        previous = self.idx
        page = (previous // ROWS + d) % pages
        self.idx = min(page * ROWS + previous % ROWS, len(ITEMS) - 1)
        self.say("")
        self.redraw(previous)

    def activate(self):
        if self.update.is_open:
            return self.update.confirm()
        if self._backup_busy:
            return
        key, kind = ITEMS[self.idx]
        if kind in ("choice", "bool"):
            return self.apply(key, 1)
        if key == "web_port":
            return self.ask_port()
        if key == "online_update":
            return self.check_online_update()
        if key == "update_sources":
            self.close()  # show refresh progress and its result on the library screen
            return self.s.update_sources()
        if key == "foxfm":
            return self.add_foxfm()
        if key == "backup":
            return self.backup_disk()
        if key == "restore":
            return self.choose_backup()
        if key == "deps":
            return self.install_deps()
        if key == "info":
            return self.show_info()

    def apply(self, key, direction):
        try:
            store.set_settings(next_value(key, direction))
        except Exception as e:
            self.say(to_text(e)[:80])
            return
        if key in ("theme", "ui_font"):
            return self.s.reopen(self.idx)
        if key == "language":
            if self.s.language_changed(self.idx):
                return
        self.say(T("Saved"))
        self.redraw()

    def ask_port(self):
        from Components.Input import Input
        from Screens.InputBox import InputBox
        self.s.session.openWithCallback(self.port_entered, InputBox, title=native(T("Web page port (1024-65535)")), text=native(str(webui.PORT)),
                                        maxSize=5, type=Input.NUMBER)

    def port_entered(self, value):
        if value is None:
            return
        try:
            port = int(str(value).strip())
            if not 1024 <= port <= 65535:
                raise ValueError
        except ValueError:
            self.say(T("Port must be between 1024 and 65535"))
            return
        ok, now = webui.set_port(port)
        self.say(T("Web page now on port %d", now) if ok else T("Port %d is busy, kept %d", port, now))
        self.redraw()

    def _backup_closed(self):
        self._backup_screen_closed = True
        if self._deps_timer is not None:
            self._deps_timer.stop()
        if self._update_timer is not None:
            self._update_timer.stop()
        if self._auto_timer is not None:
            self._auto_timer.stop()
        if self._restart_timer is not None:
            self._restart_timer.stop()
        self._connections = []

    def _backup_work(self, work, done):
        self._backup_busy = True

        def run():
            try:
                result, error = work(), None
            except Exception as e:
                result, error = None, to_text(e)
            main_call(complete, result, error)

        def complete(result, error):
            self._backup_busy = False
            if self._backup_screen_closed:
                return
            if error:
                self.backup_message(error)
            else:
                done(result)
        start_thread(run)

    def backup_message(self, text):
        from Screens.MessageBox import MessageBox
        self.s.session.open(MessageBox, native(text), type=MessageBox.TYPE_INFO, timeout=12)

    def backup_disk(self):
        from . import diskbackup
        self.say(T("Saving backup..."))
        self._backup_work(diskbackup.save, lambda path: self.backup_message(T("Backup saved:\n%s", path)))

    def choose_backup(self):
        from . import diskbackup
        self.say(T("Looking for backups..."))
        self._backup_work(diskbackup.backups, self.backup_choices)

    def backup_choices(self, paths):
        if not paths:
            return self.backup_message(T("No backups found in UltraAudio/Backups on a connected hard disk or USB drive."))
        from Screens.ChoiceBox import ChoiceBox
        self.s.session.openWithCallback(self.backup_selected, ChoiceBox, title=native(T("Choose a backup")),
                                       list=[(native(os.path.basename(p) + "  [" + p.split("/UltraAudio/")[0] + "]"), p) for p in paths])

    def backup_selected(self, choice):
        if not choice:
            return
        from . import diskbackup
        self._backup_work(lambda: diskbackup.read(choice[1]), self.confirm_restore)

    def confirm_restore(self, data):
        from Screens.MessageBox import MessageBox
        self.s.session.openWithCallback(lambda yes: self.restore_disk(data) if yes else None, MessageBox,
                                       native(T("Restore this backup? Current channels, folders, settings and custom icons will be replaced.")),
                                       type=MessageBox.TYPE_YESNO, default=False)

    def restore_disk(self, data):
        try:
            store.validate_backup(data)
            self.s.audio_timer.stop()
            self.s.pic_timer.stop()
            self.s._audio_pending = self.s._pic_pending = None
            ctl.get().stop()
        except Exception as e:
            return self.backup_message(to_text(e))
        self.say(T("Restoring backup..."))
        self._backup_work(lambda: store.restore_backup(data), self.restore_done)

    def restore_done(self, result):
        self.s.cwd = ""
        self.s._sel = {}
        self.s._shown = None
        self.s.language_changed(self.idx)
        self.s.fill()
        self.redraw()
        self.backup_message(T("Backup restored. Restart the GUI to apply all settings."))

    def add_foxfm(self):
        try:
            from . import presets
            result = presets.install_foxfm(force=True)
            self.s.fill()
            self.say(T("FoX FM: %d added, %d already present", result["added"], result["existing"]))
        except Exception as e:
            self.say(to_text(e)[:80])
        self.redraw()

    def _schedule_auto_update(self):
        if _session_update_checked[0]:
            return
        from enigma import eTimer
        if self._auto_timer is None:
            self._auto_timer = eTimer()
            connect_timer(self._auto_timer, self._auto_update_tick, self._connections)
        self._auto_timer.start(25000, True)

    def _auto_update_tick(self):
        if self._backup_screen_closed or (self._auto_started and self._auto_meta is None):
            return
        if (not user_input_idle(1.5) or self._update_busy or self._deps_busy or self._backup_busy
                or self.update.is_open or getattr(self.s.session, 'current_dialog', self.s) is not self.s):
            self._auto_timer.start(1500, True)
            return
        if self._auto_meta is not None:
            meta, self._auto_meta = self._auto_meta, None
            opened_menu = not self.is_open
            if opened_menu:
                self.idx = next(i for i, item in enumerate(ITEMS) if item[0] == 'online_update')
                self.open()
            self.update.show('checking', T('Checking for updates...'))
            self.online_check_done(meta, None)
            self.update.return_to_library = opened_menu
            return
        _session_update_checked[0] = True
        self._auto_started = True
        self._update_busy = True

        def work(report):
            from . import updater
            return updater.check()
        self._start_update_job(work, self._auto_update_done)

    def _auto_update_done(self, meta, error):
        self._update_busy = False
        if self._backup_screen_closed or error or not meta:
            return
        self._auto_meta = meta
        self._auto_update_tick()

    def _start_update_job(self, work, done):
        from enigma import eTimer
        job = {'events': queue.Queue(), 'result': None, 'complete': done, 'last': None}
        self._update_job = job
        self._update_progress = None
        if self._update_timer is None:
            self._update_timer = eTimer()
            connect_timer(self._update_timer, self._poll_update_job, self._connections)

        def report(percent, stage):
            event = (percent, stage)
            if job['last'] != event:
                job['events'].put(event)
                job['last'] = event

        def worker():
            try:
                job['result'] = (work(report), None)
            except Exception as error:
                job['result'] = (None, to_text(error))

        self._update_timer.start(250, True)
        start_thread(worker)

    def _poll_update_job(self):
        if self._backup_screen_closed or self._update_job is None:
            return
        job = self._update_job
        try:
            self._update_progress = job['events'].get_nowait()
        except queue.Empty:
            if job['result'] is not None:
                self._update_job = None
                return job['complete'](*job['result'])
        if self._update_progress is not None:
            self.online_install_progress(*self._update_progress)
        self._update_timer.start(250, True)

    def check_online_update(self):
        if self._update_busy:
            return
        self._auto_started, self._auto_meta = True, None
        if self._auto_timer is not None:
            self._auto_timer.stop()
        self._update_busy = True
        self.say(T("Checking for updates..."))
        self.update.show('checking', T('Checking for updates...'))

        def work(report):
            from . import updater
            meta = updater.check()
            return meta
        self._start_update_job(work, self.online_check_done)

    def online_check_done(self, meta, error):
        self._update_busy = False
        if self._backup_screen_closed or not self.update.is_open:
            return
        if error:
            self.say(T("Update check failed"))
            return self.update.show('error', T('Update check failed'), to_text(error))
        if not meta:
            self.say(T("Already on the latest version"))
            return self.update.show('latest', T('Already on the latest version'), T('UltraAudio is already up to date.'))
        self._update_meta = meta
        notes = (meta.get('notes_ar') if lang() == 'ar' else '') or meta.get('notes')
        self.update.show('ready', T('Version %s is ready to install', 'V1' if meta['version'] == '1.0.0' else meta['version']),
                         notes or T('An UltraAudio update is available. Press GREEN or OK to download and install it.'), meta)

    def online_update_confirmed(self, yes):
        if not yes or self._update_busy or not self._update_meta:
            return
        meta, self._update_meta = self._update_meta, None
        self._update_busy = True
        self._update_started = monotonic()
        self.s.audio_timer.stop()
        self.s.pic_timer.stop()
        self.s._audio_pending = self.s._pic_pending = None
        ctl.get().stop()
        self.say(T("Downloading and verifying update..."))

        def work(report):
            from . import updater
            return updater.install_verified(meta, report)
        self._start_update_job(work, self.online_install_done)

    def online_install_progress(self, percent, stage):
        if self._backup_screen_closed or not self._update_busy:
            return
        self.update.progress(percent, stage, int(max(0, monotonic() - self._update_started)))

    def online_install_done(self, result, error):
        self._update_busy = False
        if self._backup_screen_closed:
            return
        if error:
            self.say(T("Update installation failed"))
            return self.update.show('error', T('Update installation failed'), to_text(error))
        self.say(T('Update complete. Restarting the interface...'))
        self.update.show('complete', T('Update installed'),
                         T('Updating: %d%%', 100) + '\n\n' + T('Update complete. Restarting the interface...'))
        self.s['u_progress'].setValue(100)
        from enigma import eTimer
        self._restart_timer = eTimer()
        connect_timer(self._restart_timer, self._restart_after_update, self._connections)
        self._restart_timer.start(1500, True)

    def _restart_after_update(self):
        if self._backup_screen_closed:
            return
        try:
            from Screens.Standby import TryQuitMainloop
            self.s.session.open(TryQuitMainloop, 3)
        except Exception as error:
            self.update.show('complete', T('Restart required'),
                             T('Update installed. Restart the GUI from the receiver menu.') + '\n' + to_text(error))

    def install_deps(self):
        if self._deps_busy or self._update_busy or self._backup_busy:
            return
        from enigma import eTimer
        self._deps_busy, self._deps_result = True, None
        try:
            self._deps_offset = os.path.getsize('/tmp/ultraaudio-deps.log')
        except OSError:
            self._deps_offset = 0
        self.update.show('installing', T('Checking and repairing components...'),
                         T('Checking Python, audio decoders and output tools. Missing components will be installed from this image feed.'))
        self.s['u_title'].setText(native(T('Install missing components')))
        self.s['u_progress'].hide()
        if self._deps_timer is None:
            self._deps_timer = eTimer()
            connect_timer(self._deps_timer, self._poll_deps, self._connections)
        self._deps_timer.start(300, True)

        def work():
            from . import engine
            try:
                r = run_tool(['sh', os.path.join(engine.HERE, 'deps.sh'), '--install'], timeout=900)
                lines = [x.strip() for x in (r.stdout or '').splitlines() if x.strip()]
                results = [x for x in lines if x.startswith('RESULT:')]
                installed = [x for x in lines if x.startswith('installed:')]
                ok = r.returncode == 0 and bool(results) and results[-1].startswith('RESULT: ok')
                if ok:
                    msg = installed[-1].split(':', 1)[1].strip() if installed else ''
                else:
                    msg = results[-1].split('missing:', 1)[-1].strip() if results else (lines[-1] if lines else T('Component verification did not finish.'))
            except Exception as error:
                ok, msg = False, to_text(error)
            try:
                engine.reset_tools()
                engine.warm_up()
            except Exception:
                pass
            self._deps_result = (ok, msg)
        start_thread(work)

    def _poll_deps(self):
        if self._backup_screen_closed or not self._deps_busy:
            return
        if self._deps_result is not None:
            return self.deps_done(*self._deps_result)
        detail = T('Checking Python, audio decoders and output tools. Missing components will be installed from this image feed.')
        try:
            with open('/tmp/ultraaudio-deps.log', 'rb') as handle:
                handle.seek(0, 2)
                end = handle.tell()
                handle.seek(max(self._deps_offset, end - 12000))
                lines = handle.read().decode('utf-8', 'replace').splitlines()
            stages = [line for line in lines if line.startswith(('[CHECK]', '[FEED]', '[INSTALL]', '[WARN]', 'missing:', 'pipeline:'))]
            if stages:
                detail += '\n\n' + '\n'.join(stages[-5:])
        except EnvironmentError:  # IOError on Python 2 when the log does not exist yet
            pass
        self.s['u_notes'].setText(native(detail))
        self._deps_timer.start(500, True)

    def deps_done(self, ok, msg):
        self._deps_busy = False
        if self._backup_screen_closed:
            return
        msg = ' '.join(to_text(msg or '').split())
        if ok:
            text = T('Component checks passed. Restart the GUI, then play a station or use Test tone to check receiver audio.')
            if msg not in ('', 'nothing'):
                text += '\n\n' + T('Installed: %s', msg)
        else:
            text = T('Repair incomplete: %s', msg) + '\n\n' + T('Check internet and this image feed, then retry. Log: /tmp/ultraaudio-deps.log')
        self.update.show('complete' if ok else 'error', T('Component repair complete') if ok else T('Component repair failed'), text)
        self.s['u_title'].setText(native(T('Install missing components')))
        self.s['u_progress'].hide()
        self.say(T('Component repair complete') if ok else T('Component repair failed'))



    def show_info(self):
        def work():
            ff = which("ffmpeg")
            from .engine import ffmpeg_runtime
            ff_status = ffmpeg_runtime()
            lines = ["%s: %s (%s)" % (T("Version"), __version__, PACKAGE_VERSION),
                     "%s: http://%s:%d" % (T("Web page"), self.ip, webui.PORT),
                     "%s: %s" % (T("Python"), sys.version.split()[0]),
                     "%s: %s" % (T("ffmpeg"), (ff + ("" if ff_status[0] and ffmpeg_pcm_ok() else " (%s)" % (T("no PCM encoder") if ff_status[0] else ff_status[1][:80]))) if ff else T("no")),
                     "%s: %s" % (T("ffmpeg ALSA output"), T("yes") if ff and ffmpeg_has_alsa() else T("no")),
                     "%s: %s" % (T("Live audio delay"), (T("yes") + " (%s)" % live_delay_info()) if live_delay_info()
                                 else T("no, the stream restarts on each change")),
                     "%s: %s" % (T("aplay"), which("aplay") or T("no")),
                     "%s: %s" % (T("Python sound writer"), python_bin() or T("no (install python ctypes)")),
                     "%s: %s" % (T("GStreamer"), (which("gst-launch-1.0") + (" (%s: %s)" % (T("missing"), ", ".join(gst_missing()))
                                                  if gst_missing() else "")) if which("gst-launch-1.0") else T("no")),
                     "%s: %s" % (T("Working outputs"), ", ".join(available_modes("auto")) or T("none") + " - " + T("Missing: %s", missing_text())),
                     "%s: %s" % (T("Stream speed"), _speed_text(ctl.get().engine.status())),
                     "%s: %s" % (T("ALSA cards"), ", ".join("%d:%s" % (i, n) for i, n, _ in alsa_cards()) or T("no")),
                     "%s: %s" % (T("Last error"), " ".join((ctl.get().engine.status()["errors"] or [T("no")])[:1])[:90]),
                     "%s: %s" % (T("Sound card"), alsa_summary()[:90]),
                     "%s: %s" % (T("Audio device"), ctl.get().engine.device or alsa_candidates(store.get_settings()["alsa_device"])[0])]
            main_call(self._info_box, "\n".join(lines))
        start_thread(work)

    def _info_box(self, text):
        try:
            from Screens.MessageBox import MessageBox
            self.s.session.open(MessageBox, native(text), MessageBox.TYPE_INFO)
        except Exception:
            pass
