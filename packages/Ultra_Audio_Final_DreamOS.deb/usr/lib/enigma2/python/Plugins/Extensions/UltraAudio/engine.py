# -*- coding: utf-8 -*-
"""Audio engine: plays an IP audio link on the receiver's ALSA or DVB output.

Pipeline (auto-detected):
  ffmpeg -> ALSA (ffmpeg built with alsa)         output=alsa
  ffmpeg -> aplay (alsa-utils)                    output=aplay
  gst-launch-1.0 (no delay / limited)             output=gst
  ffmpeg -> null (self-test only)                 output=null
Reconnects by itself when the link drops.
"""
from __future__ import division
import os
import re
import struct
import signal
import subprocess
import threading
import time

from . import store
from .audiohw import playback_devices
from .compat import (DEVNULL, TimeoutExpired, acquire, communicate, connect_timer, is_main_thread,
                     monotonic, open_text, popen, queue, replace, run, start_thread, to_text,
                     urlsplit, wait, which as _which, zeros)
from .i18n import T

LOG = os.environ.get("ULTRAAUDIO_LOG", "/tmp/ultraaudio.log")
_log_lock = threading.Lock()


def log(msg):
    line = u"%s %s\n" % (to_text(time.strftime("%H:%M:%S")), to_text(msg))
    with _log_lock:
        try:
            if os.path.exists(LOG) and os.path.getsize(LOG) > 200 * 1024:
                replace(LOG, LOG + ".1")
            with open_text(LOG, "a") as f:
                f.write(line)
        except EnvironmentError:
            pass


def log_tail(n=40):
    try:
        with open_text(LOG) as f:
            return f.read().splitlines()[-n:]
    except EnvironmentError:
        return []


_main_calls = queue.Queue()
_main_timer = None
_main_connections = []


def _drain_main_calls():
    # Called by Enigma2's timer exclusively on its main loop.
    for unused in range(64):
        try:
            fn, args = _main_calls.get_nowait()
        except queue.Empty:
            return
        try:
            fn(*args)
        except Exception as exc:
            log("main-thread callback failed: %r" % exc)


def init_main_dispatcher():
    """Attach the worker queue to a native timer before enabling web controls."""
    global _main_timer
    if _main_timer is not None:
        return
    if not is_main_thread():
        raise RuntimeError("Main-thread dispatcher must be installed on the main loop")
    from enigma import eTimer
    timer = eTimer()
    connect_timer(timer, _drain_main_calls, _main_connections)   # DreamOS: keep the connection object alive
    timer.start(50, False)
    _main_timer = timer


def stop_main_dispatcher():
    global _main_timer
    if _main_timer is not None:
        _main_timer.stop()
        _main_timer = None
    del _main_connections[:]
    while True:
        try:
            _main_calls.get_nowait()
        except queue.Empty:
            break


def main_call(fn, *args):
    """Never invoke receiver/UI APIs from an HTTP or audio worker thread."""
    if is_main_thread():
        return fn(*args)
    if _main_timer is not None:
        _main_calls.put((fn, args))
        return
    try:
        import enigma
    except ImportError:
        # Standalone probes/tests have no native receiver APIs to protect.
        return fn(*args)
    try:
        from twisted.internet import reactor
        reactor.callFromThread(fn, *args)
    except (ImportError, AttributeError, RuntimeError, TypeError, OSError) as exc:
        # A stopped/broken Twisted waker is not permission to touch C++ UI
        # objects on this worker. The next request can retry after attach().
        log("main-thread dispatch unavailable: %r" % exc)


_tool_cache = {}


def warm_up():
    """Find the tools (ffmpeg formats, GStreamer elements, the Python writer) in the background when Enigma2 starts, so
    the first commentary does not wait seconds for gst-inspect / python checks."""
    def work():
        t0 = monotonic()
        try:
            modes = available_modes("auto")
            live_delay_info()
            log("audio tools ready in %.1fs: %s" % (monotonic() - t0, ", ".join(modes) or "none"))
            from . import PACKAGE_VERSION
            log("UltraAudio %s compatibility build: ALSA cards=%d; DVB sink=%s; auto devices=%s" % (
                PACKAGE_VERSION, len(alsa_cards()), dvb_sink_ok(), ','.join(alsa_candidates('auto'))))
        except Exception as e:
            log("tool check failed: %r" % (e,))
    start_thread(work, name="UltraAudio-warmup")


def reset_tools():
    """Forget what was found (after the component installer ran): the next start looks again."""
    _tool_cache.clear()
    _ff_off[0] = False
    _ff_bad_opts.clear()
    _ff_stream_off[0] = False
    _ff_no_scheme.clear()
    _relay_off[0] = False
    _gst_missing.clear()
    _dead_alsa_devs.clear()
    _oss_probed[0] = False


def which(name):
    if name not in _tool_cache:
        _tool_cache[name] = _which(name)
    return _tool_cache[name]


def ffmpeg_runtime():
    """(usable, reason). Finding /usr/bin/ffmpeg is NOT proof it can run.

    Some OE images have an FFmpeg binary but a missing / incompatible .so.
    Probe the dynamic loader before selecting any FFmpeg output. Cache only
    for this Enigma2 session; reset_tools() invalidates after component repair.
    """
    if "ffmpeg_runtime" not in _tool_cache:
        ff = which("ffmpeg")
        if not ff:
            _tool_cache["ffmpeg_runtime"] = (False, "ffmpeg not installed")
        else:
            try:
                result = run([ff, "-version"], timeout=8)
                if result.returncode == 0 and "ffmpeg version" in result.stdout.lower():
                    _tool_cache["ffmpeg_runtime"] = (True, "")
                else:
                    details = (result.stderr or result.stdout or "ffmpeg failed to start").strip().splitlines()
                    reason = details[0][:240] if details else "ffmpeg failed to start"
                    _tool_cache["ffmpeg_runtime"] = (False, reason)
                    log("FFmpeg cannot start: " + reason)
            except (EnvironmentError, TimeoutExpired) as exc:
                _tool_cache["ffmpeg_runtime"] = (False, to_text(exc)[:240])
                log("FFmpeg cannot start: %s" % exc)
    return _tool_cache["ffmpeg_runtime"]


def ffmpeg_input_support():
    """(option names, input protocols) of this ffmpeg; None for a part that could not be read.

    Old receiver builds (DreamOS 2.5) reject -rw_timeout / -reconnect_* and some have no http/https protocol: options
    it does not list are left out, and a missing protocol sends the link to GStreamer instead of failing every try."""
    if "ff_input" in _tool_cache:
        return _tool_cache["ff_input"]
    with _probe_lock:
        if "ff_input" not in _tool_cache:
            _tool_cache["ff_input"] = _probe_ffmpeg_input()
    return _tool_cache["ff_input"]


def _probe_ffmpeg_input():
    opts = protos = None
    ff = which("ffmpeg")
    if ff and ffmpeg_runtime()[0]:
        try:
            out = run([ff, "-hide_banner", "-h", "full"], timeout=12).stdout
            found = set(re.findall(r"(?m)^\s+-([A-Za-z0-9_]+)\b", out))
            opts = found if len(found) > 100 else None        # a partial / odd help text proves nothing
        except (EnvironmentError, TimeoutExpired):
            pass
        try:
            out = run([ff, "-hide_banner", "-protocols"], timeout=8).stdout
            if "Input:" in out:
                body = out.split("Input:", 1)[1].split("Output:", 1)[0]
                protos = set(x.strip() for x in body.split() if x.strip())
        except (EnvironmentError, TimeoutExpired):
            pass
        if protos is not None and not (protos & set(("http", "https"))):
            log("this ffmpeg cannot open http/https links; GStreamer plays them")
        if opts is not None:
            missing = [o for o in _FF_OPTIONAL if o not in opts]
            if missing:
                log("this ffmpeg has no %s; starting it without" % ", ".join("-" + o for o in missing))
    return (opts, protos)


def ffmpeg_reads(url):
    """Can this ffmpeg open this link's protocol? (old builds have http but no https)."""
    scheme = (urlsplit(play_url(url)).scheme or "").lower()
    if not scheme or scheme in _ff_no_scheme:
        return not scheme
    protos = ffmpeg_input_support()[1]
    return protos is None or scheme in protos


def ffmpeg_streams_ok():
    """False once this ffmpeg proved it cannot open the links (no http/https protocol)."""
    if _ff_stream_off[0]:
        return False
    protos = ffmpeg_input_support()[1]
    return protos is None or bool(protos & set(("http", "https")))


def ffmpeg_formats():
    """{name: (can read, can write)} of this receiver's ffmpeg. Receiver images often ship a trimmed ffmpeg (Vu+/OpenATV:
    no raw 's16le' or 'mp2' muxer at all), so nothing may be assumed. {} when ffmpeg cannot be asked."""
    if "formats" in _tool_cache:
        return _tool_cache["formats"]
    found = {}
    ff = which("ffmpeg")
    if ff and ffmpeg_runtime()[0]:
        try:
            result = run([ff, "-hide_banner", "-formats"], timeout=8)
            out = result.stdout if result.returncode == 0 else ""
            body = out.split("--", 1)[1] if "--" in out else out
            for line in body.splitlines():
                parts = line.split(None, 2)
                if len(parts) < 2 or not re.match(r"^[DEd.]+$", parts[0]):
                    continue
                for name in parts[1].split(","):
                    old = found.get(name, (False, False))
                    found[name] = (old[0] or "D" in parts[0], old[1] or "E" in parts[0])
        except TimeoutExpired:
            return found
        except EnvironmentError:
            pass
    _tool_cache["formats"] = found
    return found


def ffmpeg_has_alsa():
    return ffmpeg_formats().get("alsa", (False, False))[1]


def relay_formats():
    """(format ffmpeg writes the decoded PCM in, format the ffmpeg->ALSA writer reads it in), each 's16le', 'wav' or
    None. Unknown capabilities never imply an available output muxer."""
    f = ffmpeg_formats()
    if not f:
        return None, None
    out = "s16le" if f.get("s16le", (0, 0))[1] else "wav" if f.get("wav", (0, 0))[1] else None
    inp = "s16le" if f.get("s16le", (0, 0))[0] else "wav" if f.get("wav", (0, 0))[0] else None
    return out, inp


# ------------------------------------------------------------------ what this receiver can do
# A mode is "decoder + writer":
#   alsa       ffmpeg decodes, ffmpeg writes to ALSA             (live delay)
#   aplay      ffmpeg decodes, aplay writes                      (live delay)
#   pcm        ffmpeg decodes, pcmplay.py (libasound) writes     (live delay)
#   gst-pcm    GStreamer decodes, pcmplay.py writes              (live delay)
#   gst-aplay  GStreamer decodes, aplay writes                   (live delay)
#   gst        GStreamer alone, straight to alsasink             (no delay)
#   null       ffmpeg, no sound (self-test)
# Trimmed receiver images may lack aplay, PCM encoders/muxers or GStreamer output elements.
# The gst-pcm route needs gst-launch, libasound2/dvbaudiosink and ctypes.
HERE = os.path.dirname(os.path.abspath(__file__))
PCMPLAY = os.path.join(HERE, "pcmplay.py")
GSTPLAY = os.path.join(HERE, "gstplay.py")
FF_MODES = ("alsa", "aplay", "pcm", "null")
GST_RELAY_MODES = ("gst-pcm", "gst-aplay")
ALL_MODES = ("alsa", "aplay", "pcm", "gst-pcm", "gst-aplay", "gst")
_ff_off = [False]            # this ffmpeg proved it cannot make PCM at all (no pcm_s16le encoder/muxer): decode with GStreamer
_ff_bad_opts = set()         # input options this ffmpeg rejected ("Unrecognized option 'rw_timeout'" on DreamOS 2.5)
_ff_stream_off = [False]     # this ffmpeg cannot open http/https links at all: GStreamer only
_ff_no_scheme = set()        # link schemes this ffmpeg answered "Protocol not found" for (https on old builds)
_probe_lock = threading.Lock()
_tls_level = {}              # host -> 1: bundled CA store, 2: no certificate check (outdated receiver certificate store)
_gst_missing = set()         # GStreamer elements this receiver proved to lack ('no element "volume"')
_dead_alsa_devs = set()      # ALSA device names that failed with No such file or directory / missing /dev/dsp
_oss_probed = [False]        # True after modprobe snd-pcm-oss was attempted once

# GStreamer element -> the OE package that brings it (for the error text and the dependency installer)
GST_PACKAGES = {"volume": "gstreamer1.0-plugins-base-volume", "audioconvert": "gstreamer1.0-plugins-base-audioconvert",
                "audioresample": "gstreamer1.0-plugins-base-audioresample", "alsasink": "gstreamer1.0-plugins-base-alsa",
                "decodebin": "gstreamer1.0-plugins-base-playback", "uridecodebin": "gstreamer1.0-plugins-base-playback",
                "souphttpsrc": "gstreamer1.0-plugins-good-souphttpsrc", "fdsink": "gstreamer1.0",
                "capsfilter": "gstreamer1.0"}
GST_DECODE_NEEDS = ("decodebin", "audioconvert", "audioresample", "fdsink", "capsfilter")


def ffmpeg_encoders():
    """Set of encoder names of this ffmpeg, or None when it cannot be asked."""
    if "encoders" in _tool_cache:
        return _tool_cache["encoders"]
    found = set()
    ff = which("ffmpeg")
    if ff and ffmpeg_runtime()[0]:
        try:
            result = run([ff, "-hide_banner", "-encoders"], timeout=8)
            out = result.stdout if result.returncode == 0 else ""
            for line in out.splitlines():
                parts = line.split()
                if len(parts) >= 2 and re.match(r"^[VASFXBD.]{6}$", parts[0]) and parts[1] != "=":
                    found.add(parts[1])
        except TimeoutExpired:
            return found or None
        except EnvironmentError:
            pass
    _tool_cache["encoders"] = found or None
    return _tool_cache["encoders"]


def ffmpeg_pcm_ok():
    """Can this ffmpeg turn a link into raw PCM? (a trimmed receiver ffmpeg may lack PCM encoders or PCM muxers)."""
    if _ff_off[0] or not ffmpeg_runtime()[0]:
        return False
    enc = ffmpeg_encoders()
    out_fmt, _ = relay_formats()
    return enc is not None and "pcm_s16le" in enc and out_fmt is not None


def gst_elements():
    """Set of GStreamer element names (from gst-inspect-1.0), or None when gst-inspect is not there."""
    if "gst_elements" in _tool_cache:
        return _tool_cache["gst_elements"]
    found = set()
    insp = which("gst-inspect-1.0")
    if insp:
        try:
            out = run([insp], timeout=40).stdout       # the first run may have to build the registry
            for line in out.splitlines():
                m = re.match(r"^\s*[\w.\-]+:\s+([\w\-]+):\s", line)
                if m:
                    found.add(m.group(1))
        except (EnvironmentError, TimeoutExpired):
            pass
    _tool_cache["gst_elements"] = found or None
    return _tool_cache["gst_elements"]


def gst_has(name):
    if name in _gst_missing:
        return False
    els = gst_elements()
    if els is not None and name in els:
        return True
    # gst-inspect may be absent, incomplete or use a different catalogue
    # layout. Never assume an element exists solely because gst-launch exists.
    insp = which("gst-inspect-1.0")
    if not insp:
        return False
    key = "gst_has_" + name
    if key not in _tool_cache:
        try:
            _tool_cache[key] = run([insp, name], timeout=8).returncode == 0
        except (EnvironmentError, TimeoutExpired):
            _tool_cache[key] = False
    return _tool_cache[key]


def gst_missing():
    """GStreamer elements Ultra Audio would use that this receiver lacks."""
    if not which("gst-launch-1.0"):
        return []
    return [e for e in GST_DECODE_NEEDS + ("souphttpsrc", "volume", "alsasink") if not gst_has(e)]


def gst_decode_ok():
    return bool(which("gst-launch-1.0")) and all(gst_has(e) for e in GST_DECODE_NEEDS)


def dvb_sink_ok():
    """True when GStreamer or direct DVB PES can output to /dev/dvb/adapter0/audio0."""
    if not which("gst-launch-1.0"):
        return False
    if gst_has("dvbaudiosink"):
        return True
    return os.path.exists("/dev/dvb/adapter0/audio0")


def _probe_ff_dvb(in_fmt, codec, muxer):
    """Verify that this receiver's ffmpeg can actually encode 0.1s of silence with (in_fmt -> codec -> muxer)."""
    key = "ff_dvb_%s_%s_%s" % (in_fmt, codec, muxer)
    if key in _tool_cache:
        return _tool_cache[key]
    ff = which("ffmpeg")
    if not ff or not ffmpeg_runtime()[0]:
        _tool_cache[key] = False
        return False
    pcm = zeros(19200)
    if in_fmt == "wav":
        inp = ["-f", "wav", "-ignore_length", "1", "-i", "pipe:0"]
        payload = wav_header() + pcm
    else:
        inp = ["-f", "s16le", "-ar", "48000", "-ac", "2", "-i", "pipe:0"]
        payload = pcm
    cmd = [ff, "-hide_banner", "-loglevel", "error", "-nostdin"] + inp + [
        "-vn", "-c:a", codec, "-b:a", "128k", "-f", muxer, "pipe:1"]
    ok = False
    p = None
    try:
        p = popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=DEVNULL)
        out, _ = communicate(p, payload, timeout=4)     # Python 2.7 Popen.communicate() has no timeout
        ok = p.returncode == 0 and len(out) > 0
    except Exception:
        ok = False
    finally:
        if p is not None and p.poll() is None:
            try:
                p.kill()
                p.communicate()
            except Exception:
                pass
    _tool_cache[key] = ok
    return ok


def dvb_pipe_kind(dev="dvb"):
    """Best verified pipeline mode for pcmplay.py when writing to dvbaudiosink or /dev/dvb/adapter0/audio0."""
    # Legacy dvb-raw routes also need compressed output: raw PCM stalls DM900/920.
    cache_key = "dvb_pipe_pes" if dev == "dvb-pes" else "dvb_pipe_gst"
    if cache_key in _tool_cache:
        return _tool_cache[cache_key]
    if dev != "dvb-pes":
        raw_sub = "raw" if gst_has("rawaudioparse") else "wav" if gst_has("wavparse") else "caps"
        for kind, enc_el, parse_el in (
            ("gst-mp2", "avenc_mp2", "mpegaudioparse"),
            ("gst-twolame", "twolamemp2enc", "mpegaudioparse"),
            ("gst-mp3", "lamemp3enc", "mpegaudioparse"),
            ("gst-aac", "avenc_aac", "aacparse"),
            ("gst-faac", "faac", "aacparse"),
            ("gst-voaac", "voaacenc", "aacparse"),
            ("gst-fdkaac", "fdkaacenc", "aacparse"),
            ("gst-ac3", "avenc_ac3", "ac3parse"),
        ):
            if gst_has(enc_el) and gst_has(parse_el):
                _tool_cache[cache_key] = "%s:%s" % (kind, raw_sub)
                return _tool_cache[cache_key]
    if ffmpeg_runtime()[0]:
        f = ffmpeg_formats()
        enc = ffmpeg_encoders() or ()
        for in_fmt in ("s16le", "wav"):
            if f and not f.get(in_fmt, (0, 0))[0]:
                continue
            prefix = "wav-" if in_fmt == "wav" else ""
            for kind, codec, muxer, parser_el in (
                ("mp2", "mp2", "mp2", "mpegaudioparse"),
                ("mp2-mp3", "mp2", "mp3", "mpegaudioparse"),
                ("aac", "aac", "adts", "aacparse"),
                ("mpegts-mp2", "mp2", "mpegts", "mpegaudioparse"),
                ("mpegts-aac", "aac", "mpegts", "aacparse"),
                ("ac3", "ac3", "ac3", "ac3parse"),
            ):
                if enc and codec not in enc:
                    continue
                if f and not f.get(muxer, (0, 0))[1]:
                    continue
                if dev != "dvb-pes" and which("gst-inspect-1.0") and not gst_has(parser_el):
                    continue
                if _probe_ff_dvb(in_fmt, codec, muxer):
                    _tool_cache[cache_key] = prefix + kind
                    return _tool_cache[cache_key]
    _tool_cache[cache_key] = "unavailable"
    return "unavailable"


def gst_direct_ok():
    return gst_decode_ok() and (gst_has("alsasink") or dvb_sink_ok())


def _python_candidates():
    """Interpreters able to run the helper scripts: DreamOS (OE2.5/2.6) only has Python 2.7."""
    import sys
    cands = []
    exe = getattr(sys, "executable", "") or ""
    if os.path.basename(exe).startswith("python"):
        cands.append(exe)
    names = ("python3", "python2", "python", "python2.7") + tuple("python3.%d" % i for i in range(20, 4, -1))
    for name in names:
        p = which(name)
        if p and p not in cands:
            cands.append(p)
    return cands


def python_bin():
    """A Python interpreter (Python 2.7 or Python 3.x) that can run pcmplay.py (ctypes + libasound / DVB), or None."""
    if "python" in _tool_cache:
        return _tool_cache["python"]
    found = None
    for py in _python_candidates():
        try:
            if run([py, "-E", "-s", PCMPLAY, "--check"], timeout=15).returncode == 0:
                found = py
                break
        except (EnvironmentError, TimeoutExpired):
            continue
    _tool_cache["python"] = found
    return found


def pcm_writer_ok():
    return os.path.isfile(PCMPLAY) and python_bin() is not None


def gst_track_python():
    """Probe an external interpreter (Python 2 or 3); GI must never be imported into Enigma2."""
    if "gst_track_python" not in _tool_cache:
        _tool_cache["gst_track_python"] = None
        seen = set()
        for py in [python_bin()] + _python_candidates():
            if not py or py in seen:
                continue
            seen.add(py)
            try:
                if run([py, "-E", "-s", GSTPLAY, "--check"], timeout=10).returncode == 0:
                    _tool_cache["gst_track_python"] = py
                    break
            except (EnvironmentError, TimeoutExpired):
                pass
    return _tool_cache["gst_track_python"]


def gst_selected_argv(url, ua, vol, track, dev=None, buffer_ms=500):
    py = gst_track_python()
    if not py:
        raise ValueError(T("Selecting a GStreamer audio track needs Python GStreamer bindings. Run Install missing components."))
    args = [py, "-E", "-s", GSTPLAY, "--url", play_url(url), "--user-agent", ua or store.DEFAULT_UA,
            "--track", str(track), "--volume", str(vol)]
    if dev is not None:
        args += ["--device", dev, "--buffer-ms", str(buffer_ms)]
    return args


def _mode_ok(mode):
    if mode in ("alsa", "aplay", "pcm") and not ffmpeg_streams_ok():
        return False
    if mode == "alsa":
        return (ffmpeg_pcm_ok() and ffmpeg_has_alsa()) or (
            bool(alsa_cards()) and not _ff_off[0] and ffmpeg_runtime()[0] and ffmpeg_has_alsa())
    if mode == "aplay":
        return ffmpeg_pcm_ok() and bool(which("aplay"))
    if mode == "pcm":
        return ffmpeg_pcm_ok() and pcm_writer_ok()
    if mode == "gst-pcm":
        return gst_decode_ok() and pcm_writer_ok()
    if mode == "gst-aplay":
        return gst_decode_ok() and bool(which("aplay"))
    if mode == "gst":
        return gst_direct_ok()
    if mode == "null":
        return ffmpeg_runtime()[0]
    return False


_SETTING_MODES = {"auto": ALL_MODES, "alsa": ("alsa", "gst-pcm", "gst-aplay"), "aplay": ("aplay", "gst-aplay"),
                  "pcm": ("pcm", "gst-pcm"), "gst": ("gst-pcm", "gst-aplay", "gst"),
                  "dvb": ("gst-pcm", "gst", "pcm", "alsa"), "null": ("null",)}


def _mode_has_live_delay(mode):
    if mode in GST_RELAY_MODES:
        return True
    if mode in FF_MODES and mode != "null":
        return not _relay_off[0] and relay_possible(mode)
    return False


def available_modes(setting):
    """Outputs to try, best first: live-delay (relay) modes first so audio delay never restarts playback."""
    raw = [m for m in _SETTING_MODES.get(setting, ALL_MODES) if _mode_ok(m)]
    return [m for m in raw if _mode_has_live_delay(m)] + [m for m in raw if not _mode_has_live_delay(m)]


def missing_text():
    """What to install so that sound can work: a short list of package names."""
    need = []
    if not alsa_cards() and not os.path.exists('/dev/dsp') and not dvb_sink_ok():
        need.append('DVB audio output: gst-plugin-dvbmediasink (image feed)')
    if not which("ffmpeg"):
        need.append("ffmpeg")
    elif not ffmpeg_runtime()[0]:
        need.append("ffmpeg: " + ffmpeg_runtime()[1][:135])
    elif not ffmpeg_pcm_ok():
        need.append(T("a full ffmpeg (this one has no PCM encoder)"))
    if not which("gst-launch-1.0"):
        need.append("gstreamer1.0")
    else:
        for e in gst_missing():
            pkg = GST_PACKAGES.get(e, e)
            if e not in ("volume", "souphttpsrc") and pkg not in need:
                need.append(pkg)
    if not which("aplay") and not pcm_writer_ok():
        need.append("alsa-utils-aplay / python ctypes")
    return ", ".join(need)


def pick_output(setting):
    """Return (mode, error)."""
    modes = available_modes(setting)
    if modes:
        return modes[0], None
    if setting != "auto" and available_modes("auto"):
        return None, T("The chosen audio output (%s) cannot work on this receiver; set Audio output to Auto", setting.upper())
    return None, T("No working audio output on this receiver. Missing: %s. Run the installer: %s",
                   missing_text() or "?", "sh %s/deps.sh" % HERE)


def routes(settings, delay=0):
    """[(mode, device)] in the order to try: live-delay routes first, then fallbacks."""
    modes = [m for m in available_modes(settings["output"]) if not (m == "gst" and delay)]
    dev_setting = "dvb" if settings.get("output") == "dvb" else settings.get("alsa_device")
    devs = alsa_candidates(dev_setting)
    combos = []
    for d in devs:
        if d in ("dvb", "dvb-pes", "dvb-raw"):
            # Prefer live-delay relay (gst-pcm / pcm) so audio delay changes never restart the stream and 0-delay has a jitter cushion.
            dvb_order = [m for m in ("gst-pcm", "pcm", "alsa", "gst-aplay", "aplay", "gst")
                         if m in modes and not (d == "dvb-pes" and m == "gst")]
            for m in dvb_order:
                combos.append((m, d))
        else:
            for m in modes:
                combos.append((m, d))
    saved = str(settings.get("route") or "")
    if "|" in saved:
        pair = tuple(saved.split("|", 1))
        # Do not jump straight to dvb-raw ahead of dvb/dvb-pes unless dvb already failed in this session,
        # and never let a saved non-live-delay route override an available live-delay relay route.
        prefer_alsa = (dev_setting in ("auto", "", None) and bool(alsa_cards()) and pair[1].startswith("dvb"))
        has_live_alt = any(_mode_has_live_delay(m) for m, _ in combos)
        keep_saved = _mode_has_live_delay(pair[0]) or not has_live_alt
        if (pair in combos and keep_saved and pair[1] not in _dead_alsa_devs and not prefer_alsa
                and not (pair[1] == "dvb-raw" and "dvb" not in _dead_alsa_devs)):
            combos.remove(pair)
            combos.insert(0, pair)
    return combos


ASOUND = "/proc/asound"


def alsa_cards():
    """Playback cards, including kernels exposing only /proc/asound/pcm or /dev/snd nodes."""
    cards = []
    for index in sorted(set(card for card, _ in playback_devices(ASOUND))):
        try:
            with open_text(os.path.join(ASOUND, "card%d" % index, "id")) as handle:
                ident = handle.read().strip()
        except EnvironmentError:
            ident = ""
        ident = re.sub(r"[^A-Za-z0-9_.\-]", "", ident)
        cards.append((index, ident, ident or "ALSA card %d" % index))
    return cards


def ensure_oss_module():
    """If no ALSA cards exist and /dev/dsp is missing, try loading snd-pcm-oss once."""
    if _oss_probed[0] or os.path.exists("/dev/dsp") or alsa_cards():
        return
    _oss_probed[0] = True
    mp = which("modprobe")
    if mp:
        try:
            run([mp, "snd-pcm-oss"], timeout=4)
        except Exception:
            pass


def alsa_candidates(setting):
    """Devices to try, best first. 'auto' = plughw:N,0 of every real card (the direct-device method used by working commentary plugins
    on Vu+), then the named card, then ALSA's shared 'default', or 'dvb' / 'dvb-pes' / 'dvb-raw' when no ALSA card exists."""
    if setting == "dvb":
        alive = [d for d in ("dvb", "dvb-pes", "dvb-raw") if d not in _dead_alsa_devs]
        return alive or ["dvb", "dvb-pes", "dvb-raw"]
    if setting not in ("auto", "", None):
        return [setting]
    ensure_oss_module()
    cards = alsa_cards()
    dvb_devs = ["dvb", "dvb-pes", "dvb-raw"] if dvb_sink_ok() else []
    if cards:
        out = ["plughw:%d,%d" % pair for pair in playback_devices(ASOUND)]
        out += ["sysdefault:CARD=%s" % ident for _, ident, _ in cards if ident]
        out.append("default")
        out += dvb_devs
    elif os.path.exists("/dev/dsp"):
        out = ["default"] + dvb_devs
    else:
        # Receiver has no ALSA playback substreams and no /dev/dsp: try DVB hardware audio sink first
        out = dvb_devs + ["default"]
    alive = [d for d in out if d not in _dead_alsa_devs]
    return alive or out or ["default"]


def build_pipeline(input_args, mode, settings, audio_delay_ms=0, track=0, ua=None, url=None):
    """Return a list of argv lists (1 = single process, 2 = piped)."""
    dev = settings["alsa_device"]
    if dev in ("auto", ""):
        dev = alsa_candidates(dev)[0]
    vol = max(0, min(200, int(settings["volume"]))) / 100.0
    if mode == "gst":
        if audio_delay_ms:
            raise ValueError(T("Audio delay needs ffmpeg; the current GStreamer mode cannot do it"))
        is_dvb = dev in ("dvb", "dvb-raw", "dvb-pes") or str(dev).startswith("dvb:")
        if track or (is_dvb and gst_track_python()):
            return [gst_selected_argv(url, ua, vol, track, "dvb-raw" if dev == "dvb-raw" else ("dvb" if is_dvb else dev),
                                      settings["buffer_ms"])]
        if is_dvb:
            return [gst_dvb_chain(url, ua, vol, raw=(dev == "dvb-raw"))]
        cmd, _ = gst_chain(url, ua, vol)
        return [cmd + ["alsasink", "device=" + dev, "buffer-time=" + str(int(settings["buffer_ms"]) * 1000)]]
    ff = which("ffmpeg")
    filt = ["aformat=channel_layouts=stereo"]
    if audio_delay_ms > 0:
        filt.append("adelay=%d|%d" % (audio_delay_ms, audio_delay_ms))
    if abs(vol - 1.0) > 0.001:
        filt.append("volume=%.2f" % vol)
    filt.append("aresample=48000")
    filt.append("aformat=sample_fmts=s16:channel_layouts=stereo")
    common = [ff, "-hide_banner", "-loglevel", "warning", "-nostdin"]
    if mode == "null":
        common.append("-re")
    cmd = common + input_args + ["-map", "0:a:%d" % track, "-vn", "-sn", "-dn", "-af", ",".join(filt),
                                 "-ac", "2", "-ar", "48000"]
    out_fmt, _ = relay_formats()
    if mode == "alsa" and (not pcm_writer_ok() or out_fmt is None):
        return [cmd + ["-f", "alsa", dev]]
    if mode == "null":
        return [cmd + ["-f", "null", "-"]]
    if out_fmt is None:
        raise ValueError("FFmpeg has no verified PCM output muxer; use GStreamer")
    ffmpeg_cmd = cmd + ["-c:a", "pcm_s16le", "-f", out_fmt, "pipe:1"]
    return [ffmpeg_cmd, pcm_writer_argv("pcm" if mode in ("pcm", "alsa") else "aplay", dev, settings)]


def pcm_writer_argv(kind, dev, settings):
    """argv of a program that plays raw S16_LE / 48 kHz / stereo from its stdin: aplay or pcmplay.py."""
    # Test5: back to the official 1.0.6 writer settings (buffer from the settings, default 500 ms; commentary starts
    # at pcmplay's 150 ms). The forced 1200 ms / 320 ms made the Vu+ card accept only ~0.85x real time.
    buf = "--buffer-time=%d" % (int(settings["buffer_ms"]) * 1000)
    is_dvb = dev in ("dvb", "dvb-raw", "dvb-pes") or str(dev).startswith("dvb:")
    if kind == "pcm" or (is_dvb and pcm_writer_ok()):
        cmd = [python_bin(), "-E", "-s", PCMPLAY, "-D", dev, "-r", str(PCM_RATE), "-c", "2", buf]
        if is_dvb:
            cmd.append("--dvb-pipe=%s" % dvb_pipe_kind(dev))
        if settings.get("_radio"):
            cmd.append("--start-ms=180")   # only for streamed radio, unchanged for commentary
        return cmd
    return [which("aplay"), "-q", "-t", "raw", "-f", "S16_LE", "-r", str(PCM_RATE), "-c", "2", "-D", dev, buf, "-"]


GST_CAPS = "audio/x-raw,format=S16LE,rate=48000,channels=2,layout=interleaved"
# decodebin: stop at raw audio and drop every other stream BEFORE it is decoded. Without this a TV link (4K video + the
# commentary) gets its picture decoded in software too, which starves the audio on a receiver CPU.
AUDIO_ONLY = ["caps=audio/x-raw", "expose-all-streams=false"]


DVB_PASSTHRU_CAPS = ("audio/mpeg,parsed=(boolean)true;audio/mpeg,framed=(boolean)true;"
                     "audio/x-ac3,framed=(boolean)true;audio/x-eac3,framed=(boolean)true;"
                     "audio/x-dts,framed=(boolean)true;audio/x-raw")


CA_BUNDLE = os.path.join(store.ASSETS, "certs", "cacert.pem")


def _host(url):
    try:
        return (urlsplit(to_text(url)).hostname or "").lower()
    except Exception:
        return ""


def _soup_tls(url):
    """souphttpsrc properties for an https link. On DreamOS OE2.5 (Python 2 / GnuTLS from 2021), glib-networking
    rejects modern cross-signed chains even with a fresh CA bundle; pass ssl-strict=false directly on Python 2 so
    HTTPS streams start on the very first attempt without 2 wasted retries."""
    if not re.match(r"^https://", url, re.I):
        return []
    import sys as _sys
    default_level = 2 if _sys.version_info[0] == 2 else 0
    level = _tls_level.get(_host(url), default_level)
    if level == 1 and os.path.isfile(CA_BUNDLE):
        return ["ssl-ca-file=" + CA_BUNDLE, "ssl-use-system-ca-file=false"]
    if level == 2:
        return ["ssl-strict=false"]
    return []


def gst_dvb_chain(url, ua, vol, raw=False):
    """Direct GStreamer pipeline into dvbaudiosink (compressed passthrough when raw=False, PCM when raw=True)."""
    url = play_url(url)
    cmd = [which("gst-launch-1.0") or "gst-launch-1.0", "-q"]
    caps = ["caps=audio/x-raw" if raw else "caps=" + DVB_PASSTHRU_CAPS, "expose-all-streams=false"]
    if re.match(r"^https?://", url, re.I) and gst_has("souphttpsrc"):
        cmd += (["souphttpsrc", "location=" + url, "user-agent=" + (ua or store.DEFAULT_UA), "timeout=10", "blocksize=8192"]
                + _soup_tls(url) + ["!", "decodebin"] + caps + ["!"])
    else:
        cmd += ["uridecodebin", "uri=" + url] + caps + ["!"]
    if raw:
        cmd += ["audioconvert", "!", "audioresample", "!"]
        if abs(vol - 1.0) > 0.001 and gst_has("volume"):
            cmd += ["volume", "volume=%.2f" % vol, "!"]
    cmd += ["dvbaudiosink", "sync=false", "async=false"]
    return cmd


def gst_chain(url, ua, vol):
    """(gst-launch argv up to and including the trailing '!', soft gain or None): link -> decoded 48 kHz stereo S16LE.

    Only elements this receiver has are used: without the 'volume' element the gain is applied by the relay instead."""
    url = play_url(url)
    cmd = [which("gst-launch-1.0") or "gst-launch-1.0", "-q"]
    if re.match(r"^https?://", url, re.I) and gst_has("souphttpsrc"):
        cmd += (["souphttpsrc", "location=" + url, "user-agent=" + (ua or store.DEFAULT_UA), "timeout=10", "blocksize=8192"]
                + _soup_tls(url) + ["!", "decodebin"] + AUDIO_ONLY + ["!"])
    else:
        cmd += ["uridecodebin", "uri=" + url] + AUDIO_ONLY + ["!"]
    cmd += ["audioconvert", "!", "audioresample", "!"]
    soft = None
    if abs(vol - 1.0) > 0.001:
        if gst_has("volume"):
            cmd += ["volume", "volume=%.2f" % vol, "!"]
        elif soft_gain_possible():
            soft = vol
        else:
            log("no 'volume' element and no audioop: the commentary volume stays at 100%")
    cmd += [GST_CAPS, "!"]
    return cmd, soft


def build_gst_relay(url, ua, mode, settings, track=0):
    """(decoder argv, writer argv, soft gain): GStreamer decodes to raw PCM on stdout, aplay / pcmplay.py plays it."""
    dev = settings["alsa_device"]
    if dev in ("auto", ""):
        dev = alsa_candidates(dev)[0]
    vol = max(0, min(200, int(settings["volume"]))) / 100.0
    if track:
        soft = vol if abs(vol - 1.0) > 0.001 and not gst_has("volume") and soft_gain_possible() else None
        dec = gst_selected_argv(url, ua, 1.0 if soft is not None else vol, track)
    else:
        chain, soft = gst_chain(url, ua, vol)
        dec = chain + ["fdsink", "fd=1", "sync=false"]
    return dec, pcm_writer_argv("pcm" if mode == "gst-pcm" else "aplay", dev, settings), soft


PCM_RATE, PCM_FRAME = 48000, 4                 # s16le stereo: 4 bytes per frame
BYTES_PER_MS = PCM_RATE * PCM_FRAME // 1000     # 192: every whole millisecond is a whole number of frames
MAX_DELAY_MS = 60000
STARVED_S = 0.8                                 # no PCM from the link this long = a real gap, rebuild the cushion
TV_PREBUFFER_MS, RADIO_PREBUFFER_MS = 450, 700   # jitter cushion so 0-delay TV commentary never underruns between network chunks


def live_delay_info():
    """How the audio delay works on this receiver, for the info screens: 's16le' / 'wav' / 'GStreamer' (live) or None."""
    if not _relay_off[0] and ffmpeg_pcm_ok():
        out, inp = relay_formats()
        if out and (inp or which("aplay") or pcm_writer_ok()):
            return out
    if gst_decode_ok() and (pcm_writer_ok() or which("aplay")):
        return "GStreamer"
    return None


def relay_possible(mode):
    """Can this receiver's ffmpeg carry the live-delay pipeline for `mode`? (else the old single ffmpeg is used)."""
    out, inp = relay_formats()
    if out is None:
        return False
    return mode in ("aplay", "pcm") or (mode == "alsa" and pcm_writer_ok()) or inp is not None


def build_relay(input_args, mode, settings, track=0):
    """(decoder argv, writer argv, decoder format, writer format) for the live-delay pipeline: ffmpeg decodes the link to
    PCM on its stdout, the engine keeps the delay in its own buffer and feeds the writer (ffmpeg->ALSA, aplay, or null
    for the self-test). PCM travels raw (s16le) or, on a trimmed ffmpeg without it, as an endless WAV.

    The delay lives in Python, so changing it never restarts ffmpeg nor reconnects to the link."""
    out_fmt, in_fmt = relay_formats()
    if out_fmt is None:
        raise ValueError("FFmpeg has no verified PCM output muxer; use GStreamer")
    controlled_alsa = mode == "alsa" and pcm_writer_ok()
    if mode in ("aplay", "pcm") or controlled_alsa:
        in_fmt = "s16le"                 # aplay / pcmplay.py read raw PCM themselves
    dev = settings["alsa_device"]
    if dev in ("auto", ""):
        dev = alsa_candidates(dev)[0]
    vol = max(0, min(200, int(settings["volume"]))) / 100.0
    ff = which("ffmpeg")
    filt = ["aformat=channel_layouts=stereo"]
    if abs(vol - 1.0) > 0.001:
        filt.append("volume=%.2f" % vol)
    filt += ["aresample=%d" % PCM_RATE, "aformat=sample_fmts=s16:channel_layouts=stereo"]
    dec = [ff, "-hide_banner", "-loglevel", "warning", "-nostdin"]
    if mode == "null":
        dec.append("-re")
    dec += input_args + ["-map", "0:a:%d" % track, "-vn", "-sn", "-dn", "-af", ",".join(filt),
                         "-ac", "2", "-ar", str(PCM_RATE), "-c:a", "pcm_s16le", "-f", out_fmt]
    if out_fmt == "wav":
        dec += ["-bitexact"]                         # a plain 44-byte header in front of the samples
    dec.append("pipe:1")
    if in_fmt == "wav":
        raw_in = ["-f", "wav", "-ignore_length", "1", "-i", "pipe:0"]
    else:
        raw_in = ["-f", "s16le", "-ar", str(PCM_RATE), "-ac", "2", "-i", "pipe:0"]
    if controlled_alsa:
        out = pcm_writer_argv("pcm", dev, settings)
    elif mode == "alsa":
        out = [ff, "-hide_banner", "-loglevel", "warning"] + raw_in + ["-f", "alsa", dev]
    elif mode == "null":
        out = [ff, "-hide_banner", "-loglevel", "warning"] + raw_in + ["-f", "null", "-"]
    elif mode in ("aplay", "pcm"):
        out = pcm_writer_argv(mode, dev, settings)
    else:
        raise ValueError("relay mode %r" % (mode,))
    return dec, out, out_fmt, in_fmt


def wav_header(rate=PCM_RATE, channels=2):
    """WAV header of an endless stream (data size 0 = 'until the end' for ffmpeg's WAV reader)."""
    block = channels * 2
    return (b"RIFF" + struct.pack(str("<I"), 0) + b"WAVE" + b"fmt " +
            struct.pack(str("<IHHIIHH"), 16, 1, channels, rate, rate * block, block, 16) + b"data" + struct.pack(str("<I"), 0))


def _skip_wav_header(fd):
    """Read past a WAV header on fd; returns the PCM bytes that came along with it (b'' at end of stream)."""
    buf = b""
    while len(buf) < 12:
        chunk = os.read(fd, 4096)
        if not chunk:
            return b""
        buf += chunk
    if buf[:4] not in (b"RIFF", b"RF64") or buf[8:12] != b"WAVE":
        raise ValueError("not a WAV stream")
    pos = 12
    while True:
        while len(buf) < pos + 8:
            chunk = os.read(fd, 4096)
            if not chunk:
                return b""
            buf += chunk
        cid, size = buf[pos:pos + 4], struct.unpack(str("<I"), buf[pos + 4:pos + 8])[0]
        pos += 8
        if cid == b"data":
            return buf[pos:]
        pos += size + (size & 1)


def _write_all(fd, data):
    # Python 2.7's os.write() does not take a memoryview: write slices.
    off = 0
    total = len(data)
    while off < total:
        n = os.write(fd, data[off:off + 65536])
        if n <= 0:
            raise OSError("audio pipe closed")
        off += n


try:
    import warnings as _warnings
    with _warnings.catch_warnings():
        _warnings.simplefilter("ignore", DeprecationWarning)
        import audioop as _audioop           # Python 3.5 .. 3.12
except ImportError:                          # 3.13+: gone from the standard library
    _audioop = None


def scale_pcm(data, gain):
    """Multiply S16LE samples by gain (clipped) with audioop. Only called when audioop exists: a per-sample Python loop
    is slower than real time on a receiver CPU and made the commentary stutter."""
    return _audioop.mul(bytes(data), 2, gain)


def soft_gain_possible():
    return _audioop is not None


class PcmQueue(object):
    """FIFO of PCM chunks with O(1) insertion and removal at both ends."""
    PIECE = 16384

    def __init__(self):
        from collections import deque
        self.q, self.size = deque(), 0

    def push(self, data):
        if data:
            self.q.append(bytes(data))
            self.size += len(data)

    def push_silence_front(self, n):
        n -= n % PCM_FRAME
        piece = zeros(self.PIECE)
        while n > 0:
            k = min(n, self.PIECE)
            self.q.appendleft(piece if k == self.PIECE else zeros(k))
            self.size += k
            n -= k

    def drop_front(self, n):
        n = min(n, self.size)
        while n > 0 and self.q:
            c = self.q[0]
            if len(c) <= n:
                self.q.popleft()
                n -= len(c)
                self.size -= len(c)
            else:
                self.q[0] = c[n:]
                self.size -= n
                n = 0

    def take(self, n):
        out = []
        n = min(n, self.size)
        while n > 0 and self.q:
            c = self.q[0]
            if len(c) <= n:
                out.append(self.q.popleft())
                n -= len(c)
                self.size -= len(c)
            else:
                out.append(c[:n])
                self.q[0] = c[n:]
                self.size -= n
                n = 0
        return b"".join(out)


F_SETPIPE_SZ = 1031
SILENCE_STEP_MS = 20
SILENCE_CHUNK = zeros(SILENCE_STEP_MS * BYTES_PER_MS)


def _relay(src, dst, get_delay_ms, in_fmt="s16le", out_fmt="s16le", state=None, gain=None, prebuffer_ms=0):
    """Copy PCM from the decoder to the writer with decoupled reader/writer threads to absorb network jitter.

    `buf` stores ONLY real decoded audio (never silence):
    - Increasing delay pauses output for the exact requested delta while incoming audio accumulates in `buf`,
      feeding tiny 20 ms real-time silence ticks so the sound card stays active without filling OS pipes with silence.
    - Decreasing delay cancels any remaining silence wait and drops the oldest audio from `buf` while preserving a
      playable cushion, so stored audio plays immediately without muting.
    - Zero delay maintains a steady jitter cushion so live audio never stutters between network chunks."""
    fd_in, fd_out = src.stdout.fileno(), dst.stdin.fileno()
    try:
        import fcntl as _fcntl
        _fcntl.fcntl(fd_out, F_SETPIPE_SZ, 8192)
    except Exception:
        pass
    cur = max(0, min(MAX_DELAY_MS, int(get_delay_ms()))) * BYTES_PER_MS
    buf = PcmQueue()
    if gain is not None and not soft_gain_possible():
        gain = None
    if state is None:
        state = {}
    state.setdefault("bytes_in", 0)
    now0 = monotonic()
    state["last_read_t"] = now0
    cushion_ms = max(450, min(3000, int(prebuffer_ms if prebuffer_ms else TV_PREBUFFER_MS)))
    cushion_bytes = cushion_ms * BYTES_PER_MS
    min_keep_bytes = 350 * BYTES_PER_MS
    max_jitter_bytes = 20000 * BYTES_PER_MS
    cond = threading.Condition()
    done = [False]
    pending_drop = [0]
    initial_hold_s = [max(0.05, cur / float(BYTES_PER_MS * 1000) - 0.25) if cur > 0 else 0.0]
    hold_until = [now0 + initial_hold_s[0] if cur > 0 else 0.0]

    def _push_pcm(pcm_bytes):
        with cond:
            # Backpressure, never discard: a recording (MP3 file) decodes 50-80x faster than real time.
            # Dropping the oldest audio above the cap made recordings jump forward every few seconds.
            # Waiting here lets the pipe / decoder / socket hold the rest; a live link (1x) never waits.
            while not done[0] and buf.size >= cur + max_jitter_bytes:
                state["input_backpressure"] = True
                cond.wait(0.05)
            state.pop("input_backpressure", None)
            if done[0]:
                return
            now_r = monotonic()
            state["bytes_in"] += len(pcm_bytes)
            state["last_read_t"] = now_r
            if "first_t" not in state:
                state["first_t"] = now_r
                if initial_hold_s[0] > 0.0 and hold_until[0] > 0.0:
                    # Anchor initial startup delay to when the first decoded audio arrives, minus connection time already spent
                    spent = max(0.0, now_r - now0)
                    rem_s = max(0.15, initial_hold_s[0] - min(spent * 0.5, 1.0))
                    hold_until[0] = now_r + rem_s
                    initial_hold_s[0] = 0.0
            buf.push(pcm_bytes)
            if pending_drop[0] > 0 and buf.size > min_keep_bytes:
                can_drop = min(pending_drop[0], buf.size - min_keep_bytes) & ~(PCM_FRAME - 1)
                if can_drop > 0:
                    buf.drop_front(can_drop)
                    pending_drop[0] -= can_drop
            cond.notify_all()

    def _reader():
        try:
            if in_fmt == "wav":
                first_pcm = _skip_wav_header(fd_in)
                if first_pcm:
                    _push_pcm(first_pcm)
            while not done[0]:
                chunk = os.read(fd_in, 16384)
                if not chunk:
                    break
                _push_pcm(chunk)
        except (EnvironmentError, ValueError):
            pass
        finally:
            with cond:
                # EOF ends input, not playback: queued PCM still belongs to
                # this stream and must reach the writer before reconnecting.
                state["input_eof"] = True
                done[0] = True
                cond.notify_all()

    start_thread(_reader, (), "UltraAudioRelayIn")
    start_ms = 220 if prebuffer_ms >= RADIO_PREBUFFER_MS else 100
    primed = cur > 0 or not cushion_bytes
    need_bytes = min(cushion_bytes, start_ms * BYTES_PER_MS)
    silence_grace_until = now0 + 0.15 if cur > 0 else 0.0
    next_silence_t = silence_grace_until
    play_clock_t = now0 - 0.50
    try:
        if out_fmt == "wav":
            _write_all(fd_out, wav_header())
        while True:
            write_silence = False
            data = None
            with cond:
                now_w = monotonic()
                want = max(0, min(MAX_DELAY_MS, int(get_delay_ms()))) * BYTES_PER_MS
                if want > cur:
                    add_bytes = want - cur
                    add_s = add_bytes / float(BYTES_PER_MS * 1000)
                    pending_drop[0] = 0
                    initial_hold_s[0] = 0.0
                    if hold_until[0] > now_w:
                        hold_until[0] += add_s
                    else:
                        # Compensate 0.25s for UI key debounce + downstream ALSA cushion so perceived pause matches requested delay
                        eff_s = max(0.05, add_s - 0.25)
                        hold_until[0] = now_w + eff_s
                        silence_grace_until = now_w + 0.18
                        next_silence_t = silence_grace_until
                    cur = want
                elif want < cur:
                    diff = cur - want
                    initial_hold_s[0] = 0.0
                    if hold_until[0] > now_w:
                        unbuilt_bytes = max(0, int((hold_until[0] - now_w) * BYTES_PER_MS * 1000))
                        cancel_bytes = min(diff, unbuilt_bytes)
                        diff -= cancel_bytes
                        hold_until[0] -= cancel_bytes / float(BYTES_PER_MS * 1000)
                        if hold_until[0] <= now_w + 0.02:
                            hold_until[0] = 0.0
                    keep_floor = cushion_bytes if want == 0 else max(min_keep_bytes, min(want, cushion_bytes))
                    if want == 0:
                        hold_until[0] = 0.0
                        pending_drop[0] = 0
                        if buf.size > cushion_bytes:
                            buf.drop_front((buf.size - cushion_bytes) & ~(PCM_FRAME - 1))
                    elif diff > 0:
                        droppable = max(0, buf.size - keep_floor)
                        drop_now = min(diff, droppable) & ~(PCM_FRAME - 1)
                        if drop_now > 0:
                            buf.drop_front(drop_now)
                        rem = (diff - drop_now) & ~(PCM_FRAME - 1)
                        if rem > 0:
                            pending_drop[0] += rem
                    cur = want
                    primed = True
                    play_clock_t = now_w - 0.35

                if hold_until[0] > 0.0:
                    min_ready = min(cur, min_keep_bytes) if cur > 0 else min_keep_bytes
                    if ((now_w >= hold_until[0] and (buf.size >= min_ready or done[0]))
                            or (done[0] and not buf.size)):
                        hold_until[0] = 0.0
                        primed = True
                        play_clock_t = now_w - 0.35
                    else:
                        state["settling"] = True
                        if "first_t" not in state:
                            cond.wait(0.04)
                            continue
                        if now_w < silence_grace_until:
                            cond.wait(min(0.04, silence_grace_until - now_w))
                            continue
                        if now_w < next_silence_t:
                            cond.wait(min(0.02, next_silence_t - now_w))
                            continue
                        next_silence_t = max(now_w + 0.005, next_silence_t + (SILENCE_STEP_MS / 1000.0))
                        write_silence = True

                if not write_silence:
                    state["settling"] = not primed
                    if not primed:
                        if buf.size < need_bytes and not done[0]:
                            cond.wait(0.04)
                            continue
                        primed = True
                        state["settling"] = False
                        state["radio_prebuffer_ms"] = cushion_ms
                        play_clock_t = now_w - 0.45
                    # Pace writes to at most ~1.03x real time after filling the 500ms hardware cushion so HLS segment bursts
                    # stay in `buf` (where delay reductions can drop them instantly) rather than flooding OS pipes.
                    if play_clock_t > now_w + 0.12 and buf.size > 0:
                        cond.wait(min(0.025, play_clock_t - (now_w + 0.12)))
                        continue
                    n = min(4096, buf.size & ~(PCM_FRAME - 1))
                    if n <= 0:
                        if done[0]:
                            break
                        # Only re-prime when the sound card output itself has gone unfed for > 0.65s AND the input link is quiet.
                        if (cushion_bytes > 0
                                and now_w - state.get("last_write_t", now0) > 0.65
                                and now_w - state.get("last_read_t", now0) > STARVED_S):
                            primed = False
                            need_bytes = cushion_bytes
                        cond.wait(0.04)
                        continue
                    data = buf.take(n)
                    cond.notify_all()            # room in `buf`: wake a reader held by backpressure
                    if play_clock_t < now_w - 0.50:
                        play_clock_t = now_w - 0.50
                    play_clock_t += (len(data) / float(BYTES_PER_MS * 1000)) * 0.97
            try:
                state["write_started_t"] = monotonic()
                if write_silence:
                    _write_all(fd_out, SILENCE_CHUNK)
                else:
                    _write_all(fd_out, scale_pcm(data, gain) if gain is not None else data)
                state["last_write_t"] = monotonic()
                state.pop("write_started_t", None)
            except EnvironmentError:
                state["writer_broke"] = True     # the writer went first: the sound side, not the link
                raise
    except (EnvironmentError, ValueError):
        pass
    finally:
        with cond:
            done[0] = True
            state["settling"] = False
            cond.notify_all()
        for f in (dst.stdin, src.stdout):
            try:
                f.close()
            except (EnvironmentError, ValueError):
                pass
        # Closing stdin asks the writer to drain its own pipe/device buffer.
        # The supervisor must allow that drain before killing the processes.
        state["relay_done_t"] = monotonic()


def _spawn_relay(dec_argv, out_argv, errtail, get_delay_ms, dec_fmt="s16le", out_fmt="s16le", gain=None, prebuffer_ms=0):
    dec = popen(dec_argv, stdin=DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        out = popen(out_argv, stdin=subprocess.PIPE, stdout=DEVNULL, stderr=subprocess.PIPE, bufsize=0)
    except Exception:
        dec.stdout.close()
        _kill([dec])
        raise
    dec.relay_state = {"writer_broke": False, "pcm_reset_supported": PCMPLAY in out_argv}
    out.relay_state = dec.relay_state
    for p in (dec, out):
        start_thread(_drain, (p, errtail))
    start_thread(_relay, (dec, out, get_delay_ms, dec_fmt, out_fmt, dec.relay_state, gain, prebuffer_ms), "UltraAudioRelay")
    return [dec, out]


def relay_alive(procs, now, buffer_ms=500):
    """Decoder exit must not discard queued PCM or the writer's final buffer.
    Keep supervising the writer until it exits, with a bounded post-EOF drain.
    Pending writes still use the normal stalled-output watchdog.
    """
    if len(procs) < 2:
        return all(p.poll() is None for p in procs)
    if procs[-1].poll() is not None:
        return False
    state = getattr(procs[0], "relay_state", {})
    if state.get("writer_broke"):
        return False
    finished = state.get("relay_done_t")
    if finished is not None:
        return now - finished < max(5.0, int(buffer_ms) / 1000.0 + 3.0)
    # Both live decoding and buffered drain after decoder exit are active.
    return True


# Why a try failed decides what the next try changes.
_DEVICE_ERR = re.compile(r"cannot open audio device|audio open error|snd_pcm_open|Unknown PCM|No such device|"
                         r"Device or resource busy|Device '[^']+' is busy|being used by another application|"
                         r"Could not open audio device|Cannot open device /dev/dsp|alsasink|dvbaudiosink|"
                         r"pcmplay: cannot set|pcmplay: write error|output feed stalled", re.I)
_MISSING_DEV_ERR = re.compile(r"Cannot open device /dev/dsp|cannot open audio device \S+ \(No such file or directory\)|"
                              r"audio open error: No such file or directory|Playback open error on device '[^']+': No such file or directory", re.I)
_FATAL_ERR = re.compile(r"Server returned 4\d\d|HTTP error 4\d\d|\b40[13]\b.*(Forbidden|Unauthorized)|404 Not Found|410 Gone|"
                        r"matches no streams|Protocol not found", re.I)
_NO_FORMAT = re.compile(r"Requested output format '[^']*' is not known|Unknown input format|is not a suitable output format|"
                        r"Unknown encoder|Encoder not found|Decoder not found|(De|En)coder \(codec [^)]*\) not found|"
                        r"no decoder found for|Unknown decoder|Unrecognized option 'rf64'|Unrecognized option 'ignore_length'|"
                        r"Option rf64 not found|Option ignore_length not found|Error initializing the muxer for pipe", re.I)
_NO_ENCODER = re.compile(r"Error selecting an encoder|Automatic encoder selection failed|"
                         r"Default encoder for format \S+ \(codec pcm_[^)]*\) is probably disabled|"
                         r"Unknown encoder 'pcm_|Encoder \(codec pcm_[^)]*\) not found", re.I)
_GST_NO_ELEMENT = re.compile(r"no element \"([^\"]+)\"", re.I)
_FF_OPTIONAL = ("thread_queue_size", "protocol_whitelist", "reconnect", "reconnect_streamed", "reconnect_delay_max",
                "rw_timeout", "fflags", "user_agent")
_FF_BAD_OPT = re.compile(r"Unrecognized option '-?([A-Za-z0-9_]+)'|Option ([A-Za-z0-9_]+) not found", re.I)
_FF_NO_PROTO = re.compile(r"Protocol not found|protocol not found|Unknown protocol|not on whitelist", re.I)
_TLS_ERR = re.compile(r"Unacceptable TLS certificate|TLS certificate|certificate verify failed|SSL certificate problem|"
                      r"Secure connection setup failed", re.I)
_GST_NO_SSL_PROP = re.compile(r"no property \"ssl-", re.I)
_relay_off = [False]         # set for the rest of the session once this ffmpeg proved it cannot carry the live pipeline
_HTTP_REFUSED = re.compile(r"(Server returned|HTTP error) 4(0[1-4]|10)|\b40[13]\b.*(Forbidden|Unauthorized)|404 Not Found|410 Gone",
                           re.I)            # the answer of an expired token: worth asking the source for a fresh link
FATAL_LIMIT = 5              # the same hopeless answer this many times in a row: stop and give the TV its sound back


def classify_failure(tail):
    """'device' (the sound card / writer), 'fatal' (the link refuses us: 4xx, no such track, unknown host) or 'net'."""
    tail = tail or []
    if any(_DEVICE_ERR.search(x) for x in tail):
        return "device"
    if any(_FATAL_ERR.search(x) for x in tail):
        return "fatal"
    return "net"


def is_self(pid):
    """True for Enigma2 itself or one of its threads (/proc/asound reports the thread that opened the card)."""
    me = os.getpid()
    return pid == me or os.path.exists("/proc/%d/task/%d" % (me, pid))


def play_url(url):
    """Drop a '#fragment' (SatFamily-style links end with '#'): browsers never send it, ffmpeg would."""
    return to_text(url).split("#", 1)[0]


def stream_input_args(url, ua, radio=False):
    """Fast startup probing (256 KB / 0.8 s) WITHOUT +nobuffer so FFmpeg maintains its internal demuxer jitter cushion."""
    url = play_url(url)
    pairs = [("fflags", "+genpts+igndts+discardcorrupt"), ("probesize", "65536"), ("analyzeduration", "300000"),
             ("thread_queue_size", "512"), ("user_agent", ua or store.DEFAULT_UA),
             ("protocol_whitelist", "file,http,https,tcp,tls,crypto,data"),
             ("reconnect", "1"), ("reconnect_streamed", "1"), ("reconnect_delay_max", "4"),
             ("rw_timeout", "10000000")]
    known = ffmpeg_input_support()[0]
    args = []
    for name, value in pairs:
        if name in _ff_bad_opts or (known is not None and name in _FF_OPTIONAL and name not in known):
            continue
        args += ["-" + name, value]
    return args + ["-i", url]


def _spawn(argvs, errtail):
    procs = []
    prev = None
    try:
        for i, argv in enumerate(argvs):
            p = popen(argv, stdin=prev.stdout if prev else DEVNULL,
                      stdout=subprocess.PIPE if i < len(argvs) - 1 else DEVNULL, stderr=subprocess.PIPE)
            procs.append(p)
            if prev:
                prev.stdout.close()
            start_thread(_drain, (p, errtail))
            prev = p
    except Exception:
        for p in procs:
            if p.stdout:
                p.stdout.close()
        _kill(procs)
        raise
    return procs


def tone_pcm(seconds, gain=1.0, freq=440):
    """`seconds` of a sine as S16LE 48 kHz stereo."""
    import math
    amp = int(12000 * max(0.0, min(2.0, gain)))
    one = b"".join(struct.pack(str("<hh"), v, v) for v in
                   (int(amp * math.sin(2 * math.pi * freq * i / PCM_RATE)) for i in range(PCM_RATE)))
    return one * int(seconds)


def _spawn_tone(writer_argv, errtail, seconds, gain=1.0):
    """The test tone without ffmpeg: Python writes the sine into aplay / pcmplay.py."""
    p = popen(writer_argv, stdin=subprocess.PIPE, stdout=DEVNULL, stderr=subprocess.PIPE, bufsize=0)
    start_thread(_drain, (p, errtail))

    def feed():
        try:
            _write_all(p.stdin.fileno(), tone_pcm(seconds, gain))
        except EnvironmentError:
            pass
        finally:
            try:
                p.stdin.close()
            except EnvironmentError:
                pass
    start_thread(feed)
    return [p]


PIDFILE = os.environ.get("ULTRAAUDIO_PIDS", "/tmp/ultraaudio.pids")


def write_pids(procs):
    """Record child identities safely for cleanup after an Enigma2 restart."""
    from . import pidguard
    pidguard.remember(procs, PIDFILE)


def kill_stale():
    """Clean up only previous children whose PID and start time still match."""
    from . import pidguard
    count = pidguard.cleanup(PIDFILE)
    if count:
        log("cleaned up %d verified stale commentary process(es)" % count)


_GENERIC = re.compile(r"Nothing was written|Output file is empty|Error opening output|No filtered frames|Conversion failed|Exiting normally|^\s*$|received signal|Terminating thread|Task finished with error|Error sending frames|Could not write header", re.I)
_PREFIX = re.compile(r"^\[[^\]]*\]\s*")
_BUSY = re.compile(r"cannot open audio device (\S+) \(Device or resource busy\)|Device '([^']+)' is busy|being used by another application", re.I)


def alsa_status(include_proc_fds=False):
    """[(pcm, text, owner_pid_or_None)] for every playback substream: tells who really holds the card."""
    out = []
    try:
        cards = sorted(x for x in os.listdir(ASOUND) if re.match(r"^card\d+$", x))
    except EnvironmentError:
        cards = []
    for card in cards:
        base = os.path.join(ASOUND, card)
        try:
            pcms = sorted(x for x in os.listdir(base) if re.match(r"^pcm\d+p$", x))
        except EnvironmentError:
            continue
        for pcm in pcms:
            try:
                subs = sorted(x for x in os.listdir(os.path.join(base, pcm)) if x.startswith("sub"))
            except EnvironmentError:
                continue
            for sub in subs:
                try:
                    with open_text(os.path.join(base, pcm, sub, "status")) as f:
                        text = " ".join(f.read().split())
                except EnvironmentError:
                    continue
                m = re.search(r"owner_pid\s*:\s*(\d+)", text)
                pid = int(m.group(1)) if m else None
                st = re.match(r"state\s*:\s*(\S+)", text)
                if pid:
                    text = "%s held by %d[%s] (Enigma2 is %d)" % (st.group(1) if st else "open", pid, _read("/proc/%d/comm" % pid).strip() or "?", os.getpid())
                elif st:
                    text = st.group(1)
                out.append(("%s/%s/%s" % (card, pcm, sub), text[:160], pid))
    if not out and include_proc_fds:
        # Receivers without /proc/asound playback substreams (e.g. Dreambox / Hisilicon DVB audio / OSS): check /dev/dvb/adapter*/audio* and /dev/dsp
        try:
            pids = [int(x) for x in os.listdir("/proc") if x.isdigit()]
        except EnvironmentError:
            return out
        for pid in pids:
            try:
                fds = os.listdir("/proc/%d/fd" % pid)
            except EnvironmentError:
                continue
            for fd in fds:
                try:
                    target = os.readlink("/proc/%d/fd/%s" % (pid, fd))
                except EnvironmentError:
                    continue
                if re.match(r"^/dev/dvb/adapter\d+/audio\d+$", target) or target == "/dev/dsp":
                    comm = _read("/proc/%d/comm" % pid).strip() or "?"
                    out.append((target, "OPEN held by %d[%s] (Enigma2 is %d)" % (pid, comm, os.getpid()), pid))
                    break
    return out


def alsa_summary():
    return "; ".join("%s: %s" % (n, t) for n, t, _ in alsa_status(include_proc_fds=True)) or "no playback substream info"


WATCHED_MODES = ("alsa", "aplay", "pcm", "gst-pcm", "gst-aplay", "gst")   # the modes that hold a sound card we can look at
STALL_SECONDS = 4.0          # the PCM we hold stays out of RUNNING this long after it has played: the stream is starved


def _is_our_proc_or_child(pid, mine):
    if any(pid == m or os.path.exists("/proc/%d/task/%d" % (m, pid)) for m in mine):
        return True
    cur = pid
    for _ in range(3):
        stat = _read("/proc/%d/stat" % cur)
        m = re.search(r"\)\s+\S\s+(\d+)", stat)
        if not m:
            break
        ppid = int(m.group(1))
        if ppid in mine:
            return True
        if ppid <= 1 or ppid == cur:
            break
        cur = ppid
    return False


def own_pcm_state(procs, status=None):
    """State word ('RUNNING', 'XRUN', ...) of the playback substream that one of our processes holds, else None."""
    mine = [p.pid for p in procs if p is not None and p.poll() is None]
    if not mine:
        return None
    for _, text, pid in (alsa_status(include_proc_fds=False) if status is None else status):
        if pid and _is_our_proc_or_child(pid, mine):
            state = text.split(" ", 1)[0].upper()
            return "RUNNING" if state == "OPEN" else state
    # Check our own processes' open descriptors for DVB/OSS audio without scanning all of /proc.
    for pid in mine:
        try:
            for fd in os.listdir("/proc/%d/fd" % pid):
                try:
                    target = os.readlink("/proc/%d/fd/%s" % (pid, fd))
                    if re.match(r"^/dev/dvb/adapter\d+/audio\d+$", target) or target == "/dev/dsp":
                        return "RUNNING"
                except EnvironmentError:
                    continue
        except EnvironmentError:
            continue
    return None


def relay_output_stalled(state, now, buffer_ms=500):
    """A pending write proves output backpressure; missing input alone does not."""
    pending = state.get("write_started_t")
    return pending is not None and now - pending >= max(2.2, int(buffer_ms) / 1000.0 + 1.5)


class StallWatch(object):
    """Fed one sample per tick: True once the held PCM has been out of RUNNING for STALL_SECONDS after it had played.

    A decoder event (pause / seek / timeshift start) can leave the commentary's PCM underrun for good while ffmpeg itself
    stays alive; the only cure is what the user did by hand: start the pipeline again."""

    def __init__(self, limit=STALL_SECONDS):
        self.limit, self.seen, self.bad_since = limit, False, None

    def feed(self, state, now):
        if state == "RUNNING":
            self.seen, self.bad_since = True, None
            return False
        if not self.seen or state is None:
            self.bad_since = None
            return False
        if self.bad_since is None:
            self.bad_since = now
        return now - self.bad_since >= self.limit


_SOUND_DEVS = ("/dev/snd/", "/dev/dsp", "/dev/audio", "/dev/mixer")      # /dev/dsp is one of the legacy sound-device nodes that can hold the card


def alsa_holders():
    """Names of the processes that have a sound-card device open (to explain 'Device or resource busy')."""
    out = []
    try:
        pids = [x for x in os.listdir("/proc") if x.isdigit()]
    except EnvironmentError:
        return out
    for pid in pids:
        try:
            fds = os.listdir("/proc/%s/fd" % pid)
        except EnvironmentError:
            continue
        for fd in fds:
            try:
                if os.readlink("/proc/%s/fd/%s" % (pid, fd)).startswith(_SOUND_DEVS):
                    out.append("%s(%s)" % (_read("/proc/%s/comm" % pid).strip(), pid))
                    break
            except EnvironmentError:
                continue
    return out


def _read(path, limit=4096):
    try:
        with open(path, "rb") as f:
            return f.read(limit).decode("utf-8", "replace")
    except EnvironmentError:
        return ""


def proc_line(pid):
    """One line about a process: name, state, parent, command line and the sound / DVB devices it has open."""
    comm = _read("/proc/%d/comm" % pid).strip() or "?"
    stat = _read("/proc/%d/stat" % pid)
    state, ppid = "?", "?"
    m = re.search(r"\)\s+(\S)\s+(\d+)", stat)
    if m:
        state, ppid = m.group(1), m.group(2)
    cmd = _read("/proc/%d/cmdline" % pid).replace("\0", " ").strip()[:100]
    devs = []
    try:
        for fd in os.listdir("/proc/%d/fd" % pid):
            try:
                t = os.readlink("/proc/%d/fd/%s" % (pid, fd))
            except EnvironmentError:
                continue
            if t.startswith(_SOUND_DEVS + ("/dev/dvb/",)):
                devs.append(t)
    except EnvironmentError:
        pass
    me = " (this is Enigma2 itself)" if is_self(pid) else ""
    return "%s[%d]%s state=%s ppid=%s cmd=%r devices=%s" % (comm, pid, me, state, ppid, cmd, ",".join(sorted(set(devs))) or "-")


def alsa_owner():
    for _, _, pid in alsa_status():
        if pid:
            return pid
    return None


_OUTPUT_TOOLS = re.compile(r"ffmpeg|aplay|arecord|gst-launch", re.I)


def audio_processes():
    """Processes that could be playing sound, for the log."""
    out = []
    try:
        pids = sorted(int(x) for x in os.listdir("/proc") if x.isdigit())
    except EnvironmentError:
        return out
    for pid in pids:
        comm = _read("/proc/%d/comm" % pid).strip()
        if re.search(r"ffmpeg|aplay|gst|audio|alsa|enigma2|pulse|pipewire", comm, re.I):
            out.append(proc_line(pid))
    return out


def best_error(tail):
    """The most useful line of a tool's stderr: the last one that is not ffmpeg's generic epilogue."""
    for line in tail or []:
        m = _BUSY.search(line)
        if m:
            return T("Sound card busy (%s): another program holds it", m.group(1) or m.group(2) or "ALSA")
    for line in reversed(tail or []):
        if _DEVICE_ERR.search(line):
            return _PREFIX.sub("", line).strip()
    for line in reversed(tail or []):
        if _FATAL_ERR.search(line):          # what the link answered (404, no such audio track...) says the most
            return _PREFIX.sub("", line).strip()
    for line in reversed(tail or []):
        if not _GENERIC.search(line):
            return _PREFIX.sub("", line).strip()
    if any("Nothing was written" in x for x in tail or []):
        return T("The link gave no audio; check the link, its token and the audio track number")
    return ""


_XRUN = re.compile(r"xrun|underrun", re.I)
xruns = [0]                  # sound-card underruns reported by ffmpeg / aplay / pcmplay.py since the start


def _drain(p, errtail):
    # Consume diagnostic lines as they arrive from each audio subprocess.
    try:
        for raw in iter(p.stderr.readline, b""):
            line = raw.decode("utf-8", "replace").rstrip()
            if line == "pcmplay: reset-ready":
                getattr(p, "relay_state", {})["pcm_reset_ready"] = True
                continue
            if line.startswith(("pcmplay: output reset", "pcmplay: TV transition reset")):
                log(line)
                continue
            if line.startswith("pcmplay: stats"):
                log(line)                        # the writer's own 10 s report: link late or card slow?
                continue
            if line and _XRUN.search(line):
                xruns[0] += 1
                continue
            if line:
                errtail.append(line)
                del errtail[:-15]
    except (EnvironmentError, ValueError):
        pass
    finally:
        try:
            p.stderr.close()
        except (EnvironmentError, ValueError, AttributeError):
            pass


def _kill(procs):
    import signal as _sig
    for p in procs:
        if p is None:
            continue
        try:
            os.killpg(p.pid, _sig.SIGTERM)
        except EnvironmentError:
            pass
        try:
            p.terminate()
        except EnvironmentError:
            pass
    deadline = monotonic() + 0.15
    for p in procs:
        if p is None:
            continue
        try:
            wait(p, max(0.02, deadline - monotonic()))
        except TimeoutExpired:
            try:
                os.killpg(p.pid, _sig.SIGKILL)
            except EnvironmentError:
                pass
            try:
                p.kill()
            except EnvironmentError:
                pass
    for p in procs:
        if p is None:
            continue
        try:
            wait(p, 0.15)
        except (TimeoutExpired, OSError):
            pass


class Engine(object):
    def __init__(self, on_change=None):
        self.lock = threading.RLock()
        # Only one worker owns the output device, including teardown and tone tests.
        self.pipeline_lock = threading.Lock()
        self._worker = None
        self._deferred = False          # the main thread is preparing the picture before any PCM output is opened
        self.on_change = on_change
        self.gen = 0
        self.stream = None
        self.audio_delay_ms = 0
        self.state = "idle"       # idle | starting | playing | retrying | error
        self.message = ""
        self.retries = 0
        self.errtail = []
        self.procs = []
        self.mode = None
        self.device = None
        self.dev_idx = 0
        self.on_busy = None            # on_busy(n): the sound card was busy for the n-th time; its owner (the TV decoder) must let go
        self.on_acquired = None        # on_acquired(): our output holds the sound card now
        self.busy_n = 0
        self.fatal_n = 0               # tries in a row the link refused (4xx, no such track...)
        self.delay_switch_available = False  # worker-probed alternative for direct GStreamer playback
        self.live_delay = False        # the running pipeline takes delay changes live (else it restarts for them)
        self.relay_fail = 0            # live-pipeline tries in a row whose writer died at once for no sound-card reason
        self.on_refused = None         # on_refused(stream) -> True when the source gave this channel a new link
        self.refresh_tried = False     # one source refresh per refusal streak
        self.last_heal = 0.0
        self.feed_rate = None          # link + decoder speed of the last 10 s (1.0 = real time)
        self.xrun_count = 0            # sound-card underruns in the last 10 s
        self.settle_until = 0.0        # the audio delay is still being built until then (the screen shows it green)
        self.output_epoch = 0         # changes on EVERY pipeline, including reconnects with the same generation
        self.output_running = False
        self.output_sample_at = 0.0
        self.free_steps = None         # () -> [(name, fn)]: things that make the TV side let go of the sound card

    # ---- public
    def play(self, stream, audio_delay_ms=None, deferred=False):
        from . import importer
        importer.cancel_link_checks()
        with self.lock:
            self._stop_locked()
            self._deferred = bool(deferred)
            self.stream = stream
            self.audio_delay_ms = max(0, min(MAX_DELAY_MS, int(audio_delay_ms or 0)))
            self.retries = 0
            self.errtail = []
            self.mode = None
            self.live_delay = False
            self.dev_idx = 0
            self.busy_n = 0
            self.fatal_n = 0
            self.relay_fail = 0
            self.refresh_tried = False
            # a start with a delay plays that much silence first: the delay is "being built" for that long
            self.settle_until = monotonic() + self.audio_delay_ms / 1000.0 + 2.0
            self._set("starting", T("Preparing timeshift before audio...") if deferred else "")
            # One worker drains the current pipeline, then takes the newest
            # request. Rapid channel changes never create a queue of threads.
            if self._worker is None and not self._deferred:
                self._worker = start_thread(self._worker_loop, name="UltraAudio-output")
            return True

    def refuse_play(self, stream, message):
        """Publish a failed preflight without starting an unsafe output pipeline."""
        with self.lock:
            self._stop_locked()
            self.stream = stream
            self._set("error", message)

    def reset_pcm_output(self):
        """Ask only our PCM helper to reopen ALSA after a TV decoder transition."""
        with self.lock:
            if self.state not in ("starting", "playing", "retrying") or len(self.procs) < 2:
                return False
            flow = getattr(self.procs[0], "relay_state", {})
            if not flow.get("pcm_reset_supported") or self.procs[-1].poll() is not None:
                return False
            now = monotonic()
            if now - flow.get("pcm_reset_at", -99.0) < 0.15:
                return False
            # The helper explicitly announces readiness before SIGUSR1 can be sent.
            if not flow.get("pcm_reset_ready"):
                return False
            try:
                os.kill(self.procs[-1].pid, signal.SIGUSR1)
            except (EnvironmentError, AttributeError):
                return False
            flow["pcm_reset_at"] = now
            log("PCM output reset requested after TV transition; decoder/connection unchanged")
            return True

    def start_prepared(self, generation):
        """Release this prepared request only; a stop or a newer channel choice cancels it."""
        with self.lock:
            if generation != self.gen or not self._deferred or self.stream is None:
                return False
            self._deferred = False
            self.settle_until = monotonic() + self.audio_delay_ms / 1000.0 + 2.0
            self._set("starting", "")
            if self._worker is None:
                self._worker = start_thread(self._worker_loop, name="UltraAudio-output")
            return True

    def stop(self, wait=False):
        from . import importer
        importer.cancel_link_checks()
        with self.lock:
            self._stop_locked()
            self.stream = None
            self.audio_delay_ms = 0
            gen = self.gen
            self._set("stopping", "")
        if wait:
            self._finish_stop(gen, timeout=4.0)
        else:
            with self.lock:
                if self._worker is None:
                    self.mode, self.live_delay = None, False
                    self._set("idle", "")

    def _worker_loop(self):
        while True:
            with self.lock:
                if self.stream is None:
                    self.mode, self.live_delay = None, False
                    self._worker = None
                    self._set("idle", "")
                    return
                if self._deferred or self.state == "error":
                    self._worker = None
                    return
                gen = self.gen
            self._run(gen)
            with self.lock:
                if gen == self.gen:
                    self._worker = None
                    return

    def _finish_stop(self, gen, timeout=None):
        """Idle once the worker has closed its output. With a timeout (Enigma2 shutting down) never wait longer than
        that: the worker may itself be waiting for the main thread."""
        got = acquire(self.pipeline_lock, timeout) if timeout else self.pipeline_lock.acquire()
        try:
            if not got:
                log("audio worker still busy after %.0fs; killing its processes" % timeout)
                with self.lock:
                    procs = list(self.procs)
                _kill(procs)
            with self.lock:
                if gen == self.gen and self.state != "idle":
                    self.mode = None
                    self.live_delay = False
                    self._set("idle", "")
        finally:
            if got:
                self.pipeline_lock.release()

    def set_audio_delay(self, ms):
        """Change the audio delay. The running pipeline picks it up at once (see _relay): no restart, no reconnect."""
        with self.lock:
            requested = max(0, min(MAX_DELAY_MS, int(ms)))
            if self.mode == "gst" and requested and not self.delay_switch_available:
                raise ValueError(T("Audio delay needs ffmpeg; the current GStreamer mode cannot do it"))
            if requested != self.audio_delay_ms:
                log("audio delay %dms -> %dms (%s)" % (self.audio_delay_ms, requested,
                                                       "live" if self.live_delay else "restart"))
            changed = requested != self.audio_delay_ms
            if changed:
                now = monotonic()
                if self.live_delay:
                    if requested > self.audio_delay_ms:
                        base_left = max(0.0, self.settle_until - now)
                        self.settle_until = now + base_left + (requested - self.audio_delay_ms) / 1000.0
                    elif requested == 0:
                        self.settle_until = now
                    else:
                        left = max(0.0, (self.settle_until - now) - (self.audio_delay_ms - requested) / 1000.0)
                        self.settle_until = now + left
                else:
                    self.settle_until = now + requested / 1000.0 + 2.0
            self.audio_delay_ms = requested
            if changed and not self.live_delay and self.stream is not None and not self._deferred:
                self.play(self.stream, requested)  # the old single-ffmpeg pipeline only takes a new delay on a restart

    def _set_locked(self, state, message, gen):
        with self.lock:
            if gen == self.gen:
                self._set(state, message)

    def _delay_ms(self):
        return self.audio_delay_ms

    def test_tone(self, seconds=3):
        with self.lock:
            if self.state not in ("idle", "error"):
                return False, T("Stop the commentary before testing the tone")
        if not self.pipeline_lock.acquire(False):
            return False, T("The audio device is busy; try again after playback stops")
        try:
            return self._test_tone(seconds)
        finally:
            self.pipeline_lock.release()

    def _test_tone(self, seconds):
        settings = store.get_settings()
        mode, err = pick_output(settings["output"])
        if mode is None or mode == "gst":
            return False, err or T("The test tone needs ffmpeg, aplay or the Python sound writer")
        inp = ["-f", "lavfi", "-i", "sine=frequency=440:duration=%d" % seconds]
        errtail = []
        gen0 = self.gen
        for mode, dev in [c for c in routes(settings) if c[0] != "gst"] or [(mode, settings["alsa_device"])]:
            if mode in GST_RELAY_MODES:          # no ffmpeg needed: Python makes the tone, aplay / pcmplay.py plays it
                mode = "gst-pcm-tone" if mode == "gst-pcm" else "gst-aplay-tone"
            if self.gen != gen0:                      # playback started or Enigma2 is shutting down: give the card back
                return False, T("Test tone cancelled")
            settings["alsa_device"] = dev
            self._free_card(gen0)
            if self.gen != gen0:
                return False, T("Test tone cancelled")
            if str(dev).startswith("dvb"):
                try:
                    from . import dvbaudio
                    dvbaudio.prepare_dvb_sink()
                except Exception:
                    pass
            del errtail[:]
            try:
                if mode.endswith("-tone"):
                    procs = _spawn_tone(pcm_writer_argv("pcm" if mode.startswith("gst-pcm") else "aplay", dev, settings),
                                        errtail, seconds, max(0, min(200, int(settings["volume"]))) / 100.0)
                    mode = mode[:-5]
                else:
                    procs = _spawn(build_pipeline(inp, mode, settings), errtail)   # lavfi: exactly one audio stream
            except EnvironmentError as e:
                return False, to_text(e)
            t0 = time.time()
            while time.time() - t0 < seconds + 6 and any(p.poll() is None for p in procs) and self.gen == gen0:
                time.sleep(0.2)
            _kill(procs)
            if all(p.returncode == 0 for p in procs):
                log("test tone played via %s on %s" % (mode, dev))
                if mode != "null":
                    try:
                        store.set_settings({"route": "%s|%s" % (mode, dev)})
                    except Exception:
                        pass
                return True, "%s / %s" % (mode, dev)
            log("test tone failed via %s on %s: %s" % (mode, dev, " ".join(errtail[-2:])))
        return False, "\n".join(errtail[-5:])

    def status(self):
        with self.lock:
            s = self.stream
            now = monotonic()
            procs = list(self.procs)
            flow = getattr(procs[0], "relay_state", {}) if procs else {}
            last_write = flow.get("last_write_t")
            if self.live_delay:
                flowing = last_write is not None and 0 <= now - last_write < 2.0
            else:
                flowing = self.output_running and 0 <= now - self.output_sample_at < 2.0
            sync_ready = (self.state == "playing" and not self._deferred and self.mode not in (None, "null")
                          and now >= self.settle_until and bool(procs) and flowing)
            return {"state": self.state, "message": self.message, "retries": self.retries,
                    "generation": self.gen,
                    "output_epoch": self.output_epoch, "sync_ready": bool(sync_ready),
                    "preparing": self._deferred,
                    "stream_id": s["id"] if s else None, "stream_name": s["name"] if s else None,
                    "audio_delay_ms": self.audio_delay_ms, "mode": self.mode, "device": self.device,
                    "audio_delay_supported": self.mode != "gst" or self.delay_switch_available,
                    "audio_delay_live": bool(self.live_delay or (self.mode != "gst" and live_delay_info())),
                    "audio_settling": bool(flow.get("settling")) if (self.live_delay and "settling" in flow) else (monotonic() < self.settle_until),
                    "audio_delay_note": T("Audio delay needs ffmpeg") if self.mode == "gst" and not self.delay_switch_available else "",
                    "feed_rate": self.feed_rate, "underruns": self.xrun_count,
                    "errors": [best_error(self.errtail)] if self.errtail else []}

    # ---- internals
    def _set(self, state, message):
        self.state, self.message = state, message
        if state in ("starting", "playing", "retrying", "error", "idle"):
            log("state=%s %s" % (state, message))
        if self.on_change:
            try:
                self.on_change(state)
            except Exception as e:  # never let a UI callback kill the engine
                log("on_change failed: %r" % (e,))

    def _stop_locked(self):
        import signal as _sig
        self.gen += 1
        self.output_running = False
        self.output_sample_at = 0.0
        self._deferred = False
        for p in self.procs:
            if p is None:
                continue
            try:
                os.killpg(p.pid, _sig.SIGTERM)
            except EnvironmentError:
                pass
            try:
                p.terminate()
            except EnvironmentError:
                pass

    def _run(self, gen):
        with self.pipeline_lock:
            procs = []
            try:
                self._run_locked(gen, procs)
            except Exception as e:
                log("audio worker failed: %r" % e)
                _kill(procs)
                procs[:] = []
                with self.lock:
                    if gen == self.gen:
                        self._set("error", T("Could not play the audio: %s", e))
            finally:
                _kill(procs)
                with self.lock:
                    if self.procs is procs:
                        self.procs = []
                try:
                    os.unlink(PIDFILE)
                except EnvironmentError:
                    pass

    def _free_card(self, gen):
        """Before opening the card: find who holds it and make it let go, one step at a time, logging what each step did."""
        with self.lock:
            if gen != self.gen:
                return
        owner = alsa_owner()
        if not owner:
            return
        log("sound card is held by %s" % proc_line(owner))
        for line in audio_processes():
            log("  audio process: %s" % line)
        if not is_self(owner):
            log("another program owns the card; leaving its process and decoder untouched")
            return
        try:
            steps = list(self.free_steps() if self.free_steps else [])
        except Exception as e:
            log("free steps unavailable: %r" % e)
            steps = []
        for name, fn in steps:
            if alsa_owner() is None:
                break
            with self.lock:
                if gen != self.gen:
                    return
            try:
                fn()
            except Exception as e:
                log("step %s failed: %r" % (name, e))
            end = monotonic() + 0.35
            while monotonic() < end and alsa_owner() is not None:
                if gen != self.gen:
                    return
                time.sleep(0.05)
            now = alsa_owner()
            log("after %s: sound card %s" % (name, "FREE" if now is None else "still held by %d (%s)" % (now, alsa_summary()[:90])))
        if alsa_owner() is not None:
            log("sound card still held after every step: %s" % alsa_summary()[:140])

    def _run_locked(self, gen, procs):
        with self.lock:
            if gen != self.gen:
                return
        # Tool detection can take seconds; keep it off the Enigma2 UI thread.
        mode, err = pick_output(store.get_settings()["output"])
        with self.lock:
            if gen != self.gen:
                return
            self.mode = mode
            if mode is None:
                self._set("error", err)
                return
            if mode == "gst" and self.audio_delay_ms:
                raise ValueError(T("The saved audio delay needs ffmpeg; GStreamer cannot do it"))
        backoff = 1.0
        while True:
            with self.lock:
                if gen != self.gen:
                    return
                stream, delay, mode = self.stream, self.audio_delay_ms, self.mode
                self.output_running = False
                self.output_sample_at = 0.0
                self._set("starting", "")
            fresh = store.get_stream(stream["id"]) if stream.get("id") else None
            if fresh and fresh.get("url") != stream.get("url"):
                log("using the refreshed link of %s" % stream["name"])
                with self.lock:
                    if gen != self.gen:
                        return
                    self.stream = stream = dict(stream, url=fresh["url"], user_agent=fresh.get("user_agent", ""))
            settings = store.get_settings()
            applied_settings = tuple(settings.get(k) for k in ("volume", "output", "alsa_device", "buffer_ms"))
            is_radio = store.is_radio_stream(stream)
            if is_radio:
                settings = dict(settings)
                settings["buffer_ms"] = max(2000, int(settings["buffer_ms"]))
                settings["_radio"] = True
            combos = routes(settings, delay)
            if combos and not ffmpeg_reads(stream["url"]):
                # This ffmpeg cannot open the link's protocol: GStreamer routes only (no failing tries first).
                no_ff = [c for c in combos if c[0] not in FF_MODES]
                combos = no_ff or combos
            if not combos:
                with self.lock:
                    if gen == self.gen:
                        self._set("error", T("Audio delay needs ffmpeg") if available_modes(settings["output"])
                                  else pick_output(settings["output"])[1])
                return
            mode, settings["alsa_device"] = combos[self.dev_idx % len(combos)]
            # The direct route is best for zero-delay DVB playback. Discover
            # delay alternatives here on the worker, never in status()/the GUI.
            delay_settings = dict(settings, alsa_device=applied_settings[2])
            can_switch_delay = bool(routes(delay_settings, 1)) if mode == "gst" else False
            with self.lock:
                self.delay_switch_available = can_switch_delay
                self.mode, self.device = mode, settings["alsa_device"]
            relay = (mode in GST_RELAY_MODES or
                     (mode in FF_MODES and not _relay_off[0] and relay_possible(mode)))
            with self.lock:
                self.live_delay = relay
            fmts = ("s16le", "s16le")
            gain = None
            if mode in GST_RELAY_MODES:
                dec, out, gain = build_gst_relay(stream["url"], stream.get("user_agent"), mode, settings,
                                                 int(stream.get("audio_track", 0)))
                argvs = [dec, out]
            elif relay:
                dec, out, dfmt, ofmt = build_relay(stream_input_args(stream["url"], stream.get("user_agent"), is_radio), mode,
                                                   settings, int(stream.get("audio_track", 0)))
                argvs, fmts = [dec, out], (dfmt, ofmt)
            elif mode == "gst":
                argvs = build_pipeline(None, mode, settings, 0, int(stream.get("audio_track", 0)),
                                       stream.get("user_agent"), play_url(stream["url"]))
            else:
                argvs = build_pipeline(stream_input_args(stream["url"], stream.get("user_agent"), is_radio), mode, settings,
                                       delay, int(stream.get("audio_track", 0)), stream.get("user_agent"),
                                       play_url(stream["url"]))
            log("start %s via %s on %s: %s" % (stream["name"], mode, self.device, " | ".join(" ".join(a[:3]) + " ..." for a in argvs)))
            log("sound card before start: %s" % ("; ".join("%s: %s" % (n, t) for n, t, _ in alsa_status(include_proc_fds=False)) or "no playback substream info")[:140])
            if mode != "null":
                if self.busy_n > 0 or alsa_owner() is not None:
                    self._free_card(gen)
                if str(self.device).startswith("dvb"):
                    try:
                        from . import dvbaudio
                        dvbaudio.prepare_dvb_sink()
                    except Exception:
                        pass
            from . import importer
            if not importer.cancel_link_checks(wait_for_exit=True):
                self._set_locked("retrying", T("Waiting for the link check to stop"), gen)
                time.sleep(0.1)
                continue
            with self.lock:
                if gen != self.gen:
                    return
            del self.errtail[:]
            try:
                procs[:] = (_spawn_relay(argvs[0], argvs[1], self.errtail, self._delay_ms, fmts[0], fmts[1], gain,
                                       RADIO_PREBUFFER_MS if is_radio else TV_PREBUFFER_MS) if relay
                             else _spawn(argvs, self.errtail))
            except EnvironmentError as e:
                with self.lock:
                    if gen == self.gen:
                        self._set("error", T("Could not start the tool: %s", e))
                return
            with self.lock:
                if gen != self.gen:
                    return
                self.procs = procs
                self.output_epoch += 1
                self.settle_until = monotonic() + self.audio_delay_ms / 1000.0 + (0.6 if relay else settings["buffer_ms"] / 1000.0 + 1.5)
                write_pids(procs)
            started = monotonic()
            stat_t, stat_bytes, stat_xr = started, 0, xruns[0]
            first_logged = False
            acquired = False
            watch, next_look, stalled = StallWatch(), 0.0, False
            feed_stalled = False
            settings_changed = False
            while True:
                for _ in range(5):
                    if gen != self.gen:
                        break
                    time.sleep(0.08)
                # Test4: on the relay (live delay) routes the PCM flow is watched in Python (last write / last read),
                # so never poll /proc/asound/.../status there: on Vu+ the periodic status read every 0.8 s matched a
                # ~100 ms cut every 0.8 s in the commentary while the link ran at 1.00x with 0 underruns.
                if mode in WATCHED_MODES and not relay and monotonic() >= next_look and monotonic() - started > 2.0:
                    next_look = monotonic() + 0.8
                    state = own_pcm_state(procs)
                    with self.lock:
                        if gen == self.gen:
                            self.output_running = state == "RUNNING"
                            self.output_sample_at = monotonic()
                    if watch.feed(state, monotonic()) and monotonic() - self.last_heal > 10.0:
                        log("commentary stalled: the sound card has been %s for %.0fs while the stream is alive; starting it again"
                            % (state, STALL_SECONDS))
                        stalled = True
                if not acquired and mode != "null":
                    if relay:
                        holding = bool(procs) and getattr(procs[0], "relay_state", {}).get("last_write_t") is not None
                    else:
                        holding = own_pcm_state(procs) is not None
                    if holding:
                        acquired = True
                        log("sound card acquired after %.1fs: %s" % (monotonic() - started,
                                                                     "PCM flowing" if relay else alsa_summary()))
                        if self.on_acquired:
                            try:
                                self.on_acquired()
                            except Exception as e:
                                log("acquired hook failed: %r" % e)
                with self.lock:
                    if gen != self.gen:
                        return
                current_settings = store.get_settings()
                if tuple(current_settings.get(k) for k in ("volume", "output", "alsa_device", "buffer_ms")) != applied_settings:
                    settings_changed = True
                    break
                if not first_logged and procs:
                    ft = getattr(procs[0], "relay_state", {}).get("first_t")
                    if ft:
                        first_logged = True
                        with self.lock:
                            if gen == self.gen and not relay:
                                self.settle_until = max(self.settle_until, ft + self.audio_delay_ms / 1000.0
                                                        + settings["buffer_ms"] / 1000.0 + 1.5)
                        log("first audio from the link after %.1fs (%s)" % (ft - started, mode))
                if monotonic() - stat_t >= 10.0:
                    now = monotonic()
                    got = getattr(procs[0], "relay_state", {}).get("bytes_in") if procs else None
                    rate = ((got - stat_bytes) / float(BYTES_PER_MS * 1000) / (now - stat_t)) if got is not None else None
                    try:
                        with open("/proc/loadavg") as f:
                            load = f.read().split()[0]
                    except EnvironmentError:
                        load = "?"
                    with self.lock:
                        self.feed_rate, self.xrun_count = rate, xruns[0] - stat_xr
                    log("health %s: feed %s real time, %d underruns in %.0fs, cpu load %s" % (
                        mode, "%.2fx" % rate if rate is not None else "n/a", xruns[0] - stat_xr, now - stat_t, load))
                    stat_t, stat_bytes, stat_xr = now, got or 0, xruns[0]
                if relay and procs:
                    relay_state = getattr(procs[0], "relay_state", {})
                    now_check = monotonic()
                    if relay_output_stalled(relay_state, now_check, settings["buffer_ms"]):
                        log("output writer on %s stopped draining PCM; switching route" % self.device)
                        self.errtail.append("aplay: main: audio open error: cannot open audio device %s (output feed stalled)"
                                            % self.device)
                        feed_stalled = True
                    elif (not relay_state.get("input_backpressure", False)
                          and not relay_state.get("input_eof", False)
                          and now_check - relay_state.get("last_read_t", started) > 12.0):
                        log("input stream produced no audio for 12s on %s; reconnecting; decoder said: %s"
                            % (self.device, " | ".join(self.errtail[-4:]) or "nothing"))
                        self.errtail.append("Connection stalled (no audio data for 12s)")
                        stalled = True
                alive = (relay_alive(procs, monotonic(), settings["buffer_ms"]) if relay
                         else all(p.poll() is None for p in procs))
                if stalled or feed_stalled:
                    break
                relay_has_output = bool(procs and getattr(procs[0], "relay_state", {}).get("last_write_t") is not None)
                if alive and monotonic() - started > 2.0 and (not relay or relay_has_output):
                    with self.lock:
                        if gen == self.gen and self.state != "playing":
                            self._set("playing", "")
                    if monotonic() - started > 15 and (not relay or (self.feed_rate is not None and self.feed_rate >= 0.5)):
                        backoff = 1.0
                        with self.lock:
                            if gen == self.gen and (self.retries or self.fatal_n or self.refresh_tried):
                                self.retries = self.fatal_n = 0
                                self.refresh_tried = False
                        route = "%s|%s" % (mode, self.device)
                        if settings.get("route") != route and mode != "null":
                            settings["route"] = route
                            try:
                                store.set_settings({"route": route})
                            except Exception:
                                pass
                if not alive:
                    break
            writer_died = feed_stalled or (len(procs) > 1 and (getattr(procs[0], "relay_state", {}).get("writer_broke")
                                                               or (procs[-1].poll() is not None and procs[0].poll() is None)))
            time.sleep(0.05)
            pre_kill_errtail = list(self.errtail)
            _kill(procs)
            if pre_kill_errtail:
                self.errtail[:] = pre_kill_errtail
            procs[:] = []
            if settings_changed:
                self._set_locked("starting", "", gen)
                continue
            if stalled and not feed_stalled:
                self.last_heal = monotonic()
                time.sleep(0.5)
                continue
            with self.lock:
                if gen != self.gen:
                    return
                ran = monotonic() - started
                gone = set()
                for x in self.errtail:
                    gone.update(_GST_NO_ELEMENT.findall(x))
                if mode.startswith("gst") and gone:
                    _gst_missing.update(gone)
                    log("GStreamer has no element %s; using a pipeline without it" % ", ".join(sorted(gone)))
                    self.dev_idx = 0
                    self._set("starting", "")
                    continue
                if mode in FF_MODES and mode != "null":
                    bad = set()
                    for x in self.errtail:
                        for a, b in _FF_BAD_OPT.findall(x):
                            if a or b:
                                bad.add(a or b)
                    bad -= _ff_bad_opts
                    if bad:
                        _ff_bad_opts.update(bad)
                        log("this ffmpeg does not know %s; starting it without" % ", ".join("-" + o for o in sorted(bad)))
                        self._set("starting", "")
                        continue
                    if any(_FF_NO_PROTO.search(x) for x in self.errtail):
                        scheme = (urlsplit(play_url(stream["url"])).scheme or "").lower()
                        if scheme:
                            _ff_no_scheme.add(scheme)
                        else:
                            _ff_stream_off[0] = True
                        log("this ffmpeg cannot open %s links (%s); using GStreamer for them"
                            % (scheme or "these", " | ".join(x for x in self.errtail if _FF_NO_PROTO.search(x))[:160]))
                        self.dev_idx = 0
                        if not available_modes(settings["output"]):
                            self._set("error", pick_output(settings["output"])[1])
                            return
                        self._set("starting", "")
                        continue
                if mode.startswith("gst") and re.match(r"^https://", to_text(stream.get("url", "")), re.I):
                    host = _host(play_url(stream["url"]))
                    level = _tls_level.get(host, 0)
                    if any(_GST_NO_SSL_PROP.search(x) for x in self.errtail) and level in (1, 2):
                        _tls_level[host] = 2 if level == 1 else 3      # 3: this souphttpsrc has none of these properties
                        self._set("starting", "")
                        continue
                    if any(_TLS_ERR.search(x) for x in self.errtail) and level < 2:
                        _tls_level[host] = 2 if (level == 1 or not os.path.isfile(CA_BUNDLE)) else 1
                        log("the receiver cannot verify the certificate of %s; retrying %s" % (
                            host, "with the bundled CA store" if _tls_level[host] == 1 else "without certificate check"))
                        self._set("starting", "")
                        continue
                # Classify before the codec checks below use it (it was read before assignment: UnboundLocalError).
                kind = classify_failure(self.errtail)
                if mode in FF_MODES and not writer_died and kind != "device" and any(_NO_ENCODER.search(x) for x in self.errtail):
                    _ff_off[0] = True
                    log("this ffmpeg has no PCM encoder (%s); decoding with GStreamer instead"
                        % " | ".join(x for x in self.errtail if _NO_ENCODER.search(x))[:160])
                    self.dev_idx = 0
                    if not available_modes(settings["output"]):
                        self._set("error", pick_output(settings["output"])[1])
                        return
                    self._set("starting", "")
                    continue
                if mode in FF_MODES and not writer_died and kind != "device" and any(_NO_FORMAT.search(x) for x in self.errtail):
                    if relay and not (gst_decode_ok() and (pcm_writer_ok() or bool(which("aplay")))):
                        _relay_off[0] = True
                        log("the live audio delay is not possible with this ffmpeg (%s); using one ffmpeg with adelay"
                            % " | ".join(x for x in self.errtail if _NO_FORMAT.search(x))[:160])
                    else:
                        _ff_off[0] = True
                        log("this ffmpeg lacks PCM output muxers (%s); decoding with GStreamer instead"
                            % " | ".join(x for x in self.errtail if _NO_FORMAT.search(x))[:160])
                        self.dev_idx = 0
                    self._set("starting", "")
                    continue
                kind = classify_failure(self.errtail)
                if relay and mode in FF_MODES and writer_died and kind != "device" and ran < 8:
                    self.relay_fail += 1
                    kind = "device"
                else:
                    self.relay_fail = 0
                if any(_MISSING_DEV_ERR.search(x) for x in self.errtail) and self.device not in ("dvb", "dvb-pes", "dvb-raw"):
                    if self.device not in _dead_alsa_devs:
                        _dead_alsa_devs.add(self.device)
                        log("ALSA device %s does not exist on this receiver; skipping it" % self.device)
                        self.dev_idx = 0
                elif kind == "device" or (writer_died and kind != "fatal"):
                    if (ran < 25 or feed_stalled) and len(combos) > 1:
                        self.dev_idx += 1
                    self.fatal_n = 0
                elif kind == "fatal" and ran < 20:
                    self.fatal_n += 1
                else:
                    if ran < 8 and not first_logged and len(combos) > 1:
                        self.dev_idx += 1
                    self.fatal_n = 0
                self.retries += 1
                want_refresh = (kind == "fatal" and self.on_refused is not None and not self.refresh_tried
                                and any(_HTTP_REFUSED.search(x) for x in self.errtail))
                if want_refresh:
                    self.refresh_tried = True
                if self.fatal_n >= FATAL_LIMIT and not want_refresh:
                    log("giving up after %d refusals in a row: %s" % (self.fatal_n, " | ".join(self.errtail[-4:])))
                    self._set("error", T("The link does not work: %s", best_error(self.errtail) or T("Connection lost")))
                    return
                busy = any(_BUSY.search(x) for x in self.errtail)
                if busy:
                    self.busy_n += 1
                    log("sound card busy (#%d); card state: %s; processes holding /dev/snd: %s" % (
                        self.busy_n, alsa_summary(), ", ".join(alsa_holders()) or "none found"))
                log("stream ended after %.1fs on %s; ffmpeg said: %s" % (monotonic() - started, self.device, " | ".join(self.errtail[-6:])))
                self._set("retrying", "%s (%s)" % (best_error(self.errtail) or T("Connection lost"), T("attempt %d", self.retries)))
            if want_refresh:
                self._set_locked("retrying", T("Getting a fresh link from the source..."), gen)
                try:
                    renewed = bool(self.on_refused(stream))
                except Exception as e:
                    renewed = False
                    log("link refresh failed: %r" % e)
                if renewed:
                    with self.lock:
                        if gen != self.gen:
                            return
                        self.fatal_n = 0
                    continue
            if busy and self.on_busy:
                try:
                    self.on_busy(self.busy_n)
                except Exception as e:
                    log("busy hook failed: %r" % e)
            end = monotonic() + backoff
            while monotonic() < end:
                time.sleep(0.2)
                with self.lock:
                    if gen != self.gen:
                        return
            backoff = min(backoff * 2, 10.0)
