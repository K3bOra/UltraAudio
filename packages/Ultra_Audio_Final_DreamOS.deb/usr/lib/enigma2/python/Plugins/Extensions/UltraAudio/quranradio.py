# -*- coding: utf-8 -*-
"""Verified-only reciter imports for Ultra Audio. No channel on guesswork."""
from __future__ import division
import json
import re
import threading
import time
import unicodedata
from .compat import Request, urlopen_verified as urlopen, urlsplit, to_text
from . import presets, store, importer

API = 'https://www.mp3quran.net/api/v3/radios?language=ar'
FALLBACK_API = 'https://www.mp3quran.net/api/radio/radio_ar.json'
# A deliberately manageable first collection: one station per reader.
READERS = (
    u'مشاري راشد العفاسي', u'محمود خليل الحصري', u'محمد صديق المنشاوي',
    u'عبد الباسط عبد الصمد', u'مصطفى اسماعيل', u'محمود علي البنا',
    u'محمد محمود الطبلاوي', u'ماهر المعيقلي', u'ياسر الدوسري',
    u'سعد الغامدي', u'فارس عباد', u'ناصر القطامي', u'سعود الشريم',
    u'عبد الرحمن السديس', u'ادريس ابكر', u'ابو بكر الشاطري',
    u'محمد جبريل', u'احمد العجمي', u'محمد ايوب', u'صلاح بو خاطر',
    u'عبد الله بصفر', u'ابراهيم الاخضر', u'علي الحذيفي',
    u'هاني الرفاعي', u'خالد الجليل', u'الزين محمد احمد',
    u'نورين محمد صديق', u'هزاع البلوشي', u'احمد نعينع',
    u'عبد العزيز سحيم', u'بندر بليلة', u'عبد الله عواد الجهني',
    u'عمر القزابري', u'عبد الرشيد صوفي', u'العيون الكوشي',
    u'احمد خضر الطرابلسي', u'عبد الله خياط', u'عادل الكلباني',
    u'سهل ياسين', u'صلاح الهاشم',
)
FALLBACK = (
    (u'مشاري راشد العفاسي', 'https://qurango.net/radio/mishary_alafasi'),
    (u'محمود خليل الحصري', 'https://qurango.net/radio/mahmoud_khalil_alhussary_warsh'),
    (u'محمد أيوب', 'https://qurango.net/radio/mohammed_ayyub'),
    (u'ماهر المعيقلي', 'https://backup.qurango.net/radio/maher'),
)
ARABIC_EXTRA = (
    (u'NRJ Egypt 92.1', 'https://nrjstreaming.ahmed-melege.com/nrjegypt'),
    (u'Mix FM 87.8', 'https://stream-29.zeno.fm/na3vpvn10qruv'),
)
_lock = threading.RLock()
_candidates = {}
_updated = 0
_AR_MAP = dict((ord(k), ord(v)) for k, v in ((u'أ', u'ا'), (u'إ', u'ا'), (u'آ', u'ا'), (u'ى', u'ي'), (u'ؤ', u'و'), (u'ئ', u'ي')))


def normalize(value):
    value = unicodedata.normalize('NFKC', to_text(value)).lower()
    value = re.sub(u'[\u064b-\u065f\u0670\u0640]', u'', value)
    value = value.translate(_AR_MAP)
    arabic = re.sub(u'[^\u0621-\u064a]', u'', value)
    return arabic if arabic else re.sub(u'[^a-z0-9]', u'', value)


def allowed(url):
    try:
        p = urlsplit(url)
        return p.scheme == 'https' and (p.hostname or '').lower() in (
            'qurango.net', 'www.qurango.net', 'backup.qurango.net', 'mp3quran.net', 'www.mp3quran.net',
            'nrjstreaming.ahmed-melege.com', 'stream-29.zeno.fm')
    except (ValueError, AttributeError):
        return False


def read_api():
    last = None
    for url in (API, FALLBACK_API):
        try:
            req = Request(url, headers={'User-Agent': 'UltraAudio-V1-Radio/1.0', 'Accept': 'application/json'})
            response = urlopen(req, timeout=10)
            try:
                raw = response.read(512 * 1024 + 1)
            finally:
                response.close()
            if len(raw) > 512 * 1024:
                raise ValueError('The radio catalog is too large')
            val = json.loads(raw.decode('utf-8-sig'))
            entries = val.get('radios', val.get('radio', [])) if isinstance(val, dict) else val
            if not isinstance(entries, list):
                raise ValueError('Invalid radio catalog')
            return entries
        except (EnvironmentError, ValueError, UnicodeError) as e:
            last = e
    return None


def _quran_from_api():
    entries = read_api()
    result = []
    if entries is not None:
        for wanted in READERS:
            q = normalize(wanted)
            hits = []
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                name = entry.get('name') or ''
                url = to_text(entry.get('url') or '')
                if not allowed(url):
                    continue
                nm = normalize(name)
                if not q or q not in nm:
                    continue
                if any(word in nm for word in (normalize(u'تفسير'), normalize(u'ترجمة'), normalize(u'أذكار'))):
                    continue
                hits.append((len(nm) - len(q), url))
            if hits:
                hits.sort(key=lambda x: (x[0], x[1]))
                result.append((wanted, hits[0][1]))
    if entries is None:
        result = list(FALLBACK)
    return result


def catalog(kind):
    global _candidates, _updated
    if kind not in ('quran', 'arabic'):
        raise ValueError('Unknown station group')
    if kind == 'quran':
        items = _quran_from_api()
        if not items:
            items = list(FALLBACK)
    else:
        items = list(ARABIC_EXTRA)
    with _lock:
        _candidates = dict((kind + ':' + str(i), {'id': kind + ':' + str(i), 'name': name, 'url': url, 'kind': kind})
                           for i, (name, url) in enumerate(items))
        _updated = time.time()
        return [{'id': c['id'], 'name': c['name']} for c in _candidates.values()]


def _target(lib, kind):
    preset = 'radio_quran' if kind == 'quran' else 'radio_ar'
    return next((f for f in lib['folders'] if f.get('preset') == preset), None)


def verify_add(cid, abort=None):
    with _lock:
        c = _candidates.get(cid) if time.time() - _updated < 3600 else None
        c = dict(c) if c else None
    if not c or not allowed(c['url']):
        raise ValueError('Station not in verified scan list; refresh')
    lib = store._load()
    target = _target(lib, c['kind'])
    if not target:
        raise ValueError('Radio folder is missing')
    norm_name = normalize(c['name'])
    for s in lib['streams']:
        if s.get('folder') == target['id'] and (normalize(s.get('name', '')) == norm_name or
                                                presets._identity(s.get('url', '')) == presets._identity(c['url'])):
            return {'result': 'existing', 'name': c['name']}
    if abort and abort():
        return {'result': 'unknown', 'name': c['name'], 'why': 'Stop playback before checking'}
    works, why = importer.check_link(c['url'], timeout=14, stable_seconds=3.0, should_abort=abort)
    if works is not True:
        return {'result': 'failed' if works is False else 'unknown', 'name': c['name'], 'why': why}
    with store._lock:
        lib = store._load()
        target = _target(lib, c['kind'])
        if not target:
            return {'result': 'unknown', 'name': c['name'], 'why': 'Radio folder removed'}
        for s in lib['streams']:
            if s.get('folder') == target['id'] and (normalize(s.get('name', '')) == norm_name or
                                                    presets._identity(s.get('url', '')) == presets._identity(c['url'])):
                return {'result': 'existing', 'name': c['name']}
        from .compat import new_id
        ids = set([f['id'] for f in lib['folders']] + [s['id'] for s in lib['streams']])
        sid = new_id()
        while sid in ids:
            sid = new_id()
        s = store._normalize({'name': c['name'], 'url': c['url'], 'kind': 'radio', 'provider': 'radio'})
        s.update(id=sid, folder=target['id'], kind='radio', preset='quran_verified' if c['kind'] == 'quran' else 'radio_verified')
        lib['streams'].append(s)
        store._save(lib)
    return {'result': 'added', 'name': c['name']}
