# -*- coding: utf-8 -*-
"""Tiny LAN web interface (stdlib only): library (folders + links), import from a source, playback & delay control."""
from __future__ import division
import json
import os
import platform
import re
import subprocess
import sys
import threading
import time
from .compat import (BaseHTTPRequestHandler, ThreadingHTTPServer, TimeoutExpired, fullmatch, lru_cache,
                     open_text, run as _run_tool, start_thread, string_types, to_bytes, to_text)

from . import iconchoices, ctl, guide, i18n, importer, presets, receivervolume, store, tvchannel, receivertime
from .i18n import T
from .livefootball import SCORES as LIVE_SCORES, _SPLIT as LIVE_SPLIT, _BAD_PROGRAM as LIVE_BAD_PROGRAM
from .engine import (available_modes, ffmpeg_has_alsa, ffmpeg_pcm_ok, gst_missing, live_delay_info, log, log_tail,
                     missing_text, python_bin, which)

PORT = int(os.environ.get("ULTRAAUDIO_PORT") or store.get_settings().get("web_port", 9990))   # env wins (tests)
INDEX = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", "index.html")
MAX_BODY = 3 * 1024 * 1024
MAX_RESTORE = 40 * 1024 * 1024      # a backup carries the custom pictures too
WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
MANIFEST = {"name": "Ultra Audio Final V1", "short_name": "UltraAudio", "id": "/", "start_url": "/", "scope": "/", "display": "standalone",
            "background_color": "#060d0a", "theme_color": "#06100b",
            "icons": [{"src": "/ultraaudio-greenred-192.png?v=107t1", "sizes": "192x192", "type": "image/png"},
                      {"src": "/ultraaudio-greenred-512.png?v=107t1", "sizes": "512x512", "type": "image/png"}]}
_STATIC = {"/ultraaudio-greenred-180.png": "apple-touch-icon.png", "/ultraaudio-greenred-192.png": "icon-192.png", "/ultraaudio-greenred-512.png": "icon-512.png", "/icon-192.png": "icon-192.png", "/icon-512.png": "icon-512.png", "/apple-touch-icon.png": "apple-touch-icon.png", "/playback-motion.png": "playback-motion.png"}
_HOST_OK = re.compile(r"^(?:\d{1,3}(?:\.\d{1,3}){3}|\[[0-9a-fA-F:]+\]|localhost|[A-Za-z0-9\-]+|[A-Za-z0-9\-.]+\.(?:local|lan|home))(?::\d+)?$")

_server = None
_diag_cache = {}


def _run(cmd, timeout=4):
    try:
        r = _run_tool(cmd, timeout=timeout)
        return (r.stdout or r.stderr or "").strip()
    except (EnvironmentError, TimeoutExpired) as e:
        return "error: %r" % (e,)


def diagnostics():
    if "static" not in _diag_cache:
        d = {"python": sys.version.split()[0], "platform": platform.platform(),
             "ffmpeg": which("ffmpeg"), "ffmpeg_alsa": ffmpeg_has_alsa() if which("ffmpeg") else False,
             "aplay": which("aplay"), "gst": which("gst-launch-1.0"),
             "ffmpeg_pcm": ffmpeg_pcm_ok(), "python_writer": python_bin(), "gst_missing": gst_missing(),
             "outputs": available_modes("auto"), "missing": missing_text()}
        for p in ("/etc/image-version", "/etc/issue"):
            try:
                with open_text(p) as f:
                    d["image"] = f.read().strip()[:300]
                break
            except EnvironmentError:
                pass
        try:
            with open_text("/proc/asound/cards") as f:
                d["alsa_cards"] = f.read().strip()
        except EnvironmentError:
            d["alsa_cards"] = ""
        d["aplay_l"] = _run([d["aplay"], "-L"])[:1500] if d["aplay"] else ""
        d["dvb_audio"] = os.path.exists("/dev/dvb/adapter0/audio0")
        _diag_cache["static"] = d
    d = dict(_diag_cache["static"])
    try:  # timeshift config, only when running inside enigma2
        from Components.config import config
        d["timeshift_path"] = to_text(config.usage.timeshift_path.value)
        d["timeshift_ram"] = to_text(getattr(config.timeshift, "ram", getattr(config.usage, "timeshift_ram", "")))
    except Exception:
        d["timeshift_path"] = None
    d["live_audio_delay"] = live_delay_info()
    d["log"] = log_tail(40)
    try:
        from .engine import audio_processes
        d["audio_processes"] = audio_processes()[:25]
        d["last_errors"] = list(ctl.get().engine.errtail[-8:])
    except Exception as e:
        d["audio_processes"] = ["unavailable: %r" % (e,)]
    d["guide"] = guide.diagnostics()
    d["guide_clock"] = guide._CLOCK.diagnostics()
    d["receiver_time"] = receivertime.status()
    return d


def library():
    """Folders and channels with `pos`: the place the receiver's own list gives them, so the page shows the same order."""
    lib = store._load()
    language = i18n.lang()
    guide.ensure([s for s in lib["streams"] if not store.is_radio_stream(s, lib)], language)  # radio has no TV guide
    folders, streams = [], []
    # one sort for the whole library gives the same relative order as each folder's own sort on the receiver
    pos_f = {f["id"]: i for i, f in enumerate(sorted(lib["folders"], key=store.folder_key))}
    pos_s = {x["id"]: i for i, x in enumerate(sorted(lib["streams"], key=store.stream_key))}
    for f in lib["folders"]:
        src = f.get("source") or {}
        folders.append({"id": f["id"], "parent": f.get("parent", ""), "name": store.display_folder_name(f, language), "provider": f.get("provider", ""),
                        "icon_url": shared_icon_url(store.folder_icon(f, lib=lib)),
                        "count": store.count_streams(f["id"], lib), "from_url": src.get("type") == "url",
                        "streams_first": store.streams_first(f["id"], lib),
                        "updated": f.get("updated", 0), "pos": pos_f.get(f["id"], 0)})
    live_requested = False
    for s in lib["streams"]:
        t = dict(s)
        t["display_name"], t["duration"] = store.stream_display(s, lib)
        t["icon_url"] = shared_icon_url(store.stream_icon(s, lib=lib))
        t["custom_icon"] = False  # Manual choices still reuse bundled artwork.
        t["icon_choice"] = s.get("icon_choice", "")
        t["automatic_icon_url"] = shared_icon_url(store.stream_icon(dict(s, icon_choice=""), lib=lib))
        t["pos"] = pos_s.get(s["id"], 0)
        key, event, pending = (None, None, False) if store.is_radio_stream(s, lib) else guide.view(s, language)
        time_notice = receivertime.guide_notice() if key else ''
        t['guide_notice'] = T(time_notice) if time_notice else ''
        if time_notice:
            event = None
        t["kind"] = "radio" if store.is_radio_stream(s, lib) else t.get("kind", "commentary")
        t["needs_stream_url"] = store.needs_radio_url(s)
        # Reuse the receiver's shared, rate-limited score cache. One eligible
        # fixture per library snapshot; no per-channel network requests.
        if (not live_requested and event and not LIVE_BAD_PROGRAM.search(to_text(event[0]))
                and len(LIVE_SPLIT.split(to_text(event[0]))) == 2):
            LIVE_SCORES.ensure(event)
            live_requested = True
        t["guide"] = ({"title": event[0], "start": event[1], "end": event[2],
                       "match_live": LIVE_SCORES.is_live(event),
                       "time": to_text(time.strftime("%H:%M", time.localtime(event[1]))) + u" \u2013 " +
                               to_text(time.strftime("%H:%M", time.localtime(event[2])))} if event else None)
        streams.append(t)
    return {"folders": folders, "streams": streams, "now": time.time()}


def status():
    c = ctl.get()
    st = c.status()
    volume = c._on_main(receivervolume.snapshot)
    st["receiver_volume"] = volume if isinstance(volume, dict) else {"available": False, "value": None}
    memo = store.recall_channel(st.get("tv_service")) or {}
    st["saved_video_s"] = float(memo.get("video_s") or 0.0)
    st["step_audio_ms"] = store.get_settings()["step_audio_ms"]
    st["step_video_s"] = store.get_settings()["step_video_s"]
    return st


def state():
    """What the page needs (diagnostics are at /api/diag: they read the log and run tools, too slow for every poll)."""
    return {"library": library(), "settings": store.get_settings(), "status": status()}


def _stop_if_gone(c):
    """A refresh / import may have removed the commentary that is playing: stop it rather than keep a ghost."""
    sid = c.engine.status()["stream_id"]
    if sid and store.get_stream(sid) is None:
        c.stop()


def shared_icon_url(path):
    if not path or not path.startswith(store.ASSETS + os.sep):
        return None
    key = os.path.basename(path).split('@', 1)[0].split('.', 1)[0]
    expected = 'folders' if key in ('radio', 'quran') else 'logos'
    if key in ('radio', 'quran', 'event', 'match', 'live') and os.path.basename(os.path.dirname(path)) == expected:
        return '/shared-icon/' + key + '?v=test3-unified1'
    if key == 'onsportfm' and os.path.basename(os.path.dirname(path)) == 'radio':
        return '/shared-icon/onsportfm?v=106test2'
    choice = iconchoices.key_for_path(path)
    return '/bundled-icon/' + choice + '?v=test3-iconpicker1' if choice else None


@lru_cache(maxsize=128)
def _bundled_image(path):
    with open(path, 'rb') as handle:
        return handle.read()


def _img(path):
    ctype = {"png": "image/png", "jpg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}[path.rsplit(".", 1)[1]]
    if path.startswith(store.ASSETS + os.sep):
        return _bundled_image(path), ctype
    with open(path, "rb") as f:
        return f.read(), ctype


def render_index():
    """The page with the active language pack injected (no flash of the wrong language)."""
    with open_text(INDEX) as f:
        html = f.read()
    bundle = i18n.web_bundle()
    blob = to_text(json.dumps(bundle, ensure_ascii=True)).replace(u"</", u"<\\/")
    html = html.replace(u"<!--UA_I18N-->", u"<script>window.I18N=%s;</script>" % blob, 1)
    html = html.replace(u'<html lang="en" dir="ltr">',
                        u'<html lang="%s" dir="%s">' % (to_text(bundle["lang"]), to_text(bundle["dir"])), 1)
    return to_bytes(html)


def _playback_action(controller, action, data):
    """Reject a delayed browser action if playback/channel changed before dispatch."""
    def run():
        st = controller.engine.status()
        if ((data.get("id") is not None and data["id"] != st.get("stream_id"))
                or (data.get("generation") is not None and data["generation"] != st.get("generation"))
                or (data.get("service") is not None and data["service"] != controller._service_key())):
            return False
        action()
        return True
    return {"ok": bool(controller._on_main(run))}


class Handler(BaseHTTPRequestHandler):
    server_version = "UltraAudio"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):  # keep enigma2's stdout clean
        pass

    # ---- plumbing
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, (dict, list)):
            body = to_bytes(json.dumps(body, ensure_ascii=False))
        elif not isinstance(body, bytes):
            body = to_bytes(body)
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", (extra or {}).get("Cache-Control", "no-store"))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                         "script-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
        for k, v in (extra or {}).items():
            if k.lower() != "cache-control":
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        return bool(_HOST_OK.match(self.headers.get("Host", "")))

    def _origin_ok(self):
        """Allow local Web UI and non-browser clients without adding a login.

        Reject a cross-origin browser write when it supplies an Origin header.
        The existing X-UltraAudio request header remains required.
        """
        origin = self.headers.get("Origin")
        if not origin:
            return True
        host = self.headers.get("Host", "")
        return origin in ("http://" + host, "https://" + host)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": T("Bad host")})
        path = self.path.split("?", 1)[0]
        try:
            if path in ("/", "/index.html"):
                return self._send(200, render_index(), "text/html; charset=utf-8")
            if path == "/wave-logo.png":
                with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", "wave-logo.png"), "rb") as f:
                    return self._send(200, f.read(), "image/png", {"Cache-Control": "public, max-age=3600"})
            if path == "/brand-logo.png":
                with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", "logo.png"), "rb") as f:
                    return self._send(200, f.read(), "image/png", {"Cache-Control": "max-age=300"})
            if fullmatch(r"/font/readex-[4-7]00\.woff", path):
                # Readex Pro (SIL Open Font License, web/fonts/READEX-PRO-OFL.txt), bundled: the page loads nothing from the internet
                with open(os.path.join(WEB_DIR, "fonts", path[len("/font/"):]), "rb") as f:
                    return self._send(200, f.read(), "font/woff", {"Cache-Control": "public, max-age=604800"})
            if path in _STATIC:
                with open(os.path.join(WEB_DIR, _STATIC[path]), "rb") as f:
                    return self._send(200, f.read(), "image/png", {"Cache-Control": "max-age=300"})
            if path == "/manifest.webmanifest":
                return self._send(200, json.dumps(MANIFEST), "application/manifest+json")
            if path == "/api/backup":
                import time as _t
                name = "UltraAudio-backup-%s.json" % _t.strftime("%Y-%m-%d")
                return self._send(200, store.make_backup(), "application/json; charset=utf-8",
                                  {"Content-Disposition": 'attachment; filename="%s"' % name})
            if path == "/api/state":
                return self._send(200, state())
            if path == "/api/icons":
                return self._send(200, {"icons": [{"id": key, "name": name,
                    "url": "/bundled-icon/" + key + "?v=test3-iconpicker1"} for key, name in iconchoices.catalog()]})
            if path.startswith('/bundled-icon/'):
                image_path = iconchoices.resolve(path[len('/bundled-icon/'):])
                if not image_path:
                    return self._send(404, {"error": T("Not found")})
                data, ctype = _img(store.web_icon(image_path))
                return self._send(200, data, ctype, {"Cache-Control": "public, max-age=86400"})
            if path == "/api/status":
                return self._send(200, status())
            if path == "/api/diag":
                return self._send(200, diagnostics())
            if path == '/tv-picon/default' or fullmatch(r'/tv-picon/[0-9a-f]{24}', path):
                channel = ctl.get().status().get('tv_channel', {})
                # The client supplies only the current identity token, never a path.
                if path != '/tv-picon/default' and path != channel.get('icon'):
                    return self._send(404, {'error': T('Not found')})
                icon = tvchannel.read_icon(channel) if path != '/tv-picon/default' else None
                data, ctype = icon if icon is not None else _img(store.DEFAULT_PICON)
                return self._send(200, data, ctype)
            shared = fullmatch(r'/shared-icon/(radio|quran|event|match|live|onsportfm)', path)
            if shared:
                key = shared.group(1)
                family = 'radio' if key == 'onsportfm' else ('folders' if key in ('radio', 'quran') else 'logos')
                data, ctype = _img(store.web_icon(os.path.join(store.ASSETS, family, key + '.png')))
                return self._send(200, data, ctype, {"Cache-Control": "public, max-age=86400"})
            m = re.match(r"^/picon/([0-9a-f]{12})$", path)
            if m:
                data, ctype = _img(store.web_icon(store.picon_or_default(m.group(1))))
                return self._send(200, data, ctype, {"Cache-Control": "max-age=30"})
            m = re.match(r"^/ficon/([0-9a-f]{12})$", path)
            if m:
                data, ctype = _img(store.web_icon(store.folder_icon(store.get_folder(m.group(1)) or {})))
                return self._send(200, data, ctype, {"Cache-Control": "max-age=30"})
        except Exception as e:
            log("GET %s failed: %r" % (path, e))
            return self._send(500, {"error": T("Internal error, check the log")})
        self._send(404, {"error": T("Not found")})

    def do_POST(self):
        if not self._host_ok() or not self._origin_ok() or self.headers.get("X-UltraAudio") != "1":
            self.close_connection = True          # the body was not read: this connection cannot carry another request
            return self._send(403, {"error": T("Forbidden")})
        try:
            n = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            n = -1
        if n < 0 or n > (MAX_RESTORE if self.path.split("?", 1)[0] == "/api/restore" else MAX_BODY):
            self.close_connection = True
            return self._send(413, {"error": T("Request too large")})
        try:
            data = json.loads(to_text(self.rfile.read(n) or b"{}"))
            if not isinstance(data, dict):
                raise ValueError(T("Invalid request body"))
        except ValueError:
            return self._send(400, {"error": T("Invalid JSON")})
        path = self.path.split("?", 1)[0]
        try:
            self._send(200, self._route(path, data))
        except KeyError:
            self._send(404, {"error": T("Not found")})
        except ValueError as e:
            self._send(400, {"error": to_text(e)})
        except EnvironmentError as e:     # network trouble while importing / fetching a logo
            log("POST %s network error: %r" % (path, e))
            self._send(502, {"error": T("Could not reach the link: %s", getattr(e, "reason", None) or e)})
        except Exception as e:
            log("POST %s failed: %r" % (path, e))
            self._send(500, {"error": T("Internal error, check the log")})

    # ---- API
    def _route(self, path, d):
        c = ctl.get()
        if path == "/api/receiver-volume":
            value = d.get("value")
            if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 100:
                raise ValueError(T("Volume must be an integer between 0 and 100"))
            result = c._on_main(receivervolume.apply, value)
            if not isinstance(result, dict) or not result.get("available"):
                raise ValueError(T("Receiver volume unavailable"))
            return {"ok": True, "receiver_volume": result}
        if path == "/api/stream":
            sid = d.get("id")
            s = store.update_stream(sid, d) if sid else store.add_stream(d)
            return {"ok": True, "id": s["id"]}
        if path == "/api/stream/order":
            # {"ids": [...]}: the commentaries of one folder in the order the owner dragged them into
            ids = d.get("ids")
            if not isinstance(ids, list):
                raise ValueError(T("Unknown channel"))
            return {"ok": True, "moved": store.set_stream_order(ids)}
        if path == "/api/stream/delete":
            if c.engine.status()["stream_id"] == d.get("id"):
                c.stop()
            store.delete_stream(d.get("id"))
            return {"ok": True}
        if path == "/api/picon/clear":
            store.clear_picon(d.get("id"))
            return {"ok": True}
        if path == "/api/folder":
            if d.get("id"):
                f = store.rename_folder(d["id"], d.get("name", ""))
            else:
                f = store.add_folder(d.get("name", ""), d.get("parent", ""))
            return {"ok": True, "id": f["id"]}
        if path == "/api/folder/order":
            ids = d.get("ids")
            parent = d.get("parent", "")
            if not isinstance(ids, list) or not isinstance(parent, string_types):
                raise ValueError(T("Unknown folder"))
            return {"ok": True, "moved": store.set_folder_order(parent, ids)}
        if path == "/api/folder/delete":
            st = c.engine.status()
            cur = store.get_stream(st["stream_id"]) if st["stream_id"] else None
            if cur and any(p["id"] == d.get("id") for p in store.folder_path(cur.get("folder", ""))):
                c.stop()
            return {"ok": True, "removed": store.delete_folder(d.get("id"))}
        if path == "/api/folder/refresh":
            res = importer.refresh_folder(d.get("id"))
            _stop_if_gone(c)
            return dict(res, ok=True)
        if path == "/api/import":
            res = importer.import_source(store.clean_text(d.get("name"), 60), url=to_text(d.get("url") or "").strip() or None,
                                         text=d.get("text") or None, parent=d.get("parent", ""))
            _stop_if_gone(c)
            return dict(res, ok=True)
        if path == "/api/preset/foxfm":
            return dict(presets.install_foxfm(force=True), ok=True)
        if path == "/api/preset/radio":
            return dict(presets.install_radio(force=True), ok=True)
        if path == "/api/play":
            return {"ok": c.play(d.get("id"))}
        if path == "/api/stop":
            return _playback_action(c, c.stop, d)
        if path == "/api/sync/save":
            ok, message = c.save_channel_sync(d.get("id"), d.get("generation"), d.get("service"))
            return {"ok": ok, "message": message}
        if path == "/api/sync/forget":
            service = d.get("service")
            ok, message = c.forget_channel_sync(to_text(service) if isinstance(service, string_types) and service else None)
            return {"ok": ok, "message": message}
        if path == "/api/adjust":
            try:
                direction = 1 if int(d.get("dir", 1)) >= 0 else -1
            except (TypeError, ValueError):
                raise ValueError(T("Unknown adjustment"))
            if d.get("what") == "video":
                c.adjust_video(direction)
            elif d.get("what") == "audio":
                c.adjust_audio(direction)
            else:
                raise ValueError(T("Unknown adjustment"))
            return {"ok": True}
        if path == "/api/video_delay":
            try:
                seconds = float(d.get("seconds", 0.0))
            except (TypeError, ValueError):
                raise ValueError(T("Unknown adjustment"))
            if not store.isfinite(seconds):
                raise ValueError(T("Invalid picture delay"))
            return _playback_action(c, lambda: c.set_video_delay(
                max(0.0, min(600.0, seconds)), d.get("id"), d.get("generation")), d)
        if path == "/api/audio_delay":
            # an exact value: the page collects a run of presses into one change (one restart on the old pipeline)
            try:
                ms = int(d.get("ms", 0))
            except (TypeError, ValueError):
                raise ValueError(T("Unknown adjustment"))
            return _playback_action(c, lambda: c.set_audio_delay(
                max(0, min(60000, ms)), d.get("id"), d.get("generation")), d)
        if path == "/api/restore":
            store.validate_backup(d)
            c.stop()
            return dict(store.restore_backup(d), ok=True)
        if path == "/api/pause":
            return _playback_action(c, c.toggle_pause, d)
        if path == "/api/settings":
            d = dict(d)
            d.pop("web_port", None)     # the port moves from the receiver's MENU only (it restarts this very server)
            d.pop("route", None)
            return {"ok": True, "settings": store.set_settings(d)}
        if path == "/api/test":
            ok, msg = c.test_tone()
            return {"ok": ok, "message": msg}
        raise KeyError(path)


class _Server(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        """A phone that closes the page mid-answer is normal: one log line, not a traceback in Enigma2's output."""
        err = sys.exc_info()[1]
        log("web client %s: %r" % (client_address[0], err))


def start():
    """Start the web server once, in a daemon thread. Returns True when it is listening."""
    global _server
    if _server is not None:
        return True
    try:
        store.ensure_dirs()
        _server = _Server((str("0.0.0.0"), PORT), Handler)
        _server.daemon_threads = True
        start_thread(_server.serve_forever, (), "UltraAudioWeb")
        log("web interface on port %d" % PORT)
        return True
    except EnvironmentError as e:
        _server = None
        log("web interface failed to start: %r" % (e,))
        return False


def stop():
    global _server
    if _server is not None:
        _server.shutdown()
        _server.server_close()
        _server = None


def set_port(port):
    """Move the web page to another port and remember it. Returns (ok, port_now). On a busy port the old one is
    restored, so the page is never lost."""
    global PORT
    port = int(port)
    if not 1024 <= port <= 65535:
        raise ValueError(T("Invalid port"))
    old = PORT
    if port == old and _server is not None:
        return True, port
    stop()
    PORT = port
    if start():
        store.set_settings({"web_port": port})
        return True, port
    PORT = old
    start()
    return False, old
