# -*- coding: utf-8 -*-
"""A long press on the remote's AUDIO key opens Ultra Audio while watching TV.

Our own key map context (keymap.xml, AUDIO with the 'long' flag) is bound on the InfoBar with a higher priority than the
receiver's own AUDIO actions. A short press is untouched. On OpenATV the release after a long press is not a 'break'
any more, so the normal audio menu does not open; older images may still send it, so the audio menu is ignored for a
moment after our long press. Switched off in MENU (or on any error) the key does exactly what it did before.
"""
from __future__ import division
import os
import time

from . import store
from .compat import monotonic, native
from .engine import log

KEYMAP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keymap.xml")
CONTEXT, ACTION, NAME = "UltraAudioActions", "openUltraAudio", "UltraAudioLongAudio"
QUIET = 1.5                  # seconds after our long press during which the receiver's audio menu stays shut

_state = {"installed": False, "last_long": 0.0, "open": None}


def _load_keymap():
    try:
        from Components.ActionMap import loadKeymap as load       # OpenATV / newer OpenPLi
    except ImportError:
        from keymapparser import readKeymap as load               # older images
    load(native(KEYMAP))


def _on_long():
    if not store.get_settings().get("long_audio", True):
        return 0                                   # not handled: the receiver's own long AUDIO action runs
    _state["last_long"] = monotonic()
    try:
        from Screens.InfoBar import InfoBar
        ib = InfoBar.instance
        if ib is not None and _state["open"]:
            _state["open"](ib.session)
    except Exception as e:
        log("long AUDIO: opening failed: %r" % e)
    return 1


def _on_bar():
    # Returning zero leaves the receiver's normal 0 action intact while idle.
    try:
        from Screens.InfoBar import InfoBar
        from .playbackbar import open_bar
        ib = InfoBar.instance
        return open_bar(ib.session) if ib is not None else 0
    except Exception as error:
        log("playback bar key: %r" % error)
        return 0


def _attach(ib):
    from Components.ActionMap import ActionMap
    bar_name = "UltraAudioPlaybackBarKey"
    if bar_name not in ib:
        bar = ActionMap([CONTEXT], {"openUltraAudioBar": _on_bar}, -2)
        ib[bar_name] = bar
        if getattr(ib, "execing", False):
            bar.execBegin()
    if NAME in ib:
        return
    am = ActionMap([CONTEXT], {ACTION: _on_long}, -1)
    ib[NAME] = am
    if getattr(ib, "execing", False):              # the InfoBar already runs (plugin reloaded): bind now
        am.execBegin()


def install(open_plugin):
    """Called at session start, before the InfoBar exists. Never raises."""
    if _state["installed"]:
        return
    _state["open"] = open_plugin
    try:
        _load_keymap()
        from Screens.InfoBar import InfoBar
        from Screens.InfoBarGenerics import InfoBarAudioSelection
    except Exception as e:
        log("long AUDIO key not available: %r" % e)
        return

    base_init = InfoBar.__init__

    def init(self, *args, **kwargs):
        base_init(self, *args, **kwargs)
        try:
            _attach(self)
        except Exception as e:
            log("long AUDIO key: %r" % e)
    InfoBar.__init__ = init

    base_sel = InfoBarAudioSelection.audioSelection

    def audioSelection(self, *args, **kwargs):
        if monotonic() - _state["last_long"] < QUIET:
            return None                            # the release of our long press: no audio menu on top of ours
        return base_sel(self, *args, **kwargs)
    InfoBarAudioSelection.audioSelection = audioSelection

    try:
        if InfoBar.instance is not None:
            _attach(InfoBar.instance)
    except Exception as e:
        log("long AUDIO key: %r" % e)
    _state["installed"] = True
    log("long AUDIO key ready")
