# -*- coding: utf-8 -*-
"""The real channel logos that ship with the plugin (assets/logos/<id>.png, see tools/make_logos.py).

A commentary link is named after the channel it carries: 'SatFamily-4k-3' is beIN Sports 3, 'Orange-Xtra2' is beIN Sports Xtra 2,
'SarFamily-4K-Alkass-5' is Al Kass 5, 'satfamily-thamanyah-1' is Thmanyah 1. `logo_id` turns such a name into the id of
the logo (or None), after dropping the provider and quality words."""
from __future__ import division
import os
import re
import unicodedata

from . import store
from .compat import lru_cache, to_text

LOGO_DIR = os.path.join(store.ASSETS, "logos")
# provider / quality words: decoration of the link, not part of the channel
_JUNK = {u"satfamily", u"sarfamily", u"satfamilly", u"sf4k", u"sfvip", u"sflow", u"stereofm", u"orange", u"best", u"foxfm", u"fox", u"anis", u"anisfm", u"انيس",
         u"fm", u"sat", u"family", u"4k", u"uhd", u"fhd", u"hd", u"sd", u"low", u"middle", u"delay", u"vip", u"ip",
         u"tv", u"bs", u"sp", u"channel", u"audio", u"commentary"}
_ALIASES = ((u"thamanyah", u"thmanyah"), (u"thmanyeh", u"thmanyah"), (u"thm8h", u"thmanyah"),
            (u"alkaas", u"alkass"), (u"alkas", u"alkass"), (u"kass", u"alkass"),
            (u"adprem", u"ad"), (u"adsports", u"ad"), (u"abudhabisports", u"ad"), (u"abudhabi", u"ad"),
            (u"beinsports", u"bein"), (u"beinsport", u"bein"), (u"beinxtra", u"xtra"), (u"extra", u"xtra"),
            (u"beinmax", u"max"), (u"spmax", u"max"), (u"mx", u"max"), (u"pn", u"bein"),
            (u"beinfrench", u"fr"), (u"french", u"fr"),
            (u"beinsportsenglish", u"en"), (u"beinenglish", u"en"), (u"beinen", u"en"), (u"english", u"en"))
_NAMED_PREFIXES = {u"bein", u"beinsports", u"beinsport", u"beinxtra", u"beinmax", u"beinfrench", u"beinsportsenglish", u"beinenglish", u"beinen",
                   u"en", u"english", u"fr", u"french", u"xtra", u"extra", u"max", u"spmax", u"mx", u"pn",
                   u"alkass", u"alkaas", u"alkas", u"kass", u"thmanyah", u"thamanyah", u"thmanyeh", u"thm8h",
                   u"ssc", u"ad", u"adprem", u"adsports", u"abudhabisports", u"abudhabi", u"bundesliga", u"onfm"}

# These marks belong to the channel, independently of the commentary provider.
# Keep this recognition separate from the established beIN aliases: an unknown
# sports feed must not turn into beIN just because its name contains a number.
_EXTRA_FAMILIES = (
    (u"shahid", 4, u"shahid|شاهد"),
    (u"shasha", 2, u"shasha(?:h)?|شاشا|شاشة|شاشه"),
    (u"alrabiaa", 2, u"al ?rabiaa|al ?rabia|al ?rabeea|al ?rabea|al ?rabaa|الرابعة|الرابعه"),
    (u"starzplay", 2, u"starz ?play|ستارز ?بلاي"),
)
_EXTRA_DROP = _JUNK | {u"fm", u"audio", u"commentary", u"صوتيات", u"سات", u"فاميلي", u"اورانج", u"انيس"}
_DIGITS = dict((ord(a), ord(b)) for a, b in zip(u"٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", u"01234567890123456789"))
_EXTRA_PATTERNS = tuple((family, maximum, re.compile(
    u"(?:^| )(?:" + aliases + u")(?: ?(?:sports?|سبورت|الرياضية|الرياضيه))?"
    u"(?: ?([0-9]+))?(?= |$)", re.UNICODE))
    for family, maximum, aliases in _EXTRA_FAMILIES)
_FEED_PATTERNS = tuple((asset, re.compile(
    u"(?:^| )(?:" + aliases + u")(?: ?[0-9]+)?(?= |$)", re.UNICODE))
    for asset, aliases in ((u"event", u"events?|ايفنت|ايفينت"),
                           (u"match", u"match|ماتش|مباراة|مباره"),
                           (u"live", u"live|لايف|مباشر")))
_MBC_MASR = re.compile(u"(?:^| )(?:mbc|ام ?بي ?سي) ?(?:masr|misr|egypt|مصر)(?: ?([0-9]+))?(?= |$)", re.UNICODE)
_MBC_ACTION = re.compile(u"(?:^| )(?:mbc|ام ?بي ?سي) ?(?:action|اكشن)(?= |$)", re.UNICODE)


def _logo_words(name):
    """Normalize Arabic/English lettering and digits without guessing channel numbers."""
    text = unicodedata.normalize("NFKC", to_text(name)).lower().translate(_DIGITS)
    text = re.sub(u"[\u0640\u064b-\u065f\u0670]", u"", text)
    text = text.replace(u"أ", u"ا").replace(u"إ", u"ا").replace(u"آ", u"ا")
    return re.findall(u"[^\\W_]+", text, re.UNICODE)


def _special_logo(words):
    """Feed labels are distinct static white icons; MBC names retain their own branding."""
    text = u" ".join(w for w in words if w not in _EXTRA_DROP)
    for asset, pattern in _FEED_PATTERNS:
        if pattern.search(text):
            return True, str(asset)
    match = _MBC_MASR.search(text)
    if match:
        number = match.group(1) or u"1"
        return True, "mbcmasr1" if number == u"1" and not text[match.end():].strip() else None
    match = _MBC_ACTION.search(text)
    if match:
        return True, "mbcaction" if not text[match.end():].strip() else None
    return False, None


def _extra_logo(name, words=None):
    """(recognized family, asset id); unsupported numbered variants keep the old badge."""
    words = _logo_words(name) if words is None else words
    text = u" ".join(w for w in words if w not in _EXTRA_DROP)
    for family, maximum, pattern in _EXTRA_PATTERNS:
        match = pattern.search(text)
        if not match:
            continue
        # Shahid/STARZPLAY share their approved unnumbered mark on every source.
        if family in (u"shahid", u"starzplay"):
            return True, str(family)
        # The channel number must be attached to this channel name, never taken
        # from a provider, year, quality tag or another word later in the name.
        if text[match.end():].strip():
            return True, None
        number = match.group(1)
        if number is None:
            return True, str(family)
        n = int(number) if len(number) <= 2 else 0
        return True, str(family) if 1 <= n <= maximum else None
    return False, None


def _anis_channel_id(words):
    """Explicit Anis feed aliases; quality suffixes do not change identity."""
    non_anis_junk = _JUNK - {u"anis", u"anisfm", u"انيس", u"sp"}
    text = u"".join(w for w in words if w not in non_anis_junk)
    match = re.match(u"^(?:anisfm|anis|انيس)(.*)$", text)
    if not match:
        return None
    tail = match.group(1)
    if tail in (u"shahid", u"شاهد"):
        return "shahid"
    if tail in (u"shasha", u"شاشا", u"شاشة", u"شاشه"):
        return "shasha"
    if tail in (u"starzplay", u"starz", u"ستارز", u"ستارزبلاي"):
        return "starzplay"
    if re.match(u"^[1-9]$", tail):
        return "bein%s" % tail
    match = re.match(
        u"^(sports?|sp|pn|سبورت|xtra|extra|xt|اكسترا|en|eng|english|انجليزي|fr|fra|french|فرنسي|"
        u"thm8h|thmanyah|thamanyah|thmanyeh|th|8|ثمانية|ثمانيه|alkass|alkas|alkaas|kass|ks|الكاس|"
        u"max|spmax|mx|ماكس|italy|italian|it|ايطالي|ايطالى|starzplay|starz|de|shahid|shd|شاهد|"
        u"shasha|sh|شاشا|شاشة|ad|adsports|ابوظبي|alrabiaa|rabiaa|الرابعة)([1-9])?$", tail)
    if not match:
        return None
    family = match.group(1)
    number = int(match.group(2) or "1")
    if family in (u"sport", u"sports", u"sp", u"pn", u"سبورت"):
        return "bein%d" % number if 1 <= number <= 9 else None
    if family in (u"max", u"spmax", u"mx", u"ماكس") and number <= 6:
        return "max%d" % number
    if family in (u"xtra", u"extra", u"xt", u"اكسترا") and number <= 9:
        return "xtra%d" % number
    if family in (u"en", u"eng", u"english", u"انجليزي") and number <= 2:
        return "en%d" % number
    if family in (u"fr", u"fra", u"french", u"فرنسي") and number <= 2:
        return "fr%d" % number
    if family in (u"8", u"thm8h", u"thmanyah", u"thamanyah", u"thmanyeh", u"th", u"ثمانية", u"ثمانيه") and number <= 3:
        return "thmanyah%d" % number
    if family in (u"alkass", u"alkas", u"alkaas", u"kass", u"ks", u"الكاس") and number <= 8:
        return "alkass%d" % number
    if family in (u"italy", u"italian", u"it", u"ايطالي", u"ايطالى", u"starzplay", u"starz") and number <= 2:
        return "starzplay"
    if family in (u"de", u"shahid", u"shd", u"شاهد") and number <= 4:
        return "shahid"
    if family in (u"shasha", u"sh", u"شاشا", u"شاشة") and number <= 2:
        return "shasha"
    if family in (u"ad", u"adsports", u"ابوظبي") and number <= 2:
        return "ad%d" % number
    if family in (u"alrabiaa", u"rabiaa", u"الرابعة") and number <= 2:
        return "alrabiaa"
    return None


@lru_cache(maxsize=2048)
def logo_id(name):
    """Logo id for a stream name, e.g. 'bein3', 'xtra2', 'alkass5', 'thmanyah1', 'live'; None when there is none."""
    words = _logo_words(name)
    # Brand artwork wins over generic Live/Event labels and provider badges.
    for family, maximum, pattern in _EXTRA_PATTERNS:
        if family in (u"shahid", u"starzplay") and pattern.search(u" ".join(words)):
            return str(family)
    special_anis = _anis_channel_id(words)
    if special_anis and os.path.isfile(os.path.join(LOGO_DIR, special_anis + ".png")):
        return special_anis
    recognized, extra = _special_logo(words)
    if not recognized:
        recognized, extra = _extra_logo(name, words)
    if recognized:
        return extra if extra and os.path.isfile(os.path.join(LOGO_DIR, extra + ".png")) else None
    words = [w for w in words if w not in _JUNK]
    candidates = [u"".join(words)]
    # A new provider can still use an explicit channel name. Only known channel
    # words start suffix candidates; a random trailing number is never enough.
    for i, word in enumerate(words[1:], 1):
        prefix = re.match(u"^([a-z]+)(?:[0-9]+)?$", word)
        if prefix and prefix.group(1) in _NAMED_PREFIXES:
            candidates.append(u"".join(words[i:]))
    for k in candidates:
        # Accept official suffix order as well as provider labels (English 1).
        english = re.match(u"^(?:bein(?:sports?)?)?(?:([12])(?:en|english)|(?:en|english)([12]))$", k)
        if english:
            return str("en" + str(english.group(1) or english.group(2)))
        for a, b in _ALIASES:
            m = re.match(u"^%s(\\d*)$" % a, k)
            if m:
                k = b + m.group(1)
                break
        if re.match(u"^[1-9]$", k):              # the established provider's bare-number beIN feed
            k = u"bein" + k
        if k in (u"bundesliga", u"thmanyah", u"ssc", u"ad", u"en", u"fr"):
            k += u"1"
        if k and os.path.isfile(os.path.join(LOGO_DIR, str(k) + ".png")):
            return str(k)
    return None


@lru_cache(maxsize=1024)
def _find_cached(lid, scale_bucket):
    if scale_bucket == "2x":
        big = os.path.join(LOGO_DIR, lid + "@2x.png")
        if os.path.isfile(big):
            return big
    elif scale_bucket == "wqhd":
        for sfx in ("@wqhd.png", "@2x.png"):
            cand = os.path.join(LOGO_DIR, lid + sfx)
            if os.path.isfile(cand):
                return cand
    elif scale_bucket == "hd":
        hd = os.path.join(LOGO_DIR, lid + "@hd.png")
        if os.path.isfile(hd):
            return hd
    return os.path.join(LOGO_DIR, lid + ".png")


def find(stream, scale=1.0):
    """Path of the logo picture for a stream (4K @2x, WQHD @wqhd, FHD 1x, or HD @hd), or None."""
    raw_name = to_text((stream or {}).get("name", ""))
    url = to_text((stream or {}).get("url", ""))
    # If the stream name is a bare number (e.g. '1'..'9') or empty, derive its smart name from URL first
    # so 'mx/1' matches 'max1' rather than falling back to bare-number 'bein1'.
    if url and re.match(u"^[0-9\u0660-\u0669\u06f0-\u06f9]{1,2}$", raw_name.strip()):
        try:
            from . import importer
            smart = importer.smart_stream_name(raw_name, url=url, provider=(stream or {}).get("provider", ""))
            lid = logo_id(smart)
            if lid:
                bucket = "2x" if scale > 1.4 else ("wqhd" if scale >= 1.15 else ("hd" if scale < 0.85 else "1x"))
                return _find_cached(lid, bucket)
        except Exception:
            pass
    lid = logo_id(raw_name)
    if not lid and url:
        try:
            from . import importer
            smart = importer.smart_stream_name("", url=url, provider=(stream or {}).get("provider", ""))
            lid = logo_id(smart)
        except Exception:
            pass
    if not lid:
        return None
    bucket = "2x" if scale > 1.4 else ("wqhd" if scale >= 1.15 else ("hd" if scale < 0.85 else "1x"))
    return _find_cached(lid, bucket)
