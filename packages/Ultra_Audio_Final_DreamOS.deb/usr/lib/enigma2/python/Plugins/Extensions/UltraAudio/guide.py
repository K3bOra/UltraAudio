# -*- coding: utf-8 -*-
"""Official now-on-TV guides, fetched off the GUI thread and cached in RAM.

Only explicit channel families and established numbered provider aliases match.
All event times are UTC epochs; local time is applied only when drawing the UI.
No audio/controller/Enigma objects are touched by the guide workers.
"""
from __future__ import division
import calendar
from contextlib import closing
import datetime
from email.utils import parsedate_tz, mktime_tz
import json
import os
import re
import tempfile
import threading
import time
import unicodedata

from .compat import (HTMLParser, HTTPError, Request, fullmatch, lru_cache, makedirs, monotonic,
                     open_text, queue, replace, start_thread, string_types, to_text, urlencode, urlopen_verified,
                     user_input_idle, yield_to_ui)
from .sportfilter import category_hint

REFRESH = 20 * 60
BEIN_REFRESH = 10 * 60
_CACHE_BYTES = 4 * 1024 * 1024
RETRY = 5 * 60
INITIAL_RETRY = 15
MAX_AGE = 2 * 24 * 60 * 60
MAX_BYTES = 12 * 1024 * 1024
_HEADERS = {"User-Agent": "Mozilla/5.0", "Accept": "application/json,text/html", "Cache-Control": "no-cache"}
with open_text(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "epg", "bein_channels.json")) as _f:
    _BEIN_IDS = json.load(_f)
_BY_BEIN_ID = dict((to_text(v).upper(), str(k)) for k, v in _BEIN_IDS.items())
with open_text(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "epg", "bein_files.json")) as _f:
    _BEIN_FILES = json.load(_f)
_MBC_IDS = {'400921': 'mbcaction', '387290': 'mbcmasr1', '387293': 'mbcmasr2'}
_DIGITS = dict((ord(a), ord(b)) for a, b in zip(u"٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", u"01234567890123456789"))


class GuideClock(object):
    """Guide-only time from the official source's HTTP headers.

    A receiver booted at the Unix epoch otherwise requests 1970 schedules and
    rejects every present-day event. Never set the receiver/DVB/audio clock.
    Synchronization and all network I/O run only in a guide worker.
    """
    def __init__(self):
        self._lock = threading.Lock()
        self._probe_lock = threading.Lock()
        self._anchor = None
        self._next_probe = 0
        self.error = ""

    @staticmethod
    def plausible(value):
        return 1704067200 <= value < 4102444800  # 2024 through 2099

    def now(self):
        anchor = self._anchor
        return anchor[0] + max(0, monotonic() - anchor[1]) if anchor else time.time()

    def observe(self, headers):
        try:
            parsed = parsedate_tz(headers.get("Date", ""))
            if parsed is None:
                return False
            age = float(headers.get("Age", "0"))
            if not 0 <= age <= 86400:
                return False
            stamp = float(mktime_tz(parsed)) + age
            if not self.plausible(stamp):
                return False
        except (ValueError, TypeError, OverflowError, AttributeError):
            return False
        with self._lock:
            first = self._anchor is None
            if not first:
                previous = self._anchor[0] + max(0, monotonic() - self._anchor[1])
                if abs(stamp - previous) > 300:
                    return False  # a stale provider cache must not move every channel's clock
            self._anchor = (stamp, monotonic())
            self.error = ""
        if first and abs(stamp - time.time()) > 300:
            try:
                from .engine import log
                log("guide clock: receiver=%s source=%s; using source time for EPG only" % (
                    time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(time.time())),
                    time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(stamp))))
            except Exception:
                pass
        return True

    def synchronize(self):
        with self._probe_lock:
            with self._lock:
                anchored = self._anchor is not None
            if not anchored and monotonic() >= self._next_probe:
                self._next_probe = monotonic() + INITIAL_RETRY
                try:
                    req = Request("https://www.bein.com/en/tv-guide/", headers=_HEADERS)
                    with closing(urlopen_verified(req, timeout=6)) as response:
                        if not self.observe(response.headers):
                            raise ValueError("official guide response has no usable Date header")
                except Exception as exc:
                    self.error = "%s: %s" % (type(exc).__name__, to_text(exc)[:160])
            current = self.now()
            if not self.plausible(current):
                raise ValueError("receiver date/time is unset; guide time unavailable: " + self.error)
            return current

    def diagnostics(self):
        return {"receiver_epoch": time.time(), "guide_epoch": self.now(),
                "source": "official_http_date" if self._anchor is not None else "receiver",
                "receiver_clock_valid": self.plausible(time.time()), "error": self.error}


_CLOCK = GuideClock()
guide_now = _CLOCK.now
now = guide_now


def clock_unavailable():
    return not _CLOCK.plausible(now())


@lru_cache(maxsize=2048)
def channel_key(name):
    s = unicodedata.normalize("NFKC", to_text(name)).lower().translate(_DIGITS)
    s = re.sub(u"[\u064b-\u065f\u0670\u0640]", u"", s)
    s = s.replace(u"أ", u"ا").replace(u"إ", u"ا").replace(u"آ", u"ا")
    s = re.sub(u"[^a-z0-9\u0621-\u064a]+", u" ", s).strip()
    # An explicit family is required unless this is an established provider.
    provider = re.match(u"^(sat\\s*family|satfamilly|sarfamily|sf4k|orange|best|fox\\s*fm|anis|انيس|سات\\s*فاميلي)\\b", s)
    if provider:
        s = s[provider.end():].strip()
    explicit = bool(re.search(u"(?<![a-z])bein(?:\\s*sports?)?|بي\\s*ان", s))
    s = re.sub(u"(?<![a-z])bein(?:\\s*sports?)?|بي\\s*ان", u" ", s)
    s = re.sub(u"\\b(4k|uhd|fhd|hd|sd|low|middle|delay|vip|audio|commentary|tv|ip|sports?|bs)\\b", u" ", s) if provider else s
    # Satellite names commonly place HD before the number ("SPORTS HD 1"),
    # unlike provider aliases. Strip only known quality/Arabic qualifiers,
    # preserving 4K and EN/FR because those identify different beIN channels.
    s = re.sub(u"(?<![a-z0-9])(?:uhd|fhd|hd|sd)(?=[0-9]|\\b)", u" ", s)
    s = re.sub(u"\\b(?:480|576|720|1080|2160|4320)[pi]\\b", u" ", s)
    s = re.sub(u"\\b(?:ar|arabic)\\b|(?<![ء-ي])(?:عربي|العربية)(?![ء-ي])", u" ", s)
    compact = re.sub(u"\\s+", u"", s)
    family = fullmatch(u'(?:abudhabi|ad|ابوظبي)(?:sports?|الرياضية|سبورت)?([1-6])?(?:hd|sd|fhd)?', compact)
    if family:
        return str('abudhabi' + str(family.group(1) or '1'))
    family = fullmatch(u'(?:shahid|شاهد)(?:sports?|الرياضية|سبورت)?([1-8])(?:hd|sd|fhd)?', compact)
    if family:
        return str('shahid' + str(family.group(1)))
    family = fullmatch(u'(?:shasha|shashah|شاشا|شاشه|شاشة)(?:sports?|الرياضية|سبورت)?([12])?(?:hd|sd|fhd)?', compact)
    if family:
        return str('shasha' + str(family.group(1) or '1'))
    family = fullmatch(u'(?:alrabiaa|alrabia|rabiaa|الرابعة|الرابعه)(?:sports?|الرياضية|سبورت)?([12])?(?:hd|sd|fhd)?', compact)
    if family:
        return str('alrabiaa' + str(family.group(1) or '1'))
    # MBC Action is a distinct channel, not every Bundesliga or action feed.
    if fullmatch(u"(?:mbcaction|mbcاكشن|امبيسياكشن)(?:hd|sd|fhd)?", compact):
        return "mbcaction"
    m = fullmatch(u'(?:mbcmasr|mbcmisr|mbcمصر|امبيسيمصر|مبسمصر)([12])?(?:hd|sd|fhd)?', compact)
    if m:
        return str('mbcmasr' + str(m.group(1) or '1'))
    m = fullmatch(u'(?:thmanyah|thamanyah|ثمانية|ثمانيه)([1-3])?(?:hd|sd|fhd)?', compact)
    if m:
        return str('thmanyah' + str(m.group(1) or '1'))
    kass_words = {u'one': '1', u'two': '2', u'three': '3', u'four': '4', u'five': '5', u'six': '6', u'seven': '7', u'eight': '8',
                  u'الاولى': '1', u'الثانية': '2', u'الثالثة': '3', u'الرابعة': '4', u'الخامسة': '5', u'السادسة': '6', u'السابعة': '7', u'الثامنة': '8'}
    m = fullmatch(u'(?:alkass|alkaas|alkas|الكاس)(one|two|three|four|five|six|seven|eight|الاولى|الثانية|الثالثة|الرابعة|الخامسة|السادسة|السابعة|الثامنة)(?:hd|sd|fhd)?', compact)
    if m:
        return str('alkass' + kass_words[m.group(1)])
    m = fullmatch(u"(?:alkass|alkaas|alkas|الكاس)(?:sports?|الرياضية)?([1-8])(?:hd|sd|fhd)?", compact)
    if m:
        return str("alkass" + str(m.group(1)))
    if not (explicit or provider):
        return ""
    # Keep 4K distinct when explicitly named as a beIN channel; a provider's
    # quality tag (SatFamily-4K-1) was removed above and means Sports 1.
    compact = re.sub(u"sports?|الرياضية|سبورتس?", u"", compact)
    compact = re.sub(u"^([12])(en|english|fr|french)$", u"\\2\\1", compact)
    compact = re.sub(u"(?:fhd|uhd|hd|sd)$", u"", compact)
    if explicit and compact == u"4k":
        return "bein4k"
    if compact in (u"news", u"اخبار", u"الاخبارية"):
        return "beinnews"
    if explicit and not compact:
        return "beinfree"
    m = fullmatch(u'(?:max|ماكس)([1-6])(?:ar|arabic|en|english|fr|french|عربي|انجليزي|فرنسي)?', compact)
    if m:
        return str('beinmax' + str(m.group(1)))
    m = fullmatch(u"(xtra|extra|اكسترا|max|ماكس|en|english|انجليزي|fr|french|فرنسي)?([1-9])", compact)
    if m:
        family = {u"extra": "xtra", u"اكسترا": "xtra", u"ماكس": "max", u"english": "en", u"انجليزي": "en",
                  u"french": "fr", u"فرنسي": "fr"}.get(m.group(1), m.group(1)) or ""
        key = str("bein" + str(family) + str(m.group(2)))
        return key if key in _BEIN_IDS else ""
    return ""


def utc_epoch(value):
    """ISO 8601 with an explicit zone, including offsets, on Python 2.7 and 3.x."""
    m = fullmatch(r"(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)(?:\.(\d+))?(Z|[+-]\d\d:\d\d)", to_text(value or ""))
    if not m:
        raise ValueError("EPG timestamp has no explicit timezone")
    vals = [int(x) for x in m.groups()[:6]]
    dt = datetime.datetime(*vals)  # validate calendar values before timegm
    result = calendar.timegm(dt.timetuple())
    fraction = float("0." + str(m.group(7))) if m.group(7) else 0.0
    zone = m.group(8)
    if zone != "Z":
        hours, minutes = int(zone[1:3]), int(zone[4:6])
        if hours > 23 or minutes > 59:
            raise ValueError("invalid EPG timezone")
        result -= (1 if zone[0] == "+" else -1) * (hours * 3600 + minutes * 60)
    return result + fraction


def _clean(value):
    return re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]", " ", to_text(value or ""))).strip()[:500]


def _add(events, key, title, arabic, start, end, live=None, category=""):
    title, arabic = _clean(title), _clean(arabic)
    if key and (title or arabic) and 0 < end - start <= 24 * 3600:
        row = (title, arabic, start, end, live)
        hint = category_hint(category)
        events.setdefault(key, []).append(row + (hint,) if hint else row)


def _sorted(events):
    return dict((key, tuple(sorted(set(values), key=lambda e: (e[2], e[3], e[0])))) for key, values in events.items())


def parse_bein(data):
    events = {}
    rows = data.get("rows")
    if not isinstance(rows, list) or data.get("count", len(rows)) > len(rows):
        raise ValueError("incomplete beIN guide")
    for idx_r, row in enumerate(rows):
        if (idx_r & 31) == 31:
            yield_to_ui()
        try:
            key = _BY_BEIN_ID.get(to_text(row.get("channelId", "")).upper())
            details = row.get("data") or {}
            titles = details.get("Title") or {}
            start, end = utc_epoch(row["startDate"]), utc_epoch(row["endDate"])
            raw_live = row.get("live")
            if not isinstance(raw_live, bool):
                dlive = str(details.get("Live", "")).strip().lower()
                raw_live = True if dlive in ("true", "1") else (False if dlive in ("false", "0") else None)
            _add(events, key, titles.get("English") or row.get("title"), titles.get("Arabic"), start, end, raw_live, details.get("Category") or row.get("category"))
        except (KeyError, ValueError, TypeError, AttributeError, OverflowError):
            continue
    return _sorted(events)


def parse_mbc(data, language):
    events = {}
    if not isinstance(data.get("items"), list):
        raise ValueError("invalid Shahid guide")
    for channel in data["items"]:
        key = _MBC_IDS.get(str(channel.get("channelId")))
        if not key:
            continue
        for row in channel.get("items", []):
            try:
                if row.get("emptySlot"):
                    continue
                start, end = utc_epoch(row["actualFrom"]), utc_epoch(row["actualTo"])
                _add(events, key, row.get("title"), row.get("title") if language == "ar" else "", start, end)
            except (KeyError, ValueError, TypeError, OverflowError):
                continue
    return _sorted(events)


def parse_bein_file(data, key):
    """beIN TV-guide JSON uses explicit Qatar wall clocks, not UTC strings."""
    rows = data.get('responseObj')
    if not isinstance(rows, list) or key not in _BEIN_FILES['channels']:
        raise ValueError('invalid official beIN channel file')
    expected = _BEIN_FILES['channels'][key]
    events = {}
    for idx_r, row in enumerate(rows):
        if (idx_r & 31) == 31:
            yield_to_ui()
        try:
            if str(row.get('StaticChannelCode')) != expected:
                continue
            start = utc_epoch(to_text(row['StartTime']) + '+03:00')
            end = utc_epoch(to_text(row['EndTime']) + '+03:00')
            titles = row.get('Title') or {}
            live = str(row.get('Live', '')).strip().lower()
            _add(events, key, titles.get('English'), titles.get('Arabic'), start, end,
                 True if live in ('true', '1') else False if live in ('false', '0') else None, row.get('Category'))
        except (KeyError, TypeError, ValueError, AttributeError, OverflowError):
            continue
    return _sorted(events)


def fetch_bein_files(keys, now, publish=None):
    """At most three off-GUI workers; fixed official host, bounded work/bytes."""
    wanted = sorted(set(keys) & set(_BEIN_FILES['channels']))
    if not wanted:
        return {}
    day = time.strftime('%Y-%m-%d', time.gmtime(now + 3 * 3600))
    jobs, results = queue.Queue(), queue.Queue()
    for key in wanted:
        jobs.put((key, 0))
    deadline = monotonic() + 96

    def worker():
        while monotonic() < deadline:
            yield_to_ui()
            try:
                key, attempt = jobs.get_nowait()
            except queue.Empty:
                return
            try:
                remaining = max(1, deadline - monotonic())
                url = str(_BEIN_FILES['base']) + day + '/' + str(_BEIN_FILES['channels'][key]) + '.json'
                body, unused = _get(url, timeout=min(8, remaining), deadline=remaining, cacheable=True, max_bytes=1024 * 1024)
                yield_to_ui()
                part = parse_bein_file(json.loads(body), key)
                if not part.get(key):
                    raise ValueError('official channel file has no usable programs')
                results.put(part)
            except Exception as exc:
                _note_error("bein", exc)
                if attempt == 0 and monotonic() + 1 < deadline:
                    jobs.put((key, 1))
                else:
                    results.put({})
    workers = [start_thread(worker, name='UltraAudioGuide-CDN') for unused in range(min(2, len(wanted)))]
    events = {}
    pending_pub = {}
    last_pub = monotonic()
    for unused in wanted:
        remaining = deadline - monotonic()
        if remaining <= 0:
            break
        try:
            part = results.get(timeout=remaining)
            events.update(part)
            if part and publish is not None:
                pending_pub.update(part)
                now_m = monotonic()
                if now_m - last_pub >= 1.5 and user_input_idle(0.55):
                    publish(dict(pending_pub))
                    pending_pub.clear()
                    last_pub = now_m
        except queue.Empty:
            break
    if pending_pub and publish is not None:
        yield_to_ui()
        publish(dict(pending_pub))
    return events


class _AlkassHTML(HTMLParser):
    """Read the desktop rows with their explicit start/end clocks only."""
    def __init__(self):
        try:
            HTMLParser.__init__(self, convert_charrefs=True)
        except TypeError:
            HTMLParser.__init__(self)
        self.depth = 0
        self.row = None
        self.rows = []
        self.program = None
        self.span = False
        self.logos = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "img":
            m = re.search(r"/(one|two|three|four|five|six|seven|eight)\.png$", a.get("src", ""))
            if m:
                self.logos.append(m.group(1))
        if tag == "div":
            if "schalkass" in a.get("class", "").split() and not self.depth:
                self.depth = 1
            elif self.depth:
                self.depth += 1
                if self.row is not None and set(a.get("class", "").split()) & {"programs", "programsactive"}:
                    self.program = {"depth": self.depth, "title": [], "time": []}
        if not self.depth:
            return
        if tag == "table" and "margin-right:10px" in a.get("style", "").replace(" ", ""):
            self.row = len(self.rows)
            self.rows.append([])
        if tag == "span" and self.program is not None:
            self.span = True

    def handle_endtag(self, tag):
        if not self.depth:
            return
        if tag == "span":
            self.span = False
        if tag == "div":
            if self.program is not None and self.program["depth"] == self.depth:
                self.rows[self.row].append((_clean(" ".join(self.program["title"])), _clean(" ".join(self.program["time"]))))
                self.program = None
            self.depth -= 1
        if tag == "table":
            self.row = None

    def handle_data(self, text):
        if self.program is not None:
            self.program["time" if self.span else "title"].append(to_text(text))


def parse_alkass(html, day):
    parser = _AlkassHTML()
    parser.feed(to_text(html))
    expected = ["one", "two", "three", "four", "five", "six", "seven", "eight"]
    if parser.logos != expected or len(parser.rows) != 9:
        raise ValueError("unrecognized Al Kass channel layout")
    midnight = calendar.timegm(day.timetuple()) - 3 * 3600  # Qatar: UTC+03:00
    events = {}
    for index, rows in enumerate(parser.rows[:8], 1):
        for title, clock in rows:
            m = fullmatch(r"([0-2]\d):([0-5]\d)\s*-\s*([0-2]\d):([0-5]\d)", clock)
            if not m:
                continue
            h1, m1, h2, m2 = [int(x) for x in m.groups()]
            if h1 > 23 or h2 > 23:
                continue
            start = midnight + (h1 * 60 + m1) * 60
            end = midnight + (h2 * 60 + m2) * 60
            if end <= start:
                end += 86400
            _add(events, "alkass" + str(index), title, "", start, end)
    return _sorted(events)


def _get(url, timeout=12, deadline=30, cacheable=False, max_bytes=MAX_BYTES):
    started = monotonic()
    headers = dict(_HEADERS)
    if cacheable:
        headers.pop("Cache-Control", None)
    try:
        response = urlopen_verified(Request(url, headers=headers), timeout=timeout)
    except HTTPError as error:
        _CLOCK.observe(error.headers)
        error.close()
        raise
    with closing(response):
        _CLOCK.observe(response.headers)
        chunks, total = [], 0
        while True:
            if monotonic() - started > deadline:
                raise ValueError("guide download deadline exceeded")
            chunk = response.read(65536)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise ValueError("guide response too large")
            chunks.append(chunk)
        return b"".join(chunks).decode("utf-8-sig"), response.headers


_last_errors = {}


def _note_error(provider, exc):
    """Keep why a source failed, so 'no usable events' in the log says what went wrong (TLS, HTTP, parsing...)."""
    _last_errors[provider] = "%s: %s" % (type(exc).__name__, to_text(exc)[:160])


def _iso(epoch):
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(epoch))


def fetch_bein_now(wanted, now):
    if not wanted:
        return {}
    pairs = [("searchKey", ""), ("startBefore", _iso(now + 45 * 60)),
             ("endAfter", _iso(now - 10 * 60)), ("limit", "400")]
    pairs += [("channelIds", _BEIN_IDS[key]) for key in wanted]
    body, unused = _get("https://www.beinsports.com/api/opta/tv-event?" + urlencode(pairs),
                        timeout=6, deadline=10, cacheable=True)
    return dict((key, rows) for key, rows in parse_bein(json.loads(body)).items() if key in wanted)


def fetch(provider, now, keys=None, publish=None):
    if provider == "bein":
        wanted = sorted(set(keys) & set(_BEIN_IDS)) if keys is not None else sorted(_BEIN_IDS)
        if not wanted:
            return {}
        try:
            current = fetch_bein_now(wanted, now)
        except Exception as exc:
            _note_error("bein", exc)
            current = {}
        if current and publish is not None:
            publish(current)

        def full_rows(part):
            result = dict(part)
            for key, rows in part.items():
                cur_rows = current.get(key) or ()
                if not any(e[2] <= now < e[3] for e in rows) and cur_rows:
                    result[key] = _merge_events(rows, cur_rows, now)
                elif cur_rows:
                    live_slots = set((e[2], e[3]) for e in cur_rows if len(e) > 4 and e[4] is True)
                    if live_slots:
                        result[key] = tuple(
                            (e[0], e[1], e[2], e[3], True if (e[2], e[3]) in live_slots else e[4]) + e[5:]
                            for e in rows
                        )
            return result

        def publish_full(part):
            if publish is not None:
                publish(full_rows(part))
        events = full_rows(fetch_bein_files(wanted, now, publish_full))
        for key in wanted:
            if key not in events and current.get(key):
                events[key] = current[key]
        return events
    if provider.startswith("mbc_"):
        language = provider[-2:]
        day = int(now // 86400) * 86400
        params = [("csvChannelIds", ','.join(sorted(_MBC_IDS))), ("from", _iso(day)), ("to", _iso(day + 2 * 86400)),
                  ("country", "SA"), ("language", language), ("Accept-Language", language)]
        body, _headers = _get("https://api2.shahid.net/proxy/v2.1/shahid-epg-api/?" + urlencode(params))
        return parse_mbc(json.loads(body), language)
    if provider == "alkass":
        try:
            body, headers = _get("https://www.alkass.net/tvguide")
            stamp = parsedate_tz(headers.get("Date", ""))
            if stamp is None:
                raise ValueError("Al Kass response has no date")
            server_now = mktime_tz(stamp)
            age = max(0, int(headers.get("Age", "0")))
            if abs(server_now - now) > 6 * 3600 or age > 1800:
                raise ValueError("Al Kass response is stale")
            day = datetime.datetime.utcfromtimestamp(server_now + 3 * 3600).date()
            events = parse_alkass(body, day)
        except Exception as exc:
            _note_error("alkass", exc)
            events = {}
        wanted = set(keys or ('alkass' + str(i) for i in range(1, 9)))
        missing = [key for key in wanted if not any(e[2] <= now < e[3] for e in events.get(key, ()))]
        events.update(fetch_bein_files(missing, now))
        return events
    raise ValueError("unknown guide provider")


def _provider(key, language):
    if key.startswith("bein"):
        return "bein"
    if key.startswith("alkass"):
        return "alkass"
    return "mbc_" + ("ar" if language == "ar" else "en") if key in _MBC_IDS.values() else ""


def _merge_events(previous, incoming, now):
    if not incoming:
        return previous
    prev_live = set((e[2], e[3]) for e in previous if len(e) > 4 and e[4] is True)
    prev_categories = dict((e[:4], e[5:6]) for e in previous if len(e) > 5)
    patched = [
        (e[0], e[1], e[2], e[3], True if (e[2], e[3]) in prev_live else e[4])
        + (e[5:6] or prev_categories.get(e[:4], ()))
        for e in incoming
    ]
    first, last = min(e[2] for e in patched), max(e[3] for e in patched)
    keep = [e for e in previous if (e[3] <= first or e[2] >= last)
            and e[3] > now - 86400 and e[2] < now + 3 * 86400]
    return tuple(sorted(set(keep + patched), key=lambda e: (e[2], e[3], e[0])))


class Guide(object):
    def __init__(self, cache_path=None):
        self._lock = threading.Lock()
        self._cache_lock = threading.Lock()
        self._states = {}
        self._receiver = {}
        self._rev = 0
        self._view_cache = {}
        self._cache_path = cache_path or os.path.join(
            os.environ.get("ULTRAAUDIO_DATA", "/etc/enigma2/ultraaudio"), "guide-cache.json")
        self._load_cache()

    def _bump_rev(self):
        self._rev += 1
        self._view_cache.clear()

    @staticmethod
    def _empty_state():
        return {"events": {}, "busy": False, "next": 0, "updated": None,
                "channel_updated": {}, "covered": {}, "wanted": set(),
                "failures": 0, "error": "", "day": None}

    def _load_cache(self):
        try:
            with open(self._cache_path, "rb") as handle:
                raw = handle.read(_CACHE_BYTES + 1)
            if len(raw) > _CACHE_BYTES:
                return
            data = json.loads(raw.decode("utf-8"))
            if data.get("version") == 1 and isinstance(data.get("channels"), dict):
                providers = {'bein': data['channels']}
            elif data.get("version") == 2 and isinstance(data.get("providers"), dict):
                providers = data['providers']
            else:
                return
            wall, tick = guide_now(), monotonic()
            for provider, channels in providers.items():
                if provider not in ('bein', 'alkass', 'mbc_ar', 'mbc_en') or not isinstance(channels, dict):
                    continue
                state = self._empty_state()
                for key, channel in channels.items():
                    key = str(key)
                    if _provider(key, provider[-2:]) != provider or not isinstance(channel, dict):
                        continue
                    age = wall - float(channel.get("updated", 0))
                    if not 0 <= age <= MAX_AGE:
                        continue
                    events = {}
                    for row in channel.get("events", [])[:500]:
                        try:
                            title, arabic, start, end, live = row[:5]
                            category = row[5] if len(row) > 5 else ""
                            if not isinstance(title, string_types) or not isinstance(arabic, string_types):
                                continue
                            if not wall - 86400 < end < wall + 4 * 86400:
                                continue
                            _add(events, key, title, arabic, float(start), float(end), live if isinstance(live, bool) else None, category)
                        except (ValueError, TypeError, OverflowError):
                            continue
                    if events.get(key):
                        state["events"][key] = _sorted(events)[key]
                        state["channel_updated"][key] = tick - age
                        state["covered"][key] = tick - age
                if state["events"]:
                    state["updated"] = max(state["channel_updated"].values())
                    state["next"] = state["updated"] + (BEIN_REFRESH if provider == 'bein' else REFRESH)
                    self._states[str(provider)] = state
                    self._bump_rev()
        except (EnvironmentError, ValueError, TypeError, AttributeError, OverflowError):
            pass

    def _save_cache(self):
        with self._cache_lock:
            self._write_cache()

    def _write_cache(self):
        with self._lock:
            wall, tick = guide_now(), monotonic()
            providers = {}
            for provider, state in self._states.items():
                channels = {}
                for key, rows in state["events"].items():
                    stamp = state["channel_updated"].get(key)
                    if stamp is None or not 0 <= tick - stamp <= MAX_AGE:
                        continue
                    keep = [row for row in rows if wall - 86400 < row[3] < wall + 4 * 86400]
                    if keep:
                        channels[key] = {"updated": wall - (tick - stamp), "events": keep}
                if channels:
                    providers[provider] = channels
        raw = json.dumps({"version": 2, "providers": providers}, ensure_ascii=True).encode("utf-8")
        if len(raw) > _CACHE_BYTES:
            return
        temp = None
        try:
            folder = os.path.dirname(self._cache_path)
            makedirs(folder)
            fd, temp = tempfile.mkstemp(prefix=".guide-", dir=folder)
            with os.fdopen(fd, "wb") as handle:
                handle.write(raw)
            replace(temp, self._cache_path)
            temp = None
        except EnvironmentError:
            pass
        finally:
            if temp:
                try:
                    os.unlink(temp)
                except EnvironmentError:
                    pass

    def ensure(self, streams, language):
        groups = {}
        for stream in streams:
            key = channel_key(to_text(stream.get("name", "")))
            provider = _provider(key, language)
            if provider:
                groups.setdefault(provider, set()).add(key)
        for provider, keys in groups.items():
            with self._lock:
                state = self._states.setdefault(provider, self._empty_state())
                state.setdefault("wanted", set()).update(keys)
                tick, wall = monotonic(), guide_now()
                missing = provider == "bein" and any(key not in state.get("covered", {}) for key in keys)
                missing = missing or (tick >= state.get('retry_missing', 0) and
                                      any(not any(e[2] <= wall < e[3] for e in state['events'].get(key, ())) for key in keys))
                day = int((wall + 3 * 3600) // 86400) if provider in ("bein", "alkass") else None
                waiting = tick < state["next"] and (state.get("failures", 0) > 0 or not missing)
                if state["busy"] or (waiting and (day is None or day == state["day"])):
                    continue
                state["busy"] = True
                state["day"] = day
            try:
                start_thread(self._work, (provider,), "UltraAudioGuide-" + provider)
            except Exception:
                with self._lock:
                    state["busy"], state["next"] = False, monotonic() + INITIAL_RETRY
                    state["failures"] = max(1, state.get("failures", 0))

    def _work(self, provider):
        with self._lock:
            requested = set(self._states[provider].get("wanted", ()))
        try:
            request_time = _CLOCK.synchronize()
            if provider == 'bein':
                saved_initial = [False]

                def publish(part):
                    self._accept_events(provider, part)
                    if not saved_initial[0]:
                        self._save_cache()
                        saved_initial[0] = True
                events = fetch(provider, request_time, requested, publish=publish)
            else:
                events = fetch(provider, request_time, requested)
            now = guide_now()
            events = dict((key, tuple(e for e in values if now - 86400 < e[3] and e[2] < now + 3 * 86400))
                          for key, values in events.items())
            events = dict((key, values) for key, values in events.items() if values)
            if not events:
                why = _last_errors.pop("bein" if provider == "alkass" and "bein" in _last_errors else provider, "")
                raise ValueError("guide returned no usable events" + (" (%s)" % why if why else ""))
            _last_errors.pop(provider, None)
            success, error = True, ""
        except Exception as exc:
            events, success = {}, False
            error = "%s: %s" % (type(exc).__name__, to_text(exc)[:200])
        with self._lock:
            state = self._states[provider]
            if success:
                stamp = monotonic()
                channel_updated = state.setdefault("channel_updated", {})
                for key in state["events"]:
                    channel_updated.setdefault(key, state["updated"])
                for key, rows in events.items():
                    state['events'][key] = _merge_events(state['events'].get(key, ()), rows, now)
                channel_updated.update((key, stamp) for key in events)
                state["updated"], state["failures"], state["error"] = stamp, 0, ""
                self._bump_rev()
                partial = any(not any(e[2] <= now < e[3] for e in state['events'].get(key, ())) for key in requested)
                state['retry_missing'] = stamp + (60 if partial else INITIAL_RETRY)
                if provider == "bein":
                    state.setdefault("covered", {}).update((key, stamp) for key in requested)
                delay = BEIN_REFRESH if provider == "bein" else REFRESH
            else:
                state["failures"] = min(state.get("failures", 0) + 1, 6)
                state["error"] = error
                delay = min(RETRY, INITIAL_RETRY * 2 ** (state["failures"] - 1))
            state["busy"] = False
            state["next"] = monotonic() + delay
        if success:
            self._save_cache()
        if not success:
            try:
                from .engine import log
                log("guide %s: %s; retry in %ds" % (provider, error, delay))
            except Exception:
                pass

    def _accept_events(self, provider, events):
        now, stamp = guide_now(), monotonic()
        with self._lock:
            state = self._states[provider]
            for key, rows in events.items():
                rows = tuple(e for e in rows if e[3] > now - 86400 and e[2] < now + 3 * 86400)
                if not rows:
                    continue
                state['events'][key] = _merge_events(state['events'].get(key, ()), rows, now)
                state['channel_updated'][key] = stamp
                state['updated'] = stamp
            self._bump_rev()

    def diagnostics(self):
        with self._lock:
            return dict((provider, {"busy": s["busy"], "channels": len(s["events"]), "requested": len(s.get("wanted", ())),
                                    "error": s.get("error", ""),
                                    "retry_in_s": max(0, int(s["next"] - monotonic()))})
                        for provider, s in self._states.items())

    def receiver_snapshot(self, events):
        new_rec = dict((key, tuple(rows)) for key, rows in events.items())
        with self._lock:
            if new_rec != self._receiver:
                self._receiver = new_rec
                self._bump_rev()

    def view(self, stream, language, now=None):
        key = channel_key(to_text(stream.get("name", "")))
        if not key:
            return "", None, False
        use_cache = now is None
        now = guide_now() if now is None else now
        if use_cache:
            c_key = (key, language, self._rev, int(now // 30))
            cached = self._view_cache.get(c_key)
            if cached is not None:
                return cached
        provider = _provider(key, language)
        with self._lock:
            state = self._states.get(provider)
            state = state or self._empty_state()
            updated = state.get("channel_updated", {}).get(key, state["updated"])
            age = monotonic() - updated if updated is not None else MAX_AGE + 1
            values = state["events"].get(key, ()) if 0 <= age <= MAX_AGE else ()
            pending = bool(state["busy"] and not any(e[2] <= now < e[3] for e in values))
            fallback = self._receiver.get(key, ())
        active = [e for e in values if e[2] <= now < e[3]]
        titles = set((e[1] if language == "ar" and e[1] else e[0] or e[1]) for e in active)
        if len(titles) != 1:
            active = [e for e in fallback if e[2] <= now < e[3]]
        if not active and not provider:
            res = ("", None, False)
        else:
            titles = set((e[1] if language == "ar" and e[1] else e[0] or e[1]) for e in active)
            if len(titles) != 1:
                res = (key, None, pending)
            else:
                event = max(active, key=lambda e: e[2])
                title = event[1] if language == "ar" and event[1] else event[0] or event[1]
                res = (key, (title, event[2], event[3], event[4], event[0], event[1]) + event[5:6], False)
        if use_cache:
            if len(self._view_cache) > 512:
                self._view_cache.clear()
            self._view_cache[c_key] = res
        return res


_GUIDE = Guide()
ensure = _GUIDE.ensure
view = _GUIDE.view
diagnostics = _GUIDE.diagnostics
revision = lambda: _GUIDE._rev


def warm_up():
    """Begin the common beIN feeds off the GUI thread; cache makes reopens instant."""
    def work():
        try:
            from . import store
            streams = store.list_streams()
            wanted = [s for s in streams if channel_key(to_text(s.get("name", ""))).startswith("bein")]
            if wanted:
                all_bein = [{'name': 'beIN SPORTS' if key == 'beinfree' else key} for key in _BEIN_IDS]
                _GUIDE.ensure(all_bein, "en")
        except Exception:
            pass
    start_thread(work, name="UltraAudioGuide-prefetch")
