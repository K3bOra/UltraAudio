# -*- coding: utf-8 -*-
"""Compact update card on the existing UltraAudio screen."""
from __future__ import division
import os
from xml.sax.saxutils import escape

from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ScrollLabel import ScrollLabel

from .compat import native, skin_scale_attr, ui_pixmap_path
from .i18n import T
from . import store, themes
from .uifont import face as ui_face

UI = os.path.join(store.ASSETS, 'ui')
X, Y, WIDTH, HEIGHT = 660, 334, 640, 400
NAMES = ('u_glow', 'u_panel', 'u_wave', 'u_brand', 'u_title', 'u_version', 'u_notes',
         'u_green', 'u_update', 'u_red', 'u_back', 'u_progress')


# Text colours per theme: Classic keeps its own; Neon's sit on neutral smoked glass next to a vivid rim.
COLORS = {'classic': {'version': '#00DA7F', 'notes': '#E2EAE6', 'bar': '#00DA7F', 'track': '#13251D'},
          'neon': {'version': '#00DA7F', 'notes': '#E6ECEA', 'bar': '#00DA7F', 'track': '#1A2121'},
          'smoke': {'version': '#28E8FF', 'notes': '#E4EEF7', 'bar': '#28E8FF', 'track': '#142234'},
          'titanium': {'version': '#68BEFF', 'notes': '#E6F0FA', 'bar': '#68BEFF', 'track': '#162436'}}


def skin_parts(k, th=None):
    th = th or themes.get('classic')
    col = COLORS.get(th['key'], COLORS['classic'])
    scale_attr = skin_scale_attr()     # DreamOS has no skin 'scale' attribute: pre-sized pictures instead

    def n(v):
        return max(1, int(round(v * k)))

    def box(x, y, w, h):
        return 'position="%d,%d" size="%d,%d"' % tuple(int(round(v * k)) for v in (x, y, w, h))

    def picture(name, filename, x, y, w, h):
        pw, ph = n(w), n(h)
        resolved = ui_pixmap_path(themes.pic(th, filename), pw, ph)
        return ('<widget name="%s" %s pixmap="%s" alphatest="blend"%s transparent="1" zPosition="40"/>') % (
            name, box(x, y, w, h), escape(resolved, {'"': '&quot;'}), scale_attr)

    def label(name, x, y, w, h, size, color='#FFFFFF', align='left', wrap=False):
        nowrap_attr = '' if wrap else ' noWrap="1"'
        return ('<widget name="%s" %s font="Regular;%d" foregroundColor="%s" halign="%s" valign="center" '
                'transparent="1"%s zPosition="42"/>') % (
            name, box(x, y, w, h), n(size), color, align, nowrap_attr)

    g = themes.NEON_GLOW
    if th.get('update_glow'):       # Neon: soft light around the card, under everything
        glow = picture('u_glow', th['update_glow'], X - g, Y - g, WIDTH + 2 * g, HEIGHT + 2 * g).replace(
            'zPosition="40"', 'zPosition="0"')
    else:
        glow = '<widget name="u_glow" %s transparent="1" zPosition="0"/>' % box(X, Y, 1, 1)
    return '\n'.join([
        glow,
        picture('u_panel', 'update_panel.png', X, Y, WIDTH, HEIGHT),
        picture('u_wave', 'playing.png', X + 28, Y + 22, 38, 38),
        picture('u_brand', 'brand.png', X + 78, Y + 26, 180, 32),
        label('u_title', X + 306, Y + 20, 306, 44, 27, align='right'),
        label('u_version', X + 24, Y + 76, WIDTH - 48, 36, 22, col['version'], 'center', True),
        # ScrollLabel wraps across the whole content width and retains every line.
        # no scrollbarMode on the ScrollLabel: DreamOS 2.5 aborts on it
        '<widget name="u_notes" %s font="Regular;%d" foregroundColor="%s" '
        'transparent="1" zPosition="42"/>' % (
            box(X + 28, Y + 126, WIDTH - 56, 174), n(20), col['notes']),
        '<widget name="u_progress" %s backgroundColor="%s" foregroundColor="%s" '
        'borderWidth="0" zPosition="43"/>' % (box(X + 28, Y + 310, WIDTH - 56, 8), col['track'], col['bar']),
        picture('u_green', 'key_green.png', X + 114, Y + 339, 56, 42),
        label('u_update', X + 174, Y + 340, 150, 40, 22),
        picture('u_red', 'key_red.png', X + 386, Y + 339, 56, 42),
        label('u_back', X + 446, Y + 340, 164, 40, 22),
    ]).replace('font="Regular;', 'font="%s;' % ui_face())


class UpdateOverlay(object):
    def __init__(self, screen, install, th=None):
        self.screen = screen
        self.install = install
        self.is_open = False
        self.phase = None
        self.meta = None
        self.return_to_library = False
        for name in ('u_glow', 'u_panel', 'u_wave', 'u_brand', 'u_green', 'u_red'):
            screen[name] = Pixmap()
        for name in ('u_title', 'u_version', 'u_update', 'u_back'):
            screen[name] = Label(native(''))
        screen['u_notes'] = ScrollLabel(native(''))
        screen['u_progress'] = ProgressBar()
        screen['u_progress'].setValue(0)

    def bind(self):
        self._notes_above_panel()
        self._visible(False)

    def _notes_above_panel(self):
        # ScrollLabel skins can apply zPosition to the inner text only. Its
        # outer eWidget must also sit above our panel on OpenPLi/OpenBH images.
        try:
            instance = getattr(self.screen['u_notes'], 'instance', None)
            if instance is not None:
                instance.setZPosition(42)
        except Exception:
            pass

    def _visible(self, visible):
        for name in NAMES:
            try:
                self.screen[name].show() if visible else self.screen[name].hide()
            except Exception:
                pass

    def show(self, phase, version='', notes='', meta=None):
        self.phase, self.meta = phase, meta
        self.is_open = True
        self.screen['u_title'].setText(native(T('Online Update')))
        self.screen['u_version'].setText(native(version))
        self.screen['u_notes'].setText(native(notes))
        self.screen['u_update'].setText(native(T('Update') if phase == 'ready' else ''))
        self.screen['u_back'].setText(native(T('Back') if phase != 'installing' else T('Please wait...')))
        self._visible(True)
        self._notes_above_panel()
        if phase not in ('installing', 'complete'):
            self.screen['u_progress'].hide()
        if phase != 'ready':
            self.screen['u_green'].hide()
        if phase == 'installing':
            self.screen['u_red'].hide()
        self.paint_keys()

    def progress(self, percent, stage, elapsed):
        if not self.is_open or self.phase != 'installing':
            return
        percent = max(0, min(100, int(percent)))
        downloading = stage in ('Downloading update...', 'Download complete.')
        self.screen['u_version'].setText(native(T('Downloading: %d%%', percent) if downloading else T('Installing update...')))
        self.screen['u_notes'].setText(native(T(stage) + '\n\n' + T('Elapsed: %d s', elapsed)))
        self.screen['u_progress'].setValue(percent)
        self.screen['u_progress'].show() if downloading else self.screen['u_progress'].hide()
        self._notes_above_panel()

    def close(self):
        if self.phase == 'installing':
            return
        self.is_open = False
        self.phase, self.meta = None, None
        self._visible(False)
        if self.return_to_library:
            self.return_to_library = False
            self.screen.menu.close()
            return
        self.screen.menu.paint_keys()

    def confirm(self):
        if self.phase != 'ready' or self.meta is None:
            return
        # Switch state before dispatch: repeated OK/GREEN cannot install twice.
        self.show('installing', T('Downloading and verifying update...'),
                  T('The package will be checked before installation. Please wait for completion.'))
        self.screen['u_progress'].setValue(0)
        self.install(True)

    def scroll(self, direction):
        try:
            self.screen['u_notes'].pageDown() if direction > 0 else self.screen['u_notes'].pageUp()
        except Exception:
            pass

    def paint_keys(self):
        self.screen._text('kred', T('Back') if self.phase != 'installing' else '')
        self.screen._text('kgreen', T('Update') if self.phase == 'ready' else '')
        self.screen._text('kyellow', '')
        self.screen._text('kblue', '')
        self.screen._text('kok', T('UP / DOWN: scroll details'))
        self.screen.audio_keys(False)
