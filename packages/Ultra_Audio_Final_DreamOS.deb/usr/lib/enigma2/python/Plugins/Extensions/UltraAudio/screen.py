# -*- coding: utf-8 -*-
"""On-box screen: slim top bar, list of folders / audio links on the left (flush between the bars), slim key bar at the
bottom. The rest is transparent so the TV picture stays visible.

The Classic theme is the available layout."""
from __future__ import division
import os
import time

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eTimer, getDesktop, gFont

try:
    from enigma import BT_ALIGN_CENTER, BT_KEEP_ASPECT_RATIO, BT_SCALE
    _PIX_FLAGS = BT_SCALE | BT_KEEP_ASPECT_RATIO | BT_ALIGN_CENTER
    _PIX_STRETCH = BT_SCALE
except ImportError:  # old images / DreamOS
    _PIX_FLAGS = 0
    _PIX_STRETCH = 0

from . import ctl, guide, store, themes, webui, receivertime
from . import uifont
from .motion import PlaybackMarker, visible_row
from .compat import (connect_timer, lru_cache, mc_pixmap, native, skin_scale_attr,
                     string_types, to_text, ui_pixmap_path)
from .i18n import T, lang
from .menu import MenuOverlay, skin_parts as menu_skin

UI = os.path.join(store.ASSETS, "ui")
MINT, GOLD, RED, MUTED, TEXT, WHITE = "#00DA7F", "#FFE29A", "#FF5E66", "#D1DDD7", "#FFFFFF", "#FFFFFF"
_STATE_COLORS = {"playing": MINT, "starting": GOLD, "retrying": GOLD, "stopping": GOLD, "error": RED, "idle": WHITE}
# Same bar + key dashes as the plugin's footer: a 1840x64 bar whose PNG has 1 transparent row top and bottom, so the
# top bar at y=1 and the bottom bar at y=1015 leave exactly 2 px free at the screen edges.
TOP_X, TOP_Y, BAR_W, BAR_H = 40, 1, 1840, 64
DOCK_Y = 1015
LIST_Y, LIST_W = TOP_Y + BAR_H - 1, 600
# TV channel name in the top bar (centred); the live equalizer sits midway between the folder path and it
HSTATE_X, HSTATE_W = 990, 370
EQ_W, EQ_H, EQ_GAP, CRUMB_X = 96, 40, 14, 330
CRUMB_W = HSTATE_X - CRUMB_X - EQ_W - 2 * EQ_GAP
LIST_H = (DOCK_Y + 1) - LIST_Y                 # rounded PNG insets leave a subpixel seam beside each bar
ROW_W, ROW_H, ROWS = LIST_W - 24, 104, 9       # big 160x88 icons: 9 rows fill the panel
ICON_W, ICON_H = 160, 88
_pix_cache = {}
AUDIO_SETTLE = 0.25         # a short rest after the last 4 / 6 press, then the new audio delay is applied (live)
PICTURE_SETTLE = 0.85        # 1 / 3 add up the same way: the picture moves once, after the presses rest


def state_label(state):
    """Status word of the top bar, in capitals (Arabic has no capitals)."""
    return {"idle": lambda: T("Idle"), "starting": lambda: T("Starting"), "playing": lambda: T("Playing"),
            "retrying": lambda: T("Reconnecting"), "stopping": lambda: T("Stopping"),
            "error": lambda: T("Error")}.get(state, lambda: str(state))().upper()
_last_cwd = ""
_resume_menu = None          # the MENU row to open again after the screen reopened itself (theme / language change)
_resume_cwd = None           # Preserve navigation only for an internal UI/font rebuild.
_resume_selection = None     # folder cursor positions, consumed by the replacement screen only


def active_stream_location():
    """Return the actually playing audio folder and stream, not just the last visited folder.

    Never persist stale UI navigation as the current stream; a closed audio player
    must open at the Library root. Avoid restoring a deleted/moved channel.
    """
    try:
        st = ctl.get().engine.status()
        if st.get("state") not in ("playing", "starting", "retrying"):
            return None
        sid = st.get("stream_id")
        s = store.get_stream(sid) if sid else None
        if not s:
            return None
        fid = s.get("folder", "") or ""
        if fid and not store.get_folder(fid):
            fid = ""
        return fid, sid
    except Exception:
        return None


def _pixmap(path, w=None, h=None):
    # DreamOS cannot scale pixmaps: pick the pre-sized twin of a bundled picture for (w, h).
    resolved = ui_pixmap_path(path, w, h) if (w and h and path) else path
    if resolved and resolved.startswith(store.ASSETS + os.sep):
        return _bundled_pixmap(resolved)
    try:
        key = (resolved, os.path.getmtime(resolved))
    except EnvironmentError:
        return None
    if key not in _pix_cache:
        _pix_cache[key] = LoadPixmap(native(resolved))
    return _pix_cache[key]


def _frame_path(path, w, h):
    """Numbered animation / progress frames: <dir>/<w>x<h>/<name> holds the copy drawn 1:1 at that size (720p skins on
    DreamOS, which cannot scale). ui_pixmap_path cannot be used here: it strips the frame number from the name."""
    folder, name = os.path.split(path)
    tw, th = max(1, int(w)), max(1, int(h))
    sized = os.path.join(folder, "%dx%d" % (tw, th), name)
    if os.path.isfile(sized):
        return sized
    if tw < 200:
        hd_sized = os.path.join(folder, "165x9", name)
        if os.path.isfile(hd_sized):
            return hd_sized
    return path


@lru_cache(maxsize=512)
def _bundled_pixmap(path):
    # Package artwork is immutable until GUI restart; no stat per row.
    return LoadPixmap(native(path))


def _playing_key(pixels):
    name = "identity_%d.png" % pixels
    return name if os.path.isfile(os.path.join(UI, name)) else "identity.png"


def _number_key(key, pixels):
    """Use a prefiltered ring at the actual widget size, avoiding receiver PNG scaling artifacts."""
    name = "num_%s_%d.png" % (key, pixels)
    return name if os.path.isfile(os.path.join(UI, name)) else "num_%s.png" % key


KEY_TWIN_S = 0.6          # another GREEN / RED ... within this time (make + repeat) is the same press
PROGRESS_STEPS = 32
# The logo's own saturated green (0x00DA7F) holds for the first half of the match, then turns through amber and
# orange into the logo's red (0xEF041D), mixed in OKLCH at full chroma (a plain mix goes muddy, a hue sweep from the
# start goes rainbow). Indexed by the position along the WHOLE track.
PROGRESS_RAMP = (0x00DA7F,) * 17 + (0x06DA79, 0x1CD866, 0x22D62F, 0x6CCB14, 0x8FBD09, 0xA4B000, 0xB2A313, 0xBC9703,
                                    0xC38B11, 0xCA7D00, 0xD16F07, 0xD95E00, 0xE14B06, 0xEC2C00, 0xF00B13, 0xEF041D)


def _progress_tone(t):
    t = max(0.0, min(1.0, t))
    return PROGRESS_RAMP[int(round(t * (len(PROGRESS_RAMP) - 1)))]


LASER_BG = 0x1E2A26       # the list panel behind the line: the laser's halo fades towards it


def _mix(a, b, t):
    """Mix two 0xRRGGBB colours (t = 0 -> a, 1 -> b)."""
    return sum(int(round(((a >> sh) & 255) + (((b >> sh) & 255) - ((a >> sh) & 255)) * t)) << sh for sh in (16, 8, 0))


def build_skin(k, th=None):
    """Skin in FHD design coordinates, multiplied by k for other desktop sizes.

    Layout: slim top bar 2px from the top edge, slim key bar 2px from the bottom edge, and the list panel filling
    everything between them on the left (flush with both bars). The rest of the screen stays transparent so the
    TV picture shows through."""
    th = th or themes.get("classic")

    def n(v):
        return int(round(v * k))

    scale_attr = skin_scale_attr()     # ' scale="1"' only where the skin parser has it (not on DreamOS)

    def box(x, y, w, h):
        return 'position="%d,%d" size="%d,%d"' % (n(x), n(y), max(1, n(w)), max(1, n(h)))

    def pix(name, x, y, w, h, z=1):
        # the theme's own picture when it has one (Neon), else the Classic one; pre-sized where the skin cannot scale
        resolved = ui_pixmap_path(themes.pic(th, name), max(1, n(w)), max(1, n(h)))
        return '<ePixmap %s pixmap="%s" alphatest="blend"%s zPosition="%d"/>' % (box(x, y, w, h), resolved, scale_attr, z)

    def lab(name, x, y, w, h, size, color=TEXT, align="left", z=3):
        return ('<widget name="%s" %s font="Regular;%d" foregroundColor="%s" halign="%s" valign="center" '
                'transparent="1" noWrap="1" zPosition="%d"/>' % (name, box(x, y, w, h), max(1, n(size)), color, align, z))

    parts = ['<screen name="UltraAudioScreen" position="0,0" size="%d,%d" flags="wfNoBorder" backgroundColor="transparent">'
             % (n(1920), n(1080))]
    # Fixed identity | breadcrumb / message | receiver TV channel | audio | clock.
    # Neon: soft light around the bars and the list, drawn under them (static pictures, nothing animated)
    parts += [pix(name, x, y, w, h, 0) for name, x, y, w, h in th.get("glows", ())]
    parts += [pix("bar.png", TOP_X, TOP_Y, BAR_W, BAR_H),
              pix(_playing_key(n(44)), 66, TOP_Y + 10, 44, 44, 2),
              pix("brand.png", 120, TOP_Y + 16, 180, 32, 2),
              lab("crumb", CRUMB_X, TOP_Y + 12, CRUMB_W, 42, 20, WHITE),
              lab("hstate", HSTATE_X, TOP_Y + 12, HSTATE_W, 42, 22, WHITE, "center"),
              lab("hname", 1380, TOP_Y + 12, 320, 42, 20, WHITE, "right"),
              lab("clock", 1720, TOP_Y + 12, 134, 42, 20, WHITE, "right")]
    # No itemHeight attribute on the list: DreamOS skin.py rejects it; setItemHeight() is called in __init__.
    # Rounded panel and focus have genuinely transparent corners. The native
    # list selection is disabled in start(), so it cannot paint a square under
    # our moving rounded frame. The list itself remains transparent.
    cm = th.get("cursor_margin", 0)      # Neon: the cursor picture carries a halo this many px around the row
    parts += [pix("panel_list.png", TOP_X, LIST_Y, LIST_W, LIST_H),
              '<widget name="list" %s foregroundColor="#FFFFFF" foregroundColorSelected="#FFFFFF" scrollbarMode="showNever" transparent="1" '
              'zPosition="3"/>' % box(TOP_X + 12, LIST_Y + 10, ROW_W, ROW_H * ROWS),
              # Classic's ring is hollow and sits over the row; Neon's cursor is a solid glass piece, so it goes
              # under the (transparent) list and the row's picon and text are drawn on top of it
              '<widget name="selbar" %s pixmap="%s" alphatest="blend"%s zPosition="%d"/>'
              % (box(TOP_X + 12 - cm, LIST_Y + 10 - cm, ROW_W + 2 * cm, ROW_H + 2 * cm),
                 ui_pixmap_path(themes.pic(th, "select.png"), max(1, n(ROW_W + 2 * cm)), max(1, n(ROW_H + 2 * cm))),
                 scale_attr, 2 if th.get("cursor_under") else 4)]
    # live equalizer (mint and coral bars, as on the web page) sits in the top bar midway between the folder path
    # and the TV channel's name, so it never covers a row's guide or progress bar; see _place_marker
    parts.append('<widget name="playmark" %s alphatest="blend"%s transparent="1" zPosition="5"/>'
                 % (box(HSTATE_X + HSTATE_W // 2 - EQ_W - EQ_GAP, TOP_Y + 12, EQ_W, EQ_H), scale_attr))
    # bottom bar, laid out like the plugin's footer: hint left, four key dashes with their word, numbers right
    parts += [pix("bar.png", TOP_X, DOCK_Y, BAR_W, BAR_H)]
    ky = DOCK_Y + 11
    # keys right after the page info; the whole right side shows the picture / audio delays (with their number keys)
    for key, x, name, w in (("red", 330, "kred", 110), ("green", 500, "kgreen", 120), ("yellow", 680, "kyellow", 190),
                            ("blue", 930, "kblue", 170)):
        if key in ("yellow", "blue"):      # the audio keys only show while a commentary plays (see audio_keys)
            k_resolved = ui_pixmap_path(os.path.join(UI, "key_%s.png" % key), max(1, n(56)), max(1, n(42)))
            parts.append('<widget name="kdash_%s" %s pixmap="%s" alphatest="blend"%s transparent="1" zPosition="25"/>'
                         % (key, box(x, ky, 56, 42), k_resolved, scale_attr))
        else:
            parts.append(pix("key_%s.png" % key, x, ky, 56, 42, 25))
        parts.append(lab(name, x + 58, ky, w, 42, 20, "#ffffff", "left", 26))
    parts += [lab("kok", 66, ky, 255, 42, 20, WHITE, "left", 26),
              ]
    # Static ring keys flank the current values. Step amounts remain in MENU;
    # the footer keeps only the useful current picture/audio delay readouts.
    for x0, keys, cap, val in ((1176, ("1", "3"), "pcap", "pv"),
                                (1530, ("4", "6"), "acap", "pva")):
        parts += [pix(_number_key(keys[0], n(48)), x0 + 8, DOCK_Y + 6, 48, 48, 25),
                  lab(cap, x0 + 64, DOCK_Y + 2, 190, 22, 15, th["pal"]["muted"], "center", 26),
                  lab(val, x0 + 64, DOCK_Y + 23, 190, 38, 27, WHITE, "center", 26),
                  pix(_number_key(keys[1], n(48)), x0 + 262, DOCK_Y + 6, 48, 48, 25)]
    parts.append(menu_skin(k, th))    # the MENU card (hidden until MENU is pressed)
    parts.append("</screen>")
    return "\n".join(parts).replace('font="Regular;', 'font="%s;' % themes.face("UltraAudioUI"))


class UltraAudioScreen(Screen):
    def createSummary(self):
        from .frontpanel import UltraAudioFrontSummary
        return UltraAudioFrontSummary

    def __init__(self, session, ip="RECEIVER-IP"):
        global _resume_selection, _resume_cwd
        self.k = max(0.5, getDesktop(0).size().width() / 1920.0)
        self.th = themes.get()
        self.pal = self.th["pal"]
        self.grid = self.th["mode"] != "list"          # stadium / daylight: we keep the cursor ourselves
        self.cols = self.th.get("cols", 1)
        self.per_page = self.cols * self.th.get("rows", 1) if self.grid else ROWS
        self._lang = lang()            # Stadium / Daylight pick their fonts by language: reopen when it changes
        self._font = uifont.selected()
        self.skin = native(build_skin(self.k, self.th))
        Screen.__init__(self, session)
        try:
            self.setTitle(native("UltraAudio"))
        except Exception:
            pass
        self.ip = ip
        active = active_stream_location()
        # When no audio is playing, always reopen at Library root.
        # With active audio, navigate directly to that exact stream, regardless
        # of where the user previously browsed before closing the screen.
        resuming = _resume_cwd is not None
        self.cwd = (_resume_cwd if not _resume_cwd or store.get_folder(_resume_cwd) else "") if resuming else (active[0] if active else "")
        self._sel = dict(_resume_selection or {}) if resuming or active else {}
        if active and not resuming:
            folders, streams = store.children(self.cwd)
            for i, s in enumerate(streams):
                if s["id"] == active[1]:
                    self._sel[self.cwd] = len(folders) + i
                    break
        _resume_selection = None
        _resume_cwd = None
        self._colors = {}
        self._texts = {}
        self._shown = None
        self._library_shown = None
        self._view_shown = None
        self._crumb = u""
        self.entries = []              # the folder's items: dicts with payload, icon, title, sub, playing
        self._guide_streams = []
        self._guide_shown = ()
        self._minute_shown = None
        self.gidx = 0                  # stadium / daylight: index of the focused item
        self._page_shown = None
        self._state_colors = {"playing": self.pal["accent"], "starting": self.pal["warn"], "retrying": self.pal["warn"],
                              "stopping": self.pal["warn"], "error": self.pal["error"], "idle": self.pal["idle"]}
        self["list"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        if self.grid:
            faces = self.th["faces"]
            for i, (role, size) in enumerate(self.th["cell_fonts"]):
                self["list"].l.setFont(i, gFont(native(themes.face(faces[role])), int(size * self.k)))
            self["list"].l.setItemHeight(int(self.th["pitch"][1] * self.k))
        else:
            # Match the settings names: same Regular face, size and pure white.
            ui_f = native(themes.face("UltraAudioUI"))
            self["list"].l.setFont(0, gFont(ui_f, int(24 * self.k)))
            self["list"].l.setFont(1, gFont(ui_f, int(17 * self.k)))
            self["list"].l.setFont(2, gFont(ui_f, int(15 * self.k)))
            self["list"].l.setItemHeight(int(ROW_H * self.k))
        for name in ("crumb", "clock", "hname", "hstate", "pv", "pva", "pcap", "acap", "kred", "kgreen", "kyellow", "kblue", "kok") + tuple(self.th["extra"]):
            self[name] = Label(native(""))
        self["selbar"] = Pixmap()
        self["playmark"] = Pixmap()
        self._marker = None
        self._marker_visible = True
        self._bar_at = None
        self["kdash_yellow"] = Pixmap()
        self["kdash_blue"] = Pixmap()
        if not self.grid:
            try:
                self["list"].onSelectionChanged.append(self.page_info)
                self["list"].onSelectionChanged.append(self.place_bar)
            except Exception:
                pass
        self.menu = MenuOverlay(self, ip)
        self.apply_language()
        self._key_at = {}
        self["actions"] = ActionMap(
            # Not "ShortcutActions": on many images it maps the colour keys again on key RELEASE, so one GREEN press froze the picture
            # and the release un-froze it (the official plugin, and the web page, never had this).
            ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions"],
            {"ok": self.key_ok, "menu": self.menu.toggle, "cancel": self.key_cancel, "red": self._once("red", self.key_red),
             "green": self._once("green", self.key_green), "0": self.key_pic_reset, "1": lambda: self.key_pic(-1), "3": lambda: self.key_pic(1),
             "4": lambda: self.key_audio(-1), "6": lambda: self.key_audio(1), "blue": self._once("blue", self.key_audio_reset),
            "yellow": self._once("yellow", self.key_pic_reset),
             "left": lambda: self.key_side(-1), "right": lambda: self.key_side(1),
             "up": lambda: self.key_vert(-1), "down": lambda: self.key_vert(1)}, -2)
        # CH+ / CH-: while the MENU card is open they flip its pages; otherwise they are not ours (returning 0 passes
        # them on, so they keep flipping the channel list as before)
        self["chactions"] = ActionMap(["ChannelSelectBaseActions"],
                                      {"nextBouquet": lambda: self.key_ch(-1), "prevBouquet": lambda: self.key_ch(1)}, -2)
        self._timer_connections = []
        self.timer = self._timer(self.refresh)
        self._audio_pending = None            # audio delay (ms) chosen with 4 / 6, applied once the keys rest
        self._audio_target = None
        self.audio_timer = self._timer(self.apply_audio)
        self._pic_busy_until = 0.0            # the delays show green while a change is being applied
        self._aud_busy_until = 0.0
        self._pic_pending = None              # picture delay (s) chosen with 1 / 3, applied once the keys rest
        self._pic_target = None
        self.pic_timer = self._timer(self.apply_pic)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._stop_timers)
        self.onClose.append(self._remember)
        for attr, fn in (("onShow", self._marker_show), ("onHide", self._marker_hide),
                         ("onExecBegin", self._marker_show), ("onExecEnd", self._marker_hide)):
            if hasattr(self, attr):          # not every list exists on every image (DreamOS)
                getattr(self, attr).append(fn)

    def _once(self, name, handler):
        """Run a colour key once per press: a held key repeats, and a toggle (GREEN) must not flip back. Every copy
        restarts the quiet time, and so does the end of the handler (starting timeshift can take a while)."""
        def run():
            now = time.time()
            last = self._key_at.get(name, 0.0)
            self._key_at[name] = now
            if 0.0 <= now - last < KEY_TWIN_S:
                return
            try:
                handler()
            finally:
                self._key_at[name] = time.time()
        return run

    def _timer(self, callback):
        timer = eTimer()
        # Retain the connection: DreamOS disconnects when it is collected.
        connect_timer(timer, callback, self._timer_connections)
        return timer

    def _stop_timers(self):
        self._marker_visible = False
        if self._marker is not None:
            self._marker.close()
        self.timer.stop()
        self.audio_timer.stop()
        self.pic_timer.stop()
        # EXIT / a language reopen may happen before the debounce timers fire.
        # Apply only this playback's final values; never carry a pending edit to another stream.
        c = ctl.get()
        st = c.engine.status()
        current_sid = st["stream_id"]
        secs, self._pic_pending = self._pic_pending, None
        picture, self._pic_target = self._pic_target, None
        ms, self._audio_pending = self._audio_pending, None
        audio, self._audio_target = self._audio_target, None
        if secs is not None and picture and picture[0] == current_sid:
            c.set_video_delay(secs, picture[0])
        if ms is not None and audio and audio[0] == current_sid:
            c.set_audio_delay(ms, audio[0])
        self._timer_connections = []

    def apply_language(self):
        """Static texts in the chosen language (also called again when the menu changed the language)."""
        self._text("kred", T("Stop"))
        self._text("kgreen", T("Freeze"))
        self._text("kyellow", T("Reset picture"))
        self._text("kblue", T("Reset audio"))
        self._shown_page = None
        self.page_info()

    def reopen(self, menu_row=None):
        """Close and open the screen again (its skin is built when it opens): plugin.main reopens on "reopen"."""
        global _resume_menu, _resume_selection, _resume_cwd
        self._save_index()
        _resume_selection = dict(self._sel)
        _resume_cwd = self.cwd
        _resume_menu = menu_row
        self.close("reopen")

    # ------------------------------------------------------------ cursor (classic: the listbox's; the others: ours)
    def _count(self):
        return len(self.entries)

    def _index(self):
        total = len(self.entries)
        if not total:
            return 0
        i = self.gidx if self.grid else (self["list"].getSelectionIndex() or 0)
        return max(0, min(total - 1, i))

    def _cursor_native(self):
        """Keep a usable selection if the custom PNG/widget cannot be drawn."""
        self._custom_cursor = False
        self["selbar"].hide()
        try:
            instance = self["list"].instance
            if instance is not None:
                instance.setSelectionEnable(1)
        except Exception:
            pass

    def _configure_cursor(self):
        self._bar_at = None
        try:
            cm = self.th.get("cursor_margin", 0)
            w = max(1, int(round((ROW_W + 2 * cm) * self.k)))
            h = max(1, int(round((ROW_H + 2 * cm) * self.k)))
            path = ui_pixmap_path(themes.pic(self.th, "select.png"), w, h)
            pixmap = _bundled_pixmap(path) if path else None
            frame, listing = self["selbar"].instance, self["list"].instance
            if pixmap is None or frame is None or listing is None:
                return self._cursor_native()
            frame.setPixmap(pixmap)
            listing.setSelectionEnable(0)
            self._custom_cursor = True
        except Exception:
            self._cursor_native()

    def _goto(self, i):
        if self.grid:
            self.gidx = i
            self._render_page()
            self.page_info()
            self.place_bar()
        else:
            self["list"].moveToIndex(i)
            self.page_info()
            self.place_bar()

    def _entry_row(self, i, focused=False):
        e = self.entries[i]
        separator = i + 1 < len(self.entries) and (i + 1) % ROWS != 0
        if focused and self.th.get("cursor_under"):
            separator = False                     # the glass cursor has its own lower edge: no line across it
        return self._row(e["payload"], e["icon"], e["title"], e["sub"], e["playing"],
                         separator=separator, event=e.get("event"), focused=focused)

    def _relight(self, idx):
        """Update just the old/new focused row without changing the native index."""
        old = getattr(self, "_lit", None)
        rows = getattr(self, "_rows", None)
        if (getattr(self, "_relighting", False) or self.grid or rows is None or old == idx
                or not self.th.get("cursor_under") and self.pal["title_dim"] == self.pal["text"]
                and self.pal["accent_hi"] == self.pal["accent"] and self.pal["muted_hi"] == self.pal["muted"]):
            self._lit = idx
            return
        self._lit = idx
        lst = self["list"]
        changed = []
        for i, on in ((old, False), (idx, True)):
            if i is None or not 0 <= i < len(rows) or i >= len(self.entries):
                continue
            rows[i] = self._entry_row(i, focused=on)
            changed.append(i)
        self._relighting = True
        try:
            try:
                for i in changed:
                    lst.l.invalidateEntry(i)
            except Exception:
                # Some DreamOS builds lack per-row invalidation. A full reset may
                # move the native index; restore it while callbacks are guarded.
                lst.l.setList(rows)
                lst.moveToIndex(idx)
        finally:
            self._relighting = False

    def place_bar(self):
        """Put the focus frame on the focused row / card (the list flips whole pages, so it is index % page)."""
        try:
            bar = self["selbar"]
            if getattr(self, "_relighting", False):
                return
            if not getattr(self, "_custom_cursor", True):
                return bar.hide()
            total = self._count()
            if not total:
                return bar.hide()
            bar.show()
            idx = self._index()
            if not self.grid:
                self._relight(idx)
            if self.grid:
                pos = idx % self.per_page
                col, row = pos % self.cols, pos // self.cols
                lx, ly = self.th["list"][:2]
                px, py = self.th["pitch"]
                sx, sy = self.th["selbar"][1:3]
                at = (int(round((lx + col * px + sx) * self.k)), int(round((ly + row * py + sy) * self.k)))
            else:
                cm = self.th.get("cursor_margin", 0)
                # Match setItemHeight(int(ROW_H*k)) exactly. Rounding the design
                # coordinate of every row drifts by up to three pixels at 720p.
                row = idx % ROWS
                listing = self["list"].instance
                get_top = getattr(listing, "getTopIndex", None)
                if callable(get_top):
                    try:
                        top = get_top()
                    except Exception:
                        top = None
                    if top is not None and 0 <= idx - top < ROWS:
                        row = idx - top
                at = (int(round((TOP_X + 12 - cm) * self.k)),
                      int(round((LIST_Y + 10) * self.k)) - int(round(cm * self.k))
                      + row * int(ROW_H * self.k))
            if at != self._bar_at and bar.instance is not None:
                from enigma import ePoint
                bar.instance.move(ePoint(*at))
                self._bar_at = at
        except Exception:
            self._cursor_native()
        finally:
            self._sync_marker()

    def _marker_show(self):
        self._marker_visible = True
        self._sync_marker()

    def _marker_hide(self):
        self._marker_visible = False
        if self._marker is not None:
            self._marker.stop()

    def _marker_move(self, row):
        pass        # its place follows the TV channel's name (see _place_marker), not a list row

    def _place_marker(self):
        """Centre the equalizer in the gap between the folder path (left) and the TV channel's name (centre).
        Only runs when one of those two texts changes."""
        crumb, name = self._texts.get("crumb") or "", self._texts.get("hstate") or ""
        if (crumb, name) == getattr(self, "_marker_for", None):
            return
        try:
            from enigma import ePoint
            k = self.k
            # calculateSize reports intrinsic text width, including text clipped
            # by the label. Long folder names must not push the marker off-screen.
            crumb_w = min(int(round(CRUMB_W * k)), self["crumb"].instance.calculateSize().width()) if crumb else 0
            name_w = min(int(round(HSTATE_W * k)), self["hstate"].instance.calculateSize().width()) if name else 0
            left = int(round(CRUMB_X * k)) + crumb_w
            centre = int(round((HSTATE_X + HSTATE_W / 2.0) * k))
            right = centre - name_w // 2
            eq = int(round(EQ_W * k))
            x = max(left + int(round(EQ_GAP * k)), (left + right - eq) // 2)
            self["playmark"].instance.move(ePoint(x, int(round((TOP_Y + 12) * k))))
            self._marker_for = (crumb, name)
        except Exception:
            pass

    def _start_marker(self):
        # Predecode the eight small equalizer frames (9 bars, 96x40) once; the skin scales them where it can,
        # and a 720p DreamOS skin gets the pre-sized copies.
        ew, eh = int(round(EQ_W * self.k)), int(round(EQ_H * self.k))
        frames = tuple(_bundled_pixmap(_frame_path(os.path.join(UI, 'eq_%d.png' % i), ew, eh)) for i in range(8))
        frames = frames if all(frame is not None for frame in frames) else ()
        still = _bundled_pixmap(_frame_path(os.path.join(UI, 'eq_idle.png'), ew, eh))
        engine = ctl.get().engine
        def playback_state():
            # Animation must never wait for the audio worker or build its full
            # diagnostics/status payload. Skip a frame while the worker is busy.
            if not engine.lock.acquire(False):
                return None
            try:
                stream = engine.stream
                return {'state': engine.state, 'stream_id': stream.get('id') if stream else None}
            finally:
                engine.lock.release()
        widget = self["playmark"]
        widget.hide()
        self._marker = PlaybackMarker(self._timer, frames, still, playback_state,
                                      widget.instance.setPixmap, self._marker_move, widget.show, widget.hide)

    def _sync_marker(self, state=None):
        if self._marker is None:
            return
        if not self._marker_visible:
            return self._marker.stop()
        state = ctl.get().engine.status() if state is None else state
        row = None if self.grid else (0 if state.get('stream_id') else None)   # one spot in the top bar
        self._marker.update(row, state.get('state'), state.get('stream_id'), self._marker_visible)

    def page_info(self):
        """Bottom-left: 'Page 2 / 5   43 files' of the folder on screen; follows the cursor."""
        total = self._count()
        if not total:
            return self._text("kok", "")
        idx = self._index()
        nf = getattr(self, "_folder_count", 0)
        ns = total - nf
        parts = [T("Page %d / %d", idx // self.per_page + 1, (total - 1) // self.per_page + 1)]
        if nf:
            parts.append(T("%d folders", nf))
        if ns:
            parts.append(T("%d files", ns))
        self._text("kok", u"   \u00b7   ".join(parts))

    def audio_keys(self, on):
        """Show picture/audio reset keys only while commentary plays and the menu is closed."""
        for name in ("kdash_blue", "kblue", "kdash_yellow", "kyellow"):
            try:
                self[name].show() if on else self[name].hide()
            except Exception:
                pass

    # While the MENU card is open the keys drive the card; otherwise they drive the list as before.
    def key_ok(self):
        self.menu.activate() if self.menu.is_open else self.ok()

    def key_cancel(self):
        self.menu.close() if self.menu.is_open else self.back()

    def key_red(self):
        self.menu.close() if self.menu.is_open else self.stop()

    def key_green(self):
        self.menu.activate() if self.menu.is_open else ctl.get().toggle_pause()

    def key_ch(self, d):
        if not self.menu.is_open:
            return 0
        self.menu.page(d)
        return 1

    def key_side(self, d):
        """LEFT / RIGHT: flip a page of the list (like the plugin); on the cards: the next / previous card. Inside the
        MENU card they change the value."""
        if self.menu.is_open:
            return self.menu.step(d)
        if self.grid:
            return self.move_by(d)
        self.page_shift(d)

    def key_pic(self, d):
        """1 / 3: each press moves the PENDING picture delay by one 'Picture step' (MENU); the picture moves once, when the
        keys rest for PICTURE_SETTLE seconds (the same way 4 / 6 work for the audio)."""
        if self.menu.is_open:
            return
        st = ctl.get().status()
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        ctl.get().video.suspend_monitor()
        target = (st["stream_id"],)
        if self._pic_target != target:
            self._pic_pending = None
        self._pic_target = target
        v = st["video"]
        if self._pic_pending is not None:
            base = self._pic_pending
        elif v["state"] in ("off", "error"):
            memo = store.recall_channel(ctl.get()._service_key())
            base = float(memo.get("video_s") or 0.0) if memo else 0.0
        elif v["state"] == "paused":
            base = v["current_s"] if v["current_s"] is not None else v["target_s"]
        else:
            # Always step from target_s when filling or running so key-frame jitter in current_s never swallows a press!
            base = v["target_s"] if v.get("target_s") is not None else (v["current_s"] or 0.0)
        step = float(store.get_settings()["step_video_s"])
        self._pic_pending = round(max(0.0, min(600.0, base + (step if d > 0 else -step))), 1)
        self.pic_timer.start(int(PICTURE_SETTLE * 1000), True)
        self.refresh()

    def key_pic_reset(self):
        """YELLOW / 0: return the picture to live without changing the commentary."""
        if self.menu.is_open:
            return
        st = ctl.get().engine.status()
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        self.pic_timer.stop()
        self._pic_pending, self._pic_target = None, None
        ctl.get().reset_picture(st["stream_id"], st.get("generation"))
        self._pic_busy_until = time.time() + 1.5
        self.refresh()

    def apply_pic(self):
        secs, self._pic_pending = self._pic_pending, None
        target, self._pic_target = self._pic_target, None
        c = ctl.get()
        st = c.engine.status()
        if secs is not None and target and target[0] == st["stream_id"]:
            c.set_video_delay(secs, target[0])
            self._pic_busy_until = time.time() + 2.0
        self.refresh()

    def key_vert(self, d):
        """UP / DOWN with a clean wrap: DOWN on the last item goes to the first, UP on the first goes to the last.
        Stadium (one strip of cards): a page of cards. Daylight (grid): the card above / below."""
        if self.menu.is_open:
            return self.menu.move(d)
        if self.th["mode"] == "row":
            return self.page_shift(d)
        if self.th["mode"] == "grid":
            return self.move_rows(d)
        total = len(self["list"].list or [])
        if total <= 0:
            return
        idx = self["list"].getSelectionIndex() or 0
        if d > 0 and idx >= total - 1:
            self["list"].moveToIndex(0)
        elif d < 0 and idx <= 0:
            self["list"].moveToIndex(total - 1)
        else:
            self["list"].down() if d > 0 else self["list"].up()
        # Do not rely solely on image-specific selectionChanged callbacks.
        self.page_info()
        self.place_bar()

    def move_by(self, d):
        """One card left / right, wrapping from the last card to the first and back."""
        total = self._count()
        if total:
            self._goto((self._index() + d) % total)

    def move_rows(self, d):
        """Grid: the card above / below. Below the last line it wraps to the first line (same column), above the first
        line to the last one; a column the last line does not have lands on its last card."""
        total = self._count()
        if not total:
            return
        cols = self.cols
        idx = self._index()
        col = idx % cols
        last_line = ((total - 1) // cols) * cols
        target = idx + d * cols
        if target > total - 1:
            target = col if idx >= last_line else total - 1
        elif target < 0:
            target = last_line + col
        self._goto(max(0, min(total - 1, target)))

    def page_shift(self, d):
        """Same row on the next / previous page; at the outer edge it lands on the first / last item (the plugin's paging rule)."""
        total = self._count()
        if total <= 0:
            return
        per = self.per_page
        idx = self._index()
        page, row = divmod(idx, per)
        last_page = (total - 1) // per
        if d < 0:
            target = (page - 1) * per + row if page > 0 else 0
        else:
            target = min(total - 1, (page + 1) * per + row) if page < last_page else total - 1
        self._goto(target)

    def menu_closed(self):
        self._shown = None            # rebuild after settings or library actions
        self.apply_language()
        self.refresh()

    def language_changed(self, menu_row=None):
        """True when the screen reopens for it (Stadium / Daylight pick their fonts by language when they open)."""
        if themes.uses_own_fonts(self.th):
            self.reopen(menu_row)
            return True
        self.apply_language()
        self._shown = None            # list rows are rebuilt on the next refresh, in the new language
        self.refresh()
        return False

    # ------------------------------------------------------------ list
    def start(self):
        global _resume_menu
        self.menu.bind()
        self._start_marker()
        # Disable the native selection only after the custom frame loaded.
        self._configure_cursor()
        self.fill()
        self.refresh()
        self.timer.start(1000, False)
        if _resume_menu is not None:
            row, _resume_menu = _resume_menu, None
            self.menu.idx = row
            self.menu.open()

    def _remember(self):
        global _last_cwd
        _last_cwd = self.cwd

    def _row(self, payload, icon, title, sub, playing=False, separator=True, event=None, focused=False):
        k = self.k
        n = lambda v: int(v * k)
        tw = n(382)                                 # the animated marker lives in the top bar now
        P = self.pal
        hexc = lambda key: int(P[key][1:], 16)
        # Normal rows: pure bright white channel name and the top-left icon's green for the guide line.
        # Playing row: channel name turns green and guide line turns the icon's deep red. Cursor focus keeps colours unchanged.
        accent = hexc("accent_hi" if focused else "row_accent")
        muted = hexc("muted_hi" if focused else "row_muted")
        title_color = accent if playing else (0xFFFFFF if focused else hexc("title_dim"))
        guide_color = hexc("live_hi" if focused else "live") if playing else accent
        custom = isinstance(icon, string_types) and not to_text(icon).startswith(to_text(store.ASSETS))   # a user's picture or a channel's picon: any size
        cells = [payload,
                 # built-in icons are 160x88: drawn 1:1 at FHD; a user's own picon can be any size
                 mc_pixmap(pos=(n(12), n(8)), size=(n(ICON_W), n(ICON_H)), png=_pixmap(icon, n(ICON_W), n(ICON_H)),
                           flags=_PIX_FLAGS if (custom or abs(k - 1.0) > 0.01) else 0),
                 ]
        cells += [
                 MultiContentEntryText(pos=(n(186), n(10 if event else 18 if sub else 34)), size=(tw, n(36)), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                       text=native(title), color=title_color, color_sel=title_color),
                 ]
        if event:
            cells.append(MultiContentEntryText(pos=(n(186), n(46)), size=(tw, n(24)), font=1,
                                               flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=native(event[0]),
                                               color=guide_color, color_sel=guide_color))
            clock = to_text(time.strftime("%H:%M", time.localtime(event[1]))) + u" \u2013 " + to_text(time.strftime("%H:%M", time.localtime(event[2])))
            cells.append(MultiContentEntryText(pos=(n(186), n(73)), size=(n(118), n(21)), font=2,
                                               flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=native(clock),
                                               color=muted, color_sel=muted))
            # How far the match has run, as on the web page: two plain filled rectangles (no picture, no timer of its
            # own); the list is rebuilt once a minute by the existing refresh, so the bar moves with the clock.
            span = max(1.0, float(event[2] - event[1]))
            done = max(0.02, min(1.0, (guide.now() - event[1]) / span))
            # One cached, pre-rendered rail per visible row. No runtime bitmap
            # generation, segment loops or extra timer; existing minute refresh.
            bx, bw = n(186) + n(124), max(n(40), tw - n(124) - n(10))
            state = max(0, min(64, int(round(done * 64))))
            cells.append(mc_pixmap(
                pos=(bx, n(76)), size=(bw, max(1, n(14))),
                # Neon's focused row: a polished rounded rail that sits well on the glass cursor
                png=_bundled_pixmap(_frame_path(
                    os.path.join(themes.NEON_DIR, "progress_sel", "p_%02d.png" % state)
                    if focused and self.th.get("cursor_under") else os.path.join(UI, "progress", "p_%02d.png" % state),
                    bw, max(1, n(14)))),
                flags=_PIX_STRETCH))
        elif sub:
            # Only when there IS a sub line: an empty text cell still paints the row's selection background over whatever lies
            # under it, and that was cutting the lower half of the one-line titles on the focused row.
            # Same rule as the guide line: red while this radio / channel is playing, green otherwise.
            sub_color = guide_color
            sub_color_sel = sub_color
            cells.append(MultiContentEntryText(pos=(n(186), n(56)), size=(tw, n(26)), font=1, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                               text=native(sub), color=sub_color, color_sel=sub_color_sel))
        if separator:
            sep_h = max(1, n(4))
            cells.append(mc_pixmap(pos=(n(186), n(ROW_H - 4)), size=(n(370), sep_h),
                                   png=_pixmap(themes.pic(self.th, "row_separator.png"), n(370), sep_h),
                                   flags=_PIX_STRETCH))
        return cells

    def _cell(self, e, x0):
        """Stadium / Daylight: the cells of one card, x0 = the card's left edge inside its row (design pixels)."""
        k = self.k
        n = lambda v: int(round(v * k))
        c = self.th["cell"]
        colors = self.th["cell_colors"]
        native_size = abs(k - 1.0) <= 0.01
        cells = []
        for part in ("tile", "well"):                # the card's own pictures, drawn 1:1 at FHD
            spec = c.get(part)
            if spec:
                fn, px, py, pw, ph = spec
                cells.append(mc_pixmap(pos=(n(x0 + px), n(py)), size=(n(pw), n(ph)), png=_pixmap(themes.pic(self.th, fn), n(pw), n(ph)),
                                       flags=0 if native_size else _PIX_FLAGS))
        ix, iy, iw, ih = c["icon"]
        bs = c.get("scale", 1.0)
        if bs != 1.0 and not _PIX_FLAGS:             # an old image cannot scale: the 160x88 icon 1:1 in the middle of its box
            ix, iy, iw, ih, bs = ix + (iw - ICON_W) / 2.0, iy + (ih - ICON_H) / 2.0, ICON_W, ICON_H, 1.0
        icon = e["icon"]
        custom = isinstance(icon, string_types) and not to_text(icon).startswith(to_text(store.ASSETS))
        scaled = custom or abs(k * bs - 1.0) > 0.01
        cells.append(mc_pixmap(pos=(n(x0 + ix), n(iy)), size=(n(iw), n(ih)), png=_pixmap(icon, n(iw), n(ih)),
                               flags=_PIX_FLAGS if scaled else 0))
        tx, ty, tw, tth = c["title"]
        cells.append(MultiContentEntryText(pos=(n(x0 + tx), n(ty)), size=(n(tw), n(tth)), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                           text=native(e["title"]), color=colors["title"], color_sel=colors["title"]))
        sub, color = (self.th.get("dot", u"\u25cf") + u" LIVE", colors["live"]) if e["playing"] else (e["sub"], colors["sub"])
        if sub:
            sx, sy, sw, sh = c["sub"]
            cells.append(MultiContentEntryText(pos=(n(x0 + sx), n(sy)), size=(n(sw), n(sh)), font=1, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                               text=native(sub), color=color, color_sel=color))
        return cells

    def _render_page(self):
        """Stadium / Daylight: the page holding the cursor, one listbox row per line of cards (only when the page changed)."""
        per = self.per_page
        page = self._index() // per
        if page == self._page_shown:
            return
        items = self.entries[page * per:(page + 1) * per]
        px = self.th["pitch"][0]
        rows = []
        for r in range(0, len(items), self.cols):
            cells = [("line", r)]
            for c, e in enumerate(items[r:r + self.cols]):
                cells += self._cell(e, c * px)
            rows.append(cells)
        self["list"].setList(rows)
        self._page_shown = page

    def fill(self):
        revision = store.library_revision()
        if self.cwd and store.get_folder(self.cwd) is None:
            self.cwd = ""
        folders, streams = store.children(self.cwd)
        language = lang()
        lib_snapshot = store._load()
        guide.ensure([s for s in streams if not store.is_radio_stream(s, lib_snapshot)], language)
        guide_rows = tuple((None, None, False) if store.is_radio_stream(s, lib_snapshot) else guide.view(s, language)
                           for s in streams)
        time_notice = receivertime.guide_notice()
        self._guide_streams = [s for s in streams if not store.is_radio_stream(s, lib_snapshot)]
        self._guide_shown = tuple(guide.view(s, language) for s in self._guide_streams)
        self._minute_shown = int(guide.now() // 60)
        st = ctl.get().engine.status()
        playing_id = st["stream_id"] if st["state"] != "idle" else None
        entries = []
        for f in folders:
            entries.append({"payload": ("folder", f), "icon": store.folder_icon(f, self.k, lib_snapshot), "title": store.display_folder_name(f, language),
                            "sub": T("%d channels", f["count"]), "playing": False})
        for s, (guide_key, event, loading) in zip(streams, guide_rows):
            title, duration = store.stream_display(s, lib_snapshot)
            sub = (T(u"Radio \u00b7 add direct stream URL in Web") if store.needs_radio_url(s)
                   else T("Internet radio") if store.is_radio_stream(s, lib_snapshot) else to_text(s.get("tag", "")).upper())
            if duration and not store.needs_radio_url(s):
                sub += u" \u00b7 " + to_text(duration)
            if guide_key and time_notice:
                sub, event = T(time_notice), None
            elif guide_key and event is None:
                sub = (T("Loading guide...") if loading else
                       T("Set receiver date/time") if guide.clock_unavailable() else T("Guide unavailable"))
            entries.append({"payload": ("stream", s), "icon": store.stream_icon(s, scale=self.k, lib=lib_snapshot), "title": title,
                            "sub": sub, "event": event, "playing": s["id"] == playing_id})
        if store.streams_first(self.cwd, lib_snapshot):
            entries = entries[len(folders):] + entries[:len(folders)]
        self.entries = entries
        self._folder_count = len(folders)
        idx = self._sel.get(self.cwd, 0)
        idx = idx if 0 <= idx < len(entries) else 0
        if self.grid:
            self.gidx = idx
            self._page_shown = None
            self._render_page()
        else:
            rows = [self._entry_row(i, focused=(i == idx)) for i in range(len(entries))]
            self._rows, self._lit = rows, idx
            self["list"].setList(rows)
            # always place the cursor, also on the first row: the listbox keeps its old index across setList(), so
            # entering the 3rd folder used to land on the 3rd row of the new list
            if rows and hasattr(self["list"], "moveToIndex"):
                self["list"].moveToIndex(idx)
        path = store.folder_path(self.cwd)
        self._crumb = u"  \u203a  ".join([to_text(T("Library"))] + [to_text(store.display_folder_name(p, language)) for p in path])
        self._text("crumb", self._crumb)
        self._color("crumb", self.pal["dim"] if self.grid else WHITE)
        if "ftitle" in self:
            where = store.display_folder_name(path[-1], language) if path else T("Library")
            count = T("%d channels", len(streams)) if streams or not folders else T("%d folders", len(folders))
            self._text("ftitle", u"%s   \u00b7   %s" % (to_text(where).upper(), to_text(count).upper()))
        self._shown = (self.cwd, playing_id)
        self._library_shown = revision
        self._view_shown = (language, time_notice)
        self.page_info()
        self.place_bar()

    def _current(self):
        if not self.entries:
            return None
        return self.entries[self._index()]["payload"]

    def _save_index(self):
        try:
            self._sel[self.cwd] = self._index()
        except Exception:
            pass

    def ok(self):
        cur = self._current()
        if not cur:
            return
        kind, obj = cur
        if kind == "folder":
            self._save_index()
            self.cwd = obj["id"]
            self._sel.pop(self.cwd, None)        # entering a folder always starts on its first item
            return self.fill()
        if store.needs_radio_url(obj):
            try:
                from Screens.MessageBox import MessageBox
                self.session.open(MessageBox, native(T("This radio needs a direct streaming URL. Edit it on the Web page.")), MessageBox.TYPE_INFO, timeout=6)
            except Exception:
                pass
            return
        c = ctl.get()
        # Test3: OK on the playing one starts its audio again from the beginning (fresh connection) and keeps the
        # picture delay / timeshift as it is; RED is the only key that stops. On any other one it plays that one.
        c.play(obj["id"])
        self.refresh()

    def up(self):
        f = store.get_folder(self.cwd)
        self._save_index()
        self.cwd = f.get("parent", "") if f else ""
        self.fill()

    def back(self):
        if self.cwd:
            self.up()
        else:
            self.close()

    def stop(self):
        ctl.get().stop()
        self.refresh()

    def update_sources(self):
        """Settings action: refresh every saved URL source, regardless of the open folder."""
        if getattr(self, "_updating", False):
            return
        fids = [f["id"] for f in store.list_folders() if (f.get("source") or {}).get("type") == "url"]
        if not fids:
            self._text("kok", T("No saved URL sources to update"))
            return
        self._updating = True
        self._text("kok", T("Updating from the source..."))

        def work():
            from . import importer
            added = updated = removed = 0
            errors = []
            for fid in fids:
                try:
                    r = importer.refresh_folder(fid)
                    added, updated, removed = added + r["added"], updated + r["updated"], removed + r["removed"]
                except Exception as e:
                    f = store.get_folder(fid) or {}
                    errors.append(u"%s: %s" % (to_text(f.get("name", "?")), to_text(e)))
            text = T("Updated: +%d new, %d changed, %d removed", added, updated, removed)
            if errors:
                text = (text + u"   " if len(errors) < len(fids) else u"") + T("Update failed: %s", errors[0])[:110]
            ctl.main_call(self._update_done, text)
        from .compat import start_thread
        start_thread(work, name="UltraAudio-update")

    def _update_done(self, text):
        self._updating = False
        try:
            self.fill()
            self._text("kok", text)
        except Exception:
            pass

    def key_audio_reset(self):
        """BLUE: the commentary back to its own timing (no audio delay at all)."""
        if self.menu.is_open:
            return
        st = ctl.get().engine.status()
        if st["state"] not in ("starting", "playing", "retrying") or not st["audio_delay_supported"]:
            return
        ctl.get().video.suspend_monitor()
        self.audio_timer.stop()
        self._audio_pending, self._audio_target = None, None
        ctl.get().set_audio_delay(0, st["stream_id"], st.get("generation"))
        self._aud_busy_until = time.time() + 0.35
        self.refresh()

    def key_audio(self, d):
        """4 / 6: each press moves the PENDING audio delay by one step; it is applied (live, no reconnect) once the
        keys rest for AUDIO_SETTLE seconds, so a quick run of presses is one change."""
        if self.menu.is_open:
            return
        st = ctl.get().engine.status()
        if st["state"] not in ("starting", "playing", "retrying") or not st["audio_delay_supported"]:
            return
        ctl.get().video.suspend_monitor()
        target = (st["stream_id"],)
        if getattr(self, "_audio_target", None) != target:
            self._audio_pending = None
        self._audio_target = target
        base = self._audio_pending if self._audio_pending is not None else st["audio_delay_ms"]
        step = int(store.get_settings()["step_audio_ms"])
        self._audio_pending = max(0, min(60000, base + (step if d > 0 else -step)))
        # a live delay is applied after a short rest; the old pipeline restarts for each change: wait for the last press
        self.audio_timer.start(int((AUDIO_SETTLE if st.get("audio_delay_live") else 1.0) * 1000), True)
        self.refresh()

    def apply_audio(self):
        ms, self._audio_pending = self._audio_pending, None
        target, self._audio_target = getattr(self, "_audio_target", None), None
        c = ctl.get()
        st = c.engine.status()
        if ms is not None and target and target[0] == st["stream_id"]:
            prev_ms = int(st.get("audio_delay_ms") or 0)
            c.set_audio_delay(ms, target[0])
            self._aud_busy_until = time.time() + (0.35 if ms <= prev_ms else 1.0)
        self.refresh()

    def adj(self, what, direction):
        c = ctl.get()
        st = c.engine.status()
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        if what == "audio" and not st["audio_delay_supported"]:
            return
        (c.adjust_video if what == "video" else c.adjust_audio)(direction)

    # ----------------------------------------------------------- status
    def _color(self, name, color):
        if self._colors.get(name) == color:
            return                       # setting the same colour again still repaints the label
        self._colors[name] = color
        try:
            from skin import parseColor
            self[name].instance.setForegroundColor(parseColor(native(color)))
        except Exception:
            pass

    def _text(self, name, text):
        if self._texts.get(name) != text:
            self._texts[name] = text
            self[name].setText(native(text))

    def refresh(self):
        if self._font != uifont.selected() and getattr(self, "execing", True):
            return self.reopen(self.menu.idx if self.menu.is_open else None)
        self._refresh_body()
        if self.menu.is_open:
            self.menu.paint_keys()        # the key words belong to the MENU card while it is open

    def _delay_text(self, st, v):
        """(picture value, audio value, picture busy?, audio busy?): busy = a change is waiting or being applied."""
        vcur = v["current_s"] if v["current_s"] is not None else v["target_s"]
        now = time.time()
        ppend = self._pic_pending
        if ppend is not None:
            ptxt = to_text(T("%+.1f s", ppend)) + u" \u2026"
        elif v["state"] == "filling":
            ptxt = to_text(T("%+.1f s", v["target_s"])) + u" \u2026"
        else:
            shown_v = 0.0 if v["state"] in ("off", "error") else (v["target_s"] if v["state"] == "running" and v.get("target_s", 0) > 0 else vcur)
            ptxt = to_text(T("%+.1f s", shown_v))
        pbusy = (ppend is not None or now < self._pic_busy_until or v.get("busy") or v["state"] in ("filling", "paused")
                 or (v["state"] == "running" and v["current_s"] is not None and abs(v["current_s"] - v["target_s"]) > 0.6))
        pend = self._audio_pending
        atxt = to_text(T("%+.1f s", (st["audio_delay_ms"] if pend is None else pend) / 1000.0)) + (u" \u2026" if pend is not None else u"")
        abusy = pend is not None or now < self._aud_busy_until or bool(st.get("audio_settling")) or st["state"] == "starting"
        return ptxt, atxt, pbusy, abusy

    def _delay_frame(self):
        """Current-delay captions; per-key step captions are intentionally omitted."""
        self._text("pcap", T("Picture").upper())
        self._text("acap", T("Audio").upper())

    def _show_delays(self, st, v):
        ptxt, atxt, pbusy, abusy = self._delay_text(st, v)
        self._delay_frame()
        self._text("pv", ptxt)
        self._text("pva", atxt)
        self._color("pv", self.pal["accent"] if pbusy else WHITE)
        self._color("pva", self.pal["accent"] if abusy else WHITE)

    def _refresh_body(self):
        if self.grid and lang() != self._lang and getattr(self, "execing", True):
            # the language was changed on the web page: the theme's fonts depend on it
            return self.reopen(self.menu.idx if self.menu.is_open else None)
        self._text("clock", time.strftime("%H:%M"))
        c = ctl.get()
        st = c.status()
        self._text("hstate", (st.get('tv_channel') or {}).get('name') or "")
        self._color("hstate", WHITE)
        self._sync_marker(st)
        if getattr(self, "_audio_target", None) is not None and self._audio_target[0] != st["stream_id"]:
            self._audio_pending, self._audio_target = None, None
            self.audio_timer.stop()
        if self._pic_target is not None and self._pic_target[0] != st["stream_id"]:
            self._pic_pending, self._pic_target = None, None
            self.pic_timer.stop()
        v = st["video"]
        language = lang()
        guide.ensure(self._guide_streams, language)
        guide_changed = tuple(guide.view(s, language) for s in self._guide_streams) != self._guide_shown
        view = (language, receivertime.guide_notice())
        if ((self.cwd, st["stream_id"] if st["state"] != "idle" else None) != self._shown
                or store.library_revision() != self._library_shown
                or view != self._view_shown or guide_changed
                or (self._guide_streams and not self.grid and int(guide.now() // 60) != self._minute_shown)):
            self._save_index()
            self.fill()
        if self.grid:
            return self._refresh_cards(st, v)
        if st["state"] == "idle":
            self._text("hname", "%s  http://%s:%d" % (T("Web"), self.ip, webui.PORT))
            self._color("hname", WHITE)
            self._delay_frame()
            self._text("pv", T("%+.1f s", 0.0))
            self._text("pva", T("%+.1f s", 0.0))
            self._color("pv", WHITE)
            self._color("pva", WHITE)
            self._text("kgreen", T("Freeze"))
            self._text("kyellow", T("Reset picture"))
            self.audio_keys(False)
            self._text("crumb", self._crumb)
            self._color("crumb", WHITE)
            return
        self._text("hname", st["stream_name"] or "")
        self._color("hname", self.pal["accent"])
        msg = ((st["message"] or "")[:60] if st["state"] in ("error", "retrying", "starting")
               else v.get("note", "") or st.get("audio_delay_note", ""))
        self._text("crumb", msg or self._crumb)
        self._color("crumb", (self.pal["error"] if st["state"] == "error" else self.pal["warn"]) if msg else WHITE)
        self._place_marker()
        self._show_delays(st, v)
        self._text("kgreen", T("Resume") if v["state"] == "paused" else T("Freeze"))
        self._text("kyellow", T("Reset picture"))
        self._text("kblue", T("Reset audio") if st["audio_delay_supported"] else T("Audio N/A"))
        self.audio_keys(not self.menu.is_open)

    def _refresh_cards(self, st, v):
        """Stadium / Daylight: the "now playing" block, the state chip and the status line (web address or message)."""
        P = self.pal
        web = "%s  http://%s:%d" % (T("Web"), self.ip, webui.PORT)
        if st["state"] == "idle":
            self._text("hstate", state_label("idle"))
            self._color("hstate", P["idle"])
            self._text("nphead", T("Ready").upper())
            self._color("nphead", P["muted"])
            self._text("hname", T("Choose a channel"))
            self._color("hname", P["dim"])
            self._text("pv", "")
            self._text("web", web)
            self._color("web", P["muted"])
            self._text("kgreen", T("Freeze"))
            self._text("kyellow", T("Reset picture"))
            self.audio_keys(False)
            return
        self._text("hstate", "" if st["state"] == "playing" else self.th.get("dot", u"\u25cf") + u" " + state_label(st["state"]))
        self._color("hstate", self._state_colors.get(st["state"], P["idle"]))
        self._text("nphead", T("Now playing").upper())
        self._color("nphead", P["accent"])
        self._text("hname", st["stream_name"] or "")
        self._color("hname", P["text"])
        msg = ((st["message"] or "")[:60] if st["state"] in ("error", "retrying", "starting")
               else v.get("note", "") or st.get("audio_delay_note", ""))
        self._text("web", msg or web)
        self._color("web", (P["error"] if st["state"] == "error" else P["warn"]) if msg else P["muted"])
        self._show_delays(st, v)
        self._text("kgreen", T("Resume") if v["state"] == "paused" else T("Freeze"))
        self._text("kyellow", T("Reset picture"))
        self._text("kblue", T("Reset audio") if st["audio_delay_supported"] else T("Audio N/A"))
        self.audio_keys(not self.menu.is_open)
