# -*- coding: utf-8 -*-
"""Turn a source (playlist link, pasted M3U, or a list of links) into library entries.

Supported:
  * M3U / M3U8 playlists (#EXTINF with group-title; provider artwork is ignored)
  * plain text: one link per line, optionally "Name | link", "Name, link" or "Name link"
  * a JSON array / {"streams": [...]} of {"name","url"[,"group"]}
Only http/https links are kept."""
from __future__ import division
from contextlib import closing
import json
import re
import struct
import tempfile
import threading
import time
import unicodedata

from .compat import (DEVNULL, Request, TimeoutExpired, acquire, http_client, monotonic, parse_qsl, popen, wait,
                     to_text, unquote, urlopen, urlopen_verified, urlsplit)

from . import store
from .i18n import T

MAX_BYTES = 8 * 1024 * 1024
_ATTR = re.compile(r'([\w\-]+)="([^"]*)"')
_URL = re.compile(r"https?://\S+", re.I)


def queue_picons(folder=None):
    """Compatibility entry point: provider artwork is intentionally ignored."""
    return 0


HEAD_BYTES = 4096
READ_SECONDS = 30            # a playlist arrives in a few seconds; a link that keeps sending is a stream
_HLS = re.compile(r"^#EXT-X-(TARGETDURATION|STREAM-INF|MEDIA-SEQUENCE)", re.M | re.I)

_DIGITS = dict((ord(a), ord(b)) for a, b in zip(u"٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", u"01234567890123456789"))
_NOISE_PARTS = frozenset((
    "mpegts", "live", "stream", "streams", "index.m3u8", "playlist.m3u8", "mono.m3u8",
    "hls", "play", "listen", "audio", "channel", "channels", "tv", "radio", "ch", "feed"
))
_GENERIC_NAMES = frozenset((
    "", "live", "stream", "streams", "audio", "channel", "index", "index.m3u8",
    "playlist", "playlist.m3u8", "mono", "mono.m3u8", "mpegts", "imported", "source"
))

# Path/token segment aliases -> canonical family key
_FAMILY_ALIASES = {
    "pn": "sport", "sp": "sport", "sport": "sport", "sports": "sport", "bein": "sport",
    "beinsport": "sport", "beinsports": "sport", "bs": "sport", "prem": "sport", "premium": "sport",
    "mx": "max", "max": "max", "spmax": "max", "beinmax": "max", "bmax": "max",
    "mxl": "max_low", "mxlow": "max_low", "maxlow": "max_low",
    "xt": "xtra", "xtra": "xtra", "extra": "xtra", "ex": "xtra", "beinxtra": "xtra",
    "en": "en", "eng": "en", "english": "en", "beinen": "en", "beinenglish": "en", "beinsportsenglish": "en",
    "fr": "fr", "fra": "fr", "french": "fr", "beinfr": "fr", "beinfrench": "fr",
    "it": "italy", "ita": "italy", "italy": "italy", "italian": "italy", "seriea": "italy",
    "st": "starzplay", "starz": "starzplay", "starzplay": "starzplay",
    "de": "de", "ger": "de", "germany": "de", "bundesliga": "de",
    "th": "thm8h", "thm": "thm8h", "thm8h": "thm8h", "thmanyah": "thm8h", "thamanyah": "thm8h",
    "thmanyeh": "thm8h", "8": "thm8h", "ssc": "thm8h",
    "ks": "alkass", "ka": "alkass", "kass": "alkass", "alkass": "alkass", "alkas": "alkass", "alkaas": "alkass",
    "sh": "shasha", "sha": "shasha", "shasha": "shasha", "shashah": "shasha",
    "shd": "shahid", "shahid": "shahid",
    "ad": "ad", "adsports": "ad", "adprem": "ad", "abudhabi": "ad", "abudhabisports": "ad",
    "rb": "alrabiaa", "rabiaa": "alrabiaa", "alrabiaa": "alrabiaa", "rabia": "alrabiaa",
    "mbcmasr": "mbcmasr", "mbcmisr": "mbcmasr",
    "mbcaction": "mbcaction",
    "lv": "live", "live": "live",
    "ev": "event", "event": "event", "events": "event",
    "mt": "match", "match": "match",
}

SATFAMILY_CHANNELS = (
    ("SatFamily-4k-Match", "SF4K-Match"),
    ("SatFamily-4k-1", "SF4K-1"),
    ("SatFamily-4k-2", "SF4K-2"),
    ("SatFamily-4k-3", "SF4K-3"),
    ("SatFamily-4k-4", "SF4K-4"),
    ("SatFamily-4k-5", "SF4K-5"),
    ("SatFamily-4k-6", "SF4K-6"),
    ("SatFamily-4k-7", "SF4K-7"),
    ("SatFamily-4k-8", "SF4K-8"),
    ("SatFamily-4k-9", "SF4K-9"),
    ("SatFamily-4k-Xtra-1", "SF4K-XTRA1"),
    ("SatFamily-4k-Xtra-2", "SF4K-XTRA2"),
    ("SatFamily-4k-Xtra-3", "SF4K-XTRA3"),
    ("SatFamily-4k-Xtra-4", "SF4K-XTRA4"),
    ("SatFamily-4k-Xtra-5", "SF4K-XTRA5"),
    ("SatFamily-4k-Xtra-6", "SF4K-XTRA6"),
    ("SatFamily-4k-Ad-1", "SF4K-AD1"),
    ("SatFamily-4k-Ad-2", "SF4K-AD2"),
    ("SatFamily-4K-Alrabiaa-Sports-1", "SF4K-4K-Alrabiaa-Sports-1"),
    ("SatFamily-4K-Alrabiaa-Sports-2", "SF4K-4K-Alrabiaa-Sports-2"),
    ("SatFamily-4K-Shasha-Sport-1", "SF4K-4K-Shasha-1"),
    ("SatFamily-4K-Shasha-Sport-2", "SF4K-4K-Shasha-2"),
    ("SatFamily-4K-Shahid-Sports-1", "SF4K-SHAHID-SPORTS-1"),
    ("SatFamily-4K-Shahid-Sports-2", "SF4K-SHAHID-SPORTS-2"),
    ("SatFamily-4K-Shahid-Sports-3", "SF4K-SHAHID-SPORTS-3"),
    ("SatFamily-4K-Shahid-Sports-4", "SF4K-SHAHID-SPORTS-4"),
    ("SatFamily-4K-Thmanyah-1", "SF4K-Thmanyah-1"),
    ("SatFamily-4K-Thmanyah-2", "SF4K-Thmanyah-2"),
    ("SatFamily-4K-Thmanyah-3", "SF4K-Thmanyah-3"),
    ("SatFamily-4K-Alkass-5", "SF4K-Alkass-5"),
    ("SatFamily-4K-Alkass-6", "SF4K-Alkass-6"),
    ("SatFamily-4K-Alkass-7", "SF4K-Alkass-7"),
    ("SatFamily-4K-Alkass-8", "SF4K-Alkass-8"),
    ("SatFamily-4K-MBC-Action", "SF4K-Bundesliga-1"),
    ("SatFamily-4K-MBC-Masr", "SF4K-Bundesliga-2"),
    ("SatFamily-4K-Event-1", "SF4K-Event-4K-1"),
    ("SatFamily-4K-Event-2", "SF4K-Event-4K-2"),
    ("SatFamily-4K-Event-3", "SF4K-Event-4K-3"),
    ("SatFamily-4K-Event-4", "SF4K-Event-4K-4"),
    ("SatFamily-4K-Event-5", "SF4K-Event-4K-5"),
    ("SatFamily-4K-Event-6", "SF4K-Event-4K-6"),
    ("SatFamily-4K-Event-7", "SF4K-Event-4K-7"),
    ("SatFamily-4K-Event-8", "SF4K-Event-4K-8"),
    ("SatFamily-4K-Event-9", "SF4K-Event-4K-9"),
    ("SatFamily-Vip-Match", "SFVIP-Match"),
    ("SatFamily-Vip-1", "SFVIP-1"),
    ("SatFamily-Vip-2", "SFVIP-2"),
    ("SatFamily-Vip-3", "SFVIP-3"),
    ("SatFamily-Vip-4", "SFVIP-4"),
    ("SatFamily-Vip-5", "SFVIP-5"),
    ("SatFamily-Vip-6", "SFVIP-6"),
    ("SatFamily-Vip-7", "SFVIP-7"),
    ("SatFamily-Vip-8", "SFVIP-8"),
    ("SatFamily-Vip-9", "SFVIP-9"),
    ("SatFamily-Match-Low", "SFLOW-Match"),
    ("SatFamily-Low-1", "SFLOW-1"),
    ("SatFamily-Low-2", "SFLOW-2"),
    ("SatFamily-Low-3", "SFLOW-3"),
    ("SatFamily-Low-4", "SFLOW-4"),
    ("SatFamily-Low-5", "SFLOW-5"),
    ("SatFamily-Low-6", "SFLOW-6"),
    ("SatFamily-Low-7", "SFLOW-7"),
    ("SatFamily-Low-8", "SFLOW-8"),
    ("SatFamily-Low-9", "SFLOW-9"),
    ("SatFamily-Low-Xtra-1", "SFLOW-XTRA1"),
    ("SatFamily-Low-Xtra-2", "SFLOW-XTRA2"),
    ("SatFamily-Low-Xtra-3", "SFLOW-XTRA3"),
    ("SatFamily-Low-Ad-1", "SFLOW-AD1"),
    ("SatFamily-Low-Ad-2", "SFLOW-AD2"),
)
_SATFAMILY_ENDPOINT_MAP = dict((ep.lower(), nm) for nm, ep in SATFAMILY_CHANNELS)

ORANGE_CHANNELS = (
    ("Orange Live", "Orange-live"),
    ("Orange Match", "Orange-Match"),
    ("Orange 1", "Orange-1"),
    ("Orange 2", "Orange-2"),
    ("Orange 3", "Orange-3"),
    ("Orange 4", "Orange-4"),
    ("Orange 5", "Orange-5"),
    ("Orange 6", "Orange-6"),
    ("Orange 7", "Orange-7"),
    ("Orange 8", "Orange-8"),
    ("Orange 9", "Orange-9"),
    ("Orange Xtra 1", "Orange-Xtra1"),
    ("Orange Xtra 2", "Orange-Xtra2"),
    ("Orange Xtra 3", "Orange-Xtra3"),
    ("Orange Max 1", "Orange-Max1"),
    ("Orange Max 2", "Orange-Max2"),
    ("Orange Max 3", "Orange-Max3"),
    ("Orange Max 4", "Orange-Max4"),
    ("Orange Max 5", "Orange-Max5"),
    ("Orange Max 6", "Orange-Max6"),
    ("Orange Alkass 5", "Orange-Alkass-5"),
    ("Orange Alkass 6", "Orange-Alkass-6"),
    ("Orange Alkass 7", "Orange-Alkass-7"),
    ("Orange Alkass 8", "Orange-Alkass-8"),
    ("Orange Thmanyah 1", "Orange-Thmanyah-1"),
    ("Orange Thmanyah 2", "Orange-Thmanyah-2"),
    ("Orange Thmanyah 3", "Orange-Thmanyah-3"),
    ("Orange AD 1", "Orange-AD-1"),
    ("Orange AD 2", "Orange-AD-2"),
    ("Orange Shahid 1", "Orange-Shahid-1"),
    ("Orange Shahid 2", "Orange-Shahid-2"),
    ("Orange Shasha 1", "Orange-Shasha-1"),
    ("Orange Shasha 2", "Orange-Shasha-2"),
    ("Orange StarzPlay 1", "Orange-StarzPlay-1"),
    ("Orange StarzPlay 2", "Orange-StarzPlay-2"),
)
_ORANGE_ENDPOINT_MAP = dict((ep.lower(), nm) for nm, ep in ORANGE_CHANNELS)

ANIS_CHANNELS = (
    ("Anis Sport 1", "live/pn/1"),
    ("Anis Sport 2", "live/pn/2"),
    ("Anis Sport 3", "live/pn/3"),
    ("Anis Sport 4", "live/pn/4"),
    ("Anis Sport 5", "live/pn/5"),
    ("Anis Sport 6", "live/pn/6"),
    ("Anis Sport 7", "live/pn/7"),
    ("Anis Sport 8", "live/pn/8"),
    ("Anis Sport 9", "live/pn/9"),
    ("Anis Max 1", "live/mx/1"),
    ("Anis Max 2", "live/mx/2"),
    ("Anis Max 3", "live/mx/3"),
    ("Anis Max 4", "live/mx/4"),
    ("Anis Max 5", "live/mx/5"),
    ("Anis Max 6", "live/mx/6"),
    ("Anis Xtra 1", "live/xt/1"),
    ("Anis Xtra 2", "live/xt/2"),
    ("Anis EN 1", "live/en/1"),
    ("Anis EN 2", "live/en/2"),
    ("Anis FR 1", "live/fr/1"),
    ("Anis FR 2", "live/fr/2"),
    ("Anis Italy 1", "live/it/1"),
    ("Anis Italy 2", "live/it/2"),
    ("Anis DE 1", "live/de/1"),
    ("Anis DE 2", "live/de/2"),
    ("Anis Thm8h 1", "live/th/1"),
    ("Anis Thm8h 2", "live/th/2"),
    ("Anis Thm8h 3", "live/th/3"),
    ("Anis Shasha", "live/sh/1"),
    ("Anis Shahid", "live/shd/1"),
    ("Anis Al Kass 1", "live/ks/1"),
    ("Anis Al Kass 2", "live/ks/2"),
)



def looks_like_stream(head, ctype=""):
    """True when the first bytes / content type are audio or video rather than a playlist (MPEG-TS, MP3/AAC, Ogg...),
    or an HLS playlist, which is ONE channel (its lines are pieces of the stream, not channels)."""
    ctype = (ctype or "").lower()
    if not any(p in ctype for p in ("mpegurl", "scpls", "x-pls")) and ctype.startswith(("audio/", "video/", "application/ogg")):
        return True
    b = head[:512]
    ts = len(head) >= 377 and head[0:1] == head[188:189] == head[376:377] == b"\x47"     # MPEG-TS: 0x47 every 188 bytes
    if ts or b.startswith((b"ID3", b"OggS", b"fLaC", b"RIFF")):
        return True
    if len(b) >= 2 and b[:1] == b"\xff" and (bytearray(b[:2])[1] & 0xE0) == 0xE0:   # MP3 / ADTS frame sync
        return True
    if b[4:8] == b"ftyp" or b"\x00" in b:
        return True
    try:
        text = head.decode("utf-8", "replace")
    except Exception:
        return False
    return bool(_HLS.search(text))


def _decode(raw):
    for enc in ("utf-8-sig", "cp1256", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


class _ReadDeadline(ValueError):
    pass


class _DeadlineReader(object):
    """Bound the entire HTTP body read with a monotonic deadline."""
    def __init__(self, response, seconds, timeout):
        self.response = response
        self.deadline = monotonic() + seconds
        self.timeout = timeout
        self.read1 = getattr(response, "read1", response.read)
        self.sock = None
        pending, seen = [response], set()
        while pending:
            obj = pending.pop()
            if id(obj) in seen:
                continue
            seen.add(id(obj))
            if callable(getattr(obj, "settimeout", None)):
                self.sock = obj
                break
            for name in ("fp", "raw", "_sock", "sock"):
                child = getattr(obj, name, None)
                if child is not None and len(seen) < 24:
                    pending.append(child)

    def read(self, size):
        remaining = self.deadline - monotonic()
        if remaining <= 0:
            raise _ReadDeadline(T("The link keeps sending data; it does not look like a playlist"))
        if self.sock is not None:
            try:
                self.sock.settimeout(max(0.001, min(self.timeout, remaining)))
            except (EnvironmentError, ValueError):
                self.sock = None
        return self.read1(size)


def fetch_source(url, timeout=20):
    """('stream', None) when the link is itself a channel (audio, MPEG-TS, HLS), else ('text', the playlist text)."""
    if not store.valid_url(url):
        raise ValueError(T("The link must start with http or https"))
    req = Request(url, headers={"User-Agent": store.DEFAULT_UA, "Accept": "*/*"})
    try:
        r = urlopen_verified(req, timeout=timeout)
    except http_client.HTTPException as e:     # "ICY 200 OK": a SHOUTcast radio answers like this
        if "ICY" in to_text(e):
            return "stream", None
        raise IOError(to_text(e))
    with closing(r):
        if looks_like_stream(b"", r.headers.get("Content-Type", "")):
            return "stream", None
        read = _DeadlineReader(r, READ_SECONDS, timeout).read
        raw = b""
        while len(raw) < HEAD_BYTES:
            chunk = read(HEAD_BYTES - len(raw))
            if not chunk:
                break
            raw += chunk
        if looks_like_stream(raw, r.headers.get("Content-Type", "")):
            return "stream", None
        while True:
            chunk = read(65536)
            if not chunk:
                break
            raw += chunk
            if len(raw) > MAX_BYTES:
                raise ValueError(T("The file is too large"))
    return "text", _decode(raw)


def fetch_text(url, timeout=20):
    kind, text = fetch_source(url, timeout)
    if kind != "text":
        raise ValueError(T("This link is a single channel, not a playlist"))
    return text


def _norm_tokens(text):
    s = unicodedata.normalize("NFKC", to_text(text or "")).lower().translate(_DIGITS)
    s = re.sub(u"[\u0640\u064b-\u065f\u0670]", u"", s)
    s = s.replace(u"أ", u"ا").replace(u"إ", u"ا").replace(u"آ", u"ا")
    return re.findall(u"[a-z0-9\u0621-\u064a]+", s, re.UNICODE)


def _detect_provider(url="", folder_name="", parent_name="", group="", provider=""):
    """Identify the canonical provider label ('Anis', 'FoX FM', 'SatFamily', 'Orange', 'Best') from URL or folder context."""
    host = urlsplit(to_text(url or "")).netloc.lower()
    if "anis" in host:
        return "Anis"
    if "foxfm" in host or "fox" in host:
        return "FoX FM"
    if any(k in host for k in ("satfamily", "sarfamily", "satfamilly", "sf4k", "sfvip", "sflow", "stereofm")):
        return "SatFamily"
    if "orange" in host:
        return "Orange"
    if "best" in host:
        return "Best"
    for candidate in (provider, folder_name, parent_name, group):
        words = _norm_tokens(candidate)
        joined = u"".join(words)
        if not joined:
            continue
        if "anis" in joined or u"انيس" in joined:
            return "Anis"
        if "foxfm" in joined or "fox" in words or u"فوكس" in joined:
            return "FoX FM"
        if any(k in joined for k in ("satfamily", "sarfamily", "satfamilly", "sf4k", "sfvip", "sflow", "stereofm", u"ساتفاميلي")):
            return "SatFamily"
        if "orange" in joined or u"اورانج" in joined:
            return "Orange"
        if "best" in words:
            return "Best"
    return ""


def _family_from_text(text):
    """Detect channel family and low-quality flag from a folder/group title such as 'Anis SP Max' or 'ANIS MAX'."""
    words = _norm_tokens(text)
    if not words:
        return "", False
    is_low = "low" in words
    for w in words:
        if w in ("anis", u"انيس", "fm", "foxfm", "fox", "satfamily", "sarfamily", "orange", "best", "audio", "commentary", "low", "hd", "fhd", "4k", "uhd", "sd"):
            continue
        if w in ("max", "mx", "spmax", u"ماكس"):
            return ("max_low" if is_low else "max"), is_low
        if w in ("xtra", "extra", "xt", u"اكسترا"):
            return "xtra", is_low
        if w in ("alkass", "alkas", "alkaas", "kass", "ks", u"الكاس"):
            return "alkass", is_low
        if w in ("thmanyah", "thamanyah", "thmanyeh", "thm8h", "thm", "8", "ssc", u"ثمانية", u"ثمانيه"):
            return "thm8h", is_low
        if w in ("en", "eng", "english", u"انجليزي"):
            return "en", is_low
        if w in ("fr", "fra", "french", u"فرنسي"):
            return "fr", is_low
        if w in ("italy", "italian", "it", "ita", u"ايطالي", u"ايطالى"):
            return "italy", is_low
        if w in ("starzplay", "starz", "st", u"ستارز"):
            return "starzplay", is_low
        if w in ("de", "germany", "bundesliga"):
            return "de", is_low
        if w in ("shasha", "shashah", "sh", u"شاشا", u"شاشة", u"شاشه"):
            return "shasha", is_low
        if w in ("shahid", "shd", u"شاهد"):
            return "shahid", is_low
        if w in ("ad", "adsports", "adprem", "abudhabi", u"ابوظبي"):
            return "ad", is_low
        if w in ("alrabiaa", "rabiaa", "rabia", u"الرابعة", u"الرابعه"):
            return "alrabiaa", is_low
        if w in ("sport", "sports", "pn", "bein", "beinsports", u"سبورت"):
            return "sport", is_low
    return "", is_low


def _parse_url_channel(url):
    """Extract (family, number, is_low, raw_tail) from a stream URL path and query."""
    p = urlsplit(to_text(url or ""))
    raw_parts = [to_text(unquote(str(x))).strip() for x in p.path.split("/") if x and x.strip()]
    clean_parts = []
    for seg in raw_parts:
        s = re.sub(r"\.(?:m3u8?|ts|mp3|aac|ogg|flac|pls|ashx|php|jsp|asp)$", "", seg, flags=re.I).strip()
        if s:
            clean_parts.append(s)
    filtered = [s for s in clean_parts if s.lower() not in _NOISE_PARTS]
    is_low = any(s.lower() == "low" for s in filtered)
    tokens = [s for s in filtered if s.lower() != "low"]

    family = ""
    number = None

    # Check query parameters for channel id/number if needed
    q_num = None
    for k, v in parse_qsl(p.query, keep_blank_values=True):
        kl = k.lower()
        if kl in ("id", "ch", "chan", "channel", "channelid", "channel_id", "chid", "cid", "sid", "stream", "streamid"):
            v_str = to_text(v).strip()
            if v_str.isdigit() and 1 <= int(v_str) <= 99:
                q_num = int(v_str)
            else:
                m_q = re.match(r"^([a-zA-Z]+)[-_ ]*(\d{1,2})$", v_str)
                if m_q and m_q.group(1).lower() in _FAMILY_ALIASES:
                    family = _FAMILY_ALIASES[m_q.group(1).lower()]
                    q_num = int(m_q.group(2))

    # Inspect path tokens from right to left
    if len(tokens) >= 2 and tokens[-1].isdigit():
        number = int(tokens[-1])
        prev = re.sub(r"[^a-z0-9]+", "", tokens[-2].lower())
        if prev in _FAMILY_ALIASES:
            family = _FAMILY_ALIASES[prev]
        elif len(tokens) >= 3:
            prev2 = re.sub(r"[^a-z0-9]+", "", tokens[-3].lower())
            if prev2 in _FAMILY_ALIASES:
                family = _FAMILY_ALIASES[prev2]
    elif len(tokens) == 1 and tokens[0].isdigit():
        number = int(tokens[0])
    elif tokens:
        last = tokens[-1]
        # Combined token such as 'xtra1', 'alkass5', 'mx1', 'pn2', 'live1', 'max3_low'
        last_clean = last.lower()
        if last_clean.endswith(("_low", "-low")):
            is_low = True
            last_clean = last_clean[:-4]
        m = re.match(r"^([a-z0-9]+?)[-_ ]*(\d{1,2})$", last_clean)
        if m and m.group(1) in _FAMILY_ALIASES:
            family = _FAMILY_ALIASES[m.group(1)]
            number = int(m.group(2))
        else:
            m2 = re.match(r"^([a-z]+)(\d{1,2})$", re.sub(r"[^a-z0-9]+", "", last_clean))
            if m2 and m2.group(1) in _FAMILY_ALIASES:
                family = _FAMILY_ALIASES[m2.group(1)]
                number = int(m2.group(2))
            elif re.sub(r"[^a-z0-9]+", "", last_clean) in _FAMILY_ALIASES:
                family = _FAMILY_ALIASES[re.sub(r"[^a-z0-9]+", "", last_clean)]
                if len(tokens) >= 2 and tokens[-2].isdigit():
                    number = int(tokens[-2])

    if number is None and q_num is not None:
        number = q_num
    if family == "max" and is_low:
        family = "max_low"

    raw_tail = (filtered[-1] if filtered else (clean_parts[-1] if clean_parts else p.netloc)).replace("_", " ").strip()
    return family, number, is_low, raw_tail


def _format_channel_name(provider, family, number, is_low=False, folder_name="", raw_tail="", url=""):
    """Format the human-readable channel name matching ordering.py, logos.py and guide.py conventions."""
    n = number if (isinstance(number, int) and 1 <= number <= 99) else None
    if family == "max_low":
        family, is_low = "max", True

    if provider == "Anis":
        if family in ("sport", ""):
            return ("Anis Sport %d" % n) if n else "Anis Sport"
        if family == "max":
            base = ("Anis Max %d" % n) if n else "Anis Max"
            return base + (" Low" if is_low else "")
        if family == "xtra":
            return ("Anis Xtra %d" % n) if n else "Anis Xtra"
        if family == "en":
            return ("Anis EN %d" % n) if n else "Anis EN 1"
        if family == "fr":
            return ("Anis FR %d" % n) if n else "Anis FR 1"
        if family == "italy":
            return ("Anis Italy %d" % n) if n else "Anis Italy 1"
        if family == "starzplay":
            return ("Anis StarzPlay %d" % n) if n else "Anis StarzPlay"
        if family == "de":
            return ("Anis DE %d" % n) if n else "Anis DE 1"
        if family == "thm8h":
            return ("Anis Thm8h %d" % n) if n else "Anis Thm8h 1"
        if family == "alkass":
            return ("Anis Al Kass %d" % n) if n else "Anis Al Kass 1"
        if family == "shasha":
            return "Anis Shasha" if n in (None, 1) else ("Anis Shasha %d" % n)
        if family == "shahid":
            return "Anis Shahid" if n in (None, 1) else ("Anis Shahid %d" % n)
        if family == "ad":
            return ("Anis AD %d" % n) if n else "Anis AD 1"
        if family == "alrabiaa":
            return ("Anis Al Rabiaa %d" % n) if n else "Anis Al Rabiaa"
        if family == "mbcmasr":
            return ("Anis MBC Masr %d" % n) if n else "Anis MBC Masr 1"
        if family == "mbcaction":
            return "Anis MBC Action"
        if family in ("live", "event", "match"):
            label = family.capitalize()
            return ("Anis %s %d" % (label, n)) if n else ("Anis %s" % label)

    if provider == "FoX FM":
        if family in ("sport", ""):
            return ("FoX FM %d" % n) if n else "FoX FM"
        if family == "max":
            base = ("FoX FM Max %d" % n) if n else "FoX FM Max"
            return base + (" Low" if is_low else "")
        if family == "xtra":
            return ("FoX FM Xtra %d" % n) if n else "FoX FM Xtra 1"
        if family == "en":
            return ("FoX FM EN %d" % n) if n else "FoX FM EN 1"
        if family == "fr":
            return ("FoX FM FR %d" % n) if n else "FoX FM FR 1"
        if family in ("starzplay", "italy"):
            return ("FoX FM StarzPlay %d" % n) if n else "FoX FM StarzPlay 1"
        if family == "shasha":
            return ("FoX FM Shasha %d" % n) if n else "FoX FM Shasha 1"
        if family == "thm8h":
            return ("FoX FM Thmanyah %d" % n) if n else "FoX FM Thmanyah 1"
        if family in ("shahid", "de"):
            return ("FoX FM Shahid %d" % n) if n else "FoX FM Shahid 1"
        if family == "alkass":
            return ("FoX FM Alkass %d" % n) if n else "FoX FM Alkass 1"
        if family == "ad":
            return ("FoX FM AD %d" % n) if n else "FoX FM AD 1"
        if family == "alrabiaa":
            return ("FoX FM Al Rabiaa %d" % n) if n else "FoX FM Al Rabiaa"
        if family in ("live", "event", "match"):
            label = family.capitalize()
            return ("FoX FM %s %d" % (label, n)) if n else ("FoX FM %s" % label)

    if provider in ("SatFamily", "Orange", "Best"):
        if family in ("sport", ""):
            return ("%s %d" % (provider, n)) if n else provider
        family_Map = {
            "max": "Max", "xtra": "Xtra", "en": "EN", "fr": "FR", "italy": "StarzPlay",
            "starzplay": "StarzPlay", "de": "Shahid", "thm8h": "Thmanyah", "alkass": "Alkass",
            "shasha": "Shasha", "shahid": "Shahid", "ad": "AD", "alrabiaa": "Al Rabiaa",
            "mbcmasr": "MBC Masr", "mbcaction": "MBC Action",
            "live": "Live", "event": "Event", "match": "Match"
        }
        flabel = family_Map.get(family, family.capitalize())
        base = ("%s %s %d" % (provider, flabel, n)) if n else ("%s %s" % (provider, flabel))
        return base + (" Low" if is_low and family == "max" else "")

    # No specific provider: use canonical channel brand names
    if family == "sport":
        return ("beIN Sports %d" % n) if n else "beIN Sports"
    if family == "max":
        base = ("beIN Max %d" % n) if n else "beIN Max"
        return base + (" Low" if is_low else "")
    if family == "xtra":
        return ("beIN Xtra %d" % n) if n else "beIN Xtra 1"
    if family == "en":
        return ("beIN EN %d" % n) if n else "beIN EN 1"
    if family == "fr":
        return ("beIN FR %d" % n) if n else "beIN FR 1"
    if family == "alkass":
        return ("Al Kass %d" % n) if n else "Al Kass 1"
    if family == "thm8h":
        return ("Thmanyah %d" % n) if n else "Thmanyah 1"
    if family in ("starzplay", "italy"):
        return ("StarzPlay %d" % n) if n else "StarzPlay"
    if family == "shasha":
        return ("Shasha %d" % n) if n else "Shasha"
    if family in ("shahid", "de"):
        return ("Shahid %d" % n) if n else "Shahid"
    if family == "ad":
        return ("AD Sports %d" % n) if n else "AD Sports 1"
    if family == "alrabiaa":
        return ("Al Rabiaa %d" % n) if n else "Al Rabiaa"
    if family == "mbcmasr":
        return ("MBC Masr %d" % n) if n else "MBC Masr 1"
    if family == "mbcaction":
        return "MBC Action"
    if family in ("live", "event", "match"):
        label = family.capitalize()
        return ("%s %d" % (label, n)) if n else label

    if n is not None:
        clean_folder = to_text(folder_name or "").strip()
        if clean_folder and clean_folder.lower() not in _GENERIC_NAMES:
            # Avoid duplicating a trailing number if folder_name already ends with it
            return "%s %d" % (clean_folder, n)
        if 1 <= n <= 9:
            return "beIN Sports %d" % n
        return "Channel %d" % n

    p = urlsplit(to_text(url or ""))
    return (raw_tail or p.netloc or "Audio")[:80]


def is_bare_or_generic_name(name):
    """True when a channel name is missing, a bare number ('1'..'99'), or a generic placeholder ('live', 'stream')."""
    s = to_text(name or "").strip()
    if not s:
        return True
    low = s.lower()
    if low in _GENERIC_NAMES:
        return True
    if re.match(u"^(?:(?:channel|stream|track|audio|ch|قناة|صوتية)\\s*)?[0-9\u0660-\u0669\u06f0-\u06f9]{1,2}$", low):
        return True
    return False


def _endpoint_canonical_name(name="", url=""):
    """Map raw SatFamily/Orange endpoint slugs (e.g. SF4K-1, SF4K-Bundesliga-1, SFVIP-1, SFLOW-1) to canonical names."""
    cand = to_text(name or "").strip().lower()
    if cand in _SATFAMILY_ENDPOINT_MAP:
        return _SATFAMILY_ENDPOINT_MAP[cand]
    if cand in _ORANGE_ENDPOINT_MAP:
        return _ORANGE_ENDPOINT_MAP[cand]
    p = urlsplit(to_text(url or ""))
    for seg in reversed([to_text(unquote(str(x))).strip() for x in p.path.split("/") if x and x.strip()]):
        low = seg.lower()
        if low in _SATFAMILY_ENDPOINT_MAP:
            return _SATFAMILY_ENDPOINT_MAP[low]
        if low in _ORANGE_ENDPOINT_MAP:
            return _ORANGE_ENDPOINT_MAP[low]
    return ""


def smart_stream_name(name="", url="", folder_name="", parent_name="", group="", provider=""):
    """Return a clean, descriptive channel name. Preserves explicit names; upgrades bare numbers and URL slugs."""
    raw_name = to_text(name or "").strip()
    ep_name = _endpoint_canonical_name(raw_name, url if is_bare_or_generic_name(raw_name) else "")
    if ep_name:
        return ep_name[:80]
    if not is_bare_or_generic_name(raw_name):
        return raw_name[:80]
    ep_url_name = _endpoint_canonical_name("", url)
    if ep_url_name:
        return ep_url_name[:80]

    explicit_num = None
    m_num = re.match(u"^(?:(?:channel|stream|track|audio|ch|قناة|صوتية)\\s*)?([0-9\u0660-\u0669\u06f0-\u06f9]{1,2})$", raw_name.lower())
    if m_num:
        explicit_num = int(m_num.group(1).translate(_DIGITS))

    prov = _detect_provider(url=url, folder_name=folder_name, parent_name=parent_name, group=group, provider=provider)
    url_family, url_num, url_low, raw_tail = _parse_url_channel(url)
    ctx_family, ctx_low = _family_from_text(u" ".join((to_text(folder_name or ""), to_text(group or ""), to_text(parent_name or ""))))

    family = url_family or ctx_family
    number = explicit_num if explicit_num is not None else url_num
    is_low = url_low or ctx_low

    return _format_channel_name(prov, family, number, is_low=is_low, folder_name=folder_name, raw_tail=raw_tail, url=url)[:80]


def name_from_url(url, folder_name="", parent_name="", group="", provider=""):
    return smart_stream_name("", url=url, folder_name=folder_name, parent_name=parent_name, group=group, provider=provider)


def infer_source_folder_name(entries, url=None):
    """Infer a sensible default folder name when the user leaves Folder name empty at Library root."""
    if url:
        prov = _detect_provider(url=url)
        if prov:
            return "Anis FM" if prov == "Anis" else prov
    for e in entries or ():
        u = (e.get("url") if isinstance(e, dict) else "") or ""
        prov = _detect_provider(url=u, group=(e.get("group") if isinstance(e, dict) else "") or "")
        if prov:
            return "Anis FM" if prov == "Anis" else prov
    if url:
        p = urlsplit(to_text(url))
        parts = [to_text(unquote(str(x))) for x in p.path.split("/") if x and x.lower() not in _NOISE_PARTS]
        cand = (parts[-1] if parts else p.netloc).replace("_", " ").strip()[:60]
        if cand and not cand.isdigit():
            return cand
    return "Imported"


def parse_m3u(text, folder_name="", parent_name=""):
    out, pending = [], None
    for line in to_text(text).splitlines():
        line = line.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTINF"):
            quote, split = None, -1
            for index, char in enumerate(line):
                if char in ('"', "'"):
                    if quote == char:
                        quote = None
                    elif quote is None:
                        quote = char
                elif char == ',' and quote is None:
                    split = index
                    break
            head, title = (line[:split], line[split + 1:]) if split >= 0 else (line, '')
            attrs = dict(_ATTR.findall(head))
            pending = {"name": title.strip() or attrs.get("tvg-name", ""), "group": attrs.get("group-title", ""),
                       "logo": ""}
        elif line.upper().startswith("#EXTGRP:") and pending is not None:
            pending["group"] = pending.get("group") or line.split(":", 1)[1].strip()
        elif line.startswith("#"):
            continue
        elif _URL.match(line):
            e = pending or {}
            grp = e.get("group", "")
            raw_nm = e.get("name", "")
            nm = smart_stream_name(raw_nm, url=line, folder_name=folder_name, parent_name=parent_name, group=grp)
            out.append({"name": nm, "url": line, "group": grp, "logo": e.get("logo", "")})
            pending = None
    return out


def parse_links(text, folder_name="", parent_name=""):
    out = []
    for line in to_text(text).splitlines():
        line = line.strip()
        m = _URL.search(line)
        if not m or line.startswith("#"):
            continue
        url = m.group(0).rstrip(",;|)")
        label = (line[:m.start()] + u" " + line[m.end():]).strip(u" \t|,;-\u2013\u2014:=\"'")
        nm = smart_stream_name(label, url=url, folder_name=folder_name, parent_name=parent_name)
        out.append({"name": nm, "url": url, "group": ""})
    return out


def parse_json(text, folder_name="", parent_name=""):
    data = json.loads(to_text(text))
    items = data.get("streams", data.get("channels", [])) if isinstance(data, dict) else data
    out = []
    for it in items if isinstance(items, list) else []:
        if isinstance(it, dict) and it.get("url"):
            u = to_text(it["url"])
            grp = it.get("group", "")
            nm = smart_stream_name(it.get("name", ""), url=u, folder_name=folder_name, parent_name=parent_name, group=grp)
            out.append({"name": nm, "url": u, "group": grp, "logo": ""})
    return out


def parse_any(text, folder_name="", parent_name=""):
    t = to_text(text).lstrip(u"\ufeff \t\r\n")
    if t.startswith(("{", "[")):
        try:
            return parse_json(t, folder_name=folder_name, parent_name=parent_name)
        except ValueError:
            pass
    if "#EXTM3U" in t[:200].upper() or "#EXTINF" in t.upper():
        return parse_m3u(t, folder_name=folder_name, parent_name=parent_name)
    return parse_links(t, folder_name=folder_name, parent_name=parent_name)


def add_single(name, url, parent=""):
    """The link is one channel: put it straight into `parent` (no folder for one channel); never twice."""
    parent_folder = store.get_folder(parent) if parent else None
    if parent and not parent_folder:
        raise KeyError(parent)
    parent_name = parent_folder.get("name", "") if parent_folder else ""
    grand_name = ""
    if parent_folder and parent_folder.get("parent"):
        gf = store.get_folder(parent_folder.get("parent"))
        grand_name = gf.get("name", "") if gf else ""
    resolved_name = smart_stream_name(name, url=url, folder_name=parent_name, parent_name=grand_name)
    for s in store.list_streams():
        if s.get("folder", "") == (parent or "") and s.get("url") == url:
            if is_bare_or_generic_name(s.get("name", "")) and not is_bare_or_generic_name(resolved_name):
                store.update_stream(s["id"], {"name": resolved_name})
            return {"folder": parent or "", "stream": s["id"], "added": 0, "updated": 0, "removed": 0, "total": 1,
                    "single": True}
    s = store.add_stream({"name": resolved_name, "url": url, "folder": parent or ""})
    return {"folder": parent or "", "stream": s["id"], "added": 1, "updated": 0, "removed": 0, "total": 1, "single": True}


def _looks_like_playlist_url(url):
    p = urlsplit(to_text(url or ""))
    path_low = p.path.lower()
    query_low = p.query.lower()
    if path_low.endswith((".m3u", ".m3u8", ".pls", ".json", ".txt")):
        return True
    if "get.php" in path_low or "type=m3u" in query_low or "format=m3u" in query_low or "playlist" in path_low:
        return True
    return False



def _extract_token(url):
    p = urlsplit(to_text(url or "").rstrip("#").strip())
    for k, v in parse_qsl(p.query, keep_blank_values=True):
        if k.lower() == "token" and v.strip():
            return to_text(v).strip()
    m = re.search(r"[?&]token=([^&#\s]+)", to_text(url or ""), re.I)
    if m:
        return to_text(m.group(1)).strip()
    # Check if path is /tv/playlists/<user_id> where token is passed or derived
    return ""


def _call_remote_generator(api_url, input_url, timeout=8):
    """Try the provider generator API (gen.satfamily.xyz or gen.orange-audio.top); return list of entries or None."""
    try:
        payload = json.dumps({"oldLink": to_text(input_url).rstrip("#").strip()}).encode("utf-8")
        req = Request(api_url, data=payload, headers={
            "User-Agent": store.DEFAULT_UA,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        with closing(urlopen_verified(req, timeout=timeout)) as r:
            raw = r.read(MAX_BYTES)
        data = json.loads(_decode(raw))
        items = data if isinstance(data, list) else (data.get("streams") if isinstance(data, dict) else None)
        if not isinstance(items, list) or not items:
            return None
        out = []
        for it in items:
            if isinstance(it, dict) and it.get("url"):
                u = to_text(it["url"]).strip()
                nm = smart_stream_name(it.get("name", ""), url=u)
                out.append({"name": nm, "url": u, "group": "", "logo": ""})
        return out if out else None
    except Exception:
        return None


def generate_entries_from_link(url, allow_single_expansion=False):
    """Generate full channel entries from a SatFamily, Orange, or Anis link/token.
    When allow_single_expansion=False (normal import), only expands playlist URLs or links that fail direct fetch.
    When allow_single_expansion=True (explicit Generate button), expands any single channel link with a token into the full bouquet."""
    u = to_text(url or "").strip()
    if not store.valid_url(u):
        return None, ""
    p = urlsplit(u.rstrip("#"))
    host_low = p.netloc.lower()
    path_low = p.path.lower()
    token = _extract_token(u)
    base_origin = "%s://%s" % (p.scheme or "http", p.netloc)

    is_satfamily = (
        any(k in host_low for k in ("stereofm", "satfamily", "sarfamily", "satfamilly"))
        or any(path_low.startswith("/" + pf) for pf in ("sf4k-", "sfvip-", "sflow-"))
    )
    is_orange = "orange-audio" in host_low or path_low.startswith("/orange-")
    is_anis = "anisfm" in host_low or "anis." in host_low

    if is_satfamily and token:
        if allow_single_expansion or "playlist" in path_low:
            remote = _call_remote_generator("https://gen.satfamily.xyz/api/generate", u)
            if remote:
                return remote, "SatFamily"
            host_base = base_origin if "stereofm" in host_low or "satfamily" in host_low else "http://stereofm.live"
            entries = [
                {"name": nm, "url": "%s/%s/mpegts?token=%s#" % (host_base, ep, token), "group": "", "logo": ""}
                for nm, ep in SATFAMILY_CHANNELS
            ]
            return entries, "SatFamily"

    if is_orange and token:
        if allow_single_expansion or "playlist" in path_low:
            remote = _call_remote_generator("https://gen.orange-audio.top/api/yearly-generate", u)
            if remote:
                return remote, "Orange"
            host_base = base_origin if "orange" in host_low else "http://radio.orange-audio.top"
            entries = [
                {"name": nm, "url": "%s/%s/mpegts?token=%s" % (host_base, ep, token), "group": "", "logo": ""}
                for nm, ep in ORANGE_CHANNELS
            ]
            return entries, "Orange"

    if is_anis and token and allow_single_expansion:
        host_base = base_origin if "anis" in host_low else "http://radio.anisfm.vip"
        entries = [
            {"name": nm, "url": "%s/%s?token=%s" % (host_base, ep, token), "group": "", "logo": ""}
            for nm, ep in ANIS_CHANNELS
        ]
        return entries, "Anis FM"

    return None, ""


def entries_to_m3u(entries, provider=""):
    lines = [u"#EXTM3U"]
    grp = to_text(provider or "")
    for e in entries or ():
        nm = to_text(e.get("name", "")).strip()
        u = to_text(e.get("url", "")).strip()
        if not nm or not u:
            continue
        g = to_text(e.get("group", "") or grp).replace('"', "")
        nm_attr = nm.replace('"', "")
        if g:
            lines.append(u'#EXTINF:-1 tvg-id="" tvg-name="%s" tvg-logo="" group-title="%s",%s' % (nm_attr, g, nm))
        else:
            lines.append(u"#EXTINF:-1,%s" % nm)
        lines.append(u)
    return u"\n".join(lines) + u"\n"


def generate_m3u_from_input(raw_input, folder_name=""):
    """Expand a provider link/token or normalize pasted links/M3U into a clean M3U playlist with canonical names."""
    text = to_text(raw_input or "").strip()
    if not text:
        raise ValueError(T("Paste a link or links"))
    if store.valid_url(text) and "\n" not in text:
        entries, prov_folder = generate_entries_from_link(text, allow_single_expansion=True)
        if entries:
            fname = store.clean_text(folder_name, 60) or prov_folder
            return {
                "folder_name": fname,
                "provider": prov_folder,
                "count": len(entries),
                "m3u": entries_to_m3u(entries, provider=prov_folder),
            }
        # Try fetching as a playlist URL
        kind, body = fetch_source(text)
        if kind == "text" and body:
            entries = parse_any(body, folder_name=folder_name)
            fname = store.clean_text(folder_name, 60) or infer_source_folder_name(entries, url=text)
            return {
                "folder_name": fname,
                "provider": _detect_provider(url=text, folder_name=fname),
                "count": len(entries),
                "m3u": entries_to_m3u(entries, provider=fname),
            }
    entries = parse_any(text, folder_name=folder_name)
    entries = [e for e in entries if store.valid_url(e.get("url"))]
    if not entries:
        raise ValueError(T("No http/https links found in the source"))
    fname = store.clean_text(folder_name, 60) or infer_source_folder_name(entries)
    return {
        "folder_name": fname,
        "provider": _detect_provider(folder_name=fname),
        "count": len(entries),
        "m3u": entries_to_m3u(entries, provider=fname),
    }


def import_source(name, url=None, text=None, parent="", prune=True, refresh=False):
    if bool(url) == bool(text):
        raise ValueError(T("Give a link or paste text, not both"))
    name = store.clean_text(name, 60)
    parent_folder = store.get_folder(parent) if parent else None
    if parent and not parent_folder:
        raise KeyError(parent)
    parent_name = parent_folder.get("name", "") if parent_folder else ""
    grand_name = ""
    if parent_folder and parent_folder.get("parent"):
        gf = store.get_folder(parent_folder.get("parent"))
        grand_name = gf.get("name", "") if gf else ""

    context_folder = name or parent_name
    context_parent = parent_name if name else grand_name

    source = {"type": "url", "url": url} if url else {"type": "text"}
    gen_entries, gen_folder = (None, "")
    if url:
        # Check if this is a SatFamily / Orange playlist link that can be generated directly
        gen_entries, gen_folder = generate_entries_from_link(url, allow_single_expansion=False)
        if gen_entries:
            kind, body = "generated", ""
        else:
            try:
                kind, body = fetch_source(url)
            except EnvironmentError:
                # If direct fetch failed (e.g. Cloudflare 403 on stereofm.live or offline tokenized stream),
                # try full generator expansion before falling back to single stream.
                gen_entries, gen_folder = generate_entries_from_link(url, allow_single_expansion=True)
                if gen_entries:
                    kind, body = "generated", ""
                elif not refresh and not _looks_like_playlist_url(url):
                    kind, body = "stream", None
                else:
                    raise
        if kind == "stream":
            if refresh:
                raise ValueError(T("This link is a single channel, not a playlist"))
            # If the user explicitly gave a new folder name in the Import dialog, create/use that folder
            if name and name.lower() != parent_name.lower():
                entry_name = smart_stream_name("", url=url, folder_name=name, parent_name=parent_name)
                entries = [{"name": entry_name, "url": url, "group": "", "logo": ""}]
                source = {"type": "text", "key": "text:" + to_text(name).lower()}
                res = store.apply_import(name, entries, source, parent=parent, prune=False)
                res["total"] = 1
                return res
            return add_single("", url, parent)
    else:
        body = to_text(text)
        if _HLS.search(body):
            raise ValueError(T("This is the content of a stream playlist; paste its link instead"))
    if gen_entries is not None:
        entries = gen_entries
        if not name and not parent and gen_folder:
            name = gen_folder
    else:
        if len(body) > MAX_BYTES:
            raise ValueError(T("The text is too large"))
        entries = parse_any(body, folder_name=context_folder, parent_name=context_parent)
    entries = [e for e in entries if store.valid_url(e["url"])]
    if not entries:
        raise ValueError(T("No http/https links found in the source"))
    if len(entries) > 2000:
        raise ValueError(T("Too many channels (more than 2000)"))

    # If the user selected an existing 'Inside folder' (parent) and left 'Folder name' blank (or typed the same name
    # as the parent folder), import directly into that parent folder instead of creating a redundant 'Imported' child folder.
    into_parent = bool(parent and (not name or name.lower() == parent_name.lower()))
    if not name:
        name = parent_name if into_parent else infer_source_folder_name(entries, url=url)
    if text:
        source["key"] = "text:" + to_text(name).lower()
        if not refresh:
            prune = False
    res = store.apply_import(name, entries, source, parent=parent, prune=prune, into_parent=into_parent)
    res["total"] = len(entries)
    return res


def refresh_folder(fid, prune=True):
    f = store.get_folder(fid)
    if not f or not f.get("source") or f["source"].get("type") != "url":
        raise ValueError(T("This folder was not imported from a link"))
    return import_source(f["name"], url=f["source"]["url"], parent=f.get("parent", ""), prune=prune, refresh=True)


def source_folder_of(stream):
    for p in reversed(store.folder_path((stream or {}).get("folder", ""))):
        f = store.get_folder(p["id"]) or {}
        if (f.get("source") or {}).get("type") == "url":
            return f["id"]
    return None


_check_lock = threading.Lock()
_check_control = threading.Lock()
_check_epoch = [0]


def cancel_link_checks(wait_for_exit=False):
    with _check_control:
        _check_epoch[0] += 1
    if wait_for_exit:
        if acquire(_check_lock, 3.0):
            _check_lock.release()
            return True
        return False
    return True


def _has_pcm_wav(raw):
    """A WAV header alone is not evidence of decoded audio."""
    if len(raw) < 12 or raw[:4] not in (b"RIFF", b"RF64") or raw[8:12] != b"WAVE":
        return False
    pos = 12
    while pos + 8 <= len(raw):
        tag = raw[pos:pos + 4]
        size = struct.unpack(str("<I"), raw[pos + 4:pos + 8])[0]
        pos += 8
        if tag == b"data":
            return len(raw) - pos >= 2 and size != 0
        pos += size + (size & 1)
    return False


def _probe_failure(stderr):
    text = to_text(stderr)
    if re.search(r"matches no streams|does not contain any stream|no audio stream", text, re.I):
        return False, T("The selected audio track was not found")
    match = re.search(r"(?:Server returned|HTTP error|HTTP[^\n]*?error)[^\n]*?\b([45][0-9]{2})\b", text, re.I)
    if match:
        code = int(match.group(1))
        if code in (401, 403):
            return None, T("Access refused; the link may need a fresh token")
        if code in (404, 410):
            return False, T("Unavailable now (HTTP %d)", code)
        return None, T("The server could not confirm audio (HTTP %d)", code)
    if re.search(r"Unknown (decoder|encoder|input format)|[Dd]ecoder.*not found|[Ee]ncoder.*not found|"
                 r"not a suitable output format|[Uu]nrecognized option|[Oo]ption .* not found|[Pp]rotocol not found", text):
        return None, T("This receiver could not verify the audio format")
    if re.search(r"Invalid data found when processing input|moov atom not found|could not find codec parameters", text, re.I):
        return None, T("No decodable audio was received during this check")
    return None, T("Audio was not confirmed; try again or play the channel")


def check_link(url, user_agent="", timeout=12, audio_track=0, should_abort=None, stable_seconds=0):
    if not store.valid_url(url):
        return False, T("Invalid link")
    from . import engine
    ff = engine.which("ffmpeg")
    if not ff:
        return None, T("ffmpeg is needed to verify audio; playback may still work")
    try:
        track = int(audio_track or 0)
        seconds = float(timeout)
        if not 0 <= track <= 15 or not 0 < seconds <= 60:
            raise ValueError()
    except (TypeError, ValueError, OverflowError):
        return False, T("Invalid link")
    if not _check_lock.acquire(False):
        return None, T("Another link check is running; try again shortly")
    process = None
    with _check_control:
        epoch = _check_epoch[0]

    def cancelled():
        with _check_control:
            changed = epoch != _check_epoch[0]
        return changed or bool(should_abort and should_abort())

    try:
        if cancelled():
            return None, T("Check cancelled for playback")
        args = [ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-threads", "1"]
        args += engine.stream_input_args(url, user_agent, radio=bool(stable_seconds))
        args += ["-map", "0:a:%d" % track, "-vn", "-sn", "-dn", "-threads", "1",
                 "-ac", "1", "-ar", "8000", "-c:a", "pcm_s16le"]
        if stable_seconds:
            duration = max(2.5, min(5.0, float(stable_seconds)))
            args += ["-t", "%.1f" % duration]
        else:
            args += ["-frames:a", "1"]
        args += ["-f", "wav", "pipe:1"]
        with tempfile.TemporaryFile() as audio, tempfile.TemporaryFile() as errors:
            process = popen(args, stdin=DEVNULL, stdout=audio, stderr=errors)
            deadline = monotonic() + seconds
            while process.poll() is None:
                if cancelled():
                    return None, T("Check cancelled for playback")
                if monotonic() >= deadline:
                    return None, T("The check timed out; the link may still play")
                if audio.tell() > 512 * 1024 or errors.tell() > 256 * 1024:
                    return None, T("Audio was not confirmed; try again or play the channel")
                time.sleep(0.05)
            if cancelled():
                return None, T("Check cancelled for playback")
            audio.seek(0)
            raw = audio.read(512 * 1024)
            if process.returncode == 0 and _has_pcm_wav(raw):
                if stable_seconds and len(raw) < 8000 * 2 * (duration - 0.5):
                    return None, T("Audio decoded too briefly to verify stability")
                return True, T("Audio decoded")
            size = errors.tell()
            errors.seek(max(0, size - 32768))
            return _probe_failure(errors.read())
    except EnvironmentError:
        return None, T("Could not start the audio check on this receiver")
    finally:
        if process is not None:
            if process.poll() is None:
                try:
                    process.kill()
                except EnvironmentError:
                    pass
            try:
                wait(process, 2.0)
            except (TimeoutExpired, EnvironmentError):
                pass
        _check_lock.release()
