# -*- coding: utf-8 -*-
"""Turn a source (playlist link, pasted M3U, or a list of links) into library entries.

Supported:
  * M3U / M3U8 playlists (#EXTINF with group-title; provider artwork is ignored)
  * plain text: one link per line, optionally "Name | link", "Name, link" or "Name link"
  * a JSON array / {"streams": [...]} of {"name","url"[,"group"]}
Only http/https links are kept."""
from __future__ import division
from contextlib import closing
import json
import re
import struct
import tempfile
import threading
import time

from .compat import (DEVNULL, Request, TimeoutExpired, acquire, http_client, monotonic, popen, wait,
                     to_text, unquote, urlopen, urlopen_verified, urlsplit)

from . import store
from .i18n import T

MAX_BYTES = 8 * 1024 * 1024
_ATTR = re.compile(r'([\w\-]+)="([^"]*)"')
_URL = re.compile(r"https?://\S+", re.I)


def queue_picons(folder=None):
    """Compatibility entry point: provider artwork is intentionally ignored."""
    return 0


HEAD_BYTES = 4096
READ_SECONDS = 30            # a playlist arrives in a few seconds; a link that keeps sending is a stream
_HLS = re.compile(r"^#EXT-X-(TARGETDURATION|STREAM-INF|MEDIA-SEQUENCE)", re.M | re.I)


def looks_like_stream(head, ctype=""):
    """True when the first bytes / content type are audio or video rather than a playlist (MPEG-TS, MP3/AAC, Ogg...),
    or an HLS playlist, which is ONE channel (its lines are pieces of the stream, not channels)."""
    ctype = (ctype or "").lower()
    if not any(p in ctype for p in ("mpegurl", "scpls", "x-pls")) and ctype.startswith(("audio/", "video/", "application/ogg")):
        return True
    b = head[:512]
    ts = len(head) >= 377 and head[0:1] == head[188:189] == head[376:377] == b"\x47"     # MPEG-TS: 0x47 every 188 bytes
    if ts or b.startswith((b"ID3", b"OggS", b"fLaC", b"RIFF")):
        return True
    if len(b) >= 2 and b[:1] == b"\xff" and (bytearray(b[:2])[1] & 0xE0) == 0xE0:   # MP3 / ADTS frame sync
        return True
    if b[4:8] == b"ftyp" or b"\x00" in b:
        return True
    try:
        text = head.decode("utf-8", "replace")
    except Exception:
        return False
    return bool(_HLS.search(text))


def _decode(raw):
    for enc in ("utf-8-sig", "cp1256", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


class _ReadDeadline(ValueError):
    pass


class _DeadlineReader(object):
    """Bound the entire HTTP body read with a monotonic deadline."""
    def __init__(self, response, seconds, timeout):
        self.response = response
        self.deadline = monotonic() + seconds
        self.timeout = timeout
        self.read1 = getattr(response, "read1", response.read)
        self.sock = None
        pending, seen = [response], set()
        while pending:
            obj = pending.pop()
            if id(obj) in seen:
                continue
            seen.add(id(obj))
            if callable(getattr(obj, "settimeout", None)):
                self.sock = obj
                break
            for name in ("fp", "raw", "_sock", "sock"):
                child = getattr(obj, name, None)
                if child is not None and len(seen) < 24:
                    pending.append(child)

    def read(self, size):
        remaining = self.deadline - monotonic()
        if remaining <= 0:
            raise _ReadDeadline(T("The link keeps sending data; it does not look like a playlist"))
        if self.sock is not None:
            try:
                self.sock.settimeout(max(0.001, min(self.timeout, remaining)))
            except (EnvironmentError, ValueError):
                self.sock = None
        return self.read1(size)


def fetch_source(url, timeout=20):
    """('stream', None) when the link is itself a channel (audio, MPEG-TS, HLS), else ('text', the playlist text)."""
    if not store.valid_url(url):
        raise ValueError(T("The link must start with http or https"))
    req = Request(url, headers={"User-Agent": store.DEFAULT_UA, "Accept": "*/*"})
    try:
        r = urlopen_verified(req, timeout=timeout)
    except http_client.HTTPException as e:     # "ICY 200 OK": a SHOUTcast radio answers like this
        if "ICY" in to_text(e):
            return "stream", None
        raise IOError(to_text(e))
    with closing(r):
        if looks_like_stream(b"", r.headers.get("Content-Type", "")):
            return "stream", None
        read = _DeadlineReader(r, READ_SECONDS, timeout).read
        raw = b""
        while len(raw) < HEAD_BYTES:
            chunk = read(HEAD_BYTES - len(raw))
            if not chunk:
                break
            raw += chunk
        if looks_like_stream(raw, r.headers.get("Content-Type", "")):
            return "stream", None
        while True:
            chunk = read(65536)
            if not chunk:
                break
            raw += chunk
            if len(raw) > MAX_BYTES:
                raise ValueError(T("The file is too large"))
    return "text", _decode(raw)


def fetch_text(url, timeout=20):
    kind, text = fetch_source(url, timeout)
    if kind != "text":
        raise ValueError(T("This link is a single channel, not a playlist"))
    return text


def name_from_url(url):
    p = urlsplit(to_text(url))
    parts = [to_text(unquote(str(x))) for x in p.path.split("/") if x and x.lower() not in ("mpegts", "live", "stream", "index.m3u8")]
    return (parts[-1] if parts else p.netloc).replace("_", " ").strip()[:80] or p.netloc


def parse_m3u(text):
    out, pending = [], None
    for line in to_text(text).splitlines():
        line = line.strip()
        if not line:
            continue
        if line.upper().startswith("#EXTINF"):
            quote, split = None, -1
            for index, char in enumerate(line):
                if char in ('"', "'"):
                    if quote == char:
                        quote = None
                    elif quote is None:
                        quote = char
                elif char == ',' and quote is None:
                    split = index
                    break
            head, title = (line[:split], line[split + 1:]) if split >= 0 else (line, '')
            attrs = dict(_ATTR.findall(head))
            pending = {"name": title.strip() or attrs.get("tvg-name", ""), "group": attrs.get("group-title", ""),
                       "logo": ""}
        elif line.upper().startswith("#EXTGRP:") and pending is not None:
            pending["group"] = pending.get("group") or line.split(":", 1)[1].strip()
        elif line.startswith("#"):
            continue
        elif _URL.match(line):
            e = pending or {}
            out.append({"name": e.get("name") or name_from_url(line), "url": line, "group": e.get("group", ""),
                        "logo": e.get("logo", "")})
            pending = None
    return out


def parse_links(text):
    out = []
    for line in to_text(text).splitlines():
        line = line.strip()
        m = _URL.search(line)
        if not m or line.startswith("#"):
            continue
        url = m.group(0).rstrip(",;|)")
        label = (line[:m.start()] + u" " + line[m.end():]).strip(u" \t|,;-\u2013\u2014:=\"'")
        out.append({"name": label or name_from_url(url), "url": url, "group": ""})
    return out


def parse_json(text):
    data = json.loads(to_text(text))
    items = data.get("streams", data.get("channels", [])) if isinstance(data, dict) else data
    out = []
    for it in items if isinstance(items, list) else []:
        if isinstance(it, dict) and it.get("url"):
            out.append({"name": it.get("name") or name_from_url(to_text(it["url"])), "url": to_text(it["url"]),
                        "group": it.get("group", ""), "logo": ""})
    return out


def parse_any(text):
    t = to_text(text).lstrip(u"\ufeff \t\r\n")
    if t.startswith(("{", "[")):
        try:
            return parse_json(t)
        except ValueError:
            pass
    if "#EXTM3U" in t[:200].upper() or "#EXTINF" in t.upper():
        return parse_m3u(t)
    return parse_links(t)


def add_single(name, url, parent=""):
    """The link is one channel: put it straight into `parent` (no folder for one channel); never twice."""
    if parent and not store.get_folder(parent):
        raise KeyError(parent)
    for s in store.list_streams():
        if s.get("folder", "") == (parent or "") and s.get("url") == url:
            return {"folder": parent or "", "stream": s["id"], "added": 0, "updated": 0, "removed": 0, "total": 1,
                    "single": True}
    s = store.add_stream({"name": name or name_from_url(url), "url": url, "folder": parent or ""})
    return {"folder": parent or "", "stream": s["id"], "added": 1, "updated": 0, "removed": 0, "total": 1, "single": True}


def import_source(name, url=None, text=None, parent="", prune=True, refresh=False):
    if bool(url) == bool(text):
        raise ValueError(T("Give a link or paste text, not both"))
    source = {"type": "url", "url": url} if url else {"type": "text"}
    if url:
        kind, body = fetch_source(url)
        if kind == "stream":
            if refresh:
                raise ValueError(T("This link is a single channel, not a playlist"))
            return add_single(name, url, parent)
    else:
        body = to_text(text)
        if _HLS.search(body):
            raise ValueError(T("This is the content of a stream playlist; paste its link instead"))
    if len(body) > MAX_BYTES:
        raise ValueError(T("The text is too large"))
    entries = parse_any(body)
    entries = [e for e in entries if store.valid_url(e["url"])]
    if not entries:
        raise ValueError(T("No http/https links found in the source"))
    if len(entries) > 2000:
        raise ValueError(T("Too many channels (more than 2000)"))
    if not name:
        name = name_from_url(url) if url else "Imported"
    if text:
        source["key"] = "text:" + to_text(name).lower()
    res = store.apply_import(name, entries, source, parent=parent, prune=prune)
    res["total"] = len(entries)
    return res


def refresh_folder(fid, prune=True):
    f = store.get_folder(fid)
    if not f or not f.get("source") or f["source"].get("type") != "url":
        raise ValueError(T("This folder was not imported from a link"))
    return import_source(f["name"], url=f["source"]["url"], parent=f.get("parent", ""), prune=prune, refresh=True)


def source_folder_of(stream):
    for p in reversed(store.folder_path((stream or {}).get("folder", ""))):
        f = store.get_folder(p["id"]) or {}
        if (f.get("source") or {}).get("type") == "url":
            return f["id"]
    return None


_check_lock = threading.Lock()
_check_control = threading.Lock()
_check_epoch = [0]


def cancel_link_checks(wait_for_exit=False):
    with _check_control:
        _check_epoch[0] += 1
    if wait_for_exit:
        if acquire(_check_lock, 3.0):
            _check_lock.release()
            return True
        return False
    return True


def _has_pcm_wav(raw):
    """A WAV header alone is not evidence of decoded audio."""
    if len(raw) < 12 or raw[:4] not in (b"RIFF", b"RF64") or raw[8:12] != b"WAVE":
        return False
    pos = 12
    while pos + 8 <= len(raw):
        tag = raw[pos:pos + 4]
        size = struct.unpack(str("<I"), raw[pos + 4:pos + 8])[0]
        pos += 8
        if tag == b"data":
            return len(raw) - pos >= 2 and size != 0
        pos += size + (size & 1)
    return False


def _probe_failure(stderr):
    text = to_text(stderr)
    if re.search(r"matches no streams|does not contain any stream|no audio stream", text, re.I):
        return False, T("The selected audio track was not found")
    match = re.search(r"(?:Server returned|HTTP error|HTTP[^\n]*?error)[^\n]*?\b([45][0-9]{2})\b", text, re.I)
    if match:
        code = int(match.group(1))
        if code in (401, 403):
            return None, T("Access refused; the link may need a fresh token")
        if code in (404, 410):
            return False, T("Unavailable now (HTTP %d)", code)
        return None, T("The server could not confirm audio (HTTP %d)", code)
    if re.search(r"Unknown (decoder|encoder|input format)|[Dd]ecoder.*not found|[Ee]ncoder.*not found|"
                 r"not a suitable output format|[Uu]nrecognized option|[Oo]ption .* not found|[Pp]rotocol not found", text):
        return None, T("This receiver could not verify the audio format")
    if re.search(r"Invalid data found when processing input|moov atom not found|could not find codec parameters", text, re.I):
        return None, T("No decodable audio was received during this check")
    return None, T("Audio was not confirmed; try again or play the channel")


def check_link(url, user_agent="", timeout=12, audio_track=0, should_abort=None, stable_seconds=0):
    if not store.valid_url(url):
        return False, T("Invalid link")
    from . import engine
    ff = engine.which("ffmpeg")
    if not ff:
        return None, T("ffmpeg is needed to verify audio; playback may still work")
    try:
        track = int(audio_track or 0)
        seconds = float(timeout)
        if not 0 <= track <= 15 or not 0 < seconds <= 60:
            raise ValueError()
    except (TypeError, ValueError, OverflowError):
        return False, T("Invalid link")
    if not _check_lock.acquire(False):
        return None, T("Another link check is running; try again shortly")
    process = None
    with _check_control:
        epoch = _check_epoch[0]

    def cancelled():
        with _check_control:
            changed = epoch != _check_epoch[0]
        return changed or bool(should_abort and should_abort())

    try:
        if cancelled():
            return None, T("Check cancelled for playback")
        args = [ff, "-hide_banner", "-loglevel", "error", "-nostdin", "-threads", "1"]
        args += engine.stream_input_args(url, user_agent, radio=bool(stable_seconds))
        args += ["-map", "0:a:%d" % track, "-vn", "-sn", "-dn", "-threads", "1",
                 "-ac", "1", "-ar", "8000", "-c:a", "pcm_s16le"]
        if stable_seconds:
            duration = max(2.5, min(5.0, float(stable_seconds)))
            args += ["-t", "%.1f" % duration]
        else:
            args += ["-frames:a", "1"]
        args += ["-f", "wav", "pipe:1"]
        with tempfile.TemporaryFile() as audio, tempfile.TemporaryFile() as errors:
            process = popen(args, stdin=DEVNULL, stdout=audio, stderr=errors)
            deadline = monotonic() + seconds
            while process.poll() is None:
                if cancelled():
                    return None, T("Check cancelled for playback")
                if monotonic() >= deadline:
                    return None, T("The check timed out; the link may still play")
                if audio.tell() > 512 * 1024 or errors.tell() > 256 * 1024:
                    return None, T("Audio was not confirmed; try again or play the channel")
                time.sleep(0.05)
            if cancelled():
                return None, T("Check cancelled for playback")
            audio.seek(0)
            raw = audio.read(512 * 1024)
            if process.returncode == 0 and _has_pcm_wav(raw):
                if stable_seconds and len(raw) < 8000 * 2 * (duration - 0.5):
                    return None, T("Audio decoded too briefly to verify stability")
                return True, T("Audio decoded")
            size = errors.tell()
            errors.seek(max(0, size - 32768))
            return _probe_failure(errors.read())
    except EnvironmentError:
        return None, T("Could not start the audio check on this receiver")
    finally:
        if process is not None:
            if process.poll() is None:
                try:
                    process.kill()
                except EnvironmentError:
                    pass
            try:
                wait(process, 2.0)
            except (TimeoutExpired, EnvironmentError):
                pass
        _check_lock.release()
