# -*- coding: utf-8 -*-
"""UltraAudio - play an IP audio commentary over a live channel, with video/audio delay."""
from __future__ import division
import os
import time

from Plugins.Plugin import PluginDescriptor

from . import __version__
from .compat import native

_ui_error = ""


def _local_ip():
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except EnvironmentError:
        return "RECEIVER-IP"


def sessionstart(reason, session=None, **kwargs):
    if reason != 0:
        return
    try:
        from . import ctl, engine, importer, store, webui
        try:
            store.reset_session_offsets()
        except Exception as e:
            engine.log("saved offsets check failed: %s" % e)
        engine.kill_stale()
        engine.warm_up()
        try:
            from . import presets
            # Each seed is independent: one failure must not skip the radio seeds after it.
            for step in ("install_foxfm", "install_provider_order", "install_radio", "install_quran_direct",
                         "install_radio_expansion", "install_radio_link_repairs",
                         "install_radio_107", "install_radio_complete",
                         "install_sayed_saeed", "install_shaarawi", "install_turkish_radio",
                         "install_radio_folder_order"):
                try:
                    getattr(presets, step)()
                except Exception as e:
                    engine.log("bundled preset %s failed: %s" % (step, e))
        except Exception as e:
            engine.log("bundled presets could not be loaded: %s" % e)
        from . import guide, livefootball
        guide.warm_up()
        livefootball.SCORES.warm_up()
        ctl.get().attach(session)
        webui.start()
        from . import hotkey
        hotkey.install(main)
    except Exception as e:
        import traceback
        try:
            from .engine import log
            log("sessionstart failed: %s" % traceback.format_exc())
        except Exception:
            pass


def autostart(reason, **kwargs):
    if reason == 1:
        try:
            from . import ctl, webui, receivertime
            receivertime.cancel()
            ctl.get().shutdown()
            webui.stop()
        except Exception:
            pass


def main(session, **kwargs):
    global _ui_error
    try:
        setup = '/tmp/ultraaudio-setup.status'
        try:
            with open(setup) as handle:
                phase = handle.read(32).strip()
            fresh = 0 <= time.time() - os.path.getmtime(setup) < 900
        except EnvironmentError:  # Python 2 (DreamOS) raises IOError, not OSError, for a missing file
            phase, fresh = '', False
        if phase == 'failed':
            return _open_repair(session)
        if fresh and phase == 'pending':
            return _open_repair(session, pending=True)
        from .screen import UltraAudioScreen
        try:
            from . import receivertime
            receivertime.start(session)
        except Exception as exc:
            from .engine import log
            log('receiver time startup unavailable: %s' % exc)
        session.openWithCallback(lambda *result: _closed(session, *result), UltraAudioScreen, _local_ip())
    except Exception:
        import traceback
        _ui_error = traceback.format_exc()
        try:
            from .engine import log
            log("open screen failed: %s" % _ui_error)
        except Exception:
            pass
        return _open_repair(session, error=_ui_error.strip().splitlines()[-1])


def _open_repair(session, pending=False, error=''):
    # Independent of store, engine, translations and the main screen imports.
    # Restore session.in_exec if an aborted instantiateDialog cleared it.
    try:
        if hasattr(session, 'in_exec') and not session.in_exec:
            session.in_exec = True
    except Exception:
        pass
    try:
        from .repairui import ComponentRepairScreen
        session.open(ComponentRepairScreen, pending=pending, error=error)
    except Exception:
        try:
            if hasattr(session, 'in_exec') and not session.in_exec:
                session.in_exec = True
            from Screens.MessageBox import MessageBox
            msg = 'Ultra Audio: repair screen unavailable. Run: sh /usr/lib/enigma2/python/Plugins/Extensions/UltraAudio/deps.sh --install'
            try:
                from .compat import native
                msg = native(msg)
            except Exception:
                pass
            session.open(MessageBox, msg, MessageBox.TYPE_ERROR)
        except Exception:
            pass


def _closed(session, result=None, *rest):
    if result == "reopen":
        main(session)


def Plugins(**kwargs):
    desc = native("IP audio commentary with delay (%s)" % __version__)
    return [
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart),
        PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart),
        PluginDescriptor(name=native("Ultra Audio"), description=desc, where=PluginDescriptor.WHERE_PLUGINMENU,
                         icon=native("plugin.png"), fnc=main),
        PluginDescriptor(name=native("Ultra Audio"), description=desc, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
    ]
