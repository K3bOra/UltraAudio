# -*- coding: utf-8 -*-
"""Receiver channel identity and local picons; no network access or audio-name guessing."""
from __future__ import division
import hashlib
import os
import re

from .compat import fullmatch, to_bytes, to_text

PICON_DIR = '/media/hdd/picon'
MAX_PICON = 2 * 1024 * 1024


# A bouquet / folder reference (radio mode, an empty list, a service list being browsed) is not a channel: Enigma2
# then reports its path, e.g. FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet, as the "name".
_NOT_A_CHANNEL = re.compile(r'FROM\s+BOUQUET|ORDER\s+BY|userbouquet\.|bouquets\.(?:tv|radio)|FROM\s+SATELLITES|'
                            r'FROM\s+PROVIDERS|\bWHERE\b', re.I)


def is_channel(reference, name=''):
    """False for folder / bouquet references and for names that are such a path."""
    reference, name = to_text(reference or ''), to_text(name or '')
    parts = reference.split(':')
    if len(parts) > 1 and fullmatch(r'[0-9A-Fa-f]+', parts[1] or '') and int(parts[1], 16) & 0x7 == 0x7:
        return False                                   # flags: isDirectory | mustDescent | canDescent
    return not (_NOT_A_CHANNEL.search(reference) or _NOT_A_CHANNEL.search(name) or name.startswith('/'))


def snapshot(reference, name):
    reference = to_text(reference or '')
    name = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', to_text(name or '')).strip()[:200]
    if not is_channel(reference, name):
        reference, name = '', ''                      # show "no TV channel" rather than a bouquet query
    token = hashlib.sha256(to_bytes(reference)).hexdigest()[:24] if reference else ''
    return {'reference': reference, 'name': name, 'token': token,
            'icon': '/tv-picon/' + token if token else '/tv-picon/default'}


def picon_file(reference, name='', directory=None):
    directory = PICON_DIR if directory is None else directory
    root = os.path.realpath(directory)
    parts = to_text(reference or '').split(':')[:10]
    candidates = []
    if len(parts) == 10 and all(fullmatch(r'[0-9A-Fa-f]+', p) for p in parts):
        key = '_'.join(parts)
        candidates.extend([key, key.upper(), key.lower()])
    # Name-based picon packs are also local; never accept path separators.
    clean = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', to_text(name or '')).strip()
    if clean and len(clean) <= 200 and not any(c in clean for c in ('/', '\\')) and clean not in ('.', '..'):
        candidates.extend([clean, clean.replace(' ', '_'), clean.lower(), clean.lower().replace(' ', '')])
    seen = set()
    for key in candidates:
        if key in seen:
            continue
        seen.add(key)
        for ext in ('.png', '.jpg', '.jpeg'):
            path = os.path.realpath(os.path.join(root, to_text(key) + ext))
            if not path.startswith(root.rstrip(os.sep) + os.sep):
                continue
            try:
                if os.path.isfile(path) and os.path.getsize(path) <= MAX_PICON:
                    return path
            except OSError:
                pass
    return None


def read_icon(channel):
    path = picon_file(channel.get('reference', ''), channel.get('name', ''))
    if path is None:
        return None
    try:
        with open(path, 'rb') as handle:
            data = handle.read(MAX_PICON + 1)
        if len(data) > MAX_PICON:
            return None
        if data.startswith(b'\x89PNG\r\n\x1a\n'):
            return data, 'image/png'
        if data.startswith(b'\xff\xd8\xff'):
            return data, 'image/jpeg'
    except EnvironmentError:  # IOError on Python 2
        pass
    return None
