# -*- coding: utf-8 -*-
"""Look of the on-box screen (slim top bar, list on the left, key bar at the bottom; screen.build_skin draws it).

Classic: the original panels. Neon: the same layout and sizes on smoked glass with a crimson -> emerald neon rim and a
soft glow around each panel. Neon only swaps pictures (assets/themes/neon, same pixel sizes, pre-rendered) and text
colours, so it costs the receiver nothing extra. The Stadium and Daylight looks were removed."""
from __future__ import division
import os

from . import store
from .compat import native
from .i18n import RTL, T, lang
from .uifont import face as ui_face

THEMES = store.THEMES
DIR = os.path.join(store.ASSETS, "themes")
FONT_DIR = os.path.join(store.ASSETS, "fonts")
MENU_DIR = os.path.join(store.ASSETS, "menu")
UI_DIR = os.path.join(store.ASSETS, "ui")

_FONT_FILES = {
}
_registered = {}


def title(key):
    return T("Neon") if key == "neon" else T("Classic")


def current():
    t = store.get_settings().get("theme", "classic")
    return t if t in THEMES else "classic"


def face(name):
    """Font face to use for one of our faces: the face itself once registered, else the skin's own "Regular"."""
    if name in ("Regular", "UltraAudioUI") or lang() in RTL:
        return ui_face()
    if name not in _registered:
        ok = False
        path = os.path.join(FONT_DIR, _FONT_FILES.get(name, ""))
        if os.path.isfile(path):
            try:
                from enigma import addFont
                try:
                    addFont(native(path), native(name), 100, 0)
                except TypeError:
                    addFont(native(path), native(name), 100, 0, 0)
                ok = True
            except Exception:
                ok = False
        _registered[name] = ok
    return name if _registered[name] else ui_face()


def uses_own_fonts(th):
    return bool(th.get("faces"))


# ----------------------------------------------------------------------------------------------------- the specs
CARD_W, CARD_H, CARD_ROWS = 480, 812, 9   # narrow, tall settings card: 9 rows


def _classic_menu(folder=None, colors=None, labels=None, glow=None):
    # The settings card: right edge on the bars' right edge (1880), bottom 2px above the bottom key bar (1015).
    x, y = 1880 - CARD_W, 1015 - 2 - CARD_H
    m = _card(x, y, folder or MENU_DIR, {
        "panel": "panel_480x812.png", "hair1": "hair_420x2.png", "hair2": "hair_420x2.png",
        "row": "row_420x66.png", "row_sel": "row_420x66_selected.png",
        "sw_on": "set_sw_on_64x32.png", "sw_off": "set_sw_off_64x32.png"},
        colors=colors or {"sel": 0xFFFFFF, "name": 0xFFFFFF, "value": 0x00DA7F, "value_sel": 0x00DA7F, "second": 0x00DA7F},
        labels=labels or {"title": "#ffffff", "desc": "#e2eae6", "help": "#ffffff"}, shadow=True)
    if glow:                     # soft neon light around the card, G px bigger on every side (drawn under it)
        m["files"]["glow"] = glow
        px, py, pw, ph = m["panel"]
        m["glow"] = (px - NEON_GLOW, py - NEON_GLOW, pw + 2 * NEON_GLOW, ph + 2 * NEON_GLOW)
    return m


def _card(x, y, folder, files, colors, labels, shadow):
    """Card boxes in FHD design px. Header (menu.py) on the first 84px, then a hair line, the rows, a hair line and
    the help text (94px: up to 4 lines)."""
    w = CARD_W - 60                                   # 30px inner margin on both sides
    list_y = y + 94
    hair2_y = list_y + 66 * CARD_ROWS + 6
    return {"dir": folder, "files": files, "row_w": w, "colors": colors, "labels": labels, "shadow": shadow,
            "panel": (x, y, CARD_W, CARD_H), "hair1": (x + 30, y + 84, w, 2), "list": (x + 30, list_y, w, 66 * CARD_ROWS),
            "hair2": (x + 30, hair2_y, w, 2), "help": (x + 30, hair2_y + 6, w, 94),
            "sizes": {"title": 29, "desc": 20, "help": 20}}


NEON_DIR = os.path.join(DIR, "neon")
NEON_GLOW = 24               # the glow pictures reach this many design px past a panel's edge

CLASSIC = {
    "key": "classic", "mode": "list", "faces": None, "extra": (),
    "pal": {"text": "#FFFFFF", "white": "#FFFFFF", "accent": "#00DA7F", "warn": "#FFE29A", "error": "#FF7075",
            "idle": "#FFFFFF", "muted": "#D1DDD7"},
    "menu": None,
}

# Neon: neutral smoked glass, pure bright white channel names, and the top-left icon's rich green (#00DA7F) for the
# guide line (or playing channel name) and deep crimson red (#ED001B) for the playing channel's guide line.
NEON_PAL = {"text": "#FFFFFF", "white": "#FFFFFF", "accent": "#00DA7F", "warn": "#FFD66B", "error": "#FF5C7A",
            "idle": "#FFFFFF", "muted": "#C3CDC9", "live": "#FF5E66",
            # moving the cursor keeps the exact same row colours
            "title_dim": "#FFFFFF", "accent_hi": "#00DA7F", "muted_hi": "#C3CDC9", "live_hi": "#FF5E66"}


def _neon(th):
    g = NEON_GLOW
    th.update(key="neon", pal=dict(NEON_PAL), cursor_under=True, cursor_margin=10)
    th["pal"].update(row_accent="#00DA7F", row_muted="#C3CDC9")
    th["menu"] = _classic_menu(
        os.path.join(NEON_DIR, "menu"),
        # the focused row lights up: pure white name and a brighter mint value, the other rows a touch softer
        colors={"sel": 0xFFFFFF, "name": 0xFFFFFF, "value": 0x00DA7F, "value_sel": 0x00DA7F, "second": 0x00DA7F},
        labels={"title": "#ffffff", "desc": "#c3cdc9", "help": "#e6ecea"}, glow="glow_card.png")
    # pictures drawn under the panels: (file, x, y, w, h) in FHD design px. The bar glows are cut at the screen edge.
    th["glows"] = (("glow_bar_top.png", 40 - g, 0, 1840 + 2 * g, 89),
                   ("glow_list.png", 40 - g, 64 - g, 600 + 2 * g, 952 + 2 * g),
                   ("glow_bar_bottom.png", 40 - g, 1015 - g, 1840 + 2 * g, 89))
    th["update_glow"] = "glow_update.png"
    return th


def get(key=None):
    key = key or current()
    th = dict(CLASSIC)                   # Stadium and Daylight were removed
    th["pal"] = dict(CLASSIC["pal"], live="#FF5E66")
    p = th["pal"]                         # Classic: the focused row keeps the same colours as the others
    p.update(title_dim=p["text"], accent_hi=p["accent"], muted_hi=p["muted"], live_hi=p["live"],
             row_accent=p["accent"], row_muted=p["muted"])
    th["menu"] = _classic_menu()
    return _neon(th) if key == "neon" else th


def pic(th, name):
    p = os.path.join(DIR, th["key"], name)
    return p if os.path.isfile(p) else os.path.join(UI_DIR, name)
