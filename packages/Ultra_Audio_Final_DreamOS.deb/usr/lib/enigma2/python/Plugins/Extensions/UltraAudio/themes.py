# -*- coding: utf-8 -*-
"""Look of the on-box screen (slim top bar, list on the left, key bar at the bottom; screen.build_skin draws it).

All 4 themes (Classic, Neon, Smoked Glass, Midnight Titanium) bake their soft glow and rim directly
into each panel PNG at native widget dimensions with zero separate glow layers, delivering vivid OSD contrast over live
TV video and instant single-layer cursor speed."""
from __future__ import division
import os

from . import store
from .compat import lru_cache, native
from .i18n import RTL, T, lang
from .uifont import face as ui_face

THEMES = store.THEMES
DIR = os.path.join(store.ASSETS, "themes")
FONT_DIR = os.path.join(store.ASSETS, "fonts")
MENU_DIR = os.path.join(store.ASSETS, "menu")
UI_DIR = os.path.join(store.ASSETS, "ui")

_FONT_FILES = {
}
_registered = {}


def title(key):
    if key == "titanium":
        return T("Midnight Titanium")
    return T("Smoked Glass") if key == "smoke" else T("Neon") if key == "neon" else T("Classic")


def current():
    t = store.get_settings().get("theme", "classic")
    return t if t in THEMES else "classic"


def face(name):
    """Font face to use for one of our faces: the face itself once registered, else the skin's own "Regular"."""
    if name in ("Regular", "UltraAudioUI") or lang() in RTL:
        return ui_face()
    if name not in _registered:
        ok = False
        path = os.path.join(FONT_DIR, _FONT_FILES.get(name, ""))
        if os.path.isfile(path):
            try:
                from enigma import addFont
                try:
                    addFont(native(path), native(name), 100, 0)
                except TypeError:
                    addFont(native(path), native(name), 100, 0, 0)
                ok = True
            except Exception:
                ok = False
        _registered[name] = ok
    return name if _registered[name] else ui_face()


def uses_own_fonts(th):
    return bool(th.get("faces"))


# ----------------------------------------------------------------------------------------------------- the specs
CARD_W, CARD_H, CARD_ROWS = 480, 812, 9   # narrow, tall settings card: 9 rows


def _classic_menu(folder=None, colors=None, labels=None, glow=None):
    # The settings card: right edge on the bars' right edge (1880), bottom 2px above the bottom key bar (1015).
    x, y = 1880 - CARD_W, 1015 - 2 - CARD_H
    m = _card(x, y, folder or MENU_DIR, {
        "panel": "panel_480x812.png", "hair1": "hair_420x2.png", "hair2": "hair_420x2.png",
        "row": "row_420x66.png", "row_sel": "row_420x66_selected.png",
        "sw_on": "set_sw_on_64x32.png", "sw_off": "set_sw_off_64x32.png"},
        colors=colors or {"sel": 0xFFFFFF, "name": 0xFFFFFF, "value": 0x00FF88, "value_sel": 0x00FF88, "second": 0x00FF88},
        labels=labels or {"title": "#ffffff", "desc": "#e2eae6", "help": "#ffffff"}, shadow=True)
    if glow:
        m["files"]["glow"] = glow
        px, py, pw, ph = m["panel"]
        m["glow"] = (px - NEON_GLOW, py - NEON_GLOW, pw + 2 * NEON_GLOW, ph + 2 * NEON_GLOW)
    return m


def _card(x, y, folder, files, colors, labels, shadow):
    """Card boxes in FHD design px. Header (menu.py) on the first 84px, then a hair line, the rows, a hair line and
    the help text (94px: up to 4 lines)."""
    w = CARD_W - 60                                   # 30px inner margin on both sides
    list_y = y + 94
    hair2_y = list_y + 66 * CARD_ROWS + 6
    return {"dir": folder, "files": files, "row_w": w, "colors": colors, "labels": labels, "shadow": shadow,
            "panel": (x, y, CARD_W, CARD_H), "hair1": (x + 30, y + 84, w, 2), "list": (x + 30, list_y, w, 66 * CARD_ROWS),
            "hair2": (x + 30, hair2_y, w, 2), "help": (x + 30, hair2_y + 6, w, 94),
            "sizes": {"title": 29, "desc": 20, "help": 20}}


NEON_DIR = os.path.join(DIR, "neon")
NEON_GLOW = 24
GLOW_SPECS = ()
LIVE_RED = "#FF0000"

CLASSIC = {
    "key": "classic", "mode": "list", "faces": None, "extra": (), "cursor_under": True, "cursor_margin": 0,
    "pal": {"text": "#FFFFFF", "white": "#FFFFFF", "accent": "#00FF88", "warn": "#FFE29A", "error": "#FF7075",
            "idle": "#FFFFFF", "muted": "#D1DDD7"},
    "menu": None,
    "glows": (),
    "update_glow": None,
}

NEON_PAL = {"text": "#FFFFFF", "white": "#FFFFFF", "accent": "#00FFC3", "warn": "#FFD66B", "error": "#FF2498",
            "idle": "#FFFFFF", "muted": "#C8DCE0", "live": LIVE_RED,
            "title_dim": "#FFFFFF", "accent_hi": "#00FFC3", "muted_hi": "#C8DCE0", "live_hi": LIVE_RED}


def _neon(th):
    th.update(key="neon", pal=dict(NEON_PAL), cursor_under=True, cursor_margin=0,
              glows=(), update_glow=None)
    th["pal"].update(row_accent="#00FFC3", row_muted="#C8DCE0")
    th["menu"] = _classic_menu(
        os.path.join(NEON_DIR, "menu"),
        colors={"sel": 0xFFFFFF, "name": 0xFFFFFF, "value": 0x00FFC3, "value_sel": 0xFF55B8, "second": 0x00FFC3},
        labels={"title": "#ffffff", "desc": "#c8dce0", "help": "#e8f6f5"}, glow=None)
    return th


def get(key=None):
    key = key or current()
    th = dict(CLASSIC)
    th["pal"] = dict(CLASSIC["pal"], live=LIVE_RED)
    p = th["pal"]
    p.update(title_dim=p["text"], accent_hi=p["accent"], muted_hi=p["muted"], live_hi=p["live"],
             row_accent=p["accent"], row_muted=p["muted"])
    th["menu"] = _classic_menu(glow=None)
    if key == "smoke":
        th.update(key="smoke", cursor_under=True, cursor_margin=0, picon_separator=True,
                  glows=(), update_glow=None)
        th["pal"].update(accent="#28E8FF", accent_hi="#28E8FF", row_accent="#28E8FF",
                         warn="#FFD166", muted="#D0DFEC", muted_hi="#D0DFEC", row_muted="#D0DFEC")
        th["menu"] = _classic_menu(
            os.path.join(DIR, "smoke", "menu"),
            colors={"sel": 0xFFFFFF, "name": 0xFFFFFF, "value": 0x28E8FF, "value_sel": 0xFFD166, "second": 0x28E8FF},
            labels={"title": "#ffffff", "desc": "#d0dfec", "help": "#e8f0f8"},
            glow=None)
        return th
    if key == "titanium":
        th.update(key="titanium", cursor_under=True, cursor_margin=0, picon_separator=True,
                  glows=(), update_glow=None)
        th["pal"].update(accent="#6ED0FF", accent_hi="#6ED0FF", row_accent="#6ED0FF",
                         warn="#DCEEFF", muted="#B8CADB", muted_hi="#B8CADB", row_muted="#B8CADB")
        th["menu"] = _classic_menu(
            os.path.join(DIR, "titanium", "menu"),
            colors={"sel": 0xFFFFFF, "name": 0xFFFFFF, "value": 0x6ED0FF, "value_sel": 0xD2EAFF, "second": 0x6ED0FF},
            labels={"title": "#ffffff", "desc": "#c4d4e4", "help": "#e6f0fa"},
            glow=None)
        return th
    return _neon(th) if key == "neon" else th


def pic(th, name):
    return _picture(th["key"], name)


@lru_cache(maxsize=512)
def _picture(theme, name):
    p = os.path.join(DIR, theme, name)
    return p if os.path.isfile(p) else os.path.join(UI_DIR, name)
