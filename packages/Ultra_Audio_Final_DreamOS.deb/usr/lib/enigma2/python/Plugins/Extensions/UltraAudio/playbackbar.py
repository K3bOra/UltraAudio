# -*- coding: utf-8 -*-
"""Compact playback controls; uses existing controller, theme PNGs and marker frames."""
import os
import time
from xml.sax.saxutils import escape

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop, ePoint, eSize

from . import ctl, guide, store, themes
from .compat import native
from .engine import log
from .i18n import T, lang
from .motion import PlaybackMarker

WIDTH, HEIGHT = 470, 155
ACTIVE = ('starting', 'playing', 'retrying')
KEY_TWIN_S = 0.6
_dialog = None


def geometry(width, height):
    scale = min(width / 1920.0, height / 1080.0)
    w, h = max(1, int(WIDTH * scale)), max(1, int(HEIGHT * scale))
    return (width - w) // 2, height - h - 2, w, h, scale


def context(st):
    return st.get('stream_id'), st.get('generation'), st.get('tv_service')


def sized_asset(name, width, height):
    """Use offline antialiased artwork at native pixels; avoid receiver scaling."""
    path = os.path.join(store.ASSETS, 'playback', '%s_%dx%d.png' % (name, width, height))
    return path if os.path.isfile(path) else os.path.join(store.ASSETS, 'ui', name + '.png')


def fit_picon(width, height, box_width, box_height):
    """Contain the complete logo, preserving its source aspect ratio."""
    ratio = min(float(box_width) / max(1, width), float(box_height) / max(1, height))
    return max(1, int(round(width * ratio))), max(1, int(round(height * ratio)))


def build_skin(width, height, theme):
    x, y, w, h, scale = geometry(width, height)
    n = lambda v: max(1, int(v * scale))
    parts = ['<screen name="UltraAudioPlaybackBar" position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="#FF000000" title="Ultra Audio" zPosition="10">' % (x, y, w, h)]
    # The original theme card is used at its original FHD size: no new material.
    parts.append('<ePixmap position="0,0" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="0"/>' % (w, h, escape(themes.pic(theme, 'football_panel.png'))))
    parts.append('<widget name="picon" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" transparent="1" zPosition="2"/>' % (n(10), n(8), n(144), n(84)))
    parts.append('<widget name="marker" position="%d,%d" size="%d,%d" alphatest="blend" transparent="1" zPosition="3"/>' % (n(202), n(121), n(66), n(28)))
    for key, xpos in [('1', 34), ('3', 158), ('4', 284), ('6', 408)]:
        path = sized_asset('num_%s' % key, n(28), n(28))
        parts.append('<ePixmap position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="3"/>' % (n(xpos), n(117), n(28), n(28), escape(path)))
    # Original footer dashes, cropped and resized offline, directly below captions.
    for color, xpos in [('yellow', 96), ('green', 221), ('blue', 346)]:
        path = sized_asset('key_' + color, n(28), n(4))
        parts.append('<ePixmap position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="3"/>' %
                     (n(xpos), n(115), n(28), n(4), escape(path)))
    definitions = [('name', 162, 12, 290, 28, 21, 'accent', 'center'),
                   ('guide', 162, 42, 290, 34, 14, 'live', 'center'),
                   ('time', 162, 78, 290, 17, 12, 'muted', 'center'),
                   ('picture_caption', 34, 98, 152, 16, 13, 'muted', 'center'),
                   ('freeze_caption', 201, 98, 68, 16, 13, 'muted', 'center'),
                   ('audio_caption', 284, 98, 152, 16, 13, 'muted', 'center'),
                   ('picture_value', 66, 119, 88, 26, 20, 'accent', 'center'),
                   ('audio_value', 316, 119, 88, 26, 20, 'accent', 'center')]
    for name, px, py, pw, ph, size, color, align in definitions:
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" font="%s;%d" foregroundColor="%s" halign="%s" valign="center" transparent="1" noWrap="%d" zPosition="3"/>' %
                     (name, n(px), n(py), n(pw), n(ph), themes.face('UltraAudioUI'), n(size), theme['pal'][color], align, 0 if name == 'guide' else 1))
    return ''.join(parts) + '</screen>'


def open_bar(session):
    """Called only by the InfoBar's 0 action; never opens the main plugin screen."""
    global _dialog
    if _dialog is not None:
        return 0
    st = ctl.get().status()
    if st.get('state') not in ACTIVE or not st.get('stream_id'):
        return 0
    try:
        def closed(*args):
            global _dialog
            _dialog = None
        _dialog = session.openWithCallback(closed, PlaybackBar)
        return 1
    except Exception as error:
        log('playback bar: %r' % error)
        return 0


class PlaybackBar(Screen):
    def createSummary(self):
        from .frontpanel import UltraAudioFrontSummary
        return UltraAudioFrontSummary

    def __init__(self, session):
        desktop = getDesktop(0).size()
        self.skin = build_skin(desktop.width(), desktop.height(), themes.get())
        Screen.__init__(self, session)
        self._connections, self._texts = [], {}
        self._key_at = {}
        self._pending = {'picture': None, 'audio': None}
        self._closed, self._visible, self._ready = False, False, False
        self._marker, self._picon_path = None, None
        self._target = context(ctl.get().status())
        for name in ('name', 'guide', 'time', 'picture_caption', 'audio_caption', 'freeze_caption', 'picture_value', 'audio_value'):
            self[name] = Label('')
        self['picon'], self['marker'] = Pixmap(), Pixmap()
        self['actions'] = ActionMap(['NumberActions', 'OkCancelActions', 'ColorActions'],
            {'0': self.close, 'cancel': self.close,
             'yellow': self._once('yellow', lambda: self.reset('picture')),
             'blue': self._once('blue', lambda: self.reset('audio')),
             'green': self._once('green', self.freeze),
             'red': self._once('red', self.stop),
             '1': lambda: self.adjust('picture', -1), '3': lambda: self.adjust('picture', 1),
             '4': lambda: self.adjust('audio', -1), '6': lambda: self.adjust('audio', 1)}, -2)
        self._refresh_timer = self._timer(self.refresh)
        self._picture_timer = self._timer(lambda: self.apply('picture'))
        self._audio_timer = self._timer(lambda: self.apply('audio'))
        self.onLayoutFinish.append(self._layout_ready)
        self.onExecBegin.append(self._resume)
        self.onExecEnd.append(self._suspend)
        self.onHide.append(self._suspend)
        self.onClose.append(self._cleanup)

    def _once(self, name, handler):
        # Same make/repeat guard as the main screen: held GREEN must not toggle back.
        def run():
            now = time.time()
            last = self._key_at.get(name, 0.0)
            self._key_at[name] = now
            if 0.0 <= now - last < KEY_TWIN_S:
                return
            try:
                handler()
            finally:
                self._key_at[name] = time.time()
        return run

    def freeze(self):
        if self._valid(ctl.get().status()):
            ctl.get().toggle_pause()
            self.refresh()

    def stop(self):
        if self._valid(ctl.get().status()):
            ctl.get().stop()
            self.close()

    def _timer(self, callback):
        timer = eTimer()
        if hasattr(timer, 'callback'):
            timer.callback.append(callback)
        else:
            self._connections.append(timer.timeout.connect(callback))
        return timer

    def _layout_ready(self):
        self._ready = True
        desktop = getDesktop(0).size()
        scale = geometry(desktop.width(), desktop.height())[4]
        w, h = max(1, int(66 * scale)), max(1, int(28 * scale))
        frames = tuple(LoadPixmap(native(sized_asset('eq_%d' % i, w, h))) for i in range(8))
        still = LoadPixmap(native(sized_asset('eq_idle', w, h)))
        self._marker = PlaybackMarker(self._timer, frames if all(frames) else (), still,
            self._marker_status, self['marker'].instance.setPixmap, lambda row: None,
            self['marker'].show, self['marker'].hide)
        self._resume()

    def _marker_status(self):
        engine = ctl.get().engine
        if not engine.lock.acquire(False):
            return None
        try:
            return {'state': engine.state, 'stream_id': engine.stream.get('id') if engine.stream else None}
        finally:
            engine.lock.release()

    def _resume(self):
        if self._closed or not self._ready:
            return
        self._visible = True
        self.refresh()
        if not self._closed:
            self._refresh_timer.start(750, False)

    def _suspend(self):
        self._visible = False
        for timer in (self._refresh_timer, self._picture_timer, self._audio_timer):
            timer.stop()
        self._pending = {'picture': None, 'audio': None}
        if self._marker is not None:
            self._marker.stop()

    def _cleanup(self):
        self._closed = True
        self._suspend()
        if self._marker is not None:
            self._marker.close()
        self._connections = []

    def _valid(self, st):
        return (self._visible and not self._closed and st.get('state') in ACTIVE
                and context(st) == self._target)

    def _text(self, name, value):
        if self._texts.get(name) != value:
            self._texts[name] = value
            self[name].setText(native(value))

    def refresh(self):
        try:
            self._refresh_body()
        except Exception as error:
            log('playback bar refresh: %r' % error)
            self.close()

    def _refresh_body(self):
        if not self._visible or self._closed:
            return
        st = ctl.get().status()
        if not self._valid(st):
            return self.close()
        stream = store.get_stream(st['stream_id'])
        if not stream:
            return self.close()
        library = store._load()
        name, duration = store.stream_display(stream, library)
        self._text('name', name)
        desktop = getDesktop(0).size()
        scale = geometry(desktop.width(), desktop.height())[4]
        path = store.stream_icon(stream, scale=max(1.5, scale * 1.5), lib=library)
        if path != self._picon_path:
            self._picon_path = path
            pixmap = LoadPixmap(native(path))
            if pixmap is not None:
                n = lambda v: max(1, int(v * scale))
                size = pixmap.size()
                w, h = fit_picon(size.width(), size.height(), n(144), n(84))
                self['picon'].instance.resize(eSize(w, h))
                self['picon'].instance.move(ePoint(n(10) + (n(144) - w) // 2,
                                                  n(8) + (n(84) - h) // 2))
                self['picon'].instance.setPixmap(pixmap)
        event = None
        if not store.is_radio_stream(stream, library):
            guide.ensure([stream], lang())
            event = guide.view(stream, lang())[1]
        self._text('guide', event[0] if event else '')
        self._text('time', (time.strftime('%H:%M', time.localtime(event[1])) + u' – ' +
                           time.strftime('%H:%M', time.localtime(event[2]))) if event else (duration or ''))
        self._text('picture_caption', T('Picture'))
        self._text('audio_caption', T('Audio'))
        video = st.get('video') or {}
        self._text('freeze_caption', T('Resume') if video.get('state') == 'paused' else T('Freeze'))
        picture = self._pending['picture']
        if picture is None:
            picture = 0.0 if video.get('state') in ('off', 'error') else video.get('current_s')
            if picture is None:
                picture = video.get('target_s') or 0.0
        audio = self._pending['audio']
        if audio is None:
            audio = st.get('audio_delay_ms') or 0
        self._text('picture_value', T('%.1f s', picture))
        self._text('audio_value', T('%.1f s', audio / 1000.0) if st.get('audio_delay_supported') else T('N/A'))
        if self._marker is not None:
            self._marker.update(0, st['state'], st['stream_id'], visible=True)

    def reset(self, kind):
        controller = ctl.get()
        st = controller.status()
        if not self._valid(st) or (kind == 'audio' and not st.get('audio_delay_supported')):
            return
        timer = self._picture_timer if kind == 'picture' else self._audio_timer
        timer.stop()
        self._pending[kind] = None
        try:
            if kind == 'picture':
                controller.reset_picture(self._target[0], self._target[1])
            else:
                controller.video.suspend_monitor()
                controller.set_audio_delay(0, self._target[0], self._target[1])
        except Exception as error:
            log('playback bar reset: %r' % error)
        self.refresh()

    def adjust(self, kind, direction):
        st = ctl.get().status()
        if not self._valid(st) or (kind == 'audio' and not st.get('audio_delay_supported')):
            return
        settings = store.get_settings()
        value = self._pending[kind]
        if kind == 'picture':
            video = st.get('video') or {}
            if value is None:
                if video.get('state') in ('off', 'error'):
                    memo = store.recall_channel(st.get('tv_service')) or {}
                    value = float(memo.get('video_s') or 0)
                elif video.get('state') == 'paused':
                    value = video.get('current_s')
                    if value is None:
                        value = video.get('target_s') or 0.0
                else:
                    value = video.get('target_s')
                    if value is None:
                        value = video.get('current_s') or 0.0
            self._pending[kind] = round(max(0.0, min(600.0, value + direction * float(settings['step_video_s']))), 1)
            self._picture_timer.start(850, True)
        else:
            value = st.get('audio_delay_ms', 0) if value is None else value
            self._pending[kind] = max(0, min(60000, value + direction * int(settings['step_audio_ms'])))
            self._audio_timer.start(250 if st.get('audio_delay_live') else 1000, True)
        ctl.get().video.suspend_monitor()
        self.refresh()

    def apply(self, kind):
        value, self._pending[kind] = self._pending[kind], None
        st = ctl.get().status()
        if value is None or not self._valid(st):
            return
        controller = ctl.get()
        try:
            if kind == 'picture':
                controller.set_video_delay(value, self._target[0], self._target[1])
            else:
                controller.set_audio_delay(value, self._target[0], self._target[1])
        except Exception as error:
            log('playback bar adjustment: %r' % error)
        self.refresh()
