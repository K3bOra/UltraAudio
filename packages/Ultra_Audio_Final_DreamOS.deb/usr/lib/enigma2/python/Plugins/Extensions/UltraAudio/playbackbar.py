# -*- coding: utf-8 -*-
"""Compact playback controls; uses existing controller, theme PNGs and marker frames."""
import os
import time
from xml.sax.saxutils import escape

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop, gFont

from . import ctl, guide, store, themes
from .compat import lru_cache, native, skin_scale_attr, ui_pixmap_path
from .engine import log
from .i18n import T, lang
from .motion import PlaybackMarker
from .cardlayout import guide_lines

WIDTH, HEIGHT = 1104, 88
ACTIVE = ('starting', 'playing', 'retrying')
KEY_TWIN_S = 0.6
_dialog = None


def geometry(width, height):
    scale = min(width / 1920.0, height / 1080.0)
    w, h = max(1, int(round(WIDTH * scale))), max(1, int(round(HEIGHT * scale)))
    return (width - w) // 2, max(0, height - h - max(2, int(round(6 * scale)))), w, h, scale


def context(st):
    return st.get('stream_id'), st.get('generation'), st.get('tv_service')


def sized_asset(name, width, height):
    """Use offline antialiased artwork at native pixels; avoid receiver scaling."""
    t_cand = os.path.join(themes.DIR, themes.current(), '%s_%dx%d.png' % (name, width, height))
    if os.path.isfile(t_cand):
        return t_cand
    preferred = os.path.join(store.ASSETS, 'playback_horizontal', '%s_%dx%d.png' % (name, width, height))
    if os.path.isfile(preferred):
        return preferred
    path = os.path.join(store.ASSETS, 'playback', '%s_%dx%d.png' % (name, width, height))
    if os.path.isfile(path):
        return path
    fallback_horiz = os.path.join(store.ASSETS, 'playback_horizontal', '%s_32x3.png' % name)
    if os.path.isfile(fallback_horiz):
        return ui_pixmap_path(fallback_horiz, width, height)
    return ui_pixmap_path(themes.pic(themes.get(), name + '.png'), width, height)


@lru_cache(maxsize=96)
def _asset_pixmap(path):
    return LoadPixmap(native(path))


def _num_asset(key, side):
    cand = os.path.join(store.ASSETS, 'ui', 'num_%s_%d.png' % (key, side))
    if os.path.isfile(cand):
        return cand
    base = os.path.join(store.ASSETS, 'ui', 'num_%s.png' % key)
    return ui_pixmap_path(base, side, side)


def build_skin(width, height, theme):
    x, y, w, h, scale = geometry(width, height)
    n = lambda v: max(1, int(round(v * scale)))
    scale_attr = skin_scale_attr()
    align = 'right' if lang() == 'ar' else 'left'
    parts = ['<screen name="UltraAudioPlaybackBar" position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="transparent" title="Ultra Audio" zPosition="10">' % (x, y, w, h)]
    path = ui_pixmap_path(themes.pic(theme, 'playback_panel.png'), w, h)
    parts.append('<ePixmap position="0,0" size="%d,%d" pixmap="%s" alphatest="blend" transparent="1"%s zPosition="0"/>' % (w, h, escape(path), scale_attr))
    for name, xpos in [('marker', 370), ('marker_second', 444)]:
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" alphatest="blend" transparent="1"%s zPosition="3"/>' % (name, n(xpos), n(42), n(78), n(34), scale_attr))
    for name, key, xpos in [('picture_minus', '1', 766), ('picture_plus', '3', 890), ('audio_minus', '4', 932), ('audio_plus', '6', 1056)]:
        path = _num_asset(key, n(32))
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" transparent="1"%s zPosition="5"/>' % (name, n(xpos), n(36), n(32), n(32), escape(path), scale_attr))
    for name, color, xpos in [('picture_key', 'yellow', 828), ('audio_key', 'blue', 994), ('freeze_key', 'green', 682), ('stop_key', 'red', 572)]:
        path = sized_asset('key_' + color, n(32), n(3))
        ky = n(65 if name in ('freeze_key', 'stop_key') else 9)
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" transparent="1"%s zPosition="5"/>' % (name, n(xpos), ky, n(32), n(3), escape(path), scale_attr))
    definitions = [
        ('name', 32, 7, 324, 26, 22, '#F2F5F5', 'center'),
        ('guide', 32, 34, 324, 21, 16, theme['pal']['accent'], align),
        ('guide_second', 32, 55, 324, 21, 16, theme['pal']['accent'], align),
        ('time', 370, 6, 152, 14, 10, '#BFC9CA', 'center'),
        ('stop_caption', 538, 28, 100, 29, 20, '#FFFFFF', 'center'),
        ('freeze_caption', 648, 28, 100, 29, 20, '#FFFFFF', 'center'),
        ('picture_caption', 800, 15, 88, 22, 16, '#FFFFFF', 'center'),
        ('audio_caption', 966, 15, 88, 22, 16, '#FFFFFF', 'center'),
        ('picture_value', 800, 39, 88, 28, 22, '#FFFFFF', 'center'),
        ('audio_value', 966, 39, 88, 28, 22, '#FFFFFF', 'center'),
    ]
    for name, px, py, pw, ph, size, color, alignment in definitions:
        parts.append('<widget name="%s" position="%d,%d" size="%d,%d" font="%s;%d" foregroundColor="%s" halign="%s" valign="center" transparent="1" noWrap="1" zPosition="6"/>' % (name, n(px), n(py), n(pw), n(ph), themes.face('UltraAudioUI'), n(size), color, alignment))
    return ''.join(parts) + '</screen>'


def open_bar(session):
    """Called only by the InfoBar's 0 action; never opens the main plugin screen."""
    global _dialog
    if _dialog is not None:
        return 0
    st = ctl.get().status()
    if st.get('state') not in ACTIVE or not st.get('stream_id'):
        return 0
    try:
        def closed(*args):
            global _dialog
            _dialog = None
        _dialog = session.openWithCallback(closed, PlaybackBar)
        return 1
    except Exception as error:
        log('playback bar: %r' % error)
        return 0


class PlaybackBar(Screen):
    def createSummary(self):
        from .frontpanel import UltraAudioFrontSummary
        return UltraAudioFrontSummary

    def __init__(self, session):
        desktop = getDesktop(0).size()
        theme = themes.get()
        self._accent = theme["pal"]["accent"]
        self._scale = geometry(desktop.width(), desktop.height())[4]
        self.skin = build_skin(desktop.width(), desktop.height(), theme)
        Screen.__init__(self, session)
        self._connections, self._texts, self._colors = [], {}, {}
        self._key_at = {}
        self._pending = {'picture': None, 'audio': None}
        self._closed, self._visible, self._ready = False, False, False
        self._marker = None
        self._companion_frames = {}
        self._guide_key, self._guide_lines, self._guide_started = None, (), 0.0
        self._delay_values = None
        self._target = context(ctl.get().status())
        for name in ('name', 'guide', 'guide_second', 'time', 'picture_caption', 'audio_caption', 'freeze_caption', 'picture_value', 'audio_value', 'stop_caption'):
            self[name] = Label('')
        for name in ('marker', 'marker_second', 'picture_minus', 'picture_plus', 'audio_minus', 'audio_plus', 'picture_key', 'freeze_key', 'audio_key', 'stop_key'):
            self[name] = Pixmap()
        self['actions'] = ActionMap(['NumberActions', 'OkCancelActions', 'ColorActions'],
            {'0': self.close, '2': self.close, 'cancel': self.close,
             'yellow': self._once('yellow', lambda: self.reset('picture')),
             'blue': self._once('blue', lambda: self.reset('audio')),
             'green': self._once('green', self.freeze),
             'red': self._once('red', self.stop),
             '1': lambda: self.adjust('picture', -1), '3': lambda: self.adjust('picture', 1),
             '4': lambda: self.adjust('audio', -1), '6': lambda: self.adjust('audio', 1)}, -2)
        self._refresh_timer = self._timer(self.refresh)
        self._picture_timer = self._timer(lambda: self.apply('picture'))
        self._audio_timer = self._timer(lambda: self.apply('audio'))
        self.onLayoutFinish.append(self._layout_ready)
        self.onExecBegin.append(self._resume)
        self.onExecEnd.append(self._suspend)
        self.onHide.append(self._suspend)
        self.onClose.append(self._cleanup)

    def _once(self, name, handler):
        # Same make/repeat guard as the main screen: held GREEN must not toggle back.
        def run():
            now = time.time()
            last = self._key_at.get(name, 0.0)
            self._key_at[name] = now
            if 0.0 <= now - last < KEY_TWIN_S:
                return
            try:
                handler()
            finally:
                self._key_at[name] = time.time()
        return run

    def freeze(self):
        if self._valid(ctl.get().status()):
            ctl.get().toggle_pause()
            self.refresh()

    def stop(self):
        if self._valid(ctl.get().status()):
            ctl.get().stop()
            self.close()

    def _timer(self, callback):
        timer = eTimer()
        if hasattr(timer, 'callback'):
            timer.callback.append(callback)
        else:
            self._connections.append(timer.timeout.connect(callback))
        return timer

    def _layout_ready(self):
        self._ready = True
        n = lambda v: max(1, int(round(v * self._scale)))
        # Explicitly bind number and key dash pixmaps on layout ready for all images
        for name, key in (('picture_minus', '1'), ('picture_plus', '3'), ('audio_minus', '4'), ('audio_plus', '6')):
            try:
                p = _num_asset(key, n(32))
                if self[name].instance is not None and os.path.isfile(p):
                    self[name].instance.setPixmap(_asset_pixmap(p))
            except Exception:
                pass
        for name, color in (('picture_key', 'yellow'), ('audio_key', 'blue'), ('freeze_key', 'green'), ('stop_key', 'red')):
            try:
                p = sized_asset('key_' + color, n(32), n(3))
                if self[name].instance is not None and os.path.isfile(p):
                    self[name].instance.setPixmap(_asset_pixmap(p))
            except Exception:
                pass
        w, h = n(78), n(34)
        frames = tuple(_asset_pixmap(sized_asset('eq_%d' % i, w, h)) for i in range(8))
        still = _asset_pixmap(sized_asset('eq_idle', w, h))
        self._companion_frames = dict((id(frame), frames[(i + 3) % len(frames)]) for i, frame in enumerate(frames)) if all(frames) else {}
        self._marker = PlaybackMarker(self._timer, frames if all(frames) else (), still,
            self._marker_status, self._paint_markers, lambda row: None,
            self._show_markers, self._hide_markers)
        self._resume()

    def _paint_markers(self, pixmap):
        self['marker'].instance.setPixmap(pixmap)
        self['marker_second'].instance.setPixmap(self._companion_frames.get(id(pixmap), pixmap))

    def _show_markers(self):
        self['marker'].show()
        self['marker_second'].show()

    def _hide_markers(self):
        self['marker'].hide()
        self['marker_second'].hide()

    def _measure(self, name, text, font_size):
        label = self[name]
        label.setText(native(text))
        try:
            size = label.instance.calculateSize()
            return max(0, size.width()), max(0, size.height())
        except Exception:
            return int(len(text) * font_size * 0.65), font_size

    def _update_guide(self, text, scale):
        text = text or ''
        key = (text, lang(), scale)
        if key == self._guide_key:
            return
        self._guide_key = key
        face = themes.face('UltraAudioUI')
        width = max(1, int(round(320 * scale)))
        lines = ()
        # Keep two static lines. Fit once per event; never page or scroll.
        for design_size in (16, 15, 14, 13, 12):
            font_size = max(1, int(round(design_size * scale)))
            self['guide'].instance.setFont(gFont(face, font_size))
            lines = guide_lines(text, lambda t: self._measure('guide', t, font_size)[0], width)
            if len(lines) <= 2:
                break
        first = lines[0] if lines else ''
        second = lines[1] if len(lines) > 1 else ''
        if len(lines) > 2:
            while second and self._measure('guide', second + u'…', font_size)[0] > width:
                second = second[:-1]
            second += u'…'
        for name in ('guide', 'guide_second'):
            self[name].instance.setFont(gFont(face, font_size))
            self._texts.pop(name, None)
        self._text('guide', first)
        self._text('guide_second', second)

    def _place_delays(self, scale):
        values = (self._texts.get('picture_value'), self._texts.get('audio_value'), scale, lang(), themes.face('UltraAudioUI'))
        if values == self._delay_values:
            return
        self._delay_values = values
        n = lambda v: max(1, int(round(v * scale)))
        face = themes.face('UltraAudioUI')
        for kind in ('picture', 'audio'):
            name = kind + '_value'
            size = n(22)
            self[name].instance.setFont(gFont(face, size))
            measured, high = self._measure(name, self._texts.get(name) or '', size)
            if measured > n(84) or high > n(28):
                fit = min(float(n(84)) / max(1, measured), float(n(28)) / max(1, high))
                self[name].instance.setFont(gFont(face, max(n(12), int(size * fit))))

    def _marker_status(self):
        # Lock-free atomic attribute reads: never skip animation frames due to worker lock contention
        engine = ctl.get().engine
        stream = engine.stream
        return {'state': engine.state, 'stream_id': stream.get('id') if isinstance(stream, dict) else None}

    def _resume(self):
        if self._closed or not self._ready:
            return
        self._visible = True
        self.refresh()
        if not self._closed:
            self._refresh_timer.start(750, False)

    def _suspend(self):
        self._visible = False
        for timer in (self._refresh_timer, self._picture_timer, self._audio_timer):
            timer.stop()
        pic_val, aud_val = self._pending.get('picture'), self._pending.get('audio')
        self._pending = {'picture': None, 'audio': None}
        if pic_val is not None or aud_val is not None:
            try:
                controller = ctl.get()
                st = controller.status()
                if st.get('state') in ACTIVE and context(st) == self._target:
                    if pic_val is not None:
                        controller.set_video_delay(pic_val, self._target[0], self._target[1])
                    if aud_val is not None:
                        controller.set_audio_delay(aud_val, self._target[0], self._target[1])
            except Exception as err:
                log('playback bar flush on close: %r' % err)
        if self._marker is not None:
            self._marker.stop()

    def _cleanup(self):
        self._closed = True
        self._suspend()
        if self._marker is not None:
            self._marker.close()
        self._connections = []

    def _valid(self, st):
        return (self._visible and not self._closed and st.get('state') in ACTIVE
                and context(st) == self._target)

    def _text(self, name, value):
        if self._texts.get(name) != value:
            self._texts[name] = value
            self[name].setText(native(value))

    def refresh(self):
        try:
            self._refresh_body()
        except Exception as error:
            log('playback bar refresh: %r' % error)
            self.close()

    def _refresh_body(self):
        if not self._visible or self._closed:
            return
        st = ctl.get().status()
        if not self._valid(st):
            return self.close()
        stream = store.get_stream_readonly(st['stream_id']) if hasattr(store, 'get_stream_readonly') else store.get_stream(st['stream_id'])
        if not stream:
            return self.close()
        library = store.readonly_library() if hasattr(store, 'readonly_library') else store._load()
        name, duration = store.stream_display(stream, library)
        name_changed = self._texts.get('name') != name
        self._text('name', name)
        scale = self._scale
        if name_changed:
            size = max(1, int(round(22 * scale)))
            self['name'].instance.setFont(gFont(themes.face('UltraAudioUI'), size))
            measured, high = self._measure('name', name, size)
            if measured > 324 * scale or high > 26 * scale:
                fit = min(324.0 * scale / max(1, measured), 26.0 * scale / max(1, high))
                self['name'].instance.setFont(gFont(themes.face('UltraAudioUI'), max(int(12 * scale), int(size * fit))))
        event = None
        if not store.is_radio_stream(stream, library):
            guide.ensure([stream], lang())
            event = guide.view(stream, lang())[1]
        self._update_guide(event[0] if event else '', scale)
        self._text('time', (time.strftime('%H:%M', time.localtime(event[1])) + u' – ' +
                           time.strftime('%H:%M', time.localtime(event[2]))) if event else (duration or ''))
        self._text('stop_caption', T('Stop'))
        self._text('picture_caption', T('Picture'))
        self._text('audio_caption', T('Audio'))
        video = st.get('video') or {}
        self._text('freeze_caption', T('Resume') if video.get('state') == 'paused' else T('Freeze'))
        self._show_delays(st, video)
        self._place_delays(scale)
        if self._marker is not None:
            self._marker.update(0, st['state'], st['stream_id'], visible=True)

    def _show_delays(self, st, video):
        picture = self._pending['picture']
        if picture is None:
            if video.get('state') in ('off', 'error'):
                picture = 0.0
            elif video.get('state') == 'filling' or video.get('busy'):
                picture = video.get('target_s') if video.get('target_s') is not None else (video.get('current_s') or 0.0)
            else:
                picture = video.get('current_s')
                if picture is None:
                    picture = video.get('target_s') or 0.0
        audio = self._pending['audio']
        if audio is None:
            audio = st.get('audio_delay_ms') or 0
        p_busy = self._pending['picture'] is not None or video.get('busy') or video.get('state') in ('filling', 'paused')
        a_busy = self._pending['audio'] is not None or bool(st.get('audio_settling'))
        p_str = T('%.1f s', picture) + (u' …' if self._pending['picture'] is not None or video.get('state') == 'filling' or video.get('busy') else u'')
        a_str = (T('%.1f s', audio / 1000.0) + (u' …' if self._pending['audio'] is not None else u'')) if st.get('audio_delay_supported') else T('N/A')
        self._text('picture_value', p_str)
        self._text('audio_value', a_str)
        try:
            from skin import parseColor
            for name, busy in (('picture_value', p_busy), ('audio_value', a_busy)):
                color = self._accent if busy else '#FFFFFF'
                if self._colors.get(name) != color:
                    self[name].instance.setForegroundColor(parseColor(native(color)))
                    self._colors[name] = color
        except Exception:
            pass

    def _control_status(self):
        return ctl.get().control_status()

    def reset(self, kind):
        controller = ctl.get()
        st = self._control_status()
        if not self._valid(st) or (kind == 'audio' and not st.get('audio_delay_supported')):
            return
        timer = self._picture_timer if kind == 'picture' else self._audio_timer
        timer.stop()
        self._pending[kind] = None
        try:
            if kind == 'picture':
                controller.reset_picture(self._target[0], self._target[1])
            else:
                controller.video.suspend_monitor()
                controller.set_audio_delay(0, self._target[0], self._target[1])
        except Exception as error:
            log('playback bar reset: %r' % error)
        st = self._control_status()
        self._show_delays(st, st['video'])

    def adjust(self, kind, direction):
        st = self._control_status()
        if not self._valid(st) or (kind == 'audio' and not st.get('audio_delay_supported')):
            return
        settings = store.get_settings()
        value = self._pending[kind]
        if kind == 'picture':
            video = st.get('video') or {}
            if value is None:
                if video.get('state') in ('off', 'error'):
                    memo = store.recall_channel(st.get('tv_service')) or {}
                    value = float(memo.get('video_s') or 0)
                elif video.get('state') == 'paused':
                    value = video.get('current_s')
                    if value is None:
                        value = video.get('target_s') or 0.0
                else:
                    value = video.get('target_s')
                    if value is None:
                        value = video.get('current_s') or 0.0
            self._pending[kind] = round(max(0.0, min(600.0, value + direction * float(settings['step_video_s']))), 1)
            self._picture_timer.start(850, True)
        else:
            value = st.get('audio_delay_ms', 0) if value is None else value
            self._pending[kind] = max(0, min(60000, value + direction * int(settings['step_audio_ms'])))
            self._audio_timer.start(550 if st.get('audio_delay_live') else 1000, True)
        self._show_delays(st, st['video'])

    def apply(self, kind):
        value, self._pending[kind] = self._pending[kind], None
        st = self._control_status()
        if value is None or not self._valid(st):
            return
        controller = ctl.get()
        try:
            if kind == 'picture':
                controller.set_video_delay(value, self._target[0], self._target[1])
            else:
                controller.set_audio_delay(value, self._target[0], self._target[1])
        except Exception as error:
            log('playback bar adjustment: %r' % error)
        st = self._control_status()
        if self._valid(st):
            self._show_delays(st, st['video'])
