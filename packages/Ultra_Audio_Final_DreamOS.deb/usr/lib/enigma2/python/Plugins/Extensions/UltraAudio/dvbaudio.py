# -*- coding: utf-8 -*-
"""Silence the receiver's own TV sound at the DVB audio decoder, and free the sound card it holds.

Enigma2's volume-mute goes through the ALSA mixer, and on several receivers that same mixer also controls the ALSA
output we play the commentary on, so the commentary would be muted together with the channel.  On the Vu+ the audio
decoder also keeps the ALSA card open while it plays ("Device or resource busy" for everyone else), so we mute it and then
stop it (AUDIO_STOP on /dev/dvb/adapterN/audioM, a standard decoder stop request); AUDIO_PLAY brings it back.

On Dreambox / DreamOS (Broadcom Nexus):
- Pausing for timeshift calls eDVBAudio::freeze() -> ioctl(audio_fd, AUDIO_PAUSE, 0), which pauses/mutes the shared
  Nexus audio output stage until AUDIO_CONTINUE (0x6F04) is issued.
- During PVR timeshift playback, stopping audio0 (AUDIO_STOP) without flushing its buffer causes the 512 KB Audio RAVE CDB
  buffer to fill up after ~18 seconds and backpressure the PVR playpump.
- Never issue DMX_STOP on /dev/dvb/adapterN/demuxM descriptors: during timeshift rebuild, stopping a demux descriptor
  can stop the PVR or video/recording demux and blank the TV picture to black until timeshift is cancelled.
- Instead, keep audio0 isolated strictly via audio0 ioctls: clear AUDIO_PAUSE via AUDIO_PLAY + AUDIO_CONTINUE, stop
  audio0 (AUDIO_STOP), and periodically flush AUDIO_CLEAR_BUFFER (0x6F0C) every 500ms during timeshift so the Audio RAVE
  CDB buffer never fills up and video decoding is never disturbed.
"""
from __future__ import division
import fcntl
import glob
import os
import re

from .compat import monotonic
from .engine import log

AUDIO_STOP = 0x6F01                # _IO('o', 1) from linux/dvb/audio.h
AUDIO_PLAY = 0x6F02                # _IO('o', 2)
AUDIO_PAUSE = 0x6F03               # _IO('o', 3)
AUDIO_CONTINUE = 0x6F04            # _IO('o', 4)
AUDIO_SELECT_SOURCE = 0x6F05       # _IO('o', 5)
AUDIO_SET_MUTE = 0x6F06            # _IO('o', 6)
AUDIO_SET_AV_SYNC = 0x6F07         # _IO('o', 7)
AUDIO_SET_BYPASS_MODE = 0x6F08     # _IO('o', 8)
AUDIO_CLEAR_BUFFER = 0x6F0C        # _IO('o', 12)
AUDIO_SOURCE_DEMUX = 0
AUDIO_SOURCE_MEMORY = 1

_NODE = re.compile(r"^/dev/dvb/adapter(\d+)/audio(\d+)$")
PROC_FD = "/proc/self/fd"
GLOB = "/dev/dvb/adapter*/audio*"

_scan_cache = [0.0, {}]


def _scan_audio_fds():
    """Return {fd: (target, adapter_idx, audio_idx)} from /proc/self/fd with a short 0.18s cache."""
    now = monotonic()
    if 0.0 <= now - _scan_cache[0] < 0.18:
        return _scan_cache[1]
    audio_map = {}
    try:
        names = os.listdir(PROC_FD)
    except EnvironmentError:
        return audio_map
    for name in names:
        if not name.isdigit():
            continue
        fd = int(name)
        try:
            target = os.readlink(os.path.join(PROC_FD, name))
        except EnvironmentError:
            continue
        if not target.startswith("/dev/dvb/adapter"):
            continue
        m = _NODE.match(target)
        if m:
            audio_map[fd] = (target, int(m.group(1)), int(m.group(2)))
    _scan_cache[0] = now
    _scan_cache[1] = audio_map
    return audio_map


def borrowed_fds():
    """Descriptors Enigma2 itself already holds open on its audio decoders (the node is usually exclusive)."""
    return sorted(_scan_audio_fds().keys())


def audio_demux_map():
    """Retained for API compatibility; maps each open audio_fd to None (never touch demux descriptors)."""
    return dict((fd, None) for fd in borrowed_fds())


def borrowed_signature():
    """Signature of Enigma2's open audio descriptors; changes when timeshift rebuilds eDVBAudio."""
    audio_map = _scan_audio_fds()
    if not audio_map:
        return ()
    return tuple((afd, audio_map[afd][0]) for afd in sorted(audio_map.keys()))


def prepare_dvb_sink():
    """Clear hardware mute and disable hardware A/V sync against satellite PCR/STC before opening dvbaudiosink."""
    for fd in borrowed_fds():
        for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0)):
            try:
                fcntl.ioctl(fd, request, arg)
            except EnvironmentError:
                pass
    for path in sorted(glob.glob(GLOB)):
        try:
            fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
        except EnvironmentError:
            continue
        try:
            for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0), (AUDIO_CLEAR_BUFFER, 0)):
                try:
                    fcntl.ioctl(fd, request, arg)
                except EnvironmentError:
                    pass
        finally:
            try:
                os.close(fd)
            except EnvironmentError:
                pass


def keep_dvb_commentary_unmuted(open_device=False):
    """Ensure hardware mute and PCR A/V sync remain off on active commentary without flushing or stopping it."""
    fds = borrowed_fds()
    for fd in fds:
        for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0)):
            try:
                fcntl.ioctl(fd, request, arg)
            except EnvironmentError:
                pass
    if not fds and open_device:
        for path in sorted(glob.glob(GLOB)):
            try:
                fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
            except EnvironmentError:
                continue
            try:
                for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0)):
                    try:
                        fcntl.ioctl(fd, request, arg)
                    except EnvironmentError:
                        pass
            finally:
                try:
                    os.close(fd)
                except EnvironmentError:
                    pass


def keep_timeshift_isolated(active_flush=False):
    """Flush the stopped DVB audio decoder buffer during timeshift so the 512 KB Audio RAVE CDB never backpressures PVR video."""
    fds = borrowed_fds()
    if not fds:
        return False
    steps = (
        (AUDIO_SET_MUTE, 0),
        (AUDIO_SET_AV_SYNC, 0),
        (AUDIO_PLAY, 0),
        (AUDIO_CONTINUE, 0),
        (AUDIO_CLEAR_BUFFER, 0),
        (AUDIO_STOP, 0),
        (AUDIO_CLEAR_BUFFER, 0),
    ) if active_flush else (
        (AUDIO_SET_MUTE, 0),
        (AUDIO_SET_AV_SYNC, 0),
        (AUDIO_CLEAR_BUFFER, 0),
    )
    for fd in fds:
        for request, arg in steps:
            try:
                fcntl.ioctl(fd, request, arg)
            except EnvironmentError:
                pass
    return True


def _apply(fd, on, demux_fd=None):
    """Unpause + flush + stop decoder (on) or play + unmute (off) one audio decoder."""
    if on:
        steps = (
            (AUDIO_SET_MUTE, 0),
            (AUDIO_SET_AV_SYNC, 0),
            (AUDIO_PLAY, 0),
            (AUDIO_CONTINUE, 0),
            (AUDIO_CLEAR_BUFFER, 0),
            (AUDIO_STOP, 0),
            (AUDIO_CLEAR_BUFFER, 0),
        )
    else:
        steps = (
            (AUDIO_SELECT_SOURCE, AUDIO_SOURCE_DEMUX),
            (AUDIO_CLEAR_BUFFER, 0),
            (AUDIO_SET_MUTE, 0),
            (AUDIO_SET_AV_SYNC, 1),
            (AUDIO_PLAY, 0),
            (AUDIO_CONTINUE, 0),
        )
    accepted = False
    for request, arg in steps:
        try:
            fcntl.ioctl(fd, request, arg)
            if request == (AUDIO_STOP if on else AUDIO_PLAY):
                accepted = True
        except EnvironmentError as e:
            if request in (AUDIO_STOP, AUDIO_PLAY):
                log("decoder request 0x%X on fd %d failed: %r" % (request, fd, e))
    return accepted


def set_mute(on, borrowed_only=False):
    """True when at least one decoder accepted the request."""
    done = False
    for fd in borrowed_fds():
        done = _apply(fd, on) or done
    if done or borrowed_only:
        return done
    for path in sorted(glob.glob(GLOB)):
        try:
            fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
        except EnvironmentError as e:
            log("cannot open %s: %r" % (path, e))
            continue
        try:
            done = _apply(fd, on)
        finally:
            os.close(fd)
        if done:
            break
    return done
