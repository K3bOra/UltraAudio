# -*- coding: utf-8 -*-
"""Silence the receiver's own TV sound at the DVB audio decoder, and free the sound card it holds.

Enigma2's volume-mute goes through the ALSA mixer, and on several receivers that same mixer also controls the ALSA
output we play the commentary on, so the commentary would be muted together with the channel.  On the Vu+ the audio
decoder also keeps the ALSA card open while it plays ("Device or resource busy" for everyone else), so we mute it and then
stop it (AUDIO_STOP on /dev/dvb/adapterN/audioM, a standard decoder stop request); AUDIO_PLAY brings it back.

On Dreambox / DreamOS (Broadcom Nexus):
- Pausing for timeshift calls eDVBAudio::freeze() -> ioctl(audio_fd, AUDIO_PAUSE, 0), which pauses/mutes the shared
  Nexus audio output stage until AUDIO_CONTINUE (0x6F04) is issued.
- During PVR timeshift playback, stopping audio0 (AUDIO_STOP) while the demux PES filter (eDVBAudio::m_fd_demux,
  DMX_PES_AUDIO0) remains active causes the 512 KB Audio RAVE CDB buffer to fill up after ~18 seconds and backpressure
  the PVR playpump, freezing the video picture while the timeshift delay counter keeps climbing.
- Do NOT set AUDIO_SELECT_SOURCE(AUDIO_SOURCE_MEMORY) on audio0 while commentary uses ALSA plughw:0,0 (CARD=PCM),
  because on Dreambox bcm7439.ko ALSA PCM shares the memory audio source and setting AUDIO_SOURCE_MEMORY on audio0
  steals the memory audio path away from plughw:0,0.
- Instead, match DreamOS eDVBAudio::stop() directly: stop the paired audio demux PES filter (DMX_STOP on m_fd_demux),
  clear AUDIO_PAUSE via AUDIO_PLAY + AUDIO_CONTINUE, flush AUDIO_CLEAR_BUFFER, and stop audio0 (AUDIO_STOP).
"""
from __future__ import division
import fcntl
import glob
import os
import re
import struct

from .engine import log

AUDIO_STOP = 0x6F01                # _IO('o', 1) from linux/dvb/audio.h
AUDIO_PLAY = 0x6F02                # _IO('o', 2)
AUDIO_PAUSE = 0x6F03               # _IO('o', 3)
AUDIO_CONTINUE = 0x6F04            # _IO('o', 4)
AUDIO_SELECT_SOURCE = 0x6F05       # _IO('o', 5)
AUDIO_SET_MUTE = 0x6F06            # _IO('o', 6)
AUDIO_SET_AV_SYNC = 0x6F07         # _IO('o', 7)
AUDIO_SET_BYPASS_MODE = 0x6F08     # _IO('o', 8)
AUDIO_CLEAR_BUFFER = 0x6F0C        # _IO('o', 12)
AUDIO_SOURCE_DEMUX = 0
AUDIO_SOURCE_MEMORY = 1

DMX_START = 0x6F29                 # _IO('o', 41) from linux/dvb/dmx.h
DMX_STOP = 0x6F2A                  # _IO('o', 42)

_NODE = re.compile(r"^/dev/dvb/adapter(\d+)/audio(\d+)$")
_VIDEO_NODE = re.compile(r"^/dev/dvb/adapter(\d+)/video(\d+)$")
_DEMUX_NODE = re.compile(r"^/dev/dvb/adapter(\d+)/demux(\d+)$")
PROC_FD = "/proc/self/fd"
PROC_MAPS = "/proc/self/maps"
PROC_MEM = "/proc/self/mem"
GLOB = "/dev/dvb/adapter*/audio*"

_demux_cache = {}
_last_logged_pair = [None]
_stopped_demux_fds = set()


def _scan_dvb_fds():
    """Return (audio_map, video_map, demux_map) from /proc/self/fd.
    audio_map: {fd: (target, adapter_int, dev_int)}
    video_map: {fd: (target, adapter_int, dev_int)}
    demux_map: {fd: (target, adapter_int, demux_int)}
    """
    audio_map, video_map, demux_map = {}, {}, {}
    try:
        names = os.listdir(PROC_FD)
    except EnvironmentError:
        return audio_map, video_map, demux_map
    for name in names:
        if not name.isdigit():
            continue
        fd = int(name)
        try:
            target = os.readlink(os.path.join(PROC_FD, name))
        except EnvironmentError:
            continue
        m = _NODE.match(target)
        if m:
            audio_map[fd] = (target, int(m.group(1)), int(m.group(2)))
            continue
        m = _VIDEO_NODE.match(target)
        if m:
            video_map[fd] = (target, int(m.group(1)), int(m.group(2)))
            continue
        m = _DEMUX_NODE.match(target)
        if m:
            demux_map[fd] = (target, int(m.group(1)), int(m.group(2)))
    return audio_map, video_map, demux_map


def borrowed_fds():
    """Descriptors Enigma2 itself already holds open on its audio decoders (the node is usually exclusive)."""
    audio_map, _, _ = _scan_dvb_fds()
    return sorted(audio_map.keys())


def _find_demux_in_mem(audio_map, video_map, demux_map):
    """Locate eDVBAudio::m_fd_demux in /proc/self/mem by matching (m_fd, m_fd_demux, m_dev) on the heap."""
    found = {}
    if not audio_map or not demux_map:
        return found
    video_next = set(vfd + 1 for vfd in video_map if (vfd + 1) in demux_map)
    needles_12 = {}
    needles_8 = {}
    video_needles = {}
    for vfd, (_, v_adap, v_dev) in video_map.items():
        for dfd, (_, d_adap, _) in demux_map.items():
            if d_adap == v_adap:
                video_needles[struct.pack("=iii", vfd, dfd, v_dev)] = dfd
                video_needles[struct.pack("=ii", vfd, dfd)] = dfd
    for afd, (_, a_adap, a_dev) in audio_map.items():
        for dfd, (_, d_adap, _) in demux_map.items():
            if d_adap == a_adap and dfd not in video_next:
                needles_12[struct.pack("=iii", afd, dfd, a_dev)] = (afd, dfd)
        if (afd + 1) in demux_map and demux_map[afd + 1][1] == a_adap and (afd + 1) not in video_next:
            needles_8[struct.pack("=ii", afd, afd + 1)] = (afd, afd + 1)
    if not needles_12 and not needles_8:
        return found
    regions = []
    try:
        with open(PROC_MAPS, "r") as f:
            for line in f:
                parts = line.split(None, 5)
                if len(parts) < 5 or "rw-p" not in parts[1]:
                    continue
                path = parts[5].strip() if len(parts) > 5 else ""
                if path and path != "[heap]":
                    continue
                start_s, end_s = parts[0].split("-", 1)
                start, end = int(start_s, 16), int(end_s, 16)
                if 0 < end - start <= 128 * 1024 * 1024:
                    regions.append((0 if path == "[heap]" else 1, start, end))
    except Exception:
        return found
    regions.sort()
    video_demux_found = set()
    hits_8 = {}
    try:
        mem_fd = os.open(PROC_MEM, os.O_RDONLY)
    except Exception:
        return found
    try:
        for _, start, end in regions[:24]:
            pos = start
            while pos < end:
                chunk_len = min(1024 * 1024, end - pos)
                try:
                    os.lseek(mem_fd, pos, os.SEEK_SET)
                    data = os.read(mem_fd, chunk_len)
                except EnvironmentError:
                    pos += chunk_len
                    continue
                if not data:
                    break
                for v_needle, v_dfd in video_needles.items():
                    idx = 0
                    while True:
                        idx = data.find(v_needle, idx)
                        if idx < 0:
                            break
                        if (idx % 4) == 0:
                            video_demux_found.add(v_dfd)
                            break
                        idx += 1
                for needle, (afd, dfd) in needles_12.items():
                    if afd in found or dfd in video_demux_found:
                        continue
                    idx = 0
                    while True:
                        idx = data.find(needle, idx)
                        if idx < 0:
                            break
                        if (idx % 4) == 0:
                            found[afd] = dfd
                            break
                        idx += 1
                for needle, (afd, dfd) in needles_8.items():
                    if afd in hits_8 or dfd in video_demux_found:
                        continue
                    idx = 0
                    while True:
                        idx = data.find(needle, idx)
                        if idx < 0:
                            break
                        if (idx % 4) == 0:
                            hits_8[afd] = dfd
                            break
                        idx += 1
                if len(found) == len(audio_map):
                    break
                pos += chunk_len
            if len(found) == len(audio_map):
                break
    finally:
        try:
            os.close(mem_fd)
        except Exception:
            pass
    for afd, dfd in hits_8.items():
        if afd not in found and dfd not in video_demux_found:
            found[afd] = dfd
    for afd in list(found.keys()):
        if found[afd] in video_demux_found:
            del found[afd]
    return found


def audio_demux_map():
    """Return {audio_fd: demux_fd_or_None} for Enigma2's open audio decoders."""
    audio_map, video_map, demux_map = _scan_dvb_fds()
    if not audio_map:
        return {}
    sig = (tuple(sorted(audio_map.items())), tuple(sorted(video_map.items())), tuple(sorted(demux_map.items())))
    if sig in _demux_cache:
        return dict(_demux_cache[sig])
    result = {}
    mem_matches = _find_demux_in_mem(audio_map, video_map, demux_map)
    # Never touch any demux fd immediately following a video_fd (vfd + 1).
    video_next = set(vfd + 1 for vfd in video_map if (vfd + 1) in demux_map)
    for afd, (_, a_adap, _) in sorted(audio_map.items()):
        dfd = mem_matches.get(afd)
        if dfd is None:
            # In DreamOS & Enigma2 eDVBAudio::eDVBAudio, audio0 (m_fd) is opened first and its demux (m_fd_demux)
            # is opened on the very next statement on the main thread (afd + 1, or afd + 2 if 1 slot was taken).
            # Do NOT require bool(video_next): during timeshift rebuild, video0's demux may not be at vfd + 1!
            for cand in (afd + 1, afd + 2):
                if cand in demux_map and demux_map[cand][1] == a_adap and cand not in video_next and cand not in video_map:
                    dfd = cand
                    break
        result[afd] = dfd
    pair_tuple = tuple(sorted(result.items()))
    if pair_tuple != _last_logged_pair[0]:
        _last_logged_pair[0] = pair_tuple
        for afd, dfd in pair_tuple:
            log("dvbaudio: paired audio fd %d with demux fd %s (video=%s demux=%s)" % (
                afd, dfd, sorted(video_map.keys()), sorted(demux_map.keys())))
    _demux_cache.clear()
    _demux_cache[sig] = dict(result)
    return result


def borrowed_signature():
    """Signature of Enigma2's open audio/demux descriptors; changes when timeshift rebuilds eDVBAudio."""
    audio_map, _, _ = _scan_dvb_fds()
    if not audio_map:
        return ()
    dmap = audio_demux_map()
    return tuple((afd, audio_map[afd][0], dmap.get(afd)) for afd in sorted(audio_map.keys()))


def prepare_dvb_sink():
    """Clear hardware mute and disable hardware A/V sync against satellite PCR/STC before opening dvbaudiosink."""
    for fd in borrowed_fds():
        for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0)):
            try:
                fcntl.ioctl(fd, request, arg)
            except EnvironmentError:
                pass
    for path in sorted(glob.glob(GLOB)):
        try:
            fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
        except EnvironmentError:
            continue
        try:
            for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0), (AUDIO_CLEAR_BUFFER, 0)):
                try:
                    fcntl.ioctl(fd, request, arg)
                except EnvironmentError:
                    pass
        finally:
            try:
                os.close(fd)
            except EnvironmentError:
                pass


def keep_dvb_commentary_unmuted(open_device=False):
    """Ensure hardware mute and PCR A/V sync remain off on active commentary without flushing or stopping it."""
    fds = borrowed_fds()
    for fd in fds:
        for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0)):
            try:
                fcntl.ioctl(fd, request, arg)
            except EnvironmentError:
                pass
    if not fds and open_device:
        for path in sorted(glob.glob(GLOB)):
            try:
                fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
            except EnvironmentError:
                continue
            try:
                for request, arg in ((AUDIO_SET_MUTE, 0), (AUDIO_SET_AV_SYNC, 0)):
                    try:
                        fcntl.ioctl(fd, request, arg)
                    except EnvironmentError:
                        pass
            finally:
                try:
                    os.close(fd)
                except EnvironmentError:
                    pass


def keep_timeshift_isolated(active_flush=False):
    """Keep the audio demux PES filter stopped (DMX_STOP) during timeshift without disturbing ALSA plughw:0,0."""
    dmap = audio_demux_map()
    if not dmap:
        return False
    for fd, demux_fd in sorted(dmap.items()):
        if demux_fd is not None:
            try:
                fcntl.ioctl(demux_fd, DMX_STOP, 0)
                _stopped_demux_fds.add(demux_fd)
            except EnvironmentError:
                pass
        if active_flush:
            # Only used if demux_fd could not be paired and PVR playpump experienced backpressure
            for request, arg in (
                (AUDIO_SET_MUTE, 0),
                (AUDIO_SET_AV_SYNC, 0),
                (AUDIO_PLAY, 0),
                (AUDIO_CONTINUE, 0),
                (AUDIO_CLEAR_BUFFER, 0),
                (AUDIO_STOP, 0),
                (AUDIO_CLEAR_BUFFER, 0),
            ):
                try:
                    fcntl.ioctl(fd, request, arg)
                except EnvironmentError:
                    pass
    return True


def _apply(fd, on, demux_fd=None):
    """Stop demux + unpause + stop decoder (on) or start demux + play + unmute (off) one decoder."""
    if on and demux_fd is not None:
        try:
            fcntl.ioctl(demux_fd, DMX_STOP, 0)
            _stopped_demux_fds.add(demux_fd)
        except EnvironmentError as e:
            log("demux stop on fd %d failed: %r" % (demux_fd, e))
    elif not on and demux_fd is not None:
        try:
            fcntl.ioctl(demux_fd, DMX_START, 0)
            _stopped_demux_fds.discard(demux_fd)
        except EnvironmentError:
            pass
    if on:
        # Match DreamOS eDVBAudio::stop() (DMX_STOP on m_fd_demux + AUDIO_STOP on m_fd), while also clearing
        # AUDIO_PAUSE (set by eDVBAudio::freeze() during timeshift pause) via AUDIO_PLAY + AUDIO_CONTINUE and
        # flushing the RAVE CDB buffer via AUDIO_CLEAR_BUFFER. Never set AUDIO_SELECT_SOURCE(AUDIO_SOURCE_MEMORY)
        # here because on Dreambox bcm7439.ko ALSA plughw:0,0 (CARD=PCM) uses the memory audio source!
        steps = (
            (AUDIO_SET_MUTE, 0),
            (AUDIO_SET_AV_SYNC, 0),
            (AUDIO_PLAY, 0),
            (AUDIO_CONTINUE, 0),
            (AUDIO_CLEAR_BUFFER, 0),
            (AUDIO_STOP, 0),
            (AUDIO_CLEAR_BUFFER, 0),
        )
    else:
        steps = (
            (AUDIO_SELECT_SOURCE, AUDIO_SOURCE_DEMUX),
            (AUDIO_CLEAR_BUFFER, 0),
            (AUDIO_SET_MUTE, 0),
            (AUDIO_SET_AV_SYNC, 1),
            (AUDIO_PLAY, 0),
            (AUDIO_CONTINUE, 0),
        )
    accepted = False
    for request, arg in steps:
        try:
            fcntl.ioctl(fd, request, arg)
            if request == (AUDIO_STOP if on else AUDIO_PLAY):
                accepted = True
        except EnvironmentError as e:
            if request in (AUDIO_STOP, AUDIO_PLAY):
                log("decoder request 0x%X on fd %d failed: %r" % (request, fd, e))
    return accepted


def set_mute(on):
    """True when at least one decoder accepted the request."""
    done = False
    dmap = audio_demux_map()
    for fd in sorted(dmap.keys()):
        done = _apply(fd, on, dmap.get(fd)) or done
    if not on and _stopped_demux_fds:
        for demux_fd in list(_stopped_demux_fds):
            try:
                fcntl.ioctl(demux_fd, DMX_START, 0)
            except EnvironmentError:
                pass
        _stopped_demux_fds.clear()
    if done:
        return True
    for path in sorted(glob.glob(GLOB)):
        try:
            fd = os.open(path, os.O_RDWR | os.O_NONBLOCK)
        except EnvironmentError as e:
            log("cannot open %s: %r" % (path, e))
            continue
        try:
            done = _apply(fd, on, None)
        finally:
            os.close(fd)
        if done:
            break
    return done
