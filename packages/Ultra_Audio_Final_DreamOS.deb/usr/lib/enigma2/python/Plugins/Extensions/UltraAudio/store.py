# -*- coding: utf-8 -*-
"""Library (folders + audio links), settings and custom icons for UltraAudio.

Pure python, no enigma imports, so it can be tested anywhere.
Layout on disk (DATA_DIR):
    library.json   {"version": 2, "folders": [...], "streams": [...]}
    settings.json
    picons/<stream id>.png   custom icon (optional)
"""
from __future__ import division
import base64
import copy
import binascii
import io
import json
import os
import re
import shutil
import tempfile
import threading
from .uifont import FONT_IDS
from . import iconchoices

from .compat import (new_id, b64decode as _b64decode, copytree_merge, integer_types, isfinite, makedirs, mtime_sig,
                     open_text, parse_qsl, replace as _replace, string_types, to_text, urlencode, urlparse, urlsplit)

from .i18n import T

DATA_DIR = os.environ.get("ULTRAAUDIO_DATA", "/etc/enigma2/ultraaudio")
LIBRARY_FILE = os.path.join(DATA_DIR, "library.json")
LEGACY_FILE = os.path.join(DATA_DIR, "streams.json")      # v0.1
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")
MEMORY_FILE = os.path.join(DATA_DIR, "channels.json")      # per-channel memory: commentary + delays
PICON_DIR = os.path.join(DATA_DIR, "picons")
PKG_DIR = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(PKG_DIR, "assets")
DEFAULT_PICON = os.path.join(ASSETS, "logos", "live.png")

DEFAULT_UA = "Mozilla/5.0 (Linux; Android 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0 Safari/537.36"

DEFAULT_SETTINGS = {
    "output": "auto",        # auto | alsa | aplay | pcm | gst | null
    "alsa_device": "auto",   # auto = first ALSA card with a playback device
    "mute_mode": "decoder",   # decoder (TV sound only) | system (Enigma2 volume mute) | none
    "volume": 100,           # percent applied to the IP audio
    "buffer_ms": 500,         # output buffer (aplay mode)
    "step_video_s": 1.0,     # video delay step (seconds)
    "step_audio_ms": 500,    # audio delay step (milliseconds)
    "language": "en",        # en | ar  (on-box screens)
    "ui_font": "skin",      # Receiver image font or one of six bundled bilingual faces.
    "web_port": 9990,        # port of the web page
    "route": "",             # last writer|device that played (remembered automatically)
    "timeshift_ahead": False, # legacy setting retained for backup compatibility; picture timeshift is manual-only
    "long_audio": True,      # a long press on the remote's AUDIO key opens Ultra Audio
    "theme": "classic",      # look of the on-box screen: classic or neon
    "update_repo": "K3bOra/UltraAudio",  # Official manual update source
}
THEMES = ("classic", "neon")     # Stadium / Daylight were removed: an old saved value falls back to classic

# Known sources: keyword -> (provider key, label, accent colour).  Anything else gets a hash colour.
PROVIDERS = {
    "orange": ("orange", "ORANGE", "#FF9F2E"),
    "best": ("best", "BEST", "#C6F03A"),
    "satfamily": ("satfamily", "SATFAMILY", "#4C86FF"),
    "foxfm": ("foxfm", "FOXFM", "#FF6A2E"),
    "radio": ("radio", "RADIO", "#75F5AA"),
}
TAGS = ("delay", "middle", "low", "4k", "live", "match", "event")

_lock = threading.RLock()
_CTRL = re.compile(r"[\x00-\x1f\x7f]")
_ID = re.compile(r"\A[0-9a-f]{12}\Z")
_DEVICE = re.compile(r"^[A-Za-z0-9_:,=.\-]{1,64}$")
PICON_EXTS = ("png", "jpg", "gif")
MAX_PICON = 2 * 1024 * 1024
MAX_DEPTH = 4


OLD_DATA_DIR = "/etc/enigma2/audiolink"  # Previous plugin name; data migration only.


def migrate_old_data(old=OLD_DATA_DIR):
    """On first run after the rename, carry the library, settings and custom icons over from the legacy data folder.
    Never overwrites anything that already exists in the new folder. Returns True when something was copied."""
    if old == OLD_DATA_DIR and "ULTRAAUDIO_DATA" in os.environ:       # tests / custom data dir: never touch /etc
        return False
    if os.path.abspath(old) == os.path.abspath(DATA_DIR) or not os.path.isdir(old):
        return False
    if os.path.exists(LIBRARY_FILE) or os.path.exists(LEGACY_FILE):
        return False
    import shutil
    try:
        copytree_merge(old, DATA_DIR)
        return True
    except (EnvironmentError, shutil.Error):
        return False


def ensure_dirs():
    with _lock:
        migrate_old_data()
        try:
            makedirs(PICON_DIR)
        except EnvironmentError:
            pass


def clean_text(value, maxlen):
    return _CTRL.sub("", to_text(value or "")).strip()[:maxlen]


def valid_url(url):
    """Only plain http/https links are accepted (nothing that reads local files)."""
    if not isinstance(url, string_types) or len(url) > 2000 or _CTRL.search(to_text(url)) or " " in to_text(url):
        return False
    try:
        p = urlparse(to_text(url))
        return p.scheme in ("http", "https") and bool(p.hostname)
    except ValueError:
        return False


def _read(path, default):
    try:
        with open_text(path) as f:
            return json.load(f)
    except (EnvironmentError, ValueError):
        return default


def _write(path, obj):
    ensure_dirs()
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".tmp-")
    try:
        with io.open(fd, "w", encoding="utf-8") as f:
            f.write(to_text(json.dumps(obj, ensure_ascii=False, indent=2)))
        _replace(tmp, path)
        if path == LIBRARY_FILE:
            _library_cache["value"] = None
    except Exception:
        try:
            os.unlink(tmp)
        except EnvironmentError:
            pass
        raise


# ----------------------------------------------------------------- settings
_settings_cache = {"sig": None, "value": None}


def _file_sig(path):
    try:
        return mtime_sig(path)          # (inode, mtime, size): every save is a new file (an atomic rename): a new inode
    except EnvironmentError:
        return None


def get_settings():
    """The settings, re-read from disk only when the file changed (this is asked several times a second)."""
    with _lock:
        ensure_dirs()
        sig = _file_sig(SETTINGS_FILE)
        if _settings_cache["value"] is not None and sig == _settings_cache["sig"]:
            return dict(_settings_cache["value"])
        s = _get_settings_uncached()
        _settings_cache["sig"], _settings_cache["value"] = sig, dict(s)
        return s


def _get_settings_uncached():
    s = dict(DEFAULT_SETTINGS)
    saved = _read(SETTINGS_FILE, {})
    if isinstance(saved, dict):
        for k in DEFAULT_SETTINGS:
            if k in saved:
                s[k] = saved[k]
    if not s.get("update_repo"):
        s["update_repo"] = DEFAULT_SETTINGS["update_repo"]
    if isinstance(saved, dict) and saved.get("step_audio_ver") != 2 and s["step_audio_ms"] == 100:
        s["step_audio_ms"] = 500        # 100 ms was the old default, never chosen on purpose; half a second is the step now
    if isinstance(saved, dict) and saved.get("web_port_ver") != 2 and s["web_port"] == 8099:
        s["web_port"] = 9990            # the old default port; the web page lives on 9990 now
    if s["mute_mode"] == "enigma":      # versions before 0.7 used this word for the system mute
        s["mute_mode"] = "decoder"
    if s["alsa_device"] == "default":   # the old default; "auto" tries the real cards first, then "default"
        s["alsa_device"] = "auto"
    if s.get("ui_font") not in FONT_IDS:
        s["ui_font"] = "skin"
    if isinstance(saved, dict) and saved.get("dvb_route_ver") != 2 and str(s.get("route") or "").endswith("|dvb-raw"):
        s["route"] = ""
    # Test5: undo the forced 1200 ms of the 1.0.6 test builds (Vu+ BCM7xxx cut ~15% of the time with it); 500 ms is
    # the official 1.0.6 value. Only the exact forced value is reset, any other user choice is kept.
    if isinstance(saved, dict) and saved.get("buffer_ms_ver") != 5 and int(s.get("buffer_ms", 500)) == 1200:
        s["buffer_ms"] = 500
    return s


def _validated_settings(new, base=None):
    s = dict(get_settings() if base is None else base)
    if not isinstance(new, dict):
        raise ValueError(T("Invalid settings"))
    for key, values in (("output", ("auto", "alsa", "aplay", "pcm", "gst", "dvb", "null")),
                        ("mute_mode", ("decoder", "track", "system", "none", "enigma")),
                        ("language", ("en", "ar")), ("ui_font", FONT_IDS)):
        if key in new and new[key] not in values:
            raise ValueError(T("Invalid settings"))
    if new.get("output") in ("auto", "alsa", "aplay", "pcm", "gst", "dvb", "null"):
        s["output"] = str(new["output"])
    if "alsa_device" in new:
        if not _DEVICE.match(to_text(new["alsa_device"])):
            raise ValueError(T("Invalid ALSA device name"))
        s["alsa_device"] = str(to_text(new["alsa_device"]))
    if new.get("mute_mode") in ("decoder", "track", "system", "none", "enigma"):
        s["mute_mode"] = "decoder" if new["mute_mode"] == "enigma" else str(new["mute_mode"])
    if "route" in new and (new["route"] == "" or re.match(r"^(alsa|aplay|pcm|gst|gst-pcm|gst-aplay)\|[A-Za-z0-9_:,=.\-]{1,64}$", to_text(new["route"]))):
        s["route"] = str(to_text(new["route"]))
    if new.get("language") in ("en", "ar"):
        s["language"] = str(new["language"])
    if "ui_font" in new:
        s["ui_font"] = str(new["ui_font"])
    if "theme" in new:
        s["theme"] = str(new["theme"]) if new["theme"] in THEMES else "classic"
    if "update_repo" in new:
        from .updater import normalize_repo
        s["update_repo"] = normalize_repo(new["update_repo"])
    for flag in ("timeshift_ahead", "long_audio"):
        if flag in new:
            if not isinstance(new[flag], (bool,) + integer_types) or new[flag] not in (0, 1, True, False):
                raise ValueError(T("Invalid settings"))
            s[flag] = bool(new[flag])
    for key, lo, hi, cast in (("web_port", 1024, 65535, int), ("volume", 0, 200, int), ("buffer_ms", 100, 5000, int),
                              ("step_video_s", 0.1, 10, float), ("step_audio_ms", 10, 2000, int)):
        if key in new:
            try:
                v = cast(new[key])
            except (ValueError, TypeError, OverflowError):
                raise ValueError(T("%s is out of range", key))
            if not lo <= v <= hi:
                raise ValueError(T("%s is out of range", key))
            s[key] = v
    s["step_audio_ver"] = 2
    s["web_port_ver"] = 2
    s["dvb_route_ver"] = 2
    s["buffer_ms_ver"] = 5
    return s


def set_settings(new):
    with _lock:
        s = _validated_settings(new)
        _write(SETTINGS_FILE, s)
        _settings_cache["sig"] = None
        try:
            from . import i18n
            i18n.invalidate()
        except Exception:
            pass
        return s


# ------------------------------------------------------------------ metadata
# query parameters that name the channel (kept in the key); everything else in a query is a token that changes
_ID_PARAMS = {"id", "ch", "chan", "channel", "channelid", "channel_id", "chid", "cid", "sid", "stream", "streamid",
              "stream_id", "station", "stationid", "station_id", "radio", "radioid", "radio_id"}
_TOKEN_PARAMS = {"token", "access_token", "auth_token", "sig", "signature", "expires", "expire", "exp", "auth",
                 "authkey", "key", "hash", "ts", "timestamp", "session", "sessionid", "session_id", "wmsauthsign",
                 "hdnts", "hdnea", "hmac"}


def legacy_host_key(url):
    """The key versions up to 0.11.6 stored: host + path only."""
    p = urlsplit(to_text(url))
    return "%s%s" % (p.netloc.lower(), p.path.rstrip("/").lower())


def host_key(url):
    """host + path + the query parameters that name the channel (play.php?id=1 and ?id=2 are two channels), never the
    token, which changes between refreshes."""
    p = urlsplit(to_text(url))
    keep = sorted((k.lower(), v) for k, v in parse_qsl(p.query, keep_blank_values=True)
                  if k.lower() in _ID_PARAMS and len(v) <= 40)
    return p.netloc.lower() + p.path.rstrip("/") + ("?" + urlencode(keep) if keep else "")


def _detail_key(url):
    """Disambiguate equal names/paths without treating common expiring tokens as identities."""
    p = urlsplit(to_text(url))
    keep = sorted((k.lower(), v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k.lower() not in _TOKEN_PARAMS)
    return p.netloc.lower() + p.path.rstrip("/") + ("?" + urlencode(keep) if keep else "")


def detect_meta(name, url="", group=""):
    """Guess provider / channel number / tag (delay, low, 4k...) from names like 'Orange Audio 3 Delay'."""
    text = u" ".join((to_text(name or ""), to_text(group or ""), urlsplit(to_text(url or "")).netloc)).lower().replace("-", " ").replace("_", " ")
    provider = ""
    for key in PROVIDERS:
        if key in text.replace(" ", ""):
            provider = PROVIDERS[key][0]
            break
    tag = ""
    for t in TAGS:
        if re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(t), to_text(name or "").lower().replace("-", " ").replace("_", " ")):
            tag = t
            break
    nums = re.findall(r"(?<![0-9k])\d{1,2}(?![0-9])", re.sub(r"4\s?k", " ", to_text(name or "").lower()))
    number = int(nums[-1]) if nums else 0
    return {"provider": provider, "number": number, "tag": tag}


def provider_info(provider, label=""):
    """(label, accent) for a provider key; unknown ones get a stable colour from their name."""
    for p in PROVIDERS.values():
        if p[0] == provider:
            return p[1], p[2]
    text = to_text(label or provider or "AUDIO").upper()[:12]
    h = sum(ord(c) * (i + 3) for i, c in enumerate(text)) % 360
    import colorsys
    r, g, b = colorsys.hls_to_rgb(h / 360.0, 0.62, 0.7)
    return text, "#%02X%02X%02X" % (int(r * 255), int(g * 255), int(b * 255))


# ------------------------------------------------------------------- library
def _empty():
    return {"version": 2, "folders": [], "streams": []}


_library_cache = {"sig": None, "value": None, "streams": {}, "folders": {}}


def library_revision():
    """Cheap file identity for on-box refresh and external edit detection."""
    return _file_sig(LIBRARY_FILE)


def _cached_library():
    """Internal read-only snapshot. Callers hold _lock and never mutate it."""
    ensure_dirs()  # Migrate BEFORE any library/settings read or starter write.
    sig = library_revision()
    if _library_cache["value"] is None or sig != _library_cache["sig"]:
        lib = _load_uncached()
        _library_cache.update(sig=sig, value=lib,
                              streams={s["id"]: s for s in lib["streams"]},
                              folders={f["id"]: f for f in lib["folders"]})
    return _library_cache["value"]


def _load():
    """An independent editable snapshot; only _save commits its changes."""
    with _lock:
        return copy.deepcopy(_cached_library())


def _load_uncached():
    lib = _read(LIBRARY_FILE, None)
    if isinstance(lib, dict) and lib.get("version") == 2:
        folders, streams = lib.get("folders", []), lib.get("streams", [])
        lib["folders"] = [dict(f) for f in (folders if isinstance(folders, list) else [])
                          if isinstance(f, dict) and _ID.match(to_text(f.get("id", "")))]
        lib["streams"] = [dict(x) for x in (streams if isinstance(streams, list) else [])
                          if isinstance(x, dict) and _ID.match(to_text(x.get("id", ""))) and valid_url(x.get("url"))]
        by = {}
        for f in lib["folders"]:
            by.setdefault(f["id"], f)
        lib["folders"] = [f for f in lib["folders"] if by[f["id"]] is f]
        for f in lib["folders"]:
            f["name"] = clean_text(f.get("name"), 60) or "Folder"
            if not isinstance(f.get("source"), dict):
                f["source"] = None
            cur, seen = f["id"], set()
            while cur:
                if cur in seen or len(seen) > 32:
                    f["parent"] = ""
                    break
                seen.add(cur)
                node = by.get(cur)
                if node is None:
                    f["parent"] = ""
                    break
                cur = node.get("parent", "")
                if not isinstance(cur, string_types):
                    f["parent"] = ""
                    break
        for x in lib["streams"]:
            x["name"] = clean_text(x.get("name"), 80) or "Audio"
            if x.get("folder") not in by:
                x["folder"] = ""
        return lib
    lib = _empty()
    legacy = _read(LEGACY_FILE, None)       # migrate v0.1 streams.json into one folder
    if isinstance(legacy, dict) and legacy.get("streams"):
        fid = new_id()
        lib["folders"].append({"id": fid, "parent": "", "name": "Imported", "provider": "", "source": None, "updated": 0})
        for s in legacy["streams"]:
            if isinstance(s, dict) and _ID.match(to_text(s.get("id", ""))) and valid_url(s.get("url")):
                s = dict(s, folder=fid)
                s.update({k: v for k, v in detect_meta(s.get("name", ""), s["url"]).items()})
                s.setdefault("remote_key", "")
                lib["streams"].append(s)
        _write(LIBRARY_FILE, lib)
    return lib


def _save(lib):
    _write(LIBRARY_FILE, lib)


def display_folder_name(folder, language=None):
    """Translate bundled Radio/Arabic names without changing IDs or stored user names."""
    if folder.get("preset") == "radio_quran" and to_text(folder.get("name")) in (u"Quran", u"القرآن الكريم"):
        if language is None:
            from .i18n import lang
            language = lang()
        return u"القرآن الكريم" if language == "ar" else u"Quran"
    if folder.get("preset") == "radio_ar" and to_text(folder.get("name")) in (u"Arabic", u"عربي"):
        if language is None:
            from .i18n import lang
            language = lang()
        return u"عربي" if language == "ar" else u"Arabic"
    return to_text(folder.get("name", ""))


def is_radio_folder(folder_id, lib=None):
    """Radio follows the folder tree; new language folders work without special configuration."""
    if lib is None:
        with _lock:
            return is_radio_folder(folder_id, _cached_library())
    by = {f["id"]: f for f in lib["folders"]}
    seen = set()
    while folder_id and folder_id not in seen:
        seen.add(folder_id)
        f = by.get(folder_id)
        if not f:
            break
        if f.get("preset") == "radio_root":
            return True
        folder_id = f.get("parent", "")
    return False


def is_radio_stream(stream, lib=None):
    return bool(stream.get("kind") == "radio" or is_radio_folder(stream.get("folder", ""), lib))


# A unicode pattern on Python 2 as well: in a py2 byte-string pattern "\u2014" would match the letters "u2014".
_RADIO_DURATION = re.compile(u"^(.*?)\\s+[\u2014\u2013-]\\s+(\\d{1,3}:[0-5]\\d(?::[0-5]\\d)?)\\s*$", re.U)


def stream_display(stream, lib=None):
    """Separate a recording's trailing duration for display, preserving stored names."""
    name = to_text(stream.get("name", ""))
    match = _RADIO_DURATION.match(name) if is_radio_stream(stream, lib) else None
    return (match.group(1).strip(), match.group(2)) if match and match.group(1).strip() else (name, "")


def is_quran_folder(folder_id, lib=None):
    """Quran identity belongs to a folder or descendants of the bundled Quran root.

    Use preset ID rather than names: works in Arabic or English, even after
    renaming a folder or creating nested folders; normal Arabic radio remains RADIO.
    """
    if lib is None:
        with _lock:
            return is_quran_folder(folder_id, _cached_library())
    by = {f["id"]: f for f in lib["folders"]}
    seen = set()
    while folder_id and folder_id not in seen:
        seen.add(folder_id)
        f = by.get(folder_id)
        if not f:
            break
        if f.get("preset") in ("radio_quran", "radio_sayed_saeed", "radio_shaarawi"):
            return True
        folder_id = f.get("parent", "")
    return False


def is_quran_stream(stream, lib=None):
    return is_quran_folder(stream.get("folder", ""), lib)


def streams_first(folder_id, lib=None):
    """The Shaarawi landing folder leads with its live station, then tafsir."""
    lib = lib if lib is not None else _load()
    return any(f.get("id") == folder_id and f.get("preset") == "radio_shaarawi"
               for f in lib["folders"])


def needs_radio_url(stream):
    """Only verified-looking audio URLs may be started; official pages are not raw radio audio."""
    return bool(stream.get("needs_stream_url"))


def list_folders():
    return _load()["folders"]


def get_folder(fid):
    with _lock:
        _cached_library()
        return copy.deepcopy(_library_cache["folders"].get(fid))


def _depth(lib, fid):
    d, seen = 0, set()
    while fid and fid not in seen:
        seen.add(fid)
        f = next((x for x in lib["folders"] if x["id"] == fid), None)
        if not f:
            break
        fid, d = f.get("parent", ""), d + 1
    return d


def add_folder(name, parent="", provider="", source=None):
    with _lock:
        lib = _load()
        name = clean_text(name, 60)
        if not name:
            raise ValueError(T("Folder name is required"))
        if parent and not any(f["id"] == parent for f in lib["folders"]):
            raise KeyError(parent)
        if _depth(lib, parent) >= MAX_DEPTH:
            raise ValueError(T("Folders are nested too deeply"))
        f = {"id": new_id(), "parent": parent or "", "name": name,
             "provider": provider or detect_meta(name)["provider"], "source": source, "updated": 0}
        lib["folders"].append(f)
        _save(lib)
        return f


def rename_folder(fid, name):
    with _lock:
        lib = _load()
        for f in lib["folders"]:
            if f["id"] == fid:
                f["name"] = clean_text(name, 60) or f["name"]
                _save(lib)
                return f
    raise KeyError(fid)


def delete_folder(fid):
    """Delete a folder with everything inside it."""
    with _lock:
        lib = _load()
        if not any(f["id"] == fid for f in lib["folders"]):
            raise KeyError(fid)
        doomed, stack = set(), [fid]
        while stack:
            cur = stack.pop()
            if cur in doomed:
                continue
            doomed.add(cur)
            stack += [f["id"] for f in lib["folders"] if f.get("parent") == cur]
        gone = [s["id"] for s in lib["streams"] if s.get("folder") in doomed]
        lib["folders"] = [f for f in lib["folders"] if f["id"] not in doomed]
        lib["streams"] = [s for s in lib["streams"] if s.get("folder") not in doomed]
        _save(lib)
        for sid in gone:
            _remove_picons(sid)
        return len(gone)


def folder_path(fid):
    lib, out, seen = _load(), [], set()
    while fid and fid not in seen:
        seen.add(fid)
        f = next((x for x in lib["folders"] if x["id"] == fid), None)
        if not f:
            break
        out.append({"id": f["id"], "name": f["name"]})
        fid = f.get("parent", "")
    return list(reversed(out))


def count_streams(fid, lib=None):
    lib = lib or _load()
    ids, stack = set(), [fid]
    while stack:
        cur = stack.pop()
        if cur in ids:
            continue
        ids.add(cur)
        stack += [f["id"] for f in lib["folders"] if f.get("parent") == cur]
    return sum(1 for s in lib["streams"] if s.get("folder") in ids)


_NO_ORDER = 10 ** 9


def children(fid="", lib=None):
    """Folders and streams directly inside folder `fid` ('' = root), folders first, natural order."""
    lib = lib or _load()
    folders = [dict(f, count=count_streams(f["id"], lib)) for f in lib["folders"] if f.get("parent", "") == (fid or "")]
    streams = [s for s in lib["streams"] if s.get("folder", "") == (fid or "")]
    return sorted(folders, key=folder_key), sorted(streams, key=stream_key)


def name_key(x):
    """Natural order of names: 'Audio 2' before 'Audio 10'."""
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", to_text(x.get("name", "")))]


def folder_key(x):
    """Explicit web folder order takes precedence over the legacy natural-name order."""
    order = x.get("order")
    has_order = isinstance(order, integer_types) and not isinstance(order, bool) and order >= 0
    return (order if has_order else _NO_ORDER, name_key(x))


def set_folder_order(parent, ids):
    """Atomic exact permutation of ALL sibling folder ids, including nested Radio folders."""
    if not isinstance(ids, list) or not ids:
        raise ValueError(T("Unknown folder"))
    parent = to_text(parent or "")
    if not all(isinstance(i, string_types) for i in ids):
        raise ValueError(T("Unknown folder"))
    with _lock:
        lib = _load()
        siblings = [f for f in lib["folders"] if f.get("parent", "") == parent]
        known = {f["id"]: f for f in siblings}
        if (len(ids) != len(siblings) or len(set(ids)) != len(ids)
                or set(ids) != set(known)):
            raise ValueError(T("Folder order must contain every folder in the current location"))
        for n, fid in enumerate(ids):
            known[fid]["order"] = n * 10
        _save(lib)
    return True


def stream_key(x):
    """Streams the owner dragged keep that order; everything else follows, in natural name order."""
    order = x.get("order")
    has_order = isinstance(order, integer_types) and not isinstance(order, bool)
    return (order if has_order else _NO_ORDER, name_key(x))


# ------------------------------------------------------------------ streams
def list_streams():
    return _load()["streams"]


def get_stream(sid):
    with _lock:
        _cached_library()
        return copy.deepcopy(_library_cache["streams"].get(sid))


def _normalize(d, base=None):
    s = dict(base or {})
    if "name" in d:
        s["name"] = clean_text(d["name"], 80)
    if "url" in d:
        s["url"] = to_text(d["url"]).strip()
    if "icon_choice" in d:
        choice = d["icon_choice"]
        if not isinstance(choice, string_types) or (choice and not iconchoices.resolve(choice)):
            raise ValueError(T("Choose an icon from the list"))
        s["icon_choice"] = to_text(choice)
    if "audio_track" in d:
        s["audio_track"] = max(0, min(15, int(d["audio_track"] or 0)))
    if "user_agent" in d:
        s["user_agent"] = clean_text(d["user_agent"], 200)
    if not s.get("name"):
        raise ValueError(T("Channel name is required"))
    if not valid_url(s.get("url")):
        raise ValueError(T("The link must start with http or https"))
    meta = detect_meta(s["name"], s["url"])
    for k in ("provider", "number", "tag"):
        if k in d:
            s[k] = clean_text(d[k], 80) if k in ("provider", "tag") else max(0, min(9999, int(d[k] or 0)))
        else:
            s.setdefault(k, meta[k])
    s.setdefault("audio_track", 0)
    s.setdefault("user_agent", "")
    s.setdefault("video_delay_s", 0.0)
    s.setdefault("audio_delay_ms", 0)
    s.setdefault("remote_key", "")
    s.setdefault("folder", "")
    return s


def add_stream(d, folder=""):
    with _lock:
        lib = _load()
        folder = d.get("folder", folder) or ""
        if folder and not any(f["id"] == folder for f in lib["folders"]):
            raise KeyError(folder)
        s = _normalize(d)
        s["folder"] = folder
        s["id"] = new_id()
        lib["streams"].append(s)
        _save(lib)
        return s


def update_stream(sid, d):
    with _lock:
        lib = _load()
        for i, old in enumerate(lib["streams"]):
            if old["id"] == sid:
                new = _normalize(d, old)
                if old.get("needs_stream_url") and d.get("url") and d["url"] != old.get("url"):
                    new.pop("needs_stream_url", None)
                if "folder" in d:
                    if d["folder"] and not any(f["id"] == d["folder"] for f in lib["folders"]):
                        raise KeyError(d["folder"])
                    if (d["folder"] or "") != old.get("folder", ""):
                        new.pop("order", None)               # a place in another folder means nothing here
                        new["user_folder"] = True            # moved by hand: "Update from the source" keeps it there
                    new["folder"] = d["folder"] or ""
                lib["streams"][i] = new
                _save(lib)
                return new
    raise KeyError(sid)


def set_stream_order(ids):
    """The owner dragged commentaries into a new order: `ids` is the whole list of one folder, first to last."""
    ids = [to_text(i) for i in ids]
    with _lock:
        lib = _load()
        by = {x["id"]: x for x in lib["streams"]}
        if not ids or len(set(ids)) != len(ids) or any(i not in by for i in ids):
            raise ValueError(T("Unknown channel"))
        if len(set(by[i].get("folder", "") for i in ids)) != 1:
            raise ValueError(T("Unknown channel"))
        for n, i in enumerate(ids):
            by[i]["order"] = n * 10
        _save(lib)
        return True


def delete_stream(sid):
    with _lock:
        lib = _load()
        kept = [s for s in lib["streams"] if s["id"] != sid]
        if len(kept) == len(lib["streams"]):
            raise KeyError(sid)
        lib["streams"] = kept
        _save(lib)
        _remove_picons(sid)


def set_offsets(sid, video_s=None, audio_ms=None):
    with _lock:
        lib = _load()
        for s in lib["streams"]:
            if s["id"] == sid:
                if video_s is not None:
                    s["video_delay_s"] = round(max(0.0, min(600.0, float(video_s))), 1)
                if audio_ms is not None:
                    s["audio_delay_ms"] = int(max(0, min(60000, int(audio_ms))))
                _save(lib)
                return s
    return None


# -------------------------------------------------------------------- import
_AUTO_GROUPS = re.compile(r"^[A-Za-z0-9]+[-_ ](4k|low|vip|middle|delay|best)(?=[-_ ])", re.I)
_GROUP_WORD = re.compile(r"(?<![A-Za-z0-9])(4k|low|vip|middle|delay|best)(?![A-Za-z0-9])", re.I)
_GROUP_LABEL = {"4k": "4K", "low": "Low", "vip": "VIP", "middle": "Middle", "delay": "Delay", "best": "Best"}


def auto_group(name):
    """'SatFamily-Low-Ad-2' -> 'Low', 'SatFamily-Match-Low' -> 'Low'; '' when the name carries no group word.
    The word right after the provider wins; otherwise the first group word anywhere after the provider."""
    name = to_text(name or "")
    m = _AUTO_GROUPS.match(name)
    if m:
        return _GROUP_LABEL[m.group(1).lower()]
    rest = re.split(r"[-_ ]", name, 1)
    m = _GROUP_WORD.search(rest[1]) if len(rest) > 1 else None
    return _GROUP_LABEL[m.group(1).lower()] if m else ""


def apply_import(folder_name, entries, source, parent="", prune=True):
    """Refresh only this source's entries, preserving stable channel identities and offsets."""
    with _lock:
        lib = _load()
        src_key = (source or {}).get("key") or (source or {}).get("url") or folder_name
        root = next((f for f in lib["folders"] if (f.get("source") or {}).get("key") == src_key
                     and f.get("parent", "") == (parent or "")), None)
        if root is None:
            if parent and not any(f["id"] == parent for f in lib["folders"]):
                raise KeyError(parent)
            if _depth(lib, parent) >= MAX_DEPTH:
                raise ValueError(T("Folders are nested too deeply"))
            root = {"id": new_id(), "parent": parent or "", "name": clean_text(folder_name, 60) or "Source",
                    "provider": detect_meta(folder_name, (source or {}).get("url", ""))["provider"],
                    "source": None, "updated": 0}
            lib["folders"].append(root)
        root["source"] = dict(source or {}, key=src_key)
        import time as _t
        root["updated"] = int(_t.time())
        owned, stack = set(), [root["id"]]
        while stack:
            cur = stack.pop()
            if cur in owned:
                continue
            owned.add(cur)
            stack.extend(f["id"] for f in lib["folders"] if f.get("parent") == cur and not f.get("source"))
        # Source ownership follows a channel moved by hand, even into another tree or the Library root.
        # Older entries without source_id can only be attributed through this source's folder tree.
        existing = [x for x in lib["streams"] if x.get("remote_key") and
                    (x.get("source_id") == root["id"] or
                     ("source_id" not in x and x.get("folder") in owned))]
        claimed = set()
        exact, named, detailed, by_base = {}, {}, {}, {}
        for x in existing:
            base = host_key(x["url"])
            exact.setdefault((x["url"], x["name"].lower()), []).append(x)
            named.setdefault((base, x["name"].lower()), []).append(x)
            detailed.setdefault((_detail_key(x["url"]), x["name"].lower()), []).append(x)
            by_base.setdefault(base, []).append(x)

        def unclaimed(index, key):
            values = index.get(key, [])
            return next((x for x in values if x["id"] not in claimed), None)

        def sub_folder(group):
            g = clean_text(group, 60)
            if not g:
                return root["id"]
            for f in lib["folders"]:
                if f.get("parent") == root["id"] and not f.get("source") and f["name"].lower() == g.lower():
                    return f["id"]
            f = {"id": new_id(), "parent": root["id"], "name": g, "provider": root.get("provider", ""),
                 "source": None, "updated": 0, "auto": True, "source_id": root["id"]}
            lib["folders"].append(f)
            return f["id"]

        prepared, seen = [], set()
        for e in entries:
            if not isinstance(e, dict):
                continue
            name, url = clean_text(e.get("name"), 80), to_text(e.get("url", "")).strip()
            if not name or not valid_url(url):
                continue
            identity = (host_key(url), _detail_key(url), name.lower())
            if identity in seen:
                continue
            seen.add(identity)
            prepared.append((e, name, url, identity[0]))
        base_counts, name_counts = {}, {}
        for e, name, url, key in prepared:
            base_counts[key] = base_counts.get(key, 0) + 1
            nk = (key, name.lower())
            name_counts[nk] = name_counts.get(nk, 0) + 1
        derived = {name: auto_group(name) for e, name, url, key in prepared if not e.get("group")}
        use_derived = len({g for g in derived.values() if g}) >= 2
        if use_derived:
            # a channel whose name carries no group word ('SatFamily-Match-1' in the middle of the Low ones) joins the
            # group of the channels around it in the list, instead of staying alone outside every folder
            order = [name for e, name, url, key in prepared if not e.get("group")]
            last = ""
            for name in order:
                if derived.get(name):
                    last = derived[name]
                elif last:
                    derived[name] = last
            nxt = ""
            for name in reversed(order):
                if derived.get(name):
                    nxt = derived[name]
                elif nxt:
                    derived[name] = nxt
        added, updated = 0, 0
        for e, name, url, base_key in prepared:
            key = base_key + ("#" + name.lower() if base_counts[base_key] > 1 else "")
            if name_counts[(base_key, name.lower())] > 1:
                key += "#" + _detail_key(url)
            # Prefer the owner's moved channel over a duplicate an older refresh left in the source folder.
            detail = (_detail_key(url), name.lower())
            cur = next((x for x in detailed.get(detail, []) if x.get("user_folder") and x["id"] not in claimed), None)
            # Exact/name indexes also migrate the old ambiguous keys safely.
            if cur is None:
                cur = unclaimed(exact, (url, name.lower()))
            if cur is None:
                cur = unclaimed(detailed, detail)
            if cur is None and name_counts[(base_key, name.lower())] == 1:
                candidates = [x for x in named.get((base_key, name.lower()), []) if x["id"] not in claimed]
                if len(candidates) == 1:
                    cur = candidates[0]
            if cur is None:
                candidates = [x for x in by_base.get(base_key, []) if x["id"] not in claimed]
                if len(candidates) == 1 and base_counts[base_key] == 1:
                    cur = candidates[0]
            group = e.get("group", "") or (derived.get(name, "") if use_derived else "")
            meta = detect_meta(name, url, group)
            if not meta["provider"]:
                meta["provider"] = root.get("provider", "")
            if cur is not None:
                claimed.add(cur["id"])
                if cur["url"] != url or cur["name"] != name:
                    updated += 1
                # a channel the owner moved by hand stays where he put it (while that folder exists)
                keep = cur.get("user_folder") and (not cur.get("folder") or
                                                   any(f["id"] == cur.get("folder") for f in lib["folders"]))
                cur.update(dict(meta, url=url, name=name, remote_key=key, source_id=root["id"],
                                folder=cur["folder"] if keep else sub_folder(group)))
                if valid_url(e.get("logo")) and not cur.get("logo_off"):
                    cur["logo_url"] = e["logo"]
            else:
                cur = _normalize(dict(meta, name=name, url=url))
                cur.update(id=new_id(), folder=sub_folder(group), remote_key=key, source_id=root["id"],
                           logo_url=e.get("logo") if valid_url(e.get("logo")) else "")
                lib["streams"].append(cur)
                added += 1
        gone = [x for x in existing if x["id"] not in claimed] if prune else []
        ids = {x["id"] for x in gone}
        lib["streams"] = [x for x in lib["streams"] if x["id"] not in ids]
        if prune:
            used = {x.get("folder") for x in lib["streams"]} | {f.get("parent") for f in lib["folders"]}
            lib["folders"] = [f for f in lib["folders"] if not
                              (f.get("auto") and not f.get("source") and f.get("parent") == root["id"] and f["id"] not in used)]
        _save(lib)
        for x in gone:
            _remove_picons(x["id"])
        return {"folder": root["id"], "added": added, "updated": updated, "removed": len(ids)}


# ------------------------------------------------------------------- picons
def _remove_picons(sid):
    for ext in PICON_EXTS:
        try:
            os.unlink(os.path.join(PICON_DIR, "%s.%s" % (sid, ext)))
        except EnvironmentError:
            pass


def picon_file(sid):
    """Path of the stream's own (custom) picon, or None."""
    if not _ID.match(to_text(sid)):
        return None
    for ext in PICON_EXTS:
        p = os.path.join(PICON_DIR, "%s.%s" % (sid, ext))
        if os.path.isfile(p):
            return p
    return None


def _scale_suffix(scale):
    """Pre-sized artwork: @4x / @2x for big skins, @hd for 720p skins (DreamOS cannot scale pixmaps itself)."""
    if scale >= 2.8:
        return "@4x"
    if scale >= 1.4:
        return "@2x"
    if scale < 0.85:
        return "@hd"
    return ""


def _sized(folder, stem, scale):
    """assets/<folder>/<stem><suffix>.png when that size exists, else the plain 1x picture."""
    cand = os.path.join(ASSETS, folder, stem + _scale_suffix(scale) + ".png")
    return cand if os.path.isfile(cand) else os.path.join(ASSETS, folder, stem + ".png")


def _is_onsport_fm(s):
    """ON Sport FM by its name (any case/spacing) or by its bundled stream link."""
    name = re.sub(r"\s+", " ", to_text(s.get('name') or '')).strip().lower()
    if name == 'on sport fm':
        return True
    try:
        p = urlsplit(to_text(s.get('url') or ''))
        return (p.hostname or '').lower() == 'carina.streamerr.co' and p.path.rstrip('/').lower() == '/stream/onsportfm'
    except ValueError:
        return False


def stream_icon(s, use_logos=None, scale=1.0, lib=None):
    """An explicit bundled icon wins; otherwise use automatic channel/folder matching.

    Unknown channels use the approved LIVE emblem, never a missing source badge.
    """
    # The approved ON Sport FM badge is radio-only, not a logo for ON TV.
    if _is_onsport_fm(s) and is_radio_stream(s, lib):
        picture = _sized('radio', 'onsportfm', scale)
        if os.path.isfile(picture):
            return picture
    manual = iconchoices.resolve(s.get("icon_choice"), scale)
    if manual:
        return manual
    # RADIO / QURAN channels reuse their folder's approved full-color artwork,
    # not the obsolete plain white per-stream logos. Same path = same pixmap cache
    # entry on Enigma2 and the same WebP backing asset on the web. The Quran
    # branch must precede radio because Quran is nested inside Radio.
    # A stream created from the web inherits its identity through its folder.
    if is_quran_stream(s, lib):
        return _sized("folders", "quran", scale)
    if is_radio_stream(s, lib):
        return _sized("folders", "radio", scale)
    try:
        from . import logos as _logos
        p = _logos.find(s, scale)
        if p:
            return p
        p = _logos.find({'name': 'Live'}, scale)
        if p:
            return p
    except Exception:
        pass
    return DEFAULT_PICON


def folder_icon(f, scale=1.0, lib=None):
    # Reuse RADIO / QURAN artwork on their folders (including subfolders).
    # Preset identities, rather than translated names, survive folder renaming.
    preset = f.get("preset")
    fid = f.get("id", "")
    if preset == "radio_quran" or (fid and is_quran_folder(fid, lib)):
        identity = "quran"
    elif preset in ("radio_root", "radio_ar") or (fid and is_radio_folder(fid, lib)):
        identity = "radio"
    else:
        identity = ""
    if identity:
        return _sized("folders", identity, scale)
    # The new neon wordmarks are folder-only; independent TV-channel logos
    # continue to be determined by stream_icon / logos.py.
    name_key = re.sub(r"[^a-z0-9]+", "", to_text(f.get("name") or "").lower())
    prov = re.sub(r"[^a-z0-9]+", "", to_text(f.get("provider") or "").lower())
    if name_key.startswith("anis") or prov == "anis":
        identity = "anis"
    else:
        identity = ""
    for name, aliases in (("satfamily", ("satfamily", "sarfamily", "satfamilly")),
                          ("foxfm", ("foxfm",)), ("best", ("best",)),
                          ("orange", ("orange",))):
        if name_key in aliases or prov in aliases:
            identity = name
            break
    if not identity and f.get("parent"):
        # Nested folders inherit a source's identity, but never override a
        # known separate source or a child of Radio / Quran.
        parents = {v.get("id"): v for v in (lib if lib is not None else _load()).get("folders", [])}
        cur, seen = f.get("parent"), set()
        while cur and cur not in seen:
            seen.add(cur)
            ancestor = parents.get(cur) or {}
            key = re.sub(r"[^a-z0-9]+", "", to_text(ancestor.get("name") or "").lower())
            source = re.sub(r"[^a-z0-9]+", "", to_text(ancestor.get("provider") or "").lower())
            if key.startswith("anis") or source == "anis":
                identity = "anis"; break
            if key in ("satfamily", "sarfamily", "satfamilly", "foxfm", "best", "orange") or source in ("satfamily", "foxfm", "best", "orange"):
                identity = "satfamily" if key in ("sarfamily", "satfamilly") else (key if key in ("satfamily", "foxfm", "best", "orange") else source)
                break
            cur = ancestor.get("parent")
    if identity:
        result = _sized("folders", identity, scale)
        if os.path.isfile(result):
            return result
    # Fallback for unknown/custom folder names: their original provider emblem.
    prov = to_text(f.get("provider") or "").lower().replace(" ", "").replace("-", "").replace("_", "")
    if not any(prov == p[0] for p in PROVIDERS.values()):
        prov = detect_meta(to_text(f.get("name") or ""))["provider"]
    prov = prov if any(prov == p[0] for p in PROVIDERS.values()) else 'generic'
    suffix = _scale_suffix(scale)
    if suffix:
        sharp = os.path.join(ASSETS, "folders", "%s%s.png" % (prov, suffix))
        if os.path.isfile(sharp):
            return sharp
    p = os.path.join(ASSETS, "folders", "%s.png" % prov)
    return p if os.path.isfile(p) else DEFAULT_PICON


def web_icon(path):
    """The web page gets the big WebP twin of a built-in icon (assets/web/...); custom picons are served as they are."""
    try:
        rel = os.path.relpath(path, ASSETS)
    except ValueError:
        return path
    if rel.startswith(".."):
        return path
    base = re.sub(r"@(?:hd|2x|4x)$", "", os.path.splitext(rel)[0])
    w = os.path.join(ASSETS, "web", base + ".webp")
    return w if os.path.isfile(w) else path


def picon_or_default(sid):
    s = get_stream(sid)
    return stream_icon(s) if s else DEFAULT_PICON


def _sniff(data):
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if data[:4] == b"GIF8":
        return "gif"
    return None


def save_picon_bytes(sid, data, source_url=None):
    raise ValueError(T("Only bundled plugin icons are supported"))


def clear_picon(sid):
    """Clear obsolete saved artwork metadata without changing bundled icons."""
    with _lock:
        if not _ID.match(to_text(sid)):
            return
        _remove_picons(sid)
        lib = _load()
        stream = next((s for s in lib["streams"] if s["id"] == sid), None)
        if stream is not None and (stream.get("logo_url") or stream.get("picon_source_url")):
            stream["logo_url"] = stream["picon_source_url"] = ""
            stream["logo_off"] = True      # a refresh must not bring the provider's logo back either
            _save(lib)


def save_picon_dataurl(sid, dataurl):
    raise ValueError(T("Only bundled plugin icons are supported"))


def fetch_picon(sid, url):
    raise ValueError(T("Only bundled plugin icons are supported"))


def fetch_import_picon(sid, url):
    # Kept for older callers; imported artwork is never fetched.
    return False


# ----------------------------------------------------------- channel memory
MEMORY_MAX = 80
_session_memory = {}
_memory_loaded = False


def _memory():
    global _memory_loaded
    if not _memory_loaded:
        _memory_loaded = True
        ensure_dirs()
        saved = _read(MEMORY_FILE, {})
        if isinstance(saved, dict):
            for k, v in saved.items():
                if isinstance(k, string_types) and isinstance(v, dict) and _ID.match(to_text(v.get("sid", ""))):
                    try:
                        vs = round(max(0.0, min(600.0, float(v.get("video_s", 0.0) or 0.0))), 1)
                        ams = int(max(0, min(60000, int(v.get("audio_ms", 0) or 0))))
                        at = int(v.get("at", 0) or 0)
                        auto = bool(v.get("auto", True))
                        pinned = bool(v.get("pinned", False))
                        if isfinite(vs):
                            _session_memory[to_text(k)] = {"sid": to_text(v["sid"]), "video_s": vs,
                                                           "audio_ms": ams, "auto": auto, "at": at, "pinned": pinned}
                    except (ValueError, TypeError, OverflowError):
                        pass
    return _session_memory


def _save_memory():
    try:
        _write(MEMORY_FILE, _session_memory)
    except Exception:
        pass


def reset_session_offsets():
    """Keep per-TV-channel sync in channels.json; clear any legacy per-stream offsets so delays never follow audio streams to other TV channels."""
    with _lock:
        lib = _load()
        changed = False
        for stream in lib["streams"]:
            if stream.get("audio_delay_ms", 0) or stream.get("video_delay_s", 0):
                stream["audio_delay_ms"], stream["video_delay_s"] = 0, 0.0
                changed = True
        if changed:
            _save(lib)
        m = _memory()
        valid_sids = {s["id"] for s in lib.get("streams", [])}
        stale = [k for k, v in list(m.items()) if v.get("sid") not in valid_sids]
        for k in stale:
            del m[k]
        if stale:
            _save_memory()


def remember_channel(service, sid, video_s, audio_ms, auto=True, pinned=None):
    """Remember and persist the applied sync strictly for this receiver TV service (never on the audio stream).

    pinned=True marks a sync the owner saved on purpose (Save TV sync); None keeps the mark while the same
    commentary stays on this TV channel, another commentary clears it."""
    import time as _t
    if not service or not _ID.match(to_text(sid)):
        return
    vs = round(max(0.0, min(600.0, float(video_s or 0))), 1)
    ams = int(max(0, min(60000, int(audio_ms or 0))))
    with _lock:
        m = _memory()
        key = to_text(service)
        old = m.get(key)
        if pinned is None:
            pinned = bool(old and old.get("pinned") and old.get("sid") == to_text(sid))
        entry = {"sid": to_text(sid), "video_s": vs, "audio_ms": ams, "auto": bool(auto), "at": int(_t.time()),
                 "pinned": bool(pinned)}
        m[key] = entry
        if len(m) > MEMORY_MAX:
            for k in sorted(m, key=lambda k: m[k].get("at", 0))[:len(m) - MEMORY_MAX]:
                del m[k]
        if not old or (old.get("sid"), old.get("video_s"), old.get("audio_ms"), old.get("auto"), bool(old.get("pinned"))) != (
                entry["sid"], vs, ams, entry["auto"], entry["pinned"]):
            _save_memory()


def recall_channel(service):
    """The last applied TV sync for this service (persisted on disk), else None."""
    with _lock:
        e = _memory().get(to_text(service or ""))
        e = dict(e) if isinstance(e, dict) else None
    if e is None:
        return None
    return e


def forget_channel(service):
    """Disable automatic zap-resume when the user manually stops playback, while keeping saved delay offsets."""
    with _lock:
        m = _memory()
        key = to_text(service or "")
        entry = m.get(key)
        if isinstance(entry, dict) and entry.get("auto", True):
            entry["auto"] = False
            _save_memory()


def delete_channel(service):
    """Remove everything remembered for this TV service: no saved sync, no automatic resume."""
    with _lock:
        m = _memory()
        if m.pop(to_text(service or ""), None) is not None:
            _save_memory()
            return True
    return False


# ------------------------------------------------------------ backup / restore
BACKUP_FORMAT = 1
_RESTORE_SETTINGS = ("output", "alsa_device", "mute_mode", "volume", "buffer_ms", "step_video_s", "step_audio_ms",
                     "language", "timeshift_ahead", "long_audio", "theme", "ui_font")


def make_backup():
    """Everything the owner made: library (folders, channels, delays, order), settings and custom pictures."""
    import time as _t
    lib = _load()
    keep = {s["id"] for s in lib["streams"]}
    pics = {}
    try:
        names = os.listdir(PICON_DIR)
    except EnvironmentError:
        names = []
    for name in names:
        sid, _, ext = name.partition(".")
        if sid in keep and _ID.match(sid) and ext in PICON_EXTS:
            try:
                with open(os.path.join(PICON_DIR, name), "rb") as f:
                    raw = f.read(MAX_PICON + 1)
                if len(raw) <= MAX_PICON and _sniff(raw):
                    pics[name] = base64.b64encode(raw).decode("ascii")
            except EnvironmentError:
                pass
    st = get_settings()
    return {"app": "UltraAudio", "format": BACKUP_FORMAT, "created": _t.strftime("%Y-%m-%d %H:%M"),
            "library": lib, "settings": {k: st[k] for k in _RESTORE_SETTINGS if k in st}, "picons": pics}


def validate_backup(data):
    try:
        return _validate_backup(data)
    except (TypeError, AttributeError, OverflowError):
        raise ValueError(T("This file is not an Ultra Audio backup"))


def _validate_backup(data):
    """Validate the whole backup before any live file or player state is changed."""
    def bad():
        raise ValueError(T("This file is not an Ultra Audio backup"))
    if (not isinstance(data, dict) or data.get("app") != "UltraAudio" or data.get("format") != BACKUP_FORMAT
            or not isinstance(data.get("library"), dict)):
        bad()
    src = data["library"]
    folders, streams = src.get("folders"), src.get("streams")
    if (src.get("version") != 2 or not isinstance(folders, list) or not isinstance(streams, list)
            or len(folders) > 5000 or len(streams) > 20000):
        bad()
    by, normalized_folders = {}, []
    for original in folders:
        if (not isinstance(original, dict) or not isinstance(original.get("id"), string_types)
                or not _ID.match(to_text(original["id"])) or original["id"] in by
                or not isinstance(original.get("name"), string_types)):
            bad()
        f = dict(original)
        f["name"] = clean_text(f["name"], 60) or "Folder"
        if not isinstance(f.get("parent", ""), string_types):
            bad()
        f["parent"] = f.get("parent", "")
        source = f.get("source")
        if source is not None:
            if not isinstance(source, dict) or source.get("type") not in ("url", "text"):
                bad()
            if source.get("type") == "url" and not valid_url(source.get("url")):
                bad()
            if any(k in source and not isinstance(source[k], string_types) for k in ("key", "url", "text")):
                bad()
            f["source"] = dict(source)
        f["provider"] = clean_text(f.get("provider"), 80)
        by[f["id"]] = f
        normalized_folders.append(f)
    for f in normalized_folders:
        if f["parent"] not in by:
            f["parent"] = ""
        cur, seen = f["id"], set()
        while cur:
            if cur in seen or len(seen) >= 32:
                bad()
            seen.add(cur)
            cur = by[cur]["parent"] if by[cur]["parent"] in by else ""
    normalized_streams, ids = [], set()
    for original in streams:
        if (not isinstance(original, dict) or not isinstance(original.get("id"), string_types)
                or not _ID.match(to_text(original["id"])) or original["id"] in ids or original["id"] in by
                or not isinstance(original.get("name"), string_types)):
            bad()
        x = _normalize(original, original)
        for key, high, cast in (("video_delay_s", 600, float), ("audio_delay_ms", 60000, int)):
            value = float(original.get(key, 0))
            if not isfinite(value) or not 0 <= value <= high:
                bad()
            x[key] = cast(value)
        if "order" in x:
            x["order"] = int(x["order"])
        for key in ("remote_key", "source_id", "logo_url", "picon_source_url"):
            if key in x and not isinstance(x[key], string_types):
                bad()
        if x.get("folder") not in by:
            x["folder"] = ""
        ids.add(x["id"])
        normalized_streams.append(x)
    preset_state = src.get("presets", {})
    if not isinstance(preset_state, dict):
        bad()
    if "foxfm" in preset_state and preset_state["foxfm"] != 1:
        bad()
    if "radio" in preset_state and preset_state["radio"] not in (1, 2, 3):
        bad()
    # Restoring is an explicit choice of channels, including deleted defaults.
    # Mark every current seed as installed so sessionstart cannot repopulate it.
    from . import presets as bundled
    restored_presets = dict(preset_state)
    for key, current in (("foxfm", bundled.FOX_VERSION), ("radio", bundled.RADIO_VERSION),
                         ("quran_direct", bundled.QURAN_DIRECT_VERSION),
                         ("radio_extras", bundled.RADIO_EXTRAS_VERSION),
                         ("radio_expansion", bundled.RADIO_EXPANSION_VERSION),
                         ("radio_link_repair", bundled.RADIO_LINK_REPAIR_VERSION),
                         ("radio_107", bundled.RADIO_107_VERSION),
                         ("radio_complete", bundled.RADIO_COMPLETE_VERSION),
                         ("sayed_saeed", bundled.SAYED_SAEED_VERSION),
                         ("shaarawi", bundled.SHAARAWI_VERSION)):
        value = preset_state.get(key)
        if value is not None and (not isinstance(value, integer_types) or isinstance(value, bool) or not 0 <= value <= current):
            bad()
        restored_presets[key] = current
    # Old Shaarawi backups need the folder-flattening migration, without reseeding.
    if preset_state.get("shaarawi") == 1:
        restored_presets["shaarawi"] = 1
    if not normalized_folders and not normalized_streams and preset_state.get("foxfm") != 1:
        raise ValueError(T("The backup has no channels"))
    settings = data.get("settings", {})
    if not isinstance(settings, dict):
        bad()
    settings = {k: v for k, v in settings.items() if k in _RESTORE_SETTINGS}
    _validated_settings(settings)
    pics, decoded = data.get("picons", {}), {}
    if not isinstance(pics, dict) or len(pics) > 20000:
        bad()
    for name, value in pics.items():
        if not isinstance(name, string_types) or not isinstance(value, string_types):
            bad()
        sid, sep, ext = to_text(name).partition(".")
        if not sep or not _ID.match(sid) or sid not in ids or ext not in PICON_EXTS or len(value) > MAX_PICON * 2:
            bad()
        try:
            raw = _b64decode(value)
        except (binascii.Error, ValueError, TypeError):
            bad()
        if len(raw) > MAX_PICON or _sniff(raw) is None:
            bad()
        key = "%s.%s" % (sid, _sniff(raw))
        if key in decoded:
            bad()
        decoded[key] = raw
    # A restore is an explicit choice of library, including any omitted/deleted
    # presets. Never add starter channels to it on the following restart.
    return {"version": 2, "folders": normalized_folders, "streams": normalized_streams,
            "presets": restored_presets}, settings, decoded


def restore_backup(data):
    """Stage a validated backup, commit all files, and roll back every file on failure."""
    lib, settings, pics = validate_backup(data)
    with _lock:
        ensure_dirs()
        stage = tempfile.mkdtemp(prefix=".restore-", dir=DATA_DIR)
        moved, installed = [], []
        finished = False
        try:
            for name, value in (("library.json", lib), ("settings.json", _validated_settings(settings))):
                with open_text(os.path.join(stage, name), "w") as f:
                    f.write(to_text(json.dumps(value, ensure_ascii=False, indent=2)))
            os.mkdir(os.path.join(stage, "picons"))
            for name, raw in pics.items():
                with open(os.path.join(stage, "picons", name), "wb") as f:
                    f.write(raw)
            targets = ["library.json", "settings.json", "picons"]
            if os.path.isfile(LIBRARY_FILE):
                shutil.copyfile(LIBRARY_FILE, os.path.join(stage, "library.json.bak"))
                targets.append("library.json.bak")
            for name in targets:
                dst = os.path.join(DATA_DIR, name)
                if os.path.exists(dst):
                    old = os.path.join(stage, "old-" + name)
                    _replace(dst, old)
                    moved.append((old, dst))
                _replace(os.path.join(stage, name), dst)
                installed.append(dst)
            finished = True
        except Exception:
            for dst in reversed(installed):
                if os.path.isdir(dst):
                    shutil.rmtree(dst)
                elif os.path.exists(dst):
                    os.unlink(dst)
            for old, dst in reversed(moved):
                os.rename(old, dst)
            finished = True
            raise
        finally:
            _settings_cache["sig"] = None
            if finished:
                shutil.rmtree(stage, ignore_errors=True)
        try:
            from . import i18n
            i18n.invalidate()
        except Exception:
            pass
    return {"folders": len(lib["folders"]), "streams": len(lib["streams"]), "picons": len(pics)}
