# -*- coding: utf-8 -*-
"""Exclude tennis/basketball score cards without limiting football competitions."""
from __future__ import unicode_literals
import re
import unicodedata
from .compat import lru_cache, to_text

# Prefer the official sport/category over ambiguous club/player names in a title.
_EXCLUDED = re.compile(
    r"(?<![\w])(?:basket(?:ball)?|basket-ball|basketbol|nba|wnba|fiba|euroleague|"
    r"tennis|tenis|padel|fip|بادل|البادل|atp|wta|itf|wimbledon|roland\s+garros|davis\s+cup|"
    r"billie\s+jean\s+king|laver\s+cup|hopman\s+cup|"
    r"(?:كرة|كره)\s+(?:السلة|السله|المضرب|التنس)|السلة|السله|تنس|التنس|"
    r"سلة|سله|ويمبلدون|رولان\s+غاروس)(?![\w])", re.I)
_FOOTBALL = re.compile(
    r"(?<![\w])(?:football|soccer|uefa|fifa|afc|caf|conmebol|dfb|"
    r"(?:كرة|كره)\s+القدم)(?![\w])", re.I)


@lru_cache(maxsize=1024)
def _text(value):
    return unicodedata.normalize('NFKC', to_text(value or '')).replace('ـ', '')


def category_hint(category):
    """Keep a small immutable string in guide events/caches, never a raw object."""
    if isinstance(category, dict):
        category = ' '.join(to_text(category.get(k) or '') for k in ('English', 'Arabic', 'French'))
    return ' '.join(_text(category).split())[:250]


@lru_cache(maxsize=1024)
def _excluded_tuple(ev_key):
    category, titles = ev_key[0], ev_key[1:]
    if category:
        c = _text(category)
        if _EXCLUDED.search(c):
            return True
        if _FOOTBALL.search(c):
            return False
    norm_titles = [_text(t) for t in titles if t]
    if any(_FOOTBALL.search(t) for t in norm_titles):
        return False
    return any(_EXCLUDED.search(t) for t in norm_titles)


def excluded_card_event(event):
    if not event:
        return False
    category = to_text(event[6]) if len(event) > 6 and event[6] else ''
    t0 = to_text(event[0]) if len(event) > 0 and event[0] else ''
    t4 = to_text(event[4]) if len(event) > 4 and event[4] else ''
    t5 = to_text(event[5]) if len(event) > 5 and event[5] else ''
    return _excluded_tuple((category, t0, t4, t5))
