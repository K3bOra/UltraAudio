# -*- coding: utf-8 -*-
"""Two clipped scorer rows; native child widgets scroll only while visible."""
import os
from Components.GUIComponent import GUIComponent
from Tools.LoadPixmap import LoadPixmap
from enigma import eWidget, eLabel, ePixmap, ePoint, eSize, eTimer
from skin import parseFont, parseColor
from .compat import native, monotonic
from . import store


class ScorerTicker(GUIComponent):
    GUI_WIDGET = eWidget

    def __init__(self):
        GUIComponent.__init__(self)
        self.text = ''
        self.active = False
        self.body = None
        self.children = []
        self.offset = 0
        self.pause_until = 0
        self.k = 1.0
        self.timer = eTimer()
        self.connection = None
        if hasattr(self.timer, 'callback'):
            self.timer.callback.append(self.tick)
        else:
            self.connection = self.timer.timeout.connect(self.tick)

    def postWidgetCreate(self, instance):
        self.body = eWidget(instance)
        self.body.show()

    def applySkin(self, desktop, parent):
        attrs = dict(self.skinAttributes or [])
        self.font = parseFont(attrs.get('font', 'Regular;12'), ((1, 1), (1, 1)))
        self.color = parseColor(attrs.get('foregroundColor', '#E6ECEA'))
        self.skinAttributes = [(k, v) for k, v in (self.skinAttributes or [])
                               if k not in ('font', 'foregroundColor', 'halign', 'valign', 'noWrap')]
        result = GUIComponent.applySkin(self, desktop, parent)
        self.k = self.instance.size().height() / 36.0
        self.rebuild()
        return result

    def setText(self, text):
        if text != self.text:
            self.text = text
            self.rebuild()

    def rebuild(self):
        self.timer.stop()
        self.offset = 0
        self.pause_until = monotonic() + 2
        if self.body is None or not hasattr(self, 'font'):
            return
        for widget in self.children:
            widget.hide()
        self.children = []
        lines = self.text.splitlines()
        self.count = len(lines)
        self.line_h = max(1, int(round(18 * self.k)))
        self.body.move(ePoint(0, 0))
        self.body.resize(eSize(self.instance.size().width(), max(1, (len(lines) + 2) * self.line_h)))
        path = os.path.join(store.ASSETS, 'ui', 'football_ball%s.png' % ('@hd' if self.k < .85 else ''))
        pix = LoadPixmap(native(path))
        for index, text in enumerate(lines + (lines[:2] if len(lines) > 2 else [])):
            y = index * self.line_h
            icon_w = max(1, int(round(16 * self.k)))
            icon = ePixmap(self.body)
            icon.move(ePoint(0, y + max(0, (self.line_h-icon_w)//2)))
            icon.resize(eSize(icon_w, icon_w))
            icon.setAlphatest(2)
            if pix is not None:
                icon.setPixmap(pix)
            icon.show()
            label = eLabel(self.body)
            x = max(1, int(round(18 * self.k)))
            label.move(ePoint(x, y))
            label.resize(eSize(max(1, self.instance.size().width()-x), self.line_h))
            label.setFont(self.font)
            label.setForegroundColor(self.color)
            label.setTransparent(1)
            label.setNoWrap(1)
            label.setText(native(text))
            label.show()
            self.children.extend((icon, label))
        self.run()

    def run(self):
        if self.active and getattr(self, 'count', 0) > 2:
            self.timer.start(80, False)

    def tick(self):
        if not self.active or self.body is None:
            self.timer.stop()
            return
        if monotonic() < self.pause_until:
            return
        self.offset = (self.offset + 1) % (self.count * self.line_h)
        self.body.move(ePoint(0, -self.offset))
        if self.offset % self.line_h == 0:
            self.pause_until = monotonic() + 2

    def show(self):
        self.active = True
        GUIComponent.show(self)
        self.run()

    def hide(self):
        self.active = False
        self.timer.stop()
        GUIComponent.hide(self)

    def preWidgetRemove(self, instance):
        self.active = False
        self.timer.stop()
        self.children = []
        self.body = None
