# -*- coding: utf-8 -*-
"""Public scoreboard live match discovery across all leagues. No scorers or card details parsed."""
from __future__ import unicode_literals, division
import calendar
import datetime
import json
import re
import threading
import time
from .compat import lru_cache, monotonic, to_text

SOCCER_SCOREBOARD_BASE = 'https://site.api.espn.com/apis/site/v2/sports/soccer/'
SCOREBOARD_ENDPOINT = SOCCER_SCOREBOARD_BASE + 'all/scoreboard'
MAX_SCOREBOARD_BYTES = 6 * 1024 * 1024

# Comprehensive ESPN league slugs for competitions broadcast on beIN Sports & Arabic sports channels
_LEAGUE_HINTS = (
    (re.compile(r'champions\s*league.*women|سيدات.*أبطال\s*أوروبا|أبطال\s*أوروبا.*سيدات|uwcl', re.I), ('uefa.wchampions',)),
    (re.compile(r'caf.*champions|أبطال\s*أفريقيا|ابطال\s*افريقيا', re.I), ('caf.champions', 'caf.confed')),
    (re.compile(r'confederation|الكونفدرالية|الكونفدراليه|الكاف', re.I), ('caf.confed', 'caf.champions')),
    (re.compile(r'africa\s*cup|afcon|أمم\s*أفريقيا|امم\s*افريقيا|تصفيات.*أفريقيا|تصفيات.*افريقيا', re.I), ('caf.nations', 'caf.nations_qual', 'fifa.worldq.caf')),
    (re.compile(r'afc.*champions.*two|afc\s*cup|أبطال\s*آسيا\s*2|أبطال\s*آسيا\s*الثاني|الاتحاد\s*الآسيوي', re.I), ('afc.cup', 'afc.champions')),
    (re.compile(r'afc.*champions|أبطال\s*آسيا|ابطال\s*اسيا|النخبة\s*الآسيوي', re.I), ('afc.champions', 'afc.cup')),
    (re.compile(r'asian\s*cup|أمم\s*آسيا|امم\s*اسيا|تصفيات.*آسيا|تصفيات.*اسيا', re.I), ('afc.asian.cup', 'fifa.worldq.afc')),
    (re.compile(r'uefa\s*champions|أبطال\s*أوروبا|ابطال\s*اوروبا|الشامبيونز', re.I), ('uefa.champions', 'uefa.champions_qual')),
    (re.compile(r'europa\s*league|الدوري\s*الأوروبي|الدوري\s*الاوروبي|يوروبا\s*ليغ', re.I), ('uefa.europa', 'uefa.europa_qual')),
    (re.compile(r'conference\s*league|المؤتمر\s*الأوروبي|المؤتمر\s*الاوروبي', re.I), ('uefa.europa.conf', 'uefa.europa.conf_qual')),
    (re.compile(r'uefa\s*super|السوبر\s*الأوروبي|السوبر\s*الاوروبي', re.I), ('uefa.super_cup',)),
    (re.compile(r'nations\s*league|دوري\s*الأمم|دوري\s*الامم', re.I), ('uefa.nations', 'uefa.w.nations', 'concacaf.nations.league')),
    (re.compile(r'premier\s*league|الدوري\s*الإنجليزي|الدوري\s*الانجليزي|بريميرليغ', re.I), ('eng.1',)),
    (re.compile(r'championship|التشامبيونشيب|الدرجة\s*الأولى\s*الإنجليزي|الدرجه\s*الاولي\s*الانجليزي', re.I), ('eng.2', 'eng.3', 'eng.4')),
    (re.compile(r'fa\s*cup|كأس\s*الاتحاد\s*الإنجليزي|كاس\s*الاتحاد\s*الانجليزي', re.I), ('eng.fa', 'eng.w.fa')),
    (re.compile(r'carabao|efl\s*cup|league\s*cup|كأس\s*الرابطة\s*الإنجليزي|كاس\s*الرابطه|كاراباو', re.I), ('eng.league_cup', 'eng.trophy')),
    (re.compile(r'community\s*shield|الدرع\s*الخيرية|الدرع\s*الخيريه', re.I), ('eng.charity',)),
    (re.compile(r'la\s*liga\s*2|segunda|الدرجة\s*الثانية\s*الإسباني', re.I), ('esp.2',)),
    (re.compile(r'la\s*liga|laliga|الدوري\s*الإسباني|الدوري\s*الاسباني|لاليغا|لا\s*ليجا', re.I), ('esp.1', 'esp.w.1')),
    (re.compile(r'copa\s*del\s*rey|كأس\s*ملك\s*إسبانيا|كاس\s*ملك\s*اسبانيا|كأس\s*إسبانيا', re.I), ('esp.copa_del_rey', 'esp.super_cup')),
    (re.compile(r'2\.\s*bundesliga|الدرجة\s*الثانية\s*الألماني', re.I), ('ger.2',)),
    (re.compile(r'bundesliga|الدوري\s*الألماني|الدوري\s*الالماني|بوندسليغا', re.I), ('ger.1', 'ger.2')),
    (re.compile(r'dfb|pokal|كأس\s*ألمانيا|كاس\s*المانيا|السوبر\s*الألماني', re.I), ('ger.dfb_pokal', 'ger.super_cup')),
    (re.compile(r'serie\s*b|الدرجة\s*الثانية\s*الإيطالي', re.I), ('ita.2',)),
    (re.compile(r'serie\s*a|الدوري\s*الإيطالي|الدوري\s*الايطالي|الكالتشيو', re.I), ('ita.1',)),
    (re.compile(r'coppa\s*italia|كأس\s*إيطاليا|كاس\s*ايطاليا|السوبر\s*الإيطالي', re.I), ('ita.coppa_italia', 'ita.super_cup')),
    (re.compile(r'ligue\s*2|الدرجة\s*الثانية\s*الفرنسي', re.I), ('fra.2',)),
    (re.compile(r'ligue\s*1|الدوري\s*الفرنسي|ليغ\s*1', re.I), ('fra.1', 'fra.w.1')),
    (re.compile(r'coupe\s*de\s*france|trophee\s*des\s*champions|كأس\s*فرنسا|كاس\s*فرنسا|السوبر\s*الفرنسي', re.I), ('fra.coupe_de_france', 'fra.super_cup')),
    (re.compile(r'turk|super\s*lig|süper\s*lig|الدوري\s*التركي|سوبر\s*ليغ', re.I), ('tur.1',)),
    (re.compile(r'eredivisie|knvb|الدوري\s*الهولندي|كأس\s*هولندا', re.I), ('ned.1', 'ned.cup', 'ned.2')),
    (re.compile(r'primeira\s*liga|portug|الدوري\s*البرتغالي|كأس\s*البرتغال', re.I), ('por.1', 'por.taca.portugal')),
    (re.compile(r'scottish|الدوري\s*الاسكتلندي|كأس\s*اسكتلندا', re.I), ('sco.1', 'sco.tennents', 'sco.cis')),
    (re.compile(r'belgian|pro\s*league|الدوري\s*البلجيكي', re.I), ('bel.1',)),
    (re.compile(r'greek|الدوري\s*اليوناني', re.I), ('gre.1',)),
    (re.compile(r'austrian|الدوري\s*النمساوي', re.I), ('aut.1',)),
    (re.compile(r'saudi|roshn|السعودي|روشن|كأس\s*الملك', re.I), ('ksa.1', 'ksa.kings.cup')),
    (re.compile(r'libertadores|ليبرتادوريس', re.I), ('conmebol.libertadores',)),
    (re.compile(r'sudamericana|سود\s*أمريكانا|سودامريكانا', re.I), ('conmebol.sudamericana', 'conmebol.recopa')),
    (re.compile(r'brazil|brasileir|الدوري\s*البرازيلي|كأس\s*البرازيل', re.I), ('bra.1', 'bra.copa_do_brazil')),
    (re.compile(r'argentin|الدوري\s*الأرجنتيني', re.I), ('arg.1', 'arg.copa')),
    (re.compile(r'mls|major\s*league|الدوري\s*الأمريكي', re.I), ('usa.1', 'concacaf.champions', 'concacaf.leagues.cup')),
    (re.compile(r'world\s*cup\s*qual|تصفيات\s*كأس\s*العالم|تصفيات\s*المونديال', re.I), ('fifa.worldq.uefa', 'fifa.worldq.caf', 'fifa.worldq.afc', 'fifa.worldq.conmebol', 'fifa.worldq.concacaf')),
    (re.compile(r'world\s*cup|كأس\s*العالم|المونديال|إنتركونتيننتال|أبطال\s*الأندية', re.I), ('fifa.world', 'fifa.cwc', 'fifa.intercontinental_cup', 'fifa.world.u20', 'fifa.world.u17')),
    (re.compile(r'friendly|ودية|وديه|مباراة\s*ودية', re.I), ('fifa.friendly', 'club.friendly', 'fifa.friendly.w')),
)


@lru_cache(maxsize=512)
def infer_espn_leagues(text):
    """Map an EPG title/competition string to candidate ESPN soccer league slugs."""
    text = to_text(text or '')
    out = []
    for pat, slugs in _LEAGUE_HINTS:
        if pat.search(text):
            for s in slugs:
                if s not in out:
                    out.append(s)
    return tuple(out)


@lru_cache(maxsize=2048)
def _stamp(value):
    value = to_text(value or '').strip()
    if not value:
        return None
    m = re.match(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:?\d{2})?$', value)
    if m:
        base = m.group(1) + ':' + (m.group(2) or '00')
        try:
            ts = calendar.timegm(datetime.datetime.strptime(base, '%Y-%m-%dT%H:%M:%S').timetuple())
            zone = m.group(3) or 'Z'
            if zone != 'Z':
                z = zone.replace(':', '')
                sign = -1 if z[0] == '+' else 1
                ts += sign * (int(z[1:3]) * 3600 + int(z[3:5]) * 60)
            return ts
        except ValueError:
            pass
    for fmt in ('%Y-%m-%dT%H:%MZ', '%Y-%m-%dT%H:%M:%SZ'):
        try:
            return calendar.timegm(datetime.datetime.strptime(value, fmt).timetuple())
        except ValueError:
            pass
    return None


def _norm_minute(raw_min):
    raw_min = to_text(raw_min or '').replace('\u2032', "'").strip()
    m = re.match(r"^(\d{1,3})'?\s*(?:\+\s*(\d{1,2})'?)?'?$", raw_min)
    if not m:
        return None
    return ("%s+%s'" % (m.group(1), m.group(2))) if m.group(2) else ("%s'" % m.group(1))


def _valid_logo_href(url):
    u = to_text(url or '').strip()
    if not u:
        return ''
    low = u.lower()
    if 'default-team-logo' in low or 'placeholder' in low or 'no-logo' in low:
        return ''
    return u


def _team_logo_url(team):
    if not isinstance(team, dict):
        return ''
    logo = _valid_logo_href(team.get('logo'))
    if logo:
        return logo
    logos = team.get('logos')
    if isinstance(logos, list):
        for item in logos:
            if isinstance(item, dict) and item.get('href'):
                href = _valid_logo_href(item['href'])
                if href:
                    return href
    return ''


def _cached_team_aliases(team, normalize, aliases_fn):
    cached = team.get('_aliases')
    if cached is not None:
        return cached
    names = set()
    for k in ('displayName', 'shortDisplayName', 'name', 'abbreviation'):
        raw_n = team.get(k)
        if raw_n:
            if aliases_fn is not None:
                names.update(aliases_fn(raw_n))
            else:
                names.add(normalize(raw_n))
    names.discard('')
    team['_aliases'] = names
    return names


def extract_live_matches(payload, normalize, aliases_fn=None):
    """Extract live ('in'), finished ('post'), and upcoming ('pre') games from the scoreboard snapshot."""
    out = []
    now_mono = monotonic()
    for event in payload.get('events', []) if isinstance(payload, dict) else []:
        if not isinstance(event, dict):
            continue
        for game in event.get('competitions', []) or []:
            try:
                seen = game.get('_observed_at')
                if seen is not None and not 0 <= now_mono - seen <= 300:
                    continue
                status = game.get('status') or event.get('status') or {}
                stype = status.get('type') or {}
                state = to_text(stype.get('state') or '').strip().lower()
                if state not in ('in', 'post', 'pre'):
                    continue
                stamp = game.get('_stamp')
                if stamp is None:
                    stamp = _stamp(game.get('date') or event.get('date'))
                    game['_stamp'] = stamp
                if stamp is None:
                    continue
                sides = {}
                for c in game.get('competitors', []) or []:
                    side = {'home': 0, 'away': 1}.get(c.get('homeAway'))
                    if side is None or side in sides:
                        continue
                    team = c.get('team') or {}
                    aliases = _cached_team_aliases(team, normalize, aliases_fn)
                    if not aliases:
                        continue
                    disp = to_text(team.get('shortDisplayName') or team.get('displayName') or team.get('name') or '').strip()
                    raw_score = c.get('score')
                    try:
                        score_int = int(raw_score) if raw_score is not None and to_text(raw_score).strip() != '' else 0
                    except (ValueError, TypeError):
                        score_int = 0
                    sides[side] = {
                        'id': to_text(c.get('id') or team.get('id') or ''),
                        'aliases': set(aliases),
                        'name': disp,
                        'score': score_int,
                        'logo': _team_logo_url(team),
                    }
                if set(sides) != {0, 1}:
                    continue
                detail_str = to_text(stype.get('shortDetail') or status.get('displayClock') or '').strip()
                if state == 'post':
                    clock = 'FT'
                    minute_val = 90
                elif state == 'pre':
                    clock = 'LIVE'
                    minute_val = 0
                elif detail_str.upper() == 'HT' or stype.get('name') == 'STATUS_HALFTIME':
                    clock = 'HT'
                    minute_val = 45
                else:
                    norm_m = _norm_minute(detail_str)
                    clock = norm_m or 'LIVE'
                    m_num = re.match(r'^(\d+)', clock)
                    minute_val = int(m_num.group(1)) if m_num else None

                raw_gid = to_text(game.get('id') or event.get('id') or '%d_%s_%s' % (stamp, sides[0]['id'], sides[1]['id']))
                ident = 'espn_' + re.sub(r'[^A-Za-z0-9_-]', '_', raw_gid)
                home_key = 'espn_' + re.sub(r'[^A-Za-z0-9_-]', '_', sides[0]['id'] or sides[0]['name'])
                away_key = 'espn_' + re.sub(r'[^A-Za-z0-9_-]', '_', sides[1]['id'] or sides[1]['name'])
                home_g, away_g = sides[0]['score'], sides[1]['score']
                logo_urls = {}
                if sides[0]['logo']:
                    logo_urls[home_key] = sides[0]['logo']
                if sides[1]['logo']:
                    logo_urls[away_key] = sides[1]['logo']

                out.append({
                    '_observed_at': game.get('_observed_at'),
                    'id': ident,
                    'match_id': ident,
                    'state': state,
                    'teams': (home_key, away_key),
                    'logo_urls': logo_urls,
                    'names': [sides[0]['aliases'], sides[1]['aliases']],
                    'goals': (home_g, away_g),
                    'score': '%d - %d' % (away_g, home_g),
                    'clock': clock,
                    'minute': minute_val,
                    'kickoff': stamp,
                    'match_date': time.strftime('%Y-%m-%d', time.gmtime(stamp)),
                    'lang_data': {
                        'en': {
                            'home_name': sides[0]['name'],
                            'away_name': sides[1]['name'],
                                }
                    },
                })
            except Exception:
                continue
    return out


def compact_snapshot(payload):
    """Retain only teams, crests, scores, and match clock/state to minimize memory and CPU load."""
    events = []
    obs_mono = monotonic()
    for event in payload.get('events', []) if isinstance(payload, dict) else []:
        if not isinstance(event, dict):
            continue
        games = []
        for game in event.get('competitions', []) or []:
            if not isinstance(game, dict):
                continue
            status = game.get('status') or event.get('status') or {}
            if status.get('type', {}).get('state') not in ('in', 'post', 'pre'):
                continue
            date_str = game.get('date') or event.get('date')
            stamp = _stamp(date_str)
            competitors = []
            for c in game.get('competitors', []) or []:
                team = c.get('team') or {}
                t_dict = dict((k, team.get(k)) for k in ('id', 'name', 'displayName', 'shortDisplayName', 'abbreviation'))
                t_dict['logo'] = _team_logo_url(team)
                competitors.append(dict(
                    id=c.get('id'),
                    homeAway=c.get('homeAway'),
                    score=c.get('score'),
                    team=t_dict
                ))
            games.append(dict(
                _observed_at=obs_mono,
                _stamp=stamp,
                id=game.get('id') or event.get('id'),
                date=date_str,
                status=status,
                competitors=competitors,
            ))
        if games:
            events.append(dict(id=event.get('id'), competitions=games))
    return {'events': events}


def _merge_snapshots(snaps):
    seen_ids = set()
    merged_events = []
    for snap in snaps:
        if not isinstance(snap, dict):
            continue
        for ev in snap.get('events', []) or []:
            if not isinstance(ev, dict):
                continue
            eid = to_text(ev.get('id') or '')
            if eid and eid in seen_ids:
                continue
            if eid:
                seen_ids.add(eid)
            merged_events.append(ev)
    return {'events': merged_events}


class ScoreboardScorers(object):
    """Thread-safe shared date snapshot for lightweight live-match lookup across all leagues."""
    def __init__(self, read):
        self.read = read
        self.cache = {}
        self.attempts = {}
        self.league_cache = {}
        self._lock = threading.Lock()

    def _date_range_for(self, day):
        try:
            dt = datetime.datetime.strptime(to_text(day), '%Y%m%d')
            prev_d = (dt - datetime.timedelta(days=1)).strftime('%Y%m%d')
            next_d = (dt + datetime.timedelta(days=1)).strftime('%Y%m%d')
            return '%s-%s' % (prev_d, next_d)
        except Exception:
            return to_text(day)

    def refresh_day(self, day, force=False):
        now = monotonic()
        with self._lock:
            last = self.attempts.get(day)
            cached = self.cache.get(day)
            if not force and last is not None and now - last < 45 and cached is not None:
                return cached[1]
            if not force and last is not None and now - last < 10:
                return cached[1] if cached else None
            self.attempts[day] = now
        date_range = self._date_range_for(day)
        for query_dates in (day, date_range):
            try:
                raw = self.read(SCOREBOARD_ENDPOINT + '?dates=' + query_dates + '&limit=500', MAX_SCOREBOARD_BYTES)
                data = json.loads(raw.decode('utf-8'))
                if isinstance(data, dict) and isinstance(data.get('events'), list):
                    snap = compact_snapshot(data)
                    with self._lock:
                        extra_snaps = [v[1] for (k_day, _), v in self.league_cache.items() if k_day == day and v]
                        if extra_snaps:
                            snap = _merge_snapshots([snap] + extra_snaps)
                        self.cache[day] = (monotonic(), snap)
                        for key in list(self.attempts):
                            if key != day:
                                self.attempts.pop(key, None)
                                self.cache.pop(key, None)
                    return snap
            except Exception:
                continue
        with self._lock:
            cached = self.cache.get(day)
            return cached[1] if cached else None

    def refresh_leagues(self, leagues, day):
        """Fetch specific ESPN soccer league scoreboards when a competition is not in /all/scoreboard."""
        if not leagues:
            return None
        now = monotonic()
        date_range = self._date_range_for(day)
        new_snaps = []
        for slug in leagues[:4]:
            key = (day, slug)
            with self._lock:
                cached_lg = self.league_cache.get(key)
                if cached_lg and now - cached_lg[0] < 60:
                    new_snaps.append(cached_lg[1])
                    continue
            for qd in (day, date_range):
                try:
                    url = SOCCER_SCOREBOARD_BASE + slug + '/scoreboard?dates=' + qd + '&limit=200'
                    raw = self.read(url, MAX_SCOREBOARD_BYTES)
                    data = json.loads(raw.decode('utf-8'))
                    if isinstance(data, dict) and isinstance(data.get('events'), list):
                        snap = compact_snapshot(data)
                        with self._lock:
                            self.league_cache[key] = (monotonic(), snap)
                        new_snaps.append(snap)
                        break
                except Exception:
                    continue
        if not new_snaps:
            return None
        with self._lock:
            base = self.cache.get(day)
            all_snaps = ([base[1]] if base else []) + new_snaps
            merged = _merge_snapshots(all_snaps)
            self.cache[day] = (monotonic(), merged)
            return merged
