# -*- coding: utf-8 -*-
"""Public scoreboard goal details. No playback, GUI, credentials or extra threads."""
from __future__ import unicode_literals
import calendar
import datetime
import json
import re
import time
from .compat import monotonic, to_text

SCOREBOARD_ENDPOINT = 'https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard'


def _stamp(value):
    value = to_text(value or '')
    for fmt in ('%Y-%m-%dT%H:%MZ', '%Y-%m-%dT%H:%M:%SZ'):
        try:
            return calendar.timegm(datetime.datetime.strptime(value, fmt).timetuple())
        except ValueError:
            pass
    return None


def parse_scorers(payload, match, normalize):
    """Only accept one exact home/away, kickoff and full score match."""
    found = []
    for event in payload.get('events', []) if isinstance(payload, dict) else []:
        if not isinstance(event, dict):
            continue
        for game in event.get('competitions', []):
            try:
                stamp = _stamp(game.get('date') or event.get('date'))
                if stamp is None or abs(stamp - match['kickoff']) > 180:
                    continue
                if (game.get('status') or event.get('status') or {}).get('type', {}).get('state') not in ('in', 'post'):
                    continue
                sides = {}
                for competitor in game.get('competitors', []):
                    side = {'home': 0, 'away': 1}.get(competitor.get('homeAway'))
                    if side is None or side in sides:
                        raise ValueError('Invalid side')
                    team = competitor.get('team') or {}
                    names = set(normalize(team.get(k)) for k in ('displayName', 'shortDisplayName', 'name')) - {''}
                    if not names.intersection(match['names'][side]):
                        raise ValueError('Different team')
                    sides[side] = (to_text(competitor.get('id') or team.get('id')), int(competitor['score']))
                if set(sides) != {0, 1} or tuple(sides[i][1] for i in (0, 1)) != tuple(match['goals']):
                    continue
                ids = {sides[i][0]: i for i in (0, 1)}
                if len(ids) != 2:
                    continue
                goals, cards, seen = [[], []], [[0, 0], [0, 0]], set()
                for detail in game.get('details', []):
                    side = ids.get(to_text((detail.get('team') or {}).get('id')))
                    if side is None or detail.get('shootout'):
                        continue
                    minute = to_text((detail.get('clock') or {}).get('displayValue') or '').replace('\u2032', "'")
                    if not re.match(r"^\d{1,3}(?:\s*\+\s*\d{1,2})?'$", minute):
                        continue
                    athletes = detail.get('athletesInvolved') or []
                    if len(athletes) != 1:
                        continue
                    # Provider short names keep both identity and minute inside the
                    # existing narrow scorer column without changing card geometry.
                    player = to_text(athletes[0].get('shortName') or athletes[0].get('displayName') or athletes[0].get('fullName') or '').strip()
                    key = (side, minute, player, to_text((detail.get('type') or {}).get('id')))
                    if not player or key in seen:
                        continue
                    seen.add(key)
                    if detail.get('yellowCard'):
                        cards[side][0] += 1
                    if detail.get('redCard'):
                        cards[side][1] += 1
                    if detail.get('scoringPlay') and detail.get('scoreValue') == 1:
                        # Unclear own-goal attribution must not assign a player to
                        # the wrong score side. Fall back to native detail parsing.
                        if detail.get('ownGoal') or detail.get('cancelled'):
                            continue
                        goals[side].append((minute, player))
                if tuple(len(goals[i]) for i in (0, 1)) != tuple(match['goals']):
                    continue
                formatted = []
                for entries in goals:
                    grouped, order = {}, []
                    for minute, player in entries:
                        if player not in grouped:
                            grouped[player] = []
                            order.append(player)
                        grouped[player].append(minute)
                    formatted.append('\n'.join('%s  %s' % (player, ', '.join(grouped[player])) for player in order))
                found.append({'scorers_neutral': tuple(formatted),
                              'cards': tuple(tuple(row) for row in cards)})
            except (ValueError, TypeError, KeyError, AttributeError):
                continue
    return found[0] if len(found) == 1 else None


def compact_snapshot(payload):
    """Discard unrelated articles, betting metadata, links and team statistics."""
    events = []
    for event in payload.get('events', []):
        if not isinstance(event, dict):
            continue
        games = []
        for game in event.get('competitions', []) or []:
            if not isinstance(game, dict):
                continue
            status = game.get('status') or event.get('status') or {}
            if status.get('type', {}).get('state') not in ('in', 'post'):
                continue
            competitors = []
            for c in game.get('competitors', []) or []:
                team = c.get('team') or {}
                competitors.append(dict(id=c.get('id'), homeAway=c.get('homeAway'), score=c.get('score'),
                    team=dict((k, team.get(k)) for k in ('id', 'name', 'displayName', 'shortDisplayName'))))
            details = []
            for d in game.get('details', []) or []:
                item = dict((k, d.get(k)) for k in ('clock', 'type', 'team', 'scoringPlay', 'scoreValue', 'yellowCard', 'redCard', 'ownGoal', 'shootout', 'cancelled'))
                item['athletesInvolved'] = [dict(shortName=a.get('shortName'), displayName=a.get('displayName'), fullName=a.get('fullName')) for a in d.get('athletesInvolved', []) or []]
                details.append(item)
            games.append(dict(date=game.get('date') or event.get('date'), status=status,
                              competitors=competitors, details=details))
        if games:
            events.append(dict(competitions=games))
    return {'events': events}


class ScoreboardScorers(object):
    """Called by the existing score worker only, one shared date snapshot/minute."""
    def __init__(self, read):
        self.read = read
        self.cache = {}
        self.attempts = {}

    def get(self, match, normalize):
        if not any(match.get('goals') or ()):
            return None
        day = time.strftime('%Y%m%d', time.gmtime(match['kickoff']))
        now = monotonic()
        last = self.attempts.get(day)
        if last is None or now - last >= 60:
            self.attempts[day] = now
            try:
                data = json.loads(self.read(SCOREBOARD_ENDPOINT + '?dates=' + day + '&limit=1000', 4 * 1024 * 1024).decode('utf-8'))
                if isinstance(data, dict) and isinstance(data.get('events'), list):
                    self.cache[day] = (now, compact_snapshot(data))
            except Exception:
                pass
            for key in list(self.attempts):
                if key != day:
                    self.attempts.pop(key, None)
                    self.cache.pop(key, None)
        cached = self.cache.get(day)
        if not cached or not 0 <= now - cached[0] <= 120:
            return None
        return parse_scorers(cached[1], match, normalize)
