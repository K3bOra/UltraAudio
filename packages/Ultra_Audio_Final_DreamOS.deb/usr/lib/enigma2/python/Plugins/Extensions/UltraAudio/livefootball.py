# -*- coding: utf-8 -*-
"""beIN & multi-source live football score/logo reader. No audio/Enigma imports; no third-party plugin code.

The UI only consumes snapshots. All networking and PNG writes run on background
workers, on demand while a current guide event is selected.
"""
from __future__ import unicode_literals, division
import calendar
import datetime
import hashlib
try:
    from html.parser import HTMLParser
except ImportError:
    from HTMLParser import HTMLParser
import io
import math
import json
import os
import re
import ssl
import struct
import tempfile
import threading
import time
import unicodedata
import zlib
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

from .compat import (Request, urlopen, urlencode, to_text, monotonic, start_thread,
                     string_types, lru_cache, is_main_thread, user_input_idle, yield_to_ui)
from .i18n import lang as interface_language
from .sportfilter import excluded_card_event
from .scorerfeed import (
    ScoreboardScorers, SCOREBOARD_ENDPOINT, SOCCER_SCOREBOARD_BASE,
    extract_live_matches, infer_espn_leagues
)

ENDPOINT = 'https://prod-cmseventmanagement.beinsports.com/score/getScorePageList'
MEDIA = 'https://prod-media.beinsports.com/image/'
BEIN_IMAGE_HOST = 'https://images.beinsports.com/'
ESPN_LOGO_HOST = 'https://a.espncdn.com/'
ESPN_ALT_LOGO_HOST = 'https://s.espncdn.com/'
ESPN_SEARCH_ENDPOINT = 'https://site.web.api.espn.com/apis/search/v2'
FOTMOB_SUGGEST_ENDPOINT = 'https://apigw.fotmob.com/searchapi/suggest'
FOTMOB_LOGO_HOST = 'https://images.fotmob.com/image_resources/logo/teamlogo/'
SOFASCORE_LIVE_ENDPOINT = 'https://api.sofascore.com/api/v1/sport/football/events/live'
SOFASCORE_SCHEDULE_BASE = 'https://api.sofascore.com/api/v1/sport/football/scheduled-events/'
SOFASCORE_SEARCH_ENDPOINT = 'https://api.sofascore.com/api/v1/search/all'
SOFASCORE_LOGO_HOST = 'https://img.sofascore.com/api/v1/team/'
SOFASCORE_API_LOGO_HOST = 'https://api.sofascore.com/api/v1/team/'
SPORTSDB_SEARCH_ENDPOINT = 'https://www.thesportsdb.com/api/v1/json/3/searchteams.php'
WEB_HOSTS = ('https://www.beinsports.com/', 'https://prod.beinsports.com/', 'https://www.fotmob.com/')
LOGO_DIR = os.path.join(tempfile.gettempdir(), 'ultraaudio-live-football-v4')
POLL = 60
MAX_AGE = 300
DETAIL_RETRY = 10
MAX_JSON = 4 * 1024 * 1024
MAX_HTML = 2 * 1024 * 1024
MAX_PNG = 1536 * 1024
CA_BUNDLE = os.path.join(os.path.dirname(__file__), 'assets', 'certs', 'cacert.pem')
_BAD_PROGRAM = re.compile(r'highlights?|replay|repeat|preview|classic|magazine|ملخص|اعاد[ةه]|تسجيل|استوديو|تحليل|مجلة|برنامج|نشرة', re.I)
_REPLAY_WORDS = re.compile(r'\b(?:recorded|rebroadcast|rerun|recap|ozet|tekrar|kayittan)\b|اهداف|موجز', re.I)

@lru_cache(maxsize=1024)
def _is_replay_titles(titles):
    return any(_BAD_PROGRAM.search(title) or _BAD_PROGRAM.search(normalized(title)) or _REPLAY_WORDS.search(normalized(title))
               for title in titles)

def _is_replay_event(event):
    # Normalize hamza/diacritics: إعادة and اعادة must be treated identically.
    return _is_replay_titles(_event_titles(event))

_SPLIT = re.compile(r'\s+(?:vs?\.?|versus|ضد|أمام|امام|يواجه|يلاقي)\s+|\s*[×✕✖]\s*', re.I)
_COMP_SEP = re.compile(r'\s+[-–—]\s+|\s*[:|]\s*')
_NON_TEAM_WORDS = re.compile(
    r'\b(league|la\s*liga|laliga|premier|serie\s*a|serie\s*b|bundesliga|ligue\s*1|ligue\s*2|cup|champions|europa|conference|'
    r'qualification|qualifier|qualifiers|round|week|matchday|stage|group|final|semi|quarter|live|studio|show|news|report|'
    r'eredivisie|primeira|super\s*lig|championship|carabao|fa\s*cup|copa|coppa|pokal|coupe|supercup|super\s*cup|'
    r'libertadores|sudamericana|afcon|fifa|uefa|caf|afc|conmebol|concacaf|'
    r'الدوري|دوري|كأس|كاس|بطولة|بطوله|الجولة|الجوله|الأسبوع|الاسبوع|دور|مباشر|تغطية|بث|برنامج|نشرة|أخبار|اخبار|'
    r'تصفيات|أبطال|ابطال|النهائي|نهائي|المجموعات|مجموعة|مجموعه|الدرجة|الدرجه|الممتاز|الأول|الاول|الثاني|الثانية)\b',
    re.I
)
_DIGITS = dict((ord(a), ord(b)) for a, b in zip('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789'))

_AR_COMP_SLUGS = {
    'دوري-أبطال-آسيا-الثاني': ('كأس-الاتحاد-الآسيوي-للأندية', 'دوري-أبطال-آسيا-الثاني', 'afc-champions-league-two'),
    'دوري-أبطال-آسيا-2': ('كأس-الاتحاد-الآسيوي-للأندية', 'دوري-أبطال-آسيا-2', 'afc-champions-league-two'),
    'دوري-أبطال-آسيا-النخبة': ('دوري-أبطال-آسيا-النخبة', 'دوري-أبطال-آسيا', 'afc-champions-league'),
    'الدوري-الإسباني-لا-ليجا': ('la-liga', 'الدوري-الإسباني-لا-ليجا', 'الدوري-الإسباني'),
    'الدوري-الإسباني': ('la-liga', 'الدوري-الإسباني', 'الدوري-الإسباني-لا-ليجا'),
    'الدوري-الإنجليزي-الممتاز': ('premier-league', 'الدوري-الإنجليزي-الممتاز', 'الدوري-الإنجليزي'),
    'الدوري-الإنجليزي': ('premier-league', 'الدوري-الإنجليزي-الممتاز', 'الدوري-الإنجليزي'),
    'الدوري-الإيطالي': ('serie-a', 'الدوري-الإيطالي'),
    'الدوري-الألماني': ('bundesliga', 'الدوري-الألماني'),
    'الدوري-الفرنسي': ('ligue-1', 'الدوري-الفرنسي'),
    'دوري-أبطال-أوروبا': ('uefa-champions-league', 'champions-league', 'دوري-أبطال-أوروبا'),
    'الدوري-الأوروبي': ('uefa-europa-league', 'europa-league', 'الدوري-الأوروبي'),
    'دوري-المؤتمر-الأوروبي': ('uefa-europa-conference-league', 'conference-league', 'دوري-المؤتمر-الأوروبي'),
    'دوري-أبطال-أفريقيا': ('caf-champions-league', 'دوري-أبطال-أفريقيا'),
    'كأس-الكونفدرالية-الأفريقية': ('caf-confederation-cup', 'كأس-الكونفدرالية-الأفريقية', 'كأس-الاتحاد-الأفريقي'),
    'كأس-الاتحاد-الأفريقي': ('caf-confederation-cup', 'كأس-الكونفدرالية-الأفريقية', 'كأس-الاتحاد-الأفريقي'),
}

_STAGE_WORDS = (
    'دور المجموعات', 'ربع النهائي', 'نصف النهائي', 'ثمن النهائي', 'النهائي',
    'دور الـ 16', 'دور الـ 32', 'الدور الأول', 'الدور التمهيدي', 'الملحق',
    'Group Stage', 'Quarter-finals', 'Semi-finals', 'Round of 16', 'Round of 32', 'Final',
    'Play-offs', 'Qualifying', 'Qualification',
)

_WORD_MAP = {
    'utd': 'united',
    'st': 'saint',
    'ste': 'sainte',
    'ath': 'athletic',
    'atletico': 'atletico',
    'dep': 'deportivo',
    'int': 'inter',
    'internazionale': 'inter',
    'nottm': 'nottingham',
    'wed': 'wednesday',
    'boro': 'middlesbrough',
    'munchen': 'munich',
    'muenchen': 'munich',
    'koln': 'cologne',
    'koeln': 'cologne',
    'nurnberg': 'nuremberg',
    'lyonnais': 'lyon',
    'brestois': 'brest',
    'rennais': 'rennes',
    'lisboa': 'lisbon',
    'kobenhavn': 'copenhagen',
    'mgladbach': 'monchengladbach',
    'gladbach': 'monchengladbach',
    'utrecht': 'utrecht',
    'اتليتيكو': 'اتلتيكو',
    'اتليتكو': 'اتلتيكو',
    'اتلتكو': 'اتلتيكو',
    'اتليتيك': 'اتلتيك',
    'اتليتك': 'اتلتيك',
    'بلباو': 'بيلباو',
    'سلتا': 'سيلتا',
    'فيجو': 'فيغو',
    'غيرونا': 'جيرونا',
    'غيتافي': 'خيتافي',
    'جيتافي': 'خيتافي',
    'ليجانيس': 'ليغانيس',
    'بتيس': 'بيتيس',
    'مالوركا': 'مايوركا',
    'فاليكانو': 'فايكانو',
    'فاييكانو': 'فايكانو',
    'سوسييداد': 'سوسيداد',
    'الافيش': 'الافيس',
    'فالدوليد': 'وليد',
    'ميونيخ': 'ميونخ',
    'بروسيا': 'بوروسيا',
    'شتوتجارت': 'شتوتغارت',
    'فرايبورج': 'فرايبورغ',
    'لايبزيج': 'لايبزيغ',
    'فولفسبورج': 'فولفسبورغ',
    'مرسيليا': 'مارسيليا',
    'انترناسيونالي': 'انتر',
    'انترناشونال': 'انتر',
    'مانشيستر': 'مانشستر',
    'تشلسي': 'تشيلسي',
    'توتنام': 'توتنهام',
    'نيوكاستل': 'نيوكاسل',
    'نوتنجهام': 'نوتينغهام',
    'نوتنغهام': 'نوتينغهام',
    'ولفرهامبتون': 'وولفرهامبتون',
    'برينتفورد': 'برينتفورد',
    'جلادباخ': 'مونشنغلادباخ',
    'غلادباخ': 'مونشنغلادباخ',
    'مونشنجلادباخ': 'مونشنغلادباخ',
    'بايرليفركوزن': 'ليفركوزن',
    'اينتراخت': 'فرانكفورت',
    'آينتراخت': 'فرانكفورت',
    'أينتراخت': 'فرانكفورت',
    'فرنكفورت': 'فرانكفورت',
    'أوغسبورغ': 'اوغسبورغ',
    'اوجسبورج': 'اوغسبورغ',
    'اوغسبورج': 'اوغسبورغ',
    'هايدينهايم': 'هايدنهايم',
    'ستراسبورج': 'ستراسبورغ',
    'سبورتينج': 'سبورتينغ',
    'سبورتنج': 'سبورتينغ',
    'براجا': 'براغا',
    'بنفيكا': 'بنفيكا',
    'ايندهوفن': 'آيندهوفن',
    'بى اس فى': 'آيندهوفن',
    'فاينورد': 'فينورد',
    'جالاتا': 'غلطة',
    'جالطة': 'غلطة',
    'غلطه': 'غلطة',
    'جلطة': 'غلطة',
    'فناربخشه': 'فنربخشه',
    'فنربخشة': 'فنربخشه',
    'فناربخشة': 'فنربخشه',
    'بيشكتاش': 'بشكتاش',
    'بشيكتاش': 'بشكتاش',
    'باشاكشهير': 'باشاك',
    'طرابزونسبور': 'طرابزون',
    'ترابزون': 'طرابزون',
    'صنداونز': 'صنداونز',
}

_DROP_WORDS = set((
    'fc', 'sc', 'cf', 'sfc', 'afc', 'cfc', 'bfc', 'lfc', 'mfc', 'ufc', 'pfc', 'ksc', 'qsc', 'csc', 'wfc',
    'ud', 'cd', 'sd', 'rcd', 'rc', 'as', 'ac', 'ss', 'ssc', 'us', 'sv', 'tsv', 'vfb', 'vfl', 'fsv',
    'tsg', 'bsc', 'bv', 'fk', 'sk', 'nk', 'bk', 'if', 'ik', 'ff', 'hsc', 'sco', 'ogc', 'losc', 'aj',
    'krc', 'rsc', 'kaa', 'kv', 'kvc', 'cfr', 'cs', 'ca', 'cr', 'se', 'ec', 'cp', 'bc', 'jk', 'gf',
    'a', 's', 'w', 'women', 'womens', 'ladies', 'filles', 'girls', 'femenino', 'feminin', 'feminino',
    'de', 'del', 'la', 'las', 'los', 'el', 'le', 'du', 'des', 'da', 'do', 'dos', 'das', 'van', 'von', 'und', 'and', 'of',
    '04', '05', '07', '09', '29', '96', '98', '99', '1846', '1848', '1860', '1893', '1899', '1900', '1901', '1904', '1907', '1909', '1910',
    'نادي', 'فريق', 'الرياضي', 'الرياضيه', 'الرياضية', 'بلد', 'سبور', 'كلوب', 'سيدات', 'للسيدات', 'نسائي',
))

# Optional trailing nationality/city adjectives in Arabic EPG titles
_AR_QUALIFIERS = set((
    'مصري', 'تونسي', 'مغربي', 'جزايري', 'جزائري', 'سوداني', 'ليبي', 'سعودي', 'قطري', 'اماراتي',
    'عراقي', 'اردني', 'كويتي', 'بحريني', 'عماني', 'لبناني', 'سوري', 'فلسطيني', 'يمني', 'موريتاني',
    'بيضاوي', 'رباطي', 'بركاني', 'تطواني', 'فاسي', 'طنجاوي', 'مراكشي', 'وجدي', 'سوسي',
    'قسنطيني', 'سطايفي', 'وهراني', 'عاصمي', 'قبايلي', 'قبائلي',
    'منستيري', 'ساحلي', 'صفاقسي', 'بنزرتي', 'قابسي', 'قفصي', 'باجي', 'جرجيسي',
    'بورسعيدي', 'سكندري', 'اسماعيلاوي', 'محلاوي', 'سويسي', 'اسواني',
))

# Comprehensive bilingual (English <-> Arabic) club & national team equivalence groups
_ALIAS_GROUPS = (
    # England - Premier League, Championship & Cups
    ('arsenal', 'ارسنال', 'آرسنال'),
    ('aston villa', 'villa', 'استون فيلا', 'فيلا'),
    ('bournemouth', 'afc bournemouth', 'بورنموث'),
    ('brentford', 'برينتفورد'),
    ('brighton', 'brighton and hove albion', 'brighton hove albion', 'برايتون'),
    ('burnley', 'بيرنلي'),
    ('chelsea', 'تشيلسي', 'تشلسي'),
    ('crystal palace', 'palace', 'كريستال بالاس'),
    ('everton', 'ايفرتون', 'إيفرتون'),
    ('fulham', 'فولهام'),
    ('ipswich', 'ipswich town', 'ايبسويتش', 'ايبسويتش تاون', 'إيبسويتش'),
    ('leeds', 'leeds united', 'ليدز', 'ليدز يونايتد'),
    ('leicester', 'leicester city', 'ليستر', 'ليستر سيتي'),
    ('liverpool', 'ليفربول'),
    ('luton', 'luton town', 'لوتون', 'لوتون تاون'),
    ('manchester city', 'man city', 'مانشستر سيتي', 'مان سيتي'),
    ('manchester united', 'man united', 'man utd', 'مانشستر يونايتد', 'مان يونايتد'),
    ('newcastle', 'newcastle united', 'نيوكاسل', 'نيوكاسل يونايتد'),
    ('nottingham forest', 'nottingham', 'forest', 'نوتينغهام فورست', 'نوتينغهام', 'نوتنجهام فورست'),
    ('sheffield united', 'شيفيلد يونايتد'),
    ('sheffield wednesday', 'شيفيلد وينزداي'),
    ('southampton', 'ساوثهامبتون', 'ساوثامبتون'),
    ('sunderland', 'سندرلاند'),
    ('tottenham', 'tottenham hotspur', 'spurs', 'توتنهام', 'توتنهام هوتسبير', 'سبيرز'),
    ('west ham', 'west ham united', 'وست هام', 'وست هام يونايتد', 'ويست هام'),
    ('wolverhampton', 'wolverhampton wanderers', 'wolves', 'وولفرهامبتون', 'ولفرهامبتون', 'وولفز'),
    ('middlesbrough', 'boro', 'ميدلزبره', 'ميدلسبره'),
    ('west brom', 'west bromwich', 'west bromwich albion', 'وست بروميتش', 'ويست بروميتش'),
    ('watford', 'واتفورد'),
    ('norwich', 'norwich city', 'نوريتش', 'نوريتش سيتي', 'نورويتش'),
    ('coventry', 'coventry city', 'كوفنتري', 'كوفنتري سيتي'),
    ('hull', 'hull city', 'هال', 'هال سيتي'),
    ('stoke', 'stoke city', 'ستوك', 'ستوك سيتي'),
    ('swansea', 'swansea city', 'سوانزي', 'سوانزي سيتي'),
    ('cardiff', 'cardiff city', 'كارديف', 'كارديف سيتي'),
    ('blackburn', 'blackburn rovers', 'بلاكبيرن', 'بلاكبيرن روفرز'),
    ('bristol city', 'بريستول سيتي'),
    ('millwall', 'ميلوول'),
    ('qpr', 'queens park rangers', 'كوينز بارك رينجرز', 'كوينز بارك'),
    ('derby', 'derby county', 'ديربي كاونتي', 'ديربي'),
    ('portsmouth', 'بورتسموث'),
    ('plymouth', 'plymouth argyle', 'بليموث', 'بليموث ارجايل'),
    ('birmingham', 'birmingham city', 'برمنغهام', 'برمنغهام سيتي', 'برمنجهام'),
    ('preston', 'preston north end', 'بريستون'),
    ('oxford', 'oxford united', 'اكسفورد', 'اكسفورد يونايتد'),
    ('wrexham', 'ريكسهام'),
    ('bolton', 'bolton wanderers', 'بولتون'),
    ('wigans', 'wigan athletic', 'ويغان', 'ويجان'),
    ('reading', 'ريدينغ', 'ريدينج'),
    ('huddersfield', 'هدرسفيلد'),
    ('charlton', 'charlton athletic', 'تشارلتون'),
    ('barnsley', 'بارنزلي'),
    ('blackpool', 'بلاكبول'),

    # Spain - La Liga, Segunda & Copa del Rey
    ('real madrid', 'ريال مدريد'),
    ('barcelona', 'برشلونه', 'برشلونة', 'البارسا'),
    ('atletico madrid', 'atletico', 'اتلتيكو مدريد', 'اتلتيكو'),
    ('athletic bilbao', 'athletic club', 'athletic', 'bilbao', 'اتلتيك بيلباو', 'اتلتيك كلوب', 'بيلباو'),
    ('real sociedad', 'sociedad', 'ريال سوسيداد', 'سوسيداد'),
    ('real betis', 'betis', 'ريال بيتيس', 'بيتيس'),
    ('villarreal', 'فياريال', 'فيا ريال'),
    ('valencia', 'فالنسيا'),
    ('sevilla', 'اشبيليه', 'إشبيلية'),
    ('girona', 'جيرونا', 'غيرونا'),
    ('celta vigo', 'celta', 'سيلتا فيغو', 'سيلتا', 'سيلتا فيجو'),
    ('rayo vallecano', 'rayo', 'رايو فايكانو', 'رايو', 'رايو فاليكانو'),
    ('osasuna', 'اوساسونا', 'أوساسونا'),
    ('getafe', 'خيتافي', 'غيتافي'),
    ('mallorca', 'real mallorca', 'مايوركا', 'ريال مايوركا', 'مالوركا'),
    ('deportivo alaves', 'alaves', 'ديبورتيفو الافيس', 'الافيس', 'ألافيس'),
    ('las palmas', 'palmas', 'لاس بالماس', 'بالماس'),
    ('leganes', 'ليغانيس', 'ليجانيس'),
    ('real valladolid', 'valladolid', 'ريال وليد', 'وليد', 'بلد الوليد'),
    ('espanyol', 'espanyol barcelona', 'اسبانيول', 'ريال اسبانيول', 'إسبانيول'),
    ('cadiz', 'قادش'),
    ('granada', 'غرناطه', 'غرناطة'),
    ('almeria', 'الميريا', 'ألميريا'),
    ('elche', 'التشي', 'إلتشي'),
    ('levante', 'ليفانتي'),
    ('real oviedo', 'oviedo', 'ريال اوفييدو', 'اوفييدو'),
    ('real zaragoza', 'zaragoza', 'ريال سرقسطه', 'سرقسطه', 'سرقسطة'),
    ('sporting gijon', 'gijon', 'سبورتينغ خيخون', 'خيخون'),
    ('racing santander', 'santander', 'راسينغ سانتاندير', 'سانتاندير'),
    ('deportivo la coruna', 'la coruna', 'ديبورتيفو لاكورونيا', 'لاكورونيا'),
    ('tenerife', 'تينيريفي'),
    ('eibar', 'ايبار', 'إيبار'),

    # Italy - Serie A, Serie B & Coppa Italia
    ('inter', 'inter milan', 'internazionale', 'انتر', 'انتر ميلان', 'إنتر ميلان', 'انترناسيونالي'),
    ('milan', 'ac milan', 'ميلان', 'اي سي ميلان', 'إي سي ميلان'),
    ('juventus', 'juve', 'يوفنتوس', 'اليوفي'),
    ('napoli', 'نابولي'),
    ('roma', 'as roma', 'روما', 'اي اس روما'),
    ('lazio', 'لاتسيو'),
    ('atalanta', 'اتالانتا', 'أتالانتا'),
    ('fiorentina', 'فيورنتينا'),
    ('bologna', 'بولونيا'),
    ('torino', 'تورينو'),
    ('udinese', 'اودينيزي', 'أودينيزي'),
    ('genoa', 'جنوى', 'جنوه'),
    ('como', 'كومو'),
    ('parma', 'بارما'),
    ('cagliari', 'كالياري'),
    ('lecce', 'ليتشي'),
    ('empoli', 'امبولي', 'إمبولي'),
    ('hellas verona', 'verona', 'هيلاس فيرونا', 'فيرونا'),
    ('monza', 'مونزا'),
    ('venezia', 'فينيزيا', 'البندقية'),
    ('sassuolo', 'ساسولو'),
    ('sampdoria', 'سامبدوريا'),
    ('salernitana', 'ساليرنيتانا'),
    ('frosinone', 'فروزينوني'),
    ('spezia', 'سبيزيا'),
    ('cremonese', 'كريمونيزي'),
    ('pisa', 'بيزا'),
    ('palermo', 'باليرمو'),
    ('bari', 'باري'),
    ('brescia', 'بريشيا'),

    # Germany - Bundesliga, 2. Bundesliga & DFB-Pokal
    ('bayern munich', 'bayern munchen', 'bayern', 'بايرن ميونخ', 'بايرن ميونيخ', 'البايرن', 'بايرن'),
    ('borussia dortmund', 'dortmund', 'bvb', 'بوروسيا دورتموند', 'دورتموند'),
    ('bayer leverkusen', 'leverkusen', 'باير ليفركوزن', 'ليفركوزن'),
    ('rb leipzig', 'leipzig', 'لايبزيغ', 'لايبزيج', 'آر بي لايبزيغ'),
    ('eintracht frankfurt', 'frankfurt', 'اينتراخت فرانكفورت', 'فرانكفورت'),
    ('stuttgart', 'vfb stuttgart', 'شتوتغارت', 'شتوتجارت'),
    ('freiburg', 'sc freiburg', 'فرايبورغ', 'فرايبورج'),
    ('wolfsburg', 'vfl wolfsburg', 'فولفسبورغ', 'فولفسبورج'),
    ('borussia monchengladbach', 'monchengladbach', 'gladbach', 'بوروسيا مونشنغلادباخ', 'مونشنغلادباخ', 'غلادباخ', 'جلادباخ'),
    ('werder bremen', 'bremen', 'فيردر بريمن', 'بريمن'),
    ('augsburg', 'fc augsburg', 'اوغسبورغ', 'اوجسبورج'),
    ('mainz', 'mainz 05', 'ماينز', 'ماينتس'),
    ('hoffenheim', 'tsg hoffenheim', 'هوفنهايم'),
    ('union berlin', 'يونيون برلين', 'أونيون برلين'),
    ('bochum', 'vfl bochum', 'بوخوم'),
    ('heidenheim', 'هايدنهايم'),
    ('st pauli', 'saint pauli', 'سانت باولي'),
    ('holstein kiel', 'kiel', 'هولشتاين كيل', 'كيل'),
    ('cologne', 'koln', 'fc koln', 'كولن'),
    ('hamburger', 'hamburg', 'hsv', 'هامبورغ', 'هامبورج'),
    ('schalke', 'schalke 04', 'شالكه', 'شالكه 04'),
    ('hertha berlin', 'hertha', 'هرتا برلين', 'هيرتا برلين'),
    ('hannover', 'hannover 96', 'هانوفر'),
    ('nuremberg', 'nurnberg', 'نورنبرغ', 'نورنبيرغ'),
    ('kaiserslautern', 'كايزرسلاوترن'),
    ('fortuna dusseldorf', 'dusseldorf', 'فورتونا دوسلدورف', 'دوسلدورف'),
    ('darmstadt', 'دارمشتات'),
    ('paderborn', 'بادربورن'),
    ('karlsruher', 'karlsruhe', 'كارلسروه'),

    # France - Ligue 1, Ligue 2 & Coupe de France
    ('psg', 'paris saint germain', 'paris sg', 'باريس سان جيرمان', 'باريس'),
    ('marseille', 'olympique marseille', 'om', 'مارسيليا', 'اولمبيك مارسيليا'),
    ('monaco', 'as monaco', 'موناكو'),
    ('lyon', 'olympique lyon', 'olympique lyonnais', 'ol', 'ليون', 'اولمبيك ليون'),
    ('lille', 'losc', 'losc lille', 'ليل'),
    ('nice', 'ogc nice', 'نيس'),
    ('lens', 'rc lens', 'لانس', 'لينس'),
    ('rennes', 'stade rennais', 'رين', 'ستاد رين'),
    ('brest', 'stade brestois', 'بريست', 'ستاد بريست'),
    ('strasbourg', 'rc strasbourg', 'ستراسبورغ', 'ستراسبورج'),
    ('toulouse', 'تولوز'),
    ('reims', 'stade reims', 'ريمس', 'ستاد ريمس'),
    ('montpellier', 'مونبلييه', 'مونبليه'),
    ('nantes', 'fc nantes', 'نانت'),
    ('le havre', 'havre', 'لوهافر', 'لو هافر'),
    ('auxerre', 'aj auxerre', 'اوكسير', 'أوكسير'),
    ('angers', 'angers sco', 'انجيه', 'أنجيه'),
    ('saint etienne', 'st etienne', 'سانت ايتيان', 'سانت إيتيان'),
    ('metz', 'fc metz', 'ميتز'),
    ('lorient', 'fc lorient', 'لوريان'),
    ('clermont', 'clermont foot', 'كليرمون'),
    ('troyes', 'تروا'),
    ('bordeaux', 'بوردو'),
    ('caen', 'كان'),
    ('guingamp', 'غانغون', 'جانجون'),
    ('bastia', 'باستيا'),
    ('amiens', 'اميان'),
    ('ajaccio', 'اجاكسيو'),
    ('paris fc', 'باريس اف سي'),

    # Other European Clubs (Champions League / Europa / Conference / Domestic)
    ('benfica', 'sl benfica', 'بنفيكا'),
    ('porto', 'fc porto', 'بورتو'),
    ('sporting cp', 'sporting lisbon', 'sporting', 'سبورتينغ لشبونه', 'سبورتينج لشبونة', 'سبورتينغ'),
    ('braga', 'sc braga', 'sporting braga', 'سبورتينغ براغا', 'براغا', 'براجا'),
    ('vitoria guimaraes', 'guimaraes', 'فيتوريا غيماريش'),
    ('ajax', 'ajax amsterdam', 'اياكس', 'أياكس', 'اياكس امستردام'),
    ('psv', 'psv eindhoven', 'ايندهوفن', 'آيندهوفن', 'بي اس في'),
    ('feyenoord', 'فينورد', 'فاينورد'),
    ('az alkmaar', 'alkmaar', 'الكمار', 'ألكمار', 'از الكمار'),
    ('twente', 'fc twente', 'تفينتي', 'توينتي'),
    ('utrecht', 'fc utrecht', 'اوتريخت'),
    ('galatasaray', 'غلطة سراي', 'جالطة سراي', 'غلطه سراي'),
    ('fenerbahce', 'فنربخشه', 'فنربخشة', 'فناربخشة'),
    ('besiktas', 'بشكتاش', 'بيشكتاش'),
    ('trabzonspor', 'طرابزون', 'طرابزون سبور', 'ترابزون سبور'),
    ('basaksehir', 'istanbul basaksehir', 'باشاك شهير', 'باشاكشهير'),
    ('kasimpasa', 'قاسم باشا'),
    ('sivasspor', 'سيفاس سبور'),
    ('antalyaspor', 'انطاليا سبور'),
    ('alanyaspor', 'الانيا سبور'),
    ('konyaspor', 'قونيا سبور'),
    ('rizespor', 'ريزه سبور'),
    ('goztepe', 'غوزتيبي'),
    ('eyupspor', 'ايوب سبور'),
    ('samsunspor', 'سامسون سبور'),
    ('celtic', 'سيلتيك', 'سلتيك'),
    ('rangers', 'glasgow rangers', 'رينجرز', 'غلاسكو رينجرز'),
    ('aberdeen', 'ابردين'),
    ('hearts', 'هارتس'),
    ('hibernian', 'هيبرنيان'),
    ('club brugge', 'brugge', 'كلوب بروج', 'بروج'),
    ('anderlecht', 'اندرلخت', 'أندرلخت'),
    ('genk', 'krc genk', 'جينك', 'خينك'),
    ('union sg', 'union saint gilloise', 'سانت جيلواز', 'يونيون سان جيلواز'),
    ('antwerp', 'royal antwerp', 'انتويرب', 'رويال انتويرب'),
    ('gent', 'kaa gent', 'جينت', 'خينت'),
    ('standard liege', 'ستاندار لييج'),
    ('olympiacos', 'olympiakos', 'اولمبياكوس', 'أولمبياكوس'),
    ('panathinaikos', 'باناثينايكوس'),
    ('paok', 'باوك'),
    ('aek athens', 'aek', 'ايك اثينا', 'آيك أثينا'),
    ('salzburg', 'red bull salzburg', 'rb salzburg', 'ريد بول سالزبورغ', 'سالزبورغ', 'سالزبورج'),
    ('sturm graz', 'شتورم غراتس', 'شتورم جراتس'),
    ('rapid wien', 'rapid vienna', 'رابيد فيينا'),
    ('lask', 'لاسك'),
    ('young boys', 'bsc young boys', 'يونغ بويز', 'يانج بويز'),
    ('basel', 'fc basel', 'بازل'),
    ('zurich', 'fc zurich', 'زيوريخ'),
    ('servette', 'سيرفيت'),
    ('lugano', 'لوغانو'),
    ('sparta prague', 'sparta praha', 'سبارتا براغ', 'سبارتا براج'),
    ('slavia prague', 'slavia praha', 'سلافيا براغ', 'سلافيا براج'),
    ('viktoria plzen', 'plzen', 'فيكتوريا بلزن', 'بلزن'),
    ('shakhtar', 'shakhtar donetsk', 'شاختار', 'شاختار دونيتسك'),
    ('dynamo kyiv', 'dynamo kiev', 'دينامو كييف'),
    ('dinamo zagreb', 'دينامو زغرب'),
    ('hajduk split', 'هايدوك سبليت'),
    ('red star belgrade', 'crvena zvezda', 'النجم الاحمر', 'رد ستار بلغراد'),
    ('partizan', 'بارتيزان'),
    ('bodo glimt', 'bodo', 'بودو غليمت', 'بودو جليمت'),
    ('molde', 'مولده'),
    ('rosenborg', 'روزنبورغ'),
    ('brann', 'بران'),
    ('copenhagen', 'fc copenhagen', 'fc kobenhavn', 'كوبنهاغن', 'كوبنهاجن'),
    ('midtjylland', 'fc midtjylland', 'ميتييلاند', 'ميدتيلاند'),
    ('brondby', 'بروندبي'),
    ('malmo', 'malmo ff', 'مالمو'),
    ('djurgarden', 'ديورغاردن'),
    ('elfsborg', 'الفسبورغ'),
    ('ferencvaros', 'فرينكفاروزي', 'فيرينتسفاروشي'),
    ('slovan bratislava', 'سلوفان براتيسلافا'),
    ('qarabag', 'كاراباغ', 'قره باغ'),
    ('ludogorets', 'لودوغوريتس'),
    ('fcsb', 'steaua', 'ستياوا بوخارست'),
    ('legia warsaw', 'legia', 'ليغيا وارسو'),
    ('lech poznan', 'ليخ بوزنان'),
    ('jagiellonia', 'ياغيلونيا'),
    ('maccabi tel aviv', 'مكابي تل ابيب'),
    ('pafos', 'بافوس'),
    ('apoel', 'ابويل'),
    ('omonia', 'اومونيا'),

    # CAF (Africa) - CAF Champions League, Confederation Cup & Arab/African Leagues
    ('al ahly', 'al ahli', 'ahly', 'ahli', 'الاهلي', 'الأهلي', 'أهلي جدة'),
    ('zamalek', 'الزمالك'),
    ('pyramids', 'بيراميدز'),
    ('al masry', 'masry', 'المصري'),
    ('modern sport', 'modern future', 'future fc', 'مودرن سبورت', 'فيوتشر'),
    ('ismaily', 'الاسماعيلي', 'الإسماعيلي'),
    ('ceramica cleopatra', 'سيراميكا كليوباترا', 'سيراميكا'),
    ('zed fc', 'زد'),
    ('enppi', 'انبي', 'إنبي'),
    ('smouha', 'سموحه', 'سموحة'),
    ('esperance', 'esperance sportive de tunis', 'esperance tunis', 'es tunis', 'est', 'الترجي'),
    ('etoile du sahel', 'es sahel', 'ess', 'النجم الساحلي'),
    ('club africain', 'النادي الافريقي', 'الافريقي', 'الإفريقي'),
    ('cs sfaxien', 'sfaxien', 'css', 'النادي الصفاقسي', 'الصفاقسي'),
    ('us monastir', 'monastir', 'الاتحاد المنستيري', 'المنستيري'),
    ('stade tunisien', 'الملعب التونسي'),
    ('wydad', 'wydad ac', 'wydad casablanca', 'wac', 'الوداد'),
    ('raja', 'raja casablanca', 'raja club athletic', 'rca', 'الرجاء'),
    ('as far', 'far rabat', 'asfar', 'الجيش الملكي'),
    ('rs berkane', 'renaissance berkane', 'berkane', 'نهضه بركان', 'نهضة بركان', 'النهضه البركانيه'),
    ('fus rabat', 'fath union sport', 'الفتح الرباطي'),
    ('maghreb fes', 'mas fes', 'المغرب الفاسي'),
    ('hassania agadir', 'حسنيه اغادير', 'حسنية أكادير'),
    ('olympic safi', 'اولمبيك اسفي'),
    ('ittihad tanger', 'اتحاد طنجه', 'اتحاد طنجة'),
    ('mc alger', 'mouloudia alger', 'mca', 'مولوديه الجزاير', 'مولودية الجزائر'),
    ('cr belouizdad', 'belouizdad', 'crb', 'شباب بلوزداد', 'بلوزداد'),
    ('usm alger', 'usma', 'اتحاد العاصمه', 'اتحاد العاصمة', 'اتحاد الجزائر'),
    ('js kabylie', 'jsk', 'kabylie', 'شبيبه القبايل', 'شبيبة القبائل'),
    ('es setif', 'setif', 'وفاق سطيف', 'سطيف'),
    ('cs constantine', 'constantine', 'csc', 'النادي القسنطيني', 'شباب قسنطينه', 'شباب قسنطينة'),
    ('mc oran', 'مولوديه وهران'),
    ('paradou', 'بارادو'),
    ('al merrikh', 'al merreikh', 'merrikh', 'المريخ'),
    ('al ahly tripoli', 'ahli tripoli', 'الاهلي طرابلس', 'أهلي طرابلس'),
    ('al ahli benghazi', 'ahly benghazi', 'الاهلي بنغازي', 'أهلي بنغازي'),
    ('al ittihad tripoli', 'اتحاد طرابلس'),
    ('al nasr benghazi', 'النصر بنغازي'),
    ('al hilal benghazi', 'الهلال بنغازي'),
    ('mamelodi sundowns', 'sundowns', 'ماميلودي صنداونز', 'صنداونز', 'صن داونز'),
    ('orlando pirates', 'pirates', 'اورلاندو بايرتس', 'أورلاندو بايرتس'),
    ('kaizer chiefs', 'كايزر تشيفز'),
    ('stellenbosch', 'ستيلينبوش'),
    ('amazulu', 'امازولو'),
    ('tp mazembe', 'mazembe', 'تي بي مازيمبي', 'مازيمبي'),
    ('as vita club', 'vita club', 'فيتا كلوب'),
    ('maniema union', 'مانييما يونيون', 'مانييما'),
    ('lupopo', 'saint eloi lupopo', 'سانت ايلوا لوبوبو', 'لوبوبو'),
    ('petro atletico', 'petro de luanda', 'بيترو اتلتيكو', 'بترو اتلتيكو'),
    ('sagrada esperanca', 'ساغرادا اسبيرانسا', 'ساجرادا'),
    ('primeiro de agosto', 'بريميرو دي اوغوستو'),
    ('simba', 'simba sc', 'سيمبا'),
    ('young africans', 'yanga', 'يانغ افريكانز', 'يانج أفريكانز'),
    ('azam', 'عزام'),
    ('asec mimosas', 'asec', 'اسيك ميموزا', 'أسيك ميموزا'),
    ('stade malien', 'الملعب المالي'),
    ('djoliba', 'دجوليبا'),
    ('horoya', 'حورويا', 'هورويا'),
    ('enyimba', 'انييمبا', 'إنييمبا'),
    ('rivers united', 'ريفرز يونايتد'),
    ('coton sport', 'القطن الكاميروني', 'القطن'),
    ('jwaneng galaxy', 'جوانينغ غالاكسي'),
    ('nouadhibou', 'اف سي نواذيبو', 'نواذيبو'),
    ('teungueth', 'تونغيث'),
    ('gor mahia', 'غور ماهيا', 'جور ماهيا'),
    ('apr fc', 'الجيش الرواندي'),
    ('kawempe', 'kawempe ml', 'kawempe m l', 'kawempe muslim', 'kawempe muslim ladies', 'kawempe muslim lfc', 'كاويمبي', 'كاويمبي مسلم', 'كاويمبي مسلم ليديز'),
    ('usfas bamako', 'usfas', 'اوسفاس باماكو', 'أوسفاس باماكو', 'اتحاد باماكو'),
    ('wafu b', 'wafu b zone', 'wafu-b', 'wafu zone b', 'wafu b representative', 'ampem darkoa', 'ampem darkoa ladies', 'ampem darkoa ladies fc', 'امبيم داركوا', 'أمبيم داركوا', 'ممثل اتحاد غرب افريقيا ب', 'ممثل اتحاد غرب أفريقيا ب', 'غرب افريقيا ب', 'غرب أفريقيا ب'),
    ('fc masar', 'masar', 'tutankhamun', 'مسار', 'نادي مسار', 'اف سي مسار'),
    ('lekie', 'lekie ff', 'lekie filles', 'lekie filles fc', 'lekie football filles', 'lekie football girls', 'ليكي', 'نادي ليكي'),
    ('edo queens', 'ايدو كوينز', 'إيدو كوينز'),
    ('as mande', 'ماندي'),
    ('15 de agosto', '15 اغسطس'),
    ('cbe fc', 'البنك التجاري الاثيوبي'),

    # AFC (Asia) & Arab Leagues (Saudi, Qatar, UAE, Iraq, Jordan, Kuwait, Bahrain, Iran, East Asia)
    ('al hilal', 'al hilal omdurman', 'hilal', 'الهلال'),
    ('al nassr', 'al nasr', 'nassr', 'nasr', 'النصر'),
    ('al ittihad', 'ittihad', 'الاتحاد', 'اتحاد جده'),
    ('al shabab', 'shabab', 'الشباب'),
    ('al taawoun', 'taawoun', 'التعاون'),
    ('al ettifaq', 'ettifaq', 'الاتفاق'),
    ('al fateh', 'fateh', 'الفتح'),
    ('al qadsiah', 'al qadsia', 'qadsiah', 'qadsia', 'القادسيه', 'القادسية'),
    ('al fayha', 'fayha', 'الفيحاء'),
    ('damac', 'ضمك'),
    ('al raed', 'الرائد'),
    ('al khaleej', 'الخليج'),
    ('al riyadh', 'الرياض'),
    ('al okhdood', 'الاخدود'),
    ('al orobah', 'العروبه'),
    ('al kholood', 'الخلود'),
    ('al sadd', 'sadd', 'السد'),
    ('al duhail', 'duhail', 'الدحيل'),
    ('al rayyan', 'rayyan', 'الريان'),
    ('al gharafa', 'gharafa', 'الغرافه', 'الغرافة'),
    ('al arabi', 'arabi', 'العربي'),
    ('al wakrah', 'wakrah', 'الوكره', 'الوكرة'),
    ('umm salal', 'ام صلال', 'أم صلال'),
    ('al shamal', 'الشمال'),
    ('al khor', 'الخور'),
    ('al shahaniya', 'الشحانيه'),
    ('al ain', 'ain', 'العين'),
    ('al wasl', 'wasl', 'الوصل'),
    ('shabab al ahli', 'شباب الاهلي', 'شباب الأهلي'),
    ('al sharjah', 'sharjah', 'الشارقه', 'الشارقة'),
    ('al wahda', 'al wehda', 'wahda', 'wehda', 'الوحده', 'الوحدة'),
    ('al jazira', 'jazira', 'الجزيره', 'الجزيرة'),
    ('bani yas', 'بني ياس'),
    ('ajman', 'عجمان'),
    ('kalba', 'ittihad kalba', 'كلباء', 'اتحاد كلباء'),
    ('khorfakkan', 'خورفكان'),
    ('al bataeh', 'البطائح'),
    ('al shorta', 'shorta', 'الشرطه', 'الشرطة'),
    ('al quwa al jawiya', 'air force club', 'القوه الجويه', 'القوة الجوية'),
    ('al zawraa', 'zawraa', 'الزوراء'),
    ('al talaba', 'الطلبه'),
    ('erbil', 'اربيل'),
    ('najaf', 'النجف'),
    ('zakho', 'زاخو'),
    ('al wehdat', 'wehdat', 'الوحدات'),
    ('al hussein', 'al hussein irbid', 'hussein irbid', 'الحسين اربد', 'الحسين إربد', 'الحسين'),
    ('al faisaly', 'faisaly', 'الفيصلي'),
    ('al ramtha', 'الرمثا'),
    ('kazma', 'كاظمه', 'كاظمة'),
    ('al salmiya', 'السالميه'),
    ('al khaldiya', 'khaldiya', 'الخالديه', 'الخالدية'),
    ('al riffa', 'riffa', 'الرفاع'),
    ('al muharraq', 'muharraq', 'المحرق'),
    ('manama', 'المنامه'),
    ('al seeb', 'seeb', 'السيب'),
    ('dhofar', 'ظفار'),
    ('al nahda', 'النهضه العماني'),
    ('al ahed', 'العهد', 'العهد اللبناني'),
    ('al ansar', 'الانصار اللبناني'),
    ('nejmeh', 'النجمه اللبناني'),
    ('al futowa', 'الفتوه السوري'),
    ('al karamah', 'الكرامه السوري'),
    ('jableh', 'جبله'),
    ('persepolis', 'برسبوليس', 'بيرسيبوليس'),
    ('esteghlal', 'الاستقلال', 'استقلال طهران'),
    ('sepahan', 'سباهان', 'سباهان اصفهان'),
    ('tractor', 'tractor sazi', 'tractor tabriz', 'tractor sazi tabriz', 'تراكتور', 'تراكتور سازي', 'تراكتور تبريز'),
    ('neftchi fergana', 'neftchi fargona', 'neftchi ferghana', 'neftchi', 'fk neftchi fargona', 'نفتشي فرغانه', 'نيفتشي فرغانة', 'نفتشي', 'نيفتشي'),
    ('pakhtakor', 'pakhtakor tashkent', 'باختاكور', 'باختاكور طشقند'),
    ('nasaf', 'nasaf qarshi', 'ناساف', 'نسف قرشي'),
    ('navbahor', 'نافباهور'),
    ('agmk', 'اجمك'),
    ('istiklol', 'استقلول'),
    ('ahal', 'اهال'),
    ('arkadag', 'fk arkadag', 'arkadag fk', 'اركاداغ', 'أركاداغ', 'اركاداج'),
    ('gol gohar', 'gol gohar sirjan', 'كل كهر', 'كل كهر سيرجان', 'جول جوهر', 'جول جوهر سيرجان', 'گل گهر'),
    ('mesaimeer', 'مسيمير', 'نادي مسيمير'),
    ('mustaqbal al shamal', 'مستقبل الشمال'),
    ('ravshan', 'رافشان'),
    ('altyn asyr', 'التين اسير'),
    ('mumbai city', 'مومباي سيتي'),
    ('mohun bagan', 'موهون باغان'),
    ('east bengal', 'ايست بنغال'),
    ('yokohama f marinos', 'yokohama marinos', 'يوكوهاما مارينوس', 'يوكوهاما'),
    ('vissel kobe', 'فيسيل كوبي'),
    ('kawasaki frontale', 'كاواساكي فرونتال', 'كاواساكي'),
    ('urawa red diamonds', 'urawa reds', 'اوراوا ريد دايموندز', 'اوراوا ريدز'),
    ('sanfrecce hiroshima', 'سانفريس هيروشيما', 'هيروشيما'),
    ('machida zelvia', 'ماتشيدا زيلفيا'),
    ('gamba osaka', 'غامبا اوساكا'),
    ('kashima antlers', 'كاشيما انتلرز'),
    ('ulsan hd', 'ulsan hyundai', 'اولسان', 'أولسان هيونداي', 'اولسان اتش دي'),
    ('pohang steelers', 'pohang', 'بوهانغ ستيلرز', 'بوهانغ'),
    ('gwangju', 'gwangju fc', 'غوانغجو', 'جوانججو'),
    ('jeonbuk', 'jeonbuk motors', 'جيونبوك', 'تشونبوك'),
    ('fc seoul', 'سيول'),
    ('shanghai shenhua', 'shenhua', 'شانغهاي شينخوا', 'شينخوا'),
    ('shanghai port', 'شانغهاي بورت', 'شنغهاي بورت'),
    ('shandong taishan', 'شاندونغ تايشان'),
    ('beijing guoan', 'بكين غوان'),
    ('buriram united', 'buriram', 'بوريرام يونايتد', 'بوريرام'),
    ('bangkok united', 'بانكوك يونايتد'),
    ('port fc', 'بورت التايلاندي'),
    ('muangthong', 'موانغ ثونغ'),
    ('johor darul tazim', 'jdt', 'johor', 'جوهور دار التعظيم', 'جوهور'),
    ('selangor', 'سيلانغور'),
    ('lion city sailors', 'ليون سيتي سيلورز', 'ليون سيتي'),
    ('tampines rovers', 'تامبينز روفرز'),
    ('central coast mariners', 'سنترال كوست مارينرز'),
    ('sydney fc', 'سيدني اف سي', 'سيدني'),
    ('melbourne city', 'ملبورن سيتي'),
    ('melbourne victory', 'ملبورن فيكتوري'),
    ('persib bandung', 'بيرسيب باندونغ'),
    ('kaya fc', 'كايا'),
    ('nam dinh', 'نام دينه'),
    ('hanoi police', 'كونغ ان هانوي'),

    # Americas (CONMEBOL / MLS)
    ('flamengo', 'فلامنغو', 'فلامنجو'),
    ('palmeiras', 'بالميراس'),
    ('botafogo', 'بوتافوغو', 'بوتافوجو'),
    ('atletico mineiro', 'اتلتيكو مينيرو'),
    ('sao paulo', 'ساو باولو'),
    ('corinthians', 'كورينثيانز'),
    ('fluminense', 'فلومينينسي'),
    ('gremio', 'غريميو', 'جريميو'),
    ('internacional', 'انترناسيونال'),
    ('cruzeiro', 'كروزيرو'),
    ('santos', 'سانتوس'),
    ('vasco da gama', 'فاسكو دا غاما'),
    ('river plate', 'ريفر بليت'),
    ('boca juniors', 'بوكا جونيورز'),
    ('racing club', 'راسينغ كلوب'),
    ('independiente', 'اندبندينتي'),
    ('san lorenzo', 'سان لورينزو'),
    ('velez sarsfield', 'فيليز سارسفيلد'),
    ('estudiantes', 'استوديانتس'),
    ('penarol', 'بينارول'),
    ('nacional', 'ناسيونال'),
    ('colo colo', 'كولو كولو'),
    ('inter miami', 'انتر ميامي', 'إنتر ميامي'),
    ('la galaxy', 'لوس انجلوس غالاكسي'),
    ('lafc', 'los angeles fc', 'لوس انجلوس اف سي'),
    ('columbus crew', 'كولومبوس كرو'),

    # National Teams (FIFA / UEFA / CAF / AFC / CONMEBOL / CONCACAF)
    ('egypt', 'مصر', 'منتخب مصر'),
    ('morocco', 'المغرب', 'منتخب المغرب'),
    ('algeria', 'الجزاير', 'الجزائر', 'منتخب الجزائر'),
    ('tunisia', 'تونس', 'منتخب تونس'),
    ('saudi arabia', 'السعوديه', 'السعودية', 'منتخب السعودية'),
    ('qatar', 'قطر', 'منتخب قطر'),
    ('uae', 'united arab emirates', 'الامارات', 'الإمارات', 'منتخب الإمارات'),
    ('iraq', 'العراق', 'منتخب العراق'),
    ('jordan', 'الاردن', 'الأردن', 'منتخب الأردن'),
    ('palestine', 'فلسطين', 'منتخب فلسطين'),
    ('syria', 'سوريا', 'منتخب سوريا'),
    ('lebanon', 'لبنان', 'منتخب لبنان'),
    ('kuwait', 'الكويت', 'منتخب الكويت'),
    ('bahrain', 'البحرين', 'منتخب البحرين'),
    ('oman', 'عمان', 'منتخب عمان'),
    ('yemen', 'اليمن', 'منتخب اليمن'),
    ('sudan', 'السودان', 'منتخب السودان'),
    ('libya', 'ليبيا', 'منتخب ليبيا'),
    ('mauritania', 'موريتانيا', 'منتخب موريتانيا'),
    ('comoros', 'جزر القمر'),
    ('djibouti', 'جيبوتي'),
    ('somalia', 'الصومال'),
    ('senegal', 'السنغال'),
    ('nigeria', 'نيجيريا'),
    ('ivory coast', 'cote divoire', 'كوت ديفوار', 'ساحل العاج'),
    ('cameroon', 'الكاميرون'),
    ('ghana', 'غانا'),
    ('mali', 'مالي'),
    ('burkina faso', 'بوركينا فاسو'),
    ('south africa', 'جنوب افريقيا', 'جنوب أفريقيا'),
    ('dr congo', 'congo dr', 'الكونغو الديمقراطيه', 'الكونغو الديمقراطية'),
    ('congo', 'الكونغو'),
    ('guinea', 'غينيا'),
    ('equatorial guinea', 'غينيا الاستوائيه', 'غينيا الاستوائية'),
    ('cape verde', 'cabo verde', 'الراس الاخضر', 'الرأس الأخضر'),
    ('angola', 'انغولا', 'أنغولا'),
    ('zambia', 'زامبيا'),
    ('zimbabwe', 'زيمبابوي'),
    ('uganda', 'اوغندا', 'أوغندا'),
    ('tanzania', 'تنزانيا'),
    ('kenya', 'كينيا'),
    ('mozambique', 'موزمبيق'),
    ('namibia', 'ناميبيا'),
    ('benin', 'بنين'),
    ('gabon', 'الغابون', 'الجابون'),
    ('togo', 'توغو', 'توجو'),
    ('niger', 'النيجر'),
    ('madagascar', 'مدغشقر'),
    ('central african republic', 'افريقيا الوسطى'),
    ('gambia', 'غامبيا', 'جامبيا'),
    ('sierra leone', 'سيراليون'),
    ('liberia', 'ليبيريا'),
    ('rwanda', 'رواندا'),
    ('burundi', 'بوروندي'),
    ('ethiopia', 'اثيوبيا', 'إثيوبيا'),
    ('botswana', 'بوتسوانا'),
    ('malawi', 'مالاوي'),
    ('lesotho', 'ليسوتو'),
    ('eswatini', 'اسواتيني'),
    ('south sudan', 'جنوب السودان'),
    ('chad', 'تشاد'),
    ('japan', 'اليابان'),
    ('south korea', 'korea republic', 'كوريا الجنوبيه', 'كوريا الجنوبية'),
    ('north korea', 'korea dpr', 'كوريا الشماليه', 'كوريا الشمالية'),
    ('iran', 'ايران', 'إيران'),
    ('australia', 'استراليا', 'أستراليا'),
    ('uzbekistan', 'اوزبكستان', 'أوزبكستان'),
    ('china', 'الصين'),
    ('thailand', 'تايلاند'),
    ('indonesia', 'اندونيسيا', 'إندونيسيا'),
    ('malaysia', 'ماليزيا'),
    ('vietnam', 'فيتنام'),
    ('india', 'الهند'),
    ('tajikistan', 'طاجيكستان'),
    ('kyrgyzstan', 'قرغيزستان', 'قيرغيزستان'),
    ('turkmenistan', 'تركمانستان'),
    ('hong kong', 'هونغ كونغ'),
    ('spain', 'اسبانيا', 'إسبانيا'),
    ('france', 'فرنسا'),
    ('england', 'انجلترا', 'إنجلترا'),
    ('germany', 'المانيا', 'ألمانيا'),
    ('italy', 'ايطاليا', 'إيطاليا'),
    ('portugal', 'البرتغال'),
    ('netherlands', 'holland', 'هولندا'),
    ('belgium', 'بلجيكا'),
    ('croatia', 'كرواتيا'),
    ('switzerland', 'سويسرا'),
    ('denmark', 'الدنمارك', 'الدنمرك'),
    ('austria', 'النمسا'),
    ('turkey', 'turkiye', 'تركيا'),
    ('serbia', 'صربيا'),
    ('poland', 'بولندا'),
    ('ukraine', 'اوكرانيا', 'أوكرانيا'),
    ('scotland', 'اسكتلندا'),
    ('wales', 'ويلز'),
    ('hungary', 'المجر', 'هنغاريا'),
    ('czechia', 'czech republic', 'التشيك', 'جمهوريه التشيك'),
    ('slovakia', 'سلوفاكيا'),
    ('romania', 'رومانيا'),
    ('greece', 'اليونان'),
    ('sweden', 'السويد'),
    ('norway', 'النرويج'),
    ('finland', 'فنلندا'),
    ('iceland', 'ايسلندا', 'آيسلندا'),
    ('ireland', 'republic of ireland', 'ايرلندا', 'جمهورية أيرلندا'),
    ('northern ireland', 'ايرلندا الشماليه'),
    ('slovenia', 'سلوفينيا'),
    ('albania', 'البانيا', 'ألبانيا'),
    ('georgia', 'جورجيا'),
    ('bosnia', 'bosnia and herzegovina', 'البوسنه', 'البوسنة والهرسك'),
    ('montenegro', 'الجبل الاسود'),
    ('north macedonia', 'مقدونيا الشماليه'),
    ('kosovo', 'كوسوفو'),
    ('bulgaria', 'بلغاريا'),
    ('israel', 'اسرائيل'),
    ('cyprus', 'قبرص'),
    ('luxembourg', 'لوكسمبورغ'),
    ('belarus', 'بيلاروسيا'),
    ('armenia', 'ارمينيا'),
    ('azerbaijan', 'اذربيجان'),
    ('kazakhstan', 'كازاخستان'),
    ('argentina', 'الارجنتين', 'الأرجنتين'),
    ('brazil', 'البرازيل'),
    ('uruguay', 'اوروغواي', 'أوروغواي'),
    ('colombia', 'كولومبيا'),
    ('chile', 'تشيلي'),
    ('ecuador', 'الاكوادور', 'الإكوادور'),
    ('paraguay', 'باراغواي', 'باراجواي'),
    ('peru', 'بيرو'),
    ('venezuela', 'فنزويلا'),
    ('bolivia', 'بوليفيا'),
    ('mexico', 'المكسيك'),
    ('usa', 'united states', 'امريكا', 'الولايات المتحده', 'الولايات المتحدة'),
    ('canada', 'كندا'),
    ('costa rica', 'كوستاريكا'),
    ('panama', 'بنما'),
    ('jamaica', 'جامايكا'),
    ('honduras', 'هندوراس'),
    ('new zealand', 'نيوزيلندا'),
)

_BARE_CITIES = set((
    'manchester', 'sheffield', 'bristol', 'madrid', 'glasgow', 'prague', 'praha', 'lisbon', 'lisboa',
    'cairo', 'casablanca', 'tunis', 'algiers', 'riyadh', 'jeddah', 'doha', 'dubai', 'abu dhabi',
    'istanbul', 'athens', 'belgrade', 'buenos aires', 'sao paulo', 'rio', 'london', 'moscow', 'tehran',
    'مانشستر', 'شيفيلد', 'مدريد', 'القاهره', 'الدار البيضاء', 'تونس', 'الجزاير', 'الرياض', 'جده', 'الدوحه', 'دبي',
))

# Cities where one club's short name is the bare city name and another club adds a rival qualifier
_SUBSET_RIVAL_CITIES = set((
    'milan', 'milano', 'ميلان', 'ميلانو',
    'roma', 'rome', 'روما',
    'torino', 'turin', 'تورينو',
    'barcelona', 'برشلونه',
    'sevilla', 'seville', 'اشبيليه',
    'liverpool', 'ليفربول',
))

_RIVAL_EXTRA = set((
    'united', 'city', 'real', 'atletico', 'inter', 'internazionale', 'wednesday', 'rovers', 'espanyol',
    'everton', 'lazio', 'juventus', 'torino', 'celtic', 'rangers', 'betis',
    'يونايتد', 'سيتي', 'ريال', 'اتلتيكو', 'انتر', 'وينزداي', 'روفرز', 'اسبانيول', 'ايفرتون', 'لاتسيو', 'يوفنتوس', 'تورينو', 'بيتيس',
))

_GENERIC_SHARED_WORDS = _BARE_CITIES | _SUBSET_RIVAL_CITIES | _RIVAL_EXTRA | set((
    'athletic', 'sporting', 'olympique', 'stade', 'racing', 'union', 'town', 'wanderers', 'county',
    'albion', 'hotspur', 'borussia', 'bayer', 'dynamo', 'dinamo', 'lokomotiv', 'spartak', 'cska',
    'red', 'star', 'young', 'boys', 'new', 'saint', 'sainte', 'san', 'santa', 'sao', 'al', 'el',
    'club', 'sports', 'sport', 'football', 'national', 'royal', 'deportivo',
    'اهلي', 'هلال', 'اتحاد', 'نصر', 'شباب', 'وحدات', 'شبيبه', 'مولوديه', 'نهضه', 'جيش', 'ترجي',
    'وداد', 'رجاء', 'نجم', 'افريقي', 'صفاقسي', 'فيصلي', 'عربي', 'قادسيه', 'شرطه', 'وكره', 'ريان',
    'غرافه', 'سد', 'دحيل', 'عين', 'وصل', 'شارقه', 'وحده', 'جزيره', 'اولمبيك', 'ستاد', 'سبورتينغ',
))


_guide_now_fn = [None]


def _wall_now():
    fn = _guide_now_fn[0]
    if fn is not None:
        return fn()
    try:
        from . import guide
        fn = getattr(guide, 'now', None) or time.time
        _guide_now_fn[0] = fn
        return fn()
    except Exception:
        return time.time()


def _ascii_digits(value):
    return to_text('' if value is None else value).translate(_DIGITS)


@lru_cache(maxsize=4096)
def normalized(value):
    value = _ascii_digits(value)
    value = re.sub(r'[\u200b-\u200f\u202a-\u202e\u2066-\u2069\u061c\ufeff]', '', value)
    value = unicodedata.normalize('NFKC', value).lower()
    value = re.sub('[ً-ٰٟـ]', '', value)
    for a, b in (
        ('أ', 'ا'), ('إ', 'ا'), ('آ', 'ا'), ('ٱ', 'ا'), ('ى', 'ي'), ('ة', 'ه'),
        ('ؤ', 'و'), ('ئ', 'ي'), ('ڤ', 'ف'), ('گ', 'ك'), ('پ', 'ب'), ('چ', 'ج'),
        ('ı', 'i'), ('ø', 'o'), ('ł', 'l'), ('đ', 'd'), ('ð', 'd'), ('ß', 'ss'),
        ('æ', 'ae'), ('œ', 'oe'), ('þ', 'th'),
    ):
        if a in value:
            value = value.replace(a, b)
    if 'يي' in value:
        value = re.sub(r'ي{2,}', 'ي', value)
    value = ''.join(c for c in unicodedata.normalize('NFKD', value)
                    if not unicodedata.combining(c))
    return ' '.join(re.sub(r'[^\w]+', ' ', value, flags=re.UNICODE).split())


@lru_cache(maxsize=4096)
def team_name(value):
    """Discard EPG country tags and club type initials while expanding common abbreviations."""
    s = to_text(value or '')
    if '(' in s:
        s = re.sub(r'\([^)]*\)', ' ', s)
    s = normalized(s)
    raw_words = s.split()
    if not raw_words:
        return ''
    expanded = []
    for idx, w in enumerate(raw_words):
        if w == 'man' and idx + 1 < len(raw_words) and raw_words[idx + 1] in ('united', 'utd', 'city'):
            expanded.append('manchester')
        else:
            expanded.append(_WORD_MAP.get(w, w))
    filtered = [w for w in expanded if w not in _DROP_WORDS]
    words = filtered if filtered else expanded
    while len(words) > 1 and words[0] == 'club':
        words.pop(0)
    while len(words) > 1 and words[-1] == 'club' and words[0] not in ('athletic', 'اتلتيك', 'racing', 'راسينغ'):
        words.pop()
    return ' '.join(words)


_SPECIAL_ALIASES = {}


def _init_special_aliases():
    for group in _ALIAS_GROUPS:
        canonical = []
        for raw_item in group:
            tn = team_name(raw_item)
            if tn and tn not in canonical:
                canonical.append(tn)
            nm = normalized(raw_item)
            if nm and nm not in canonical:
                canonical.append(nm)
        for item in canonical:
            bucket = _SPECIAL_ALIASES.setdefault(item, set())
            for other in canonical:
                if other != item:
                    bucket.add(other)


_init_special_aliases()


@lru_cache(maxsize=4096)
def _team_aliases_frozen(value):
    base = team_name(value)
    if not base:
        return frozenset()
    out = set([base])
    for extra in _SPECIAL_ALIASES.get(base, ()):
        out.add(extra)
    words = base.split()
    if len(words) > 1 and words[0] in ('al', 'el'):
        out.add(' '.join(words[1:]))
    if len(words) == 1 and words[0].startswith('ال') and len(words[0]) > 4:
        out.add(words[0][2:])
    elif len(words) > 1:
        stripped_ar = [w[2:] if w.startswith('ال') and len(w) > 4 else w for w in words]
        out.add(' '.join(stripped_ar))
        last_w = stripped_ar[-1]
        if last_w in _AR_QUALIFIERS:
            stem_ar = ' '.join(words[:-1])
            stem_stripped = ' '.join(stripped_ar[:-1])
            if stem_ar and stem_ar not in _BARE_CITIES:
                out.add(stem_ar)
            if stem_stripped and stem_stripped not in _BARE_CITIES:
                out.add(stem_stripped)
                if len(stripped_ar[:-1]) == 1 and not words[0].startswith('ال'):
                    out.add('ال' + stripped_ar[0])
    if len(words) > 1 and words[0] in ('real', 'ريال', 'deportivo', 'ديبورتيفو', 'sporting', 'سبورتينغ', 'سبورتينج', 'olympique', 'اولمبيك', 'stade', 'ستاد', 'borussia', 'بوروسيا', 'bayer', 'باير'):
        rem = ' '.join(words[1:])
        if rem not in _BARE_CITIES:
            out.add(rem)
    for item in list(out):
        if 'غ' in item:
            out.add(item.replace('غ', 'ج'))
        if 'ج' in item:
            out.add(item.replace('ج', 'غ'))
    for item in list(out):
        for extra in _SPECIAL_ALIASES.get(item, ()):
            out.add(extra)
    out.discard('')
    return frozenset(out)


def team_aliases(value):
    """Generate canonical alias variations (including bilingual Arabic<->English equivalents)."""
    return set(_team_aliases_frozen(value))


@lru_cache(maxsize=2048)
def english_search_name(value):
    """Return the best Latin/English team name for an Arabic or English EPG team name."""
    raw = to_text(value or '').strip()
    if re.search(r'[A-Za-z]', raw):
        return re.sub(r'\([^)]*\)', ' ', raw).strip()
    for alias in sorted(_team_aliases_frozen(raw), key=lambda x: (-len(x), x)):
        if re.search(r'^[a-z0-9\s]+$', alias):
            return alias
    return raw


@lru_cache(maxsize=4096)
def _alias_words(alias):
    s = frozenset(alias.split())
    return s if (s and not (s <= _BARE_CITIES)) else None


def teams_match(set_a, set_b):
    """Check if two team alias sets refer to the same team without confusing city rivals."""
    if not set_a or not set_b:
        return False
    if set_a & set_b:
        return True
    b_sets = None
    for a in set_a:
        sa = _alias_words(a)
        if sa is None:
            continue
        if b_sets is None:
            b_sets = [sb for sb in (_alias_words(b) for b in set_b) if sb is not None]
            if not b_sets:
                return False
        for sb in b_sets:
            shared = sa & sb
            if not (shared - _BARE_CITIES):
                continue
            if (sa - sb) & _RIVAL_EXTRA and (sb - sa) & _RIVAL_EXTRA:
                continue
            if sa <= sb or sb <= sa:
                diff = sa ^ sb
                if shared <= _SUBSET_RIVAL_CITIES and (diff & _RIVAL_EXTRA):
                    continue
                if all(w in _AR_QUALIFIERS or (w.startswith('ال') and w[2:] in _AR_QUALIFIERS) for w in shared):
                    continue
                return True
    return False


def _looks_like_team_segment(seg):
    s = to_text(seg or '').strip()
    if not s or len(s) > 42 or len(s) < 2:
        return False
    if _NON_TEAM_WORDS.search(s):
        return False
    if re.match(r'^\d+$', s) or re.search(r'\b20\d{2}\b', s):
        return False
    return True


@lru_cache(maxsize=2048)
def extract_fixture_pair(title):
    """Extract (team_a, team_b) from an EPG title, stripping competition prefixes/suffixes safely."""
    text = to_text(title or '').strip()
    if not text:
        return None
    for seg in _COMP_SEP.split(text):
        seg = seg.strip()
        pair = _SPLIT.split(seg)
        if len(pair) == 2 and pair[0].strip() and pair[1].strip():
            a = _COMP_SEP.split(pair[0].strip())[-1].strip()
            b = _COMP_SEP.split(pair[1].strip())[0].strip()
            if a and b:
                return (a, b)
    pair = _SPLIT.split(text)
    if len(pair) == 2:
        a = _COMP_SEP.split(pair[0].strip())[-1].strip()
        b = _COMP_SEP.split(pair[1].strip())[0].strip()
        if a and b:
            return (a, b)
    after_colon = text.split(':', 1)[-1].strip() if ':' in text else text
    hy_parts = [p.strip() for p in re.split(r'\s+[-–—]\s+', after_colon) if p.strip()]
    if len(hy_parts) == 2:
        a, b = hy_parts
        if _looks_like_team_segment(a) and _looks_like_team_segment(b):
            return (a, b)
    elif len(hy_parts) >= 3:
        team_cands = [p for p in hy_parts if _looks_like_team_segment(p)]
        if len(team_cands) == 2:
            return (team_cands[0], team_cands[1])
    return None


def _event_titles(event):
    if not event:
        return ()
    out = []
    for idx in (0, 4, 5):
        if len(event) > idx and event[idx]:
            t = to_text(event[idx]).strip()
            if t and t not in out:
                out.append(t)
    return tuple(out)


def _event_pairs(event):
    pairs = []
    for t in _event_titles(event):
        p = extract_fixture_pair(t)
        if p and p not in pairs:
            pairs.append(p)
    return pairs


@lru_cache(maxsize=2048)
def _slug(value):
    s = unicodedata.normalize('NFKC', to_text(value or '')).strip().lower()
    s = re.sub(r'[^a-z0-9\u0600-\u06ff\s-]', '', s)
    return re.sub(r'[\s-]+', '-', s).strip('-')


def _valid_score_int(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return int(v) == v and 0 <= int(v) <= 99
    if isinstance(v, string_types):
        s = _ascii_digits(v).strip()
        if s.isdigit():
            return 0 <= int(s) <= 99
    return False


def _parse_iso_epoch(stamp):
    stamp = _ascii_digits(stamp).strip()
    if not stamp:
        return None
    if re.match(r'^\d{10}$', stamp):
        return int(stamp)
    if re.match(r'^\d{13}$', stamp):
        return int(stamp) // 1000
    m = re.match(r'^(\d{4}-\d{2}-\d{2})[T\s](\d{2}:\d{2})(?::(\d{2}))?(?:\.\d+)?(Z|[+-]\d{2}:?\d{2})?$', stamp)
    if m:
        base = m.group(1) + 'T' + m.group(2) + ':' + (m.group(3) or '00')
        try:
            ts = calendar.timegm(datetime.datetime.strptime(base, '%Y-%m-%dT%H:%M:%S').timetuple())
            zone = m.group(4) or 'Z'
            if zone != 'Z':
                z = zone.replace(':', '')
                sign = -1 if z[0] == '+' else 1
                ts += sign * (int(z[1:3]) * 3600 + int(z[3:5]) * 60)
            return ts
        except ValueError:
            pass
    for fmt in ('%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%dT%H:%MZ', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M'):
        try:
            return calendar.timegm(datetime.datetime.strptime(stamp, fmt).timetuple())
        except ValueError:
            pass
    return None


def _iter_raw_matches(data):
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                yield item
        return
    if not isinstance(data, dict):
        return
    for group in data.values():
        if isinstance(group, dict):
            if 'home_team_name' in group or 'match_id' in group or 'match_opta_id' in group:
                yield group
            else:
                for raw in group.values():
                    if isinstance(raw, dict):
                        yield raw
                    elif isinstance(raw, list):
                        for item in raw:
                            if isinstance(item, dict):
                                yield item
        elif isinstance(group, list):
            for raw in group:
                if isinstance(raw, dict):
                    yield raw


def parse_payload(data, lang_code='en'):
    """Parse beIN getScorePageList response, retaining live ('in'), finished ('post'), and calendar ('pre') matches."""
    if not isinstance(data, (dict, list)):
        raise ValueError('Invalid score response')
    out = {}
    cancelled_statuses = ('POSTPONED', 'CANCELLED', 'CANCELED', 'SUSPENDED', 'ABANDONED')
    finished_statuses = ('FT', 'FINISHED', 'ENDED', 'AET', 'PEN_FT', 'FULL_TIME', 'FULLTIME', 'انتهت')
    pre_statuses = ('FIXTURE', 'PREMATCH', 'PRE_MATCH', 'UPCOMING', 'NOT_STARTED', 'NOTSTARTED', 'SCHEDULED', 'لم تبدأ')
    live_statuses = (
        'LIVE', 'PLAYING', 'INPROGRESS', 'IN_PROGRESS', 'INPLAY', 'IN_PLAY', 'ACTIVE',
        '1H', '2H', 'FIRST_HALF', 'SECOND_HALF', 'HT', 'HALFTIME', 'HALF_TIME', 'ET', 'PEN',
        'مباشر', 'الشوط الأول', 'الشوط الثاني', 'استراحة', 'إستراحة'
    )
    for raw in _iter_raw_matches(data):
        try:
            ev_status = to_text(raw.get('event_status') or '').strip().lower()
            info = raw.get('match_info') or {}
            if not isinstance(info, dict):
                info = {}
            status = to_text(info.get('match_status') or raw.get('match_status') or '').strip().upper()
            if status in cancelled_statuses or ev_status in ('postponed', 'cancelled', 'canceled', 'suspended', 'abandoned'):
                continue
            stamp = to_text(info.get('match_timestamp') or raw.get('match_timestamp') or info.get('start_time') or raw.get('start_time') or '')
            kickoff = _parse_iso_epoch(stamp)
            if kickoff is None:
                continue

            shown_raw = to_text(info.get('combine_status_time') or raw.get('combine_status_time') or '')
            shown = _ascii_digits(shown_raw).replace('\u2032', "'").strip()
            Shown_up = shown.upper()
            minute_val = None
            m_shown = re.match(r"^(\d{1,3})'?\s*(?:\+\s*(\d{1,2})'?)?'?$", shown)

            state = 'in'
            if status in finished_statuses or ev_status in ('ft', 'finished', 'ended', 'fulltime', 'full_time') or Shown_up in ('FT', 'AET', 'انتهت'):
                state = 'post'
                clock = 'FT'
                minute_val = 90
            elif status in pre_statuses or ev_status in ('prematch', 'pre_match', 'fixture', 'upcoming', 'notstarted', 'not_started', 'scheduled'):
                state = 'pre'
                clock = ''
                minute_val = 0
            elif status in ('HT', 'HALF_TIME', 'HALFTIME') or Shown_up in ('HT', 'استراحة', 'إستراحة') or ev_status in ('ht', 'halftime', 'half_time'):
                state = 'in'
                clock = 'HT'
                minute_val = 45
            elif m_shown:
                minute_val = int(m_shown.group(1))
                if not 0 <= minute_val <= 140:
                    continue
                state = 'in'
                clock = ("%s+%s'" % (m_shown.group(1), m_shown.group(2))) if m_shown.group(2) else ("%d'" % max(1, minute_val))
            else:
                live_t = info.get('live_time') if info.get('live_time') is not None else raw.get('live_time')
                inj_t = info.get('injury_time') if info.get('injury_time') is not None else raw.get('injury_time')
                if isinstance(live_t, string_types):
                    m_lt = re.match(r"^(\d{1,3})", _ascii_digits(live_t).strip())
                    live_t = int(m_lt.group(1)) if m_lt else None
                if isinstance(inj_t, string_types):
                    m_it = re.match(r"^(\d{1,2})", _ascii_digits(inj_t).strip())
                    inj_t = int(m_it.group(1)) if m_it else None
                if not isinstance(live_t, bool) and isinstance(live_t, int) and 0 < live_t <= 140:
                    state = 'in'
                    minute_val = max(1, live_t)
                    if not isinstance(inj_t, bool) and isinstance(inj_t, int) and 0 < inj_t <= 30:
                        clock = "%d+%d'" % (minute_val, inj_t)
                    else:
                        clock = "%d'" % minute_val
                elif ev_status in ('playing', 'live', 'inprogress', 'in_progress', 'inplay', 'in_play', 'ht', 'active') or status in live_statuses:
                    state = 'in'
                    clock = 'LIVE'
                elif status in pre_statuses or ev_status in ('prematch', 'pre_match', 'fixture', 'upcoming', 'notstarted', 'not_started', 'scheduled', ''):
                    state = 'pre'
                    clock = 'LIVE'
                    minute_val = 0
                else:
                    state = 'pre'
                    clock = 'LIVE'
                    minute_val = 0

            full_pair = extract_fixture_pair(raw.get('match_name') or '') or _SPLIT.split(to_text(raw.get('match_name') or ''))
            home_disp = to_text(raw.get('home_team_name') or info.get('home_team_name') or '').strip()
            away_disp = to_text(raw.get('away_team_name') or info.get('away_team_name') or '').strip()
            if len(full_pair) == 2:
                if not home_disp:
                    home_disp = full_pair[0].strip()
                if not away_disp:
                    away_disp = full_pair[1].strip()
            if not home_disp or not away_disp:
                continue

            ident = to_text(raw.get('match_opta_id') or raw.get('match_id') or info.get('match_id') or '').strip()
            home = to_text(raw.get('home_team_id') or info.get('home_team_id') or '').strip()
            away = to_text(raw.get('away_team_id') or info.get('away_team_id') or '').strip()
            if not home:
                home = 'bein_' + re.sub(r'[^A-Za-z0-9_-]', '_', _slug(home_disp))[:32]
            if not away:
                away = 'bein_' + re.sub(r'[^A-Za-z0-9_-]', '_', _slug(away_disp))[:32]
            if not ident:
                ident = 'bein_%d_%s_%s' % (kickoff, home[:16], away[:16])
            if not all(re.match(r'^[A-Za-z0-9_-]{1,64}$', s) for s in (ident, home, away)) or home == away:
                continue

            raw_h_goals = raw.get('home_team_goals') if raw.get('home_team_goals') is not None else info.get('home_team_goals')
            raw_a_goals = raw.get('away_team_goals') if raw.get('away_team_goals') is not None else info.get('away_team_goals')
            if _valid_score_int(raw_h_goals) and _valid_score_int(raw_a_goals):
                home_goals = int(_ascii_digits(raw_h_goals))
                away_goals = int(_ascii_digits(raw_a_goals))
            elif state in ('pre', 'in'):
                home_goals, away_goals = 0, 0
            else:
                continue

            aliases = [team_aliases(home_disp), team_aliases(away_disp)]
            if len(full_pair) == 2:
                aliases[0].update(team_aliases(full_pair[0]))
                aliases[1].update(team_aliases(full_pair[1]))
            if not aliases[0] or not aliases[1]:
                continue

            logo_urls = {}
            for side_id, keys in ((home, ('home_team_logo', 'home_logo', 'home_team_image')),
                                  (away, ('away_team_logo', 'away_logo', 'away_team_image'))):
                for lk in keys:
                    lv = to_text(raw.get(lk) or info.get(lk) or '').strip()
                    if lv:
                        if lv.startswith('http://') or lv.startswith('https://'):
                            logo_urls[side_id] = lv
                        elif lv.endswith('.png'):
                            logo_urls[side_id] = MEDIA + lv.lstrip('/')
                        break

            match_date = to_text(info.get('match_date') or raw.get('match_date') or '')[:10] or stamp[:10]

            # If duplicate ident exists, prefer 'in' over 'post' over 'pre'
            prev = out.get(ident)
            if prev and (prev.get('state') == 'post' or (prev.get('state') == 'in' and state == 'pre')):
                continue
            out[ident] = {
                'id': ident,
                'match_id': to_text(raw.get('match_id') or ident),
                'state': state,
                'teams': (home, away),
                'logo_urls': logo_urls,
                'names': aliases,
                'goals': (home_goals, away_goals),
                'score': '%d - %d' % (away_goals, home_goals),
                'clock': clock,
                'minute': minute_val,
                'kickoff': kickoff,
                'match_date': match_date,
                'lang_data': {
                    lang_code: {
                        'home_name': home_disp,
                        'away_name': away_disp,
                    }
                },
            }
        except Exception:
            continue
    return out


def _state_rank(m, women_match=True):
    st = m.get('state', 'in')
    s_rank = 0 if st == 'in' else (1 if st == 'post' else 2)
    w_rank = 0 if women_match else 1
    return (s_rank, w_rank)


_WOMEN_RE = re.compile(r'women|female|ladies|feminin|féminin|femenin|سيدات|نسائي|نسائية', re.I)


@lru_cache(maxsize=1024)
def _cached_event_meta(titles, cat_hint):
    alias_pairs = []
    for t in titles:
        p = extract_fixture_pair(t)
        if p:
            a_s, b_s = _team_aliases_frozen(p[0]), _team_aliases_frozen(p[1])
            if a_s and b_s and (a_s, b_s) not in alias_pairs:
                alias_pairs.append((a_s, b_s))
    title_women = any(bool(_WOMEN_RE.search(t)) for t in titles + ((cat_hint,) if cat_hint else ()))
    return tuple(alias_pairs), title_women


def match_event(event, matches, now=None):
    """Match an EPG event (checking both English and Arabic EPG titles) against live/current matches."""
    now = _wall_now() if now is None else now
    if not event or len(event) < 3 or excluded_card_event(event):
        return None
    title, start, end = event[:3]
    if not start <= now < end or _is_replay_event(event):
        return None
    titles = _event_titles(event)
    cat_hint = to_text(event[6]) if len(event) > 6 and event[6] else ''
    alias_pairs, title_women = _cached_event_meta(titles, cat_hint)
    if not alias_pairs:
        return None

    exact = []
    fuzzy = []
    min_ko = max(start - 14400, now - 8 * 3600)
    max_ko = min(end + 14400, now + 7200)
    for m in matches:
        ko = m['kickoff']
        if not (min_ko <= ko <= max_ko):
            continue
        h, v = m['names']
        matched_exact = False
        matched_fuzzy = False
        for a_set, b_set in alias_pairs:
            if (bool(a_set & h) and bool(b_set & v)) or (bool(a_set & v) and bool(b_set & h)):
                matched_exact = True
                break
            elif (teams_match(a_set, h) and teams_match(b_set, v)) or (teams_match(a_set, v) and teams_match(b_set, h)):
                matched_fuzzy = True
        if matched_exact or matched_fuzzy:
            src_women = m.get('_is_women')
            if src_women is None:
                source_identity = ' '.join(n for side in m['names'] for n in side)
                src_women = bool(_WOMEN_RE.search(source_identity))
                m['_is_women'] = src_women
            women_match = (src_women == title_women) if src_women else True
            if matched_exact:
                exact.append((_state_rank(m, women_match), m))
            else:
                fuzzy.append((_state_rank(m, women_match), m))
    if exact:
        exact.sort(key=lambda item: item[0])
        return exact[0][1]
    if fuzzy:
        fuzzy.sort(key=lambda item: item[0])
        return fuzzy[0][1]
    return None


_ssl_lock = threading.Lock()
_global_ssl_ctxs = []
_preferred_ctx_idx = [0]

# Pre-mapped official team crest URLs (FotMob & SofaScore CDNs) for instant 0-search resolution
_KNOWN_TEAM_LOGO_RAW = (
    # AFC Champions League Elite & AFC Champions League Two
    (('tractor', 'tractor sazi', 'tractor tabriz', 'تراكتور'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/176352.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/176352_small.png',
        'https://img.sofascore.com/api/v1/team/53715/image',
        'https://api.sofascore.com/api/v1/team/53715/image',
    )),
    (('neftchi fergana', 'neftchi fargona', 'neftchi', 'نيفتشي فرغانة', 'نفتشي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/102145.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/102145_small.png',
        'https://img.sofascore.com/api/v1/team/36256/image',
        'https://api.sofascore.com/api/v1/team/36256/image',
    )),
    (('al sadd', 'sadd', 'السد'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101895.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101895_small.png',
        'https://img.sofascore.com/api/v1/team/39733/image',
    )),
    (('al ahli', 'al ahli saudi', 'الاهلي السعودي', 'أهلي جدة'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/2530.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/2530_small.png',
        'https://img.sofascore.com/api/v1/team/34469/image',
    )),
    (('al wasl', 'wasl', 'الوصل'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/102111.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/102111_small.png',
        'https://img.sofascore.com/api/v1/team/47674/image',
    )),
    (('al quwa al jawiya', 'air force club', 'القوة الجوية', 'القوه الجويه'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101656.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101656_small.png',
        'https://img.sofascore.com/api/v1/team/213877/image',
    )),
    (('al hilal', 'hilal', 'الهلال'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/2529.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/2529_small.png',
        'https://img.sofascore.com/api/v1/team/21895/image',
    )),
    (('al nassr', 'nassr', 'النصر'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101918.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101918_small.png',
        'https://img.sofascore.com/api/v1/team/23400/image',
    )),
    (('al ittihad', 'ittihad', 'الاتحاد'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/8577.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/8577_small.png',
        'https://img.sofascore.com/api/v1/team/34315/image',
    )),
    (('al ain', 'ain', 'العين'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/102117.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/102117_small.png',
        'https://img.sofascore.com/api/v1/team/39729/image',
    )),
    (('al gharafa', 'gharafa', 'الغرافة', 'الغرافه'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101897.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101897_small.png',
    )),
    (('al rayyan', 'rayyan', 'الريان'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101898.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101898_small.png',
    )),
    (('al shamal', 'shamal', 'الشمال'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101904.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101904_small.png',
    )),
    (('esteghlal', 'الاستقلال'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101614.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101614_small.png',
    )),
    (('persepolis', 'برسبوليس', 'بيرسيبوليس'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101610.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101610_small.png',
    )),
    (('sepahan', 'سباهان'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101611.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101611_small.png',
    )),
    (('arkadag', 'fk arkadag', 'arkadag fk', 'اركاداغ', 'أركاداغ'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/1689659.png',
        'https://img.sofascore.com/api/v1/team/477964/image',
        'https://api.sofascore.com/api/v1/team/477964/image',
    )),
    (('gol gohar', 'gol gohar sirjan', 'كل كهر', 'كل كهر سيرجان', 'جول جوهر'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/424165.png',
        'https://img.sofascore.com/api/v1/team/169522/image',
        'https://api.sofascore.com/api/v1/team/169522/image',
    )),
    (('pakhtakor', 'pakhtakor tashkent', 'باختاكور'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/102141.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/102141_small.png',
    )),
    (('al shorta', 'shorta', 'الشرطة', 'الشرطه'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/101655.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/101655_small.png',
    )),
    (('shabab al ahli', 'شباب الأهلي', 'شباب الاهلي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/177356.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/177356_small.png',
    )),
    # CAF Women's Champions League & CAF Club Competitions
    (('usfas bamako', 'usfas', 'أوسفاس باماكو', 'اوسفاس باماكو'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/1840115.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/1840115_small.png',
        'https://img.sofascore.com/api/v1/team/292593/image',
        'https://api.sofascore.com/api/v1/team/292593/image',
        'https://img.sofascore.com/api/v1/team/418626/image',
    )),
    (('wafu b', 'wafu b zone', 'ampem darkoa', 'ampem darkoa ladies', 'أمبيم داركوا', 'ممثل اتحاد غرب أفريقيا ب'), (
        'https://img.sofascore.com/api/v1/team/497379/image',
        'https://api.sofascore.com/api/v1/team/497379/image',
        'https://img.sofascore.com/api/v1/team/1265252/image',
        'https://api.sofascore.com/api/v1/team/1265252/image',
        'https://img.sofascore.com/api/v1/team/935464/image',
        'https://img.sofascore.com/api/v1/team/1265255/image',
    )),
    (('fc masar', 'masar', 'مسار', 'نادي مسار'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/1840123.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/1840123_small.png',
        'https://img.sofascore.com/api/v1/team/933430/image',
        'https://img.sofascore.com/api/v1/team/934888/image',
        'https://img.sofascore.com/api/v1/team/373361/image',
    )),
    (('lekie', 'lekie ff', 'lekie filles', 'lekie football filles', 'lekie football girls', 'ليكي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/2421624.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/2421624_small.png',
        'https://img.sofascore.com/api/v1/team/413450/image',
        'https://api.sofascore.com/api/v1/team/413450/image',
    )),
    (('fus rabat', 'fath union sport', 'الفتح الرباطي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/102036.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/102036_small.png',
    )),
    (('mamelodi sundowns', 'sundowns', 'ماميلودي صنداونز', 'صن داونز'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/4530.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/4530_small.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/2421625.png',
        'https://img.sofascore.com/api/v1/team/331932/image',
    )),
    (('as far', 'far rabat', 'الجيش الملكي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/1840126.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/102035.png',
    )),
    (('kawempe', 'kawempe muslim', 'kawempe muslim ladies', 'كاويمبي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/2421628.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/2421628_small.png',
    )),
    # Turkish Süper Lig
    (('fenerbahce', 'فنربخشة', 'فنربخشه'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/8695.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/8695_small.png',
        'https://img.sofascore.com/api/v1/team/3052/image',
    )),
    (('goztepe', 'غوزتيبي', 'جوزتيبي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/1925.png',
        'https://images.fotmob.com/image_resources/logo/teamlogo/1925_small.png',
        'https://img.sofascore.com/api/v1/team/3054/image',
    )),
    (('galatasaray', 'غلطة سراي'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/8637.png',
        'https://img.sofascore.com/api/v1/team/3061/image',
    )),
    (('besiktas', 'بشكتاش'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/8696.png',
        'https://img.sofascore.com/api/v1/team/3050/image',
    )),
    (('trabzonspor', 'طرابزون سبور'), (
        'https://images.fotmob.com/image_resources/logo/teamlogo/9752.png',
        'https://img.sofascore.com/api/v1/team/3051/image',
    )),
)

_KNOWN_TEAM_LOGO_MAP = {}
for _names, _urls in _KNOWN_TEAM_LOGO_RAW:
    for _n in _names:
        _tn = team_name(_n)
        if _tn:
            _KNOWN_TEAM_LOGO_MAP[_tn] = _urls
        _nm = normalized(_n)
        if _nm:
            _KNOWN_TEAM_LOGO_MAP[_nm] = _urls


def _known_logo_urls(*hints):
    """Return pre-mapped official crest URLs for a team if in _KNOWN_TEAM_LOGO_MAP."""
    out = []
    for h in hints:
        if not h:
            continue
        for al in (team_aliases(h) | set([team_name(h), normalized(h)])):
            if al in _KNOWN_TEAM_LOGO_MAP:
                for u in _KNOWN_TEAM_LOGO_MAP[al]:
                    if u not in out:
                        out.append(u)
    return out


def _get_ssl_contexts():
    """Return shared SSL contexts built once so worker threads never re-parse cacert.pem."""
    if not _global_ssl_ctxs:
        with _ssl_lock:
            if not _global_ssl_ctxs:
                ctxs = []
                if os.path.isfile(CA_BUNDLE):
                    try:
                        ctxs.append(ssl.create_default_context(cafile=CA_BUNDLE))
                    except Exception:
                        pass
                try:
                    ctxs.append(ssl.create_default_context())
                except Exception:
                    pass
                if hasattr(ssl, '_create_unverified_context'):
                    try:
                        ctxs.append(ssl._create_unverified_context())
                    except Exception:
                        pass
                _global_ssl_ctxs[:] = ctxs
    ctxs = _global_ssl_ctxs
    idx = _preferred_ctx_idx[0]
    if 0 < idx < len(ctxs):
        return [ctxs[idx]] + [c for i, c in enumerate(ctxs) if i != idx]
    return list(ctxs)


def _read(url, limit, web=False, timeout=None):
    contexts = _get_ssl_contexts()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/json,*/*' if web else 'application/json,image/png,image/*,*/*',
        'Accept-Language': 'en-US,en;q=0.9,ar;q=0.8',
    }
    if 'sofascore.com' in url:
        headers['Referer'] = 'https://www.sofascore.com/'
        headers['Origin'] = 'https://www.sofascore.com'
    elif 'fotmob.com' in url:
        headers['Referer'] = 'https://www.fotmob.com/'
    wait_s = timeout if timeout is not None else (3.5 if web else 5.5)
    last = None
    for context in contexts:
        try:
            req = Request(url, headers=headers)
            response = urlopen(req, timeout=wait_s, context=context)
            try:
                final = to_text(response.geturl() or '')
                if final and not (final.startswith('https://') or final.startswith('http://')):
                    raise ValueError('Unexpected score redirect')
                data = response.read(limit + 1)
                if len(data) > limit:
                    raise ValueError('Score response too large')
                ctxs = _global_ssl_ctxs
                if ctxs and context in ctxs:
                    _preferred_ctx_idx[0] = ctxs.index(context)
                return data
            finally:
                response.close()
        except Exception as exc:
            reason = getattr(exc, 'reason', exc)
            err_txt = to_text(reason).upper()
            if isinstance(reason, ssl.SSLError) or 'CERTIFICATE_VERIFY_FAILED' in err_txt or 'SSL' in err_txt:
                last = exc
                continue
            raise
    raise last


def _png_valid(data):
    """Validate PNG header and reject 1x1 / tiny invisible placeholder images."""
    if not data or len(data) < 57 or data[:8] != b'\x89PNG\r\n\x1a\n' or data[12:16] != b'IHDR':
        return False
    w, h = struct.unpack('>II', data[16:24])
    return 16 <= w <= 2048 and 16 <= h <= 2048


def _paeth(a, b, c):
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def _encode_rgba_png(rgba_bytes, tw, th):
    raw_rows = bytearray()
    stride = tw * 4
    for y in range(th):
        raw_rows.append(0)
        raw_rows.extend(rgba_bytes[y * stride:(y + 1) * stride])

    def chunk(ctype, cdata):
        crc = zlib.crc32(ctype + cdata) & 0xffffffff
        return struct.pack('>I', len(cdata)) + ctype + cdata + struct.pack('>I', crc)

    ihdr = struct.pack('>IIBBBBB', tw, th, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(raw_rows), 6)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', idat) + chunk(b'IEND', b'')


def _lanczos2(x):
    x = abs(x)
    if x < 1e-7:
        return 1.0
    if x >= 2.0:
        return 0.0
    px = math.pi * x
    return (math.sin(px) / px) * (math.sin(px * 0.5) / (px * 0.5))


@lru_cache(maxsize=256)
def _lanczos_weights(src_len, dst_len):
    scale = float(src_len) / float(dst_len)
    support_scale = max(1.0, scale)
    support = 2.0 * support_scale
    inv_scale = 1.0 / support_scale
    table = []
    for d_i in range(dst_len):
        center = (d_i + 0.5) * scale - 0.5
        left = max(0, int(math.floor(center - support)))
        right = min(src_len - 1, int(math.ceil(center + support)))
        weights = []
        w_sum = 0.0
        for s_i in range(left, right + 1):
            w = _lanczos2((s_i - center) * inv_scale)
            if abs(w) > 1e-6:
                weights.append((s_i, w))
                w_sum += w
        if not weights or abs(w_sum) < 1e-6:
            nearest = max(0, min(src_len - 1, int(round(center))))
            table.append(((nearest, 1.0),))
        else:
            table.append(tuple((s_i, w / w_sum) for s_i, w in weights))
    return tuple(table)


def _decode_png_rgba(data):
    """Decode PNG (or PIL-supported image) into (bytearray_rgba, width, height)."""
    if not data or len(data) < 57:
        return None
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data)).convert('RGBA')
        if 16 <= im.width <= 2048 and 16 <= im.height <= 2048:
            return bytearray(im.tobytes()), im.width, im.height
    except Exception:
        pass
    if not _png_valid(data):
        return None
    w, h, bit_depth, color_type, comp, filt, interlace = struct.unpack('>IIBBBBB', data[16:29])
    if interlace != 0 or bit_depth not in (1, 2, 4, 8, 16) or color_type not in (0, 2, 3, 4, 6):
        return None
    pos = 8
    idat_parts = []
    plte = b''
    trns = b''
    while pos + 8 <= len(data):
        length = struct.unpack('>I', data[pos:pos + 4])[0]
        ctype = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if ctype == b'IDAT':
            idat_parts.append(body)
        elif ctype == b'PLTE':
            plte = body
        elif ctype == b'tRNS':
            trns = body
        elif ctype == b'IEND':
            break
    if not idat_parts:
        return None
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[color_type]
    if bit_depth < 8:
        bpp = 1
        stride = (w * bit_depth + 7) // 8
    else:
        bpp = channels * (2 if bit_depth == 16 else 1)
        stride = w * bpp
    raw = bytearray(zlib.decompress(b''.join(idat_parts)))
    if len(raw) < h * (1 + stride):
        return None
    recon = bytearray(h * stride)
    for y in range(h):
        if (y & 15) == 15:
            yield_to_ui()
        row_start = y * (1 + stride)
        ftype = raw[row_start]
        src = raw[row_start + 1:row_start + 1 + stride]
        dst_off = y * stride
        prev_off = (y - 1) * stride
        if ftype == 0:
            recon[dst_off:dst_off + stride] = src
        elif ftype == 1:
            for i in range(stride):
                a = recon[dst_off + i - bpp] if i >= bpp else 0
                recon[dst_off + i] = (src[i] + a) & 0xff
        elif ftype == 2:
            for i in range(stride):
                b = recon[prev_off + i] if y > 0 else 0
                recon[dst_off + i] = (src[i] + b) & 0xff
        elif ftype == 3:
            for i in range(stride):
                a = recon[dst_off + i - bpp] if i >= bpp else 0
                b = recon[prev_off + i] if y > 0 else 0
                recon[dst_off + i] = (src[i] + ((a + b) >> 1)) & 0xff
        elif ftype == 4:
            for i in range(stride):
                a = recon[dst_off + i - bpp] if i >= bpp else 0
                b = recon[prev_off + i] if y > 0 else 0
                c = recon[prev_off + i - bpp] if (y > 0 and i >= bpp) else 0
                recon[dst_off + i] = (src[i] + _paeth(a, b, c)) & 0xff
        else:
            return None

    if bit_depth == 16:
        recon = bytearray(recon[0::2])
    elif bit_depth < 8:
        unpacked = bytearray(w * h)
        mask = (1 << bit_depth) - 1
        scale_g = 255 // mask
        for y in range(h):
            r_off = y * stride
            u_off = y * w
            x = 0
            for b_idx in range(stride):
                byte_val = recon[r_off + b_idx]
                shift = 8 - bit_depth
                while shift >= 0 and x < w:
                    sample = (byte_val >> shift) & mask
                    unpacked[u_off + x] = sample if color_type == 3 else (sample * scale_g)
                    x += 1
                    shift -= bit_depth
        recon = unpacked

    rgba = bytearray(w * h * 4)
    if color_type == 6:
        rgba[:] = recon
    elif color_type == 2:
        trns_rgb = struct.unpack('>HHH', trns[:6]) if len(trns) >= 6 else None
        for idx in range(w * h):
            s = idx * 3
            d = idx * 4
            r, g, b = recon[s], recon[s + 1], recon[s + 2]
            rgba[d] = r
            rgba[d + 1] = g
            rgba[d + 2] = b
            rgba[d + 3] = 0 if (trns_rgb and (r, g, b) == trns_rgb) else 255
    elif color_type == 3:
        palette = []
        num_c = len(plte) // 3
        for idx in range(256):
            if idx < num_c:
                r = ord(plte[idx * 3:idx * 3 + 1])
                g = ord(plte[idx * 3 + 1:idx * 3 + 2])
                b = ord(plte[idx * 3 + 2:idx * 3 + 3])
                a = ord(trns[idx:idx + 1]) if idx < len(trns) else 255
                palette.append((r, g, b, a))
            else:
                palette.append((0, 0, 0, 0))
        for idx in range(w * h):
            c = palette[recon[idx]]
            d = idx * 4
            rgba[d], rgba[d + 1], rgba[d + 2], rgba[d + 3] = c
    elif color_type == 4:
        for idx in range(w * h):
            v = recon[idx * 2]
            a = recon[idx * 2 + 1]
            d = idx * 4
            rgba[d] = v
            rgba[d + 1] = v
            rgba[d + 2] = v
            rgba[d + 3] = a
    elif color_type == 0:
        trns_g = struct.unpack('>H', trns[:2])[0] & 0xff if len(trns) >= 2 else None
        for idx in range(w * h):
            v = recon[idx]
            d = idx * 4
            rgba[d] = v
            rgba[d + 1] = v
            rgba[d + 2] = v
            rgba[d + 3] = 0 if (trns_g is not None and v == trns_g) else 255
    return rgba, w, h


def _strip_logo_box_background(rgba, w, h):
    """Remove any opaque solid box or 2-color checkerboard background around the outer edges of a logo."""
    if w < 16 or h < 16:
        return
    corners = ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1))
    corner_alphas = [rgba[(cy * w + cx) * 4 + 3] for cx, cy in corners]
    if min(corner_alphas) >= 180:
        border_coords = []
        for x in range(w):
            border_coords.append((x, 0))
            border_coords.append((x, h - 1))
        for y in range(1, h - 1):
            border_coords.append((0, y))
            border_coords.append((w - 1, y))
        buckets = {}
        for bx, by in border_coords:
            p = (by * w + bx) * 4
            if rgba[p + 3] >= 180:
                key = (rgba[p] >> 3, rgba[p + 1] >> 3, rgba[p + 2] >> 3)
                buckets[key] = buckets.get(key, 0) + 1
        if buckets:
            top_keys = sorted(buckets.items(), key=lambda kv: -kv[1])[:2]
            bg_colors = []
            for k_rgb, _ in top_keys:
                c_rgb = (k_rgb[0] * 8 + 4, k_rgb[1] * 8 + 4, k_rgb[2] * 8 + 4)
                if len(bg_colors) == 0 or (max(c_rgb) - min(c_rgb) <= 28 and max(bg_colors[0]) - min(bg_colors[0]) <= 28):
                    bg_colors.append(c_rgb)

            def matches_bg(r, g, b, tol=18):
                for br, bg, bb in bg_colors:
                    if abs(r - br) <= tol and abs(g - bg) <= tol and abs(b - bb) <= tol:
                        return True
                return False

            matched_border = 0
            seed_queue = []
            visited = bytearray(w * h)
            for bx, by in border_coords:
                idx = by * w + bx
                p = idx * 4
                if rgba[p + 3] >= 180 and matches_bg(rgba[p], rgba[p + 1], rgba[p + 2], 18):
                    matched_border += 1
                    if not visited[idx]:
                        visited[idx] = 1
                        seed_queue.append(idx)
            if matched_border >= int(len(border_coords) * 0.85):
                head = 0
                while head < len(seed_queue):
                    if (head & 255) == 255:
                        yield_to_ui()
                    curr = seed_queue[head]
                    head += 1
                    p = curr * 4
                    rgba[p] = 0
                    rgba[p + 1] = 0
                    rgba[p + 2] = 0
                    rgba[p + 3] = 0
                    cy, cx = divmod(curr, w)
                    for nx, ny in ((cx - 1, cy), (cx + 1, cy), (cx, cy - 1), (cx, cy + 1)):
                        if 0 <= nx < w and 0 <= ny < h:
                            nidx = ny * w + nx
                            if not visited[nidx]:
                                np_off = nidx * 4
                                na = rgba[np_off + 3]
                                nr, ng, nb = rgba[np_off], rgba[np_off + 1], rgba[np_off + 2]
                                if na < 20 or matches_bg(nr, ng, nb, 18):
                                    visited[nidx] = 1
                                    seed_queue.append(nidx)
                                elif matches_bg(nr, ng, nb, 34):
                                    # Feather 1px anti-aliased boundary against removed box background
                                    rgba[np_off + 3] = min(na, 110)

def _fast_downsample_rgba(rgba, w, h, max_dim=160):
    """Downsample oversized logos before flood-fill and Lanczos resampling to keep CPU load tiny."""
    if w <= max_dim and h <= max_dim:
        return rgba, w, h
    step = max(2, int(max(w, h) // max_dim))
    nw, nh = max(16, w // step), max(16, h // step)
    out = bytearray(nw * nh * 4)
    s4 = step * 4
    w4 = w * 4
    half_s = (step >> 1)
    half_s4 = half_s * 4
    for ny in range(nh):
        if (ny & 15) == 15:
            yield_to_ui()
        sy0 = ny * step
        row0 = sy0 * w4
        row1 = min(h - 1, sy0 + half_s) * w4
        d_row = ny * nw * 4
        for nx in range(nw):
            sx0 = nx * s4
            sx1 = sx0 + half_s4
            p00 = row0 + sx0
            p01 = row0 + sx1
            p10 = row1 + sx0
            p11 = row1 + sx1
            d = d_row + nx * 4
            out[d] = (rgba[p00] + rgba[p01] + rgba[p10] + rgba[p11]) >> 2
            out[d + 1] = (rgba[p00 + 1] + rgba[p01 + 1] + rgba[p10 + 1] + rgba[p11 + 1]) >> 2
            out[d + 2] = (rgba[p00 + 2] + rgba[p01 + 2] + rgba[p10 + 2] + rgba[p11 + 2]) >> 2
            out[d + 3] = (rgba[p00 + 3] + rgba[p01 + 3] + rgba[p10 + 3] + rgba[p11 + 3]) >> 2
    return out, nw, nh


def _decode_and_prepare_logo(data):
    """Decode logo, strip any box/checkerboard background, and tightly crop to visible crest."""
    decoded = _decode_png_rgba(data)
    if not decoded:
        return None
    rgba, orig_w, orig_h = decoded
    rgba, w, h = _fast_downsample_rgba(rgba, orig_w, orig_h, 160)
    _strip_logo_box_background(rgba, w, h)
    xmin, ymin, xmax, ymax = w, h, -1, -1
    visible_src = 0
    for y in range(h):
        if (y & 15) == 15:
            yield_to_ui()
        row_off = y * w * 4
        for x in range(w):
            a = rgba[row_off + x * 4 + 3]
            if a < 14:
                if a:
                    p = row_off + x * 4
                    rgba[p] = rgba[p + 1] = rgba[p + 2] = rgba[p + 3] = 0
            elif a >= 20:
                visible_src += 1
                if x < xmin:
                    xmin = x
                if x > xmax:
                    xmax = x
                if y < ymin:
                    ymin = y
                if y > ymax:
                    ymax = y
    if xmax < xmin or ymax < ymin or visible_src < 32:
        return None
    cw = xmax - xmin + 1
    ch = ymax - ymin + 1
    if cw < 8 or ch < 8:
        return None
    cropped = bytearray(cw * ch * 4)
    for y in range(ch):
        s_off = ((ymin + y) * w + xmin) * 4
        d_off = y * cw * 4
        cropped[d_off:d_off + cw * 4] = rgba[s_off:s_off + cw * 4]
    return cropped, cw, ch, orig_w, orig_h


def _sharpen_interior_rgba(buf, w, h, amount=0.35):
    """Apply subtle 3x3 unsharp mask to interior crest pixels (without haloing outer transparent edges)."""
    out = bytearray(buf)
    stride = w * 4
    for y in range(1, h - 1):
        row = y * stride
        for x in range(1, w - 1):
            p = row + x * 4
            if buf[p + 3] < 150:
                continue
            if (buf[p - 4 + 3] < 150 or buf[p + 4 + 3] < 150 or
                    buf[p - stride + 3] < 150 or buf[p + stride + 3] < 150):
                continue
            for c in range(3):
                center = buf[p + c]
                neigh = (buf[p - 4 + c] + buf[p + 4 + c] + buf[p - stride + c] + buf[p + stride + c]) * 0.25
                val = int(round(center + (center - neigh) * amount))
                out[p + c] = 255 if val > 255 else (0 if val < 0 else val)
    return out


def _render_prepared_logo(cropped_rgba, cw, ch, target=78):
    """Resample tightly-cropped crest into target x target using premultiplied Lanczos-3 + unsharp mask."""
    tw = th = max(16, int(target))
    margin = 1 if tw < 96 else 2
    avail = max(1, tw - 2 * margin)
    if cw >= ch:
        fw = avail
        fh = max(1, int(round(ch * float(avail) / cw)))
    else:
        fh = avail
        fw = max(1, int(round(cw * float(avail) / ch)))

    wx = _lanczos_weights(cw, fw)
    wy = _lanczos_weights(ch, fh)

    tmp = [0.0] * (ch * fw * 4)
    for y in range(ch):
        if (y & 15) == 15:
            yield_to_ui()
        src_row = y * cw * 4
        dst_row = y * fw * 4
        for dx in range(fw):
            pr = pg = pb = pa = 0.0
            for sx, wt in wx[dx]:
                p = src_row + sx * 4
                a = cropped_rgba[p + 3]
                if a > 0:
                    aw = a * wt
                    pr += cropped_rgba[p] * aw
                    pg += cropped_rgba[p + 1] * aw
                    pb += cropped_rgba[p + 2] * aw
                    pa += aw
            d_off = dst_row + dx * 4
            tmp[d_off] = pr
            tmp[d_off + 1] = pg
            tmp[d_off + 2] = pb
            tmp[d_off + 3] = pa

    out = bytearray(tw * th * 4)
    ox = (tw - fw) // 2
    oy = (th - fh) // 2
    visible_pixels = 0
    for dy in range(fh):
        if (dy & 15) == 15:
            yield_to_ui()
        for dx in range(fw):
            pr = pg = pb = pa = 0.0
            col_off = dx * 4
            for sy, wt in wy[dy]:
                p = sy * fw * 4 + col_off
                pr += tmp[p] * wt
                pg += tmp[p + 1] * wt
                pb += tmp[p + 2] * wt
                pa += tmp[p + 3] * wt
            if pa >= 12.0:
                a_i = min(255, int(round(pa)))
                r_i = min(255, max(0, int(round(pr / pa))))
                g_i = min(255, max(0, int(round(pg / pa))))
                b_i = min(255, max(0, int(round(pb / pa))))
                d_off = ((oy + dy) * tw + (ox + dx)) * 4
                out[d_off] = r_i
                out[d_off + 1] = g_i
                out[d_off + 2] = b_i
                out[d_off + 3] = a_i
                if a_i >= 25:
                    visible_pixels += 1

    if visible_pixels < max(16, (tw * th) // 40):
        return None
    sharpened = _sharpen_interior_rgba(out, tw, th, 0.35)
    res = _encode_rgba_png(sharpened, tw, th)
    return res if _png_valid(res) else None


def _pure_python_resize_png(data, tw=78, th=78):
    """Pure-stdlib PNG decoder, background stripper, auto-cropper and Lanczos-3 resampler."""
    prep = _decode_and_prepare_logo(data)
    if not prep:
        return None
    cropped_rgba, cw, ch, _, _ = prep
    return _render_prepared_logo(cropped_rgba, cw, ch, min(tw, th))


def _optimize_logo_png(data, target=78):
    """Resize team logos to target x target with tight auto-crop, background removal, and Lanczos-3 sharpening."""
    prep = _decode_and_prepare_logo(data)
    if not prep:
        return None
    cropped_rgba, cw, ch, _, _ = prep
    return _render_prepared_logo(cropped_rgba, cw, ch, target)


# 5x7 pixel font for club monogram initials in fallback club shield badges
_FONT_5X7 = {
    'A': (0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11),
    'B': (0x1E, 0x11, 0x11, 0x1E, 0x11, 0x11, 0x1E),
    'C': (0x0E, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0E),
    'D': (0x1E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1E),
    'E': (0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F),
    'F': (0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x10),
    'G': (0x0E, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0F),
    'H': (0x11, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11),
    'I': (0x0E, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0E),
    'J': (0x07, 0x02, 0x02, 0x02, 0x12, 0x12, 0x0C),
    'K': (0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11),
    'L': (0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1F),
    'M': (0x11, 0x1B, 0x15, 0x15, 0x11, 0x11, 0x11),
    'N': (0x11, 0x19, 0x15, 0x13, 0x11, 0x11, 0x11),
    'O': (0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E),
    'P': (0x1E, 0x11, 0x11, 0x1E, 0x10, 0x10, 0x10),
    'Q': (0x0E, 0x11, 0x11, 0x11, 0x15, 0x12, 0x0D),
    'R': (0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11),
    'S': (0x0F, 0x10, 0x10, 0x0E, 0x01, 0x01, 0x1E),
    'T': (0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04),
    'U': (0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E),
    'V': (0x11, 0x11, 0x11, 0x11, 0x11, 0x0A, 0x04),
    'W': (0x11, 0x11, 0x11, 0x15, 0x15, 0x1B, 0x11),
    'X': (0x11, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x11),
    'Y': (0x11, 0x11, 0x0A, 0x04, 0x04, 0x04, 0x04),
    'Z': (0x1F, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1F),
}

_CLUB_PALETTES = (
    ((198, 40, 40), (140, 20, 20), (255, 215, 100)),    # Crimson & Gold
    ((21, 101, 192), (13, 71, 161), (240, 244, 248)),   # Royal Blue & Silver
    ((27, 94, 32), (46, 125, 50), (255, 213, 79)),      # Forest Green & Gold
    ((245, 127, 23), (198, 40, 40), (255, 255, 255)),   # Amber & Red
    ((74, 20, 140), (106, 27, 154), (255, 215, 64)),    # Purple & Gold
    ((0, 105, 92), (0, 77, 64), (224, 242, 241)),       # Teal & White
    ((183, 28, 28), (33, 33, 33), (255, 215, 64)),      # Red & Black
    ((13, 71, 161), (183, 28, 28), (255, 215, 64)),     # Blaugrana
)


def _club_monogram(name_hint):
    en = english_search_name(name_hint or '')
    words = [w.upper() for w in re.findall(r'[A-Za-z]+', en) if w.lower() not in ('fc', 'sc', 'cf', 'al', 'el', 'as', 'ac', 'fk', 'us', 'club', 'sport', 'women', 'ladies')]
    if not words:
        words = [w.upper() for w in re.findall(r'[A-Za-z]+', en)]
    if len(words) >= 2:
        code = (words[0][0] + words[1][0] + (words[2][0] if len(words) >= 3 else (words[1][1:2] if len(words[1]) > 1 else ''))).upper()
        return code[:3]
    if len(words) == 1 and len(words[0]) >= 2:
        return words[0][:3]
    return 'FC'


def _generate_club_shield_png(name_hint, size=65):
    """Generate a crisp 65x65 or 43x43 club shield crest PNG when a team has no online logo."""
    en = team_name(name_hint or '') or normalized(name_hint or '') or 'club'
    hval = int(hashlib.md5(en.encode('utf-8')).hexdigest()[:8], 16)
    if 'tractor' in en:
        c1, c2, rim = (205, 32, 39), (150, 18, 24), (245, 245, 245)
    elif 'neftchi' in en:
        c1, c2, rim = (27, 94, 32), (245, 176, 25), (255, 235, 130)
    elif 'usfas' in en:
        c1, c2, rim = (34, 120, 45), (235, 185, 20), (255, 255, 255)
    elif 'wafu' in en or 'ampem' in en:
        c1, c2, rim = (20, 80, 165), (220, 50, 45), (255, 215, 70)
    elif 'masar' in en:
        c1, c2, rim = (190, 35, 35), (30, 30, 35), (245, 200, 65)
    elif 'lekie' in en:
        c1, c2, rim = (25, 115, 50), (200, 40, 40), (250, 215, 55)
    else:
        c1, c2, rim = _CLUB_PALETTES[hval % len(_CLUB_PALETTES)]

    mono = _club_monogram(name_hint)
    buf = bytearray(size * size * 4)
    cx = (size - 1) / 2.0

    for y in range(size):
        for x in range(size):
            dx = x - cx
            ny = (y - (size * 0.08)) / (size * 0.84)
            if 0.0 <= ny <= 1.0:
                if ny < 0.55:
                    half_w = (size * 0.42)
                else:
                    t = (ny - 0.55) / 0.45
                    half_w = (size * 0.42) * max(0.0, 1.0 - (t * t * 0.88))
                dist_edge = half_w - abs(dx)
                if ny < 0.08:
                    dist_edge = min(dist_edge, (ny / 0.08) * 4.0)
            else:
                dist_edge = -1.0

            p = (y * size + x) * 4
            if dist_edge >= 0.0:
                alpha = 255 if dist_edge >= 1.2 else int(max(0.0, min(1.0, dist_edge / 1.2)) * 255)
                border_w = max(2.2, size * 0.055)
                if dist_edge < border_w or ny < 0.12:
                    r, g, b = rim
                else:
                    stripe = ((x * 5) // size) % 2
                    r, g, b = c1 if stripe == 0 else c2
                    if ny < 0.42:
                        r = min(255, r + 18)
                        g = min(255, g + 18)
                        b = min(255, b + 18)
                buf[p] = r
                buf[p + 1] = g
                buf[p + 2] = b
                buf[p + 3] = alpha

    band_y0 = int(size * 0.34)
    band_y1 = int(size * 0.66)
    for y in range(band_y0, band_y1):
        for x in range(size):
            p = (y * size + x) * 4
            if buf[p + 3] > 180:
                if y in (band_y0, band_y1 - 1):
                    buf[p], buf[p + 1], buf[p + 2] = rim
                else:
                    buf[p] = (buf[p] // 3) + 12
                    buf[p + 1] = (buf[p + 1] // 3) + 12
                    buf[p + 2] = (buf[p + 2] // 3) + 15

    scale = 2 if size >= 56 else 1
    char_w = 5 * scale
    char_h = 7 * scale
    gap = scale
    total_w = len(mono) * char_w + max(0, len(mono) - 1) * gap
    start_x = (size - total_w) // 2
    start_y = (size - char_h) // 2
    for idx, ch in enumerate(mono):
        rows = _FONT_5X7.get(ch, _FONT_5X7['F'])
        ox = start_x + idx * (char_w + gap)
        for ry, bits in enumerate(rows):
            for rx in range(5):
                if (bits >> (4 - rx)) & 1:
                    for sy in range(scale):
                        for sx in range(scale):
                            px = ox + rx * scale + sx
                            py = start_y + ry * scale + sy
                            if 0 <= px < size and 0 <= py < size:
                                p = (py * size + px) * 4
                                buf[p] = 255
                                buf[p + 1] = 255
                                buf[p + 2] = 255
                                buf[p + 3] = 255

    return _encode_rgba_png(buf, size, size)


def _extract_fotmob_options(node):
    """Recursively yield all option dicts from FotMob searchapi/suggest (whether dict or list)."""
    if isinstance(node, dict):
        if 'payload' in node and isinstance(node['payload'], dict):
            yield node
        for k, v in node.items():
            if k != 'squadMemberSuggest':
                for item in _extract_fotmob_options(v):
                    yield item
    elif isinstance(node, list):
        for item in node:
            for sub in _extract_fotmob_options(item):
                yield sub


def _parse_sofascore_events(data):
    """Parse SofaScore live/scheduled football events JSON into normalized match dicts with team logo URLs."""
    out = []
    events = data.get('events') if isinstance(data, dict) else None
    if not isinstance(events, list):
        return out
    wall = _wall_now()
    for ev in events:
        try:
            if not isinstance(ev, dict):
                continue
            status = ev.get('status') or {}
            stype = to_text(status.get('type') or '').strip().lower()
            if stype in ('canceled', 'cancelled', 'postponed', 'abandoned'):
                continue
            if stype == 'inprogress':
                state = 'in'
            elif stype == 'finished':
                state = 'post'
            elif stype == 'notstarted':
                state = 'pre'
            else:
                continue

            start_ts = ev.get('startTimestamp')
            if not isinstance(start_ts, (int, float)):
                continue
            kickoff = int(start_ts)

            ht_team = ev.get('homeTeam') or {}
            at_team = ev.get('awayTeam') or {}
            h_id = to_text(ht_team.get('id') or '').strip()
            a_id = to_text(at_team.get('id') or '').strip()
            h_name = to_text(ht_team.get('shortName') or ht_team.get('name') or '').strip()
            a_name = to_text(at_team.get('shortName') or at_team.get('name') or '').strip()
            if not h_name or not a_name:
                continue

            h_aliases = set()
            a_aliases = set()
            for k in ('name', 'shortName', 'slug'):
                if ht_team.get(k):
                    h_aliases.update(team_aliases(ht_team[k]))
                if at_team.get(k):
                    a_aliases.update(team_aliases(at_team[k]))
            if not h_aliases or not a_aliases:
                continue

            h_sc_obj = ev.get('homeScore') or {}
            a_sc_obj = ev.get('awayScore') or {}
            h_goals = int(h_sc_obj.get('current') if h_sc_obj.get('current') is not None else (h_sc_obj.get('display') or 0))
            a_goals = int(a_sc_obj.get('current') if a_sc_obj.get('current') is not None else (a_sc_obj.get('display') or 0))
            desc = to_text(status.get('description') or '').strip().lower()
            time_obj = ev.get('time') or {}
            period_start = time_obj.get('currentPeriodStartTimestamp')
            initial_sec = int(time_obj.get('initial') or 0)
            minute_val = None
            if state == 'post':
                clock = 'FT'
                minute_val = 90
            elif state == 'pre':
                clock = 'LIVE'
                minute_val = 0
            elif desc in ('halftime', 'ht', 'half time'):
                clock = 'HT'
                minute_val = 45
            elif isinstance(period_start, (int, float)) and period_start > 0 and wall >= period_start:
                elapsed_min = int((wall - period_start + initial_sec) // 60) + 1
                minute_val = max(1, min(130, elapsed_min))
                clock = "%d'" % minute_val
            else:
                clock = 'LIVE'
                if '2nd' in desc:
                    minute_val = 46

            home_key = ('sofa_' + h_id) if h_id else ('sofa_' + _slug(h_name)[:28])
            away_key = ('sofa_' + a_id) if a_id else ('sofa_' + _slug(a_name)[:28])
            logo_urls = {}
            if h_id.isdigit():
                logo_urls[home_key] = SOFASCORE_LOGO_HOST + h_id + '/image'
            if a_id.isdigit():
                logo_urls[away_key] = SOFASCORE_LOGO_HOST + a_id + '/image'

            ev_id = to_text(ev.get('id') or '%d_%s_%s' % (kickoff, h_id, a_id))
            ident = 'sofa_' + re.sub(r'[^A-Za-z0-9_-]', '_', ev_id)
            out.append({
                'id': ident,
                'match_id': ident,
                'state': state,
                'teams': (home_key, away_key),
                'logo_urls': logo_urls,
                'names': [h_aliases, a_aliases],
                'goals': (h_goals, a_goals),
                'score': '%d - %d' % (a_goals, h_goals),
                'clock': clock,
                'minute': minute_val,
                'kickoff': kickoff,
                'match_date': time.strftime('%Y-%m-%d', time.gmtime(kickoff)),
                'lang_data': {
                    'en': {
                        'home_name': h_name,
                        'away_name': a_name,
                    }
                },
            })
        except Exception:
            continue
    return out


def _write_atomic_file(path, data):
    if not os.path.isdir(LOGO_DIR):
        try:
            os.makedirs(LOGO_DIR)
        except OSError:
            pass
    fd, temporary = tempfile.mkstemp(prefix='download-', dir=LOGO_DIR)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
        os.rename(temporary, path)
    finally:
        if os.path.exists(temporary):
            try:
                os.unlink(temporary)
            except OSError:
                pass


_MAX_LOGO_WORKERS = 1


class Scores(object):
    def __init__(self):
        self._lock = threading.Lock()
        self._ready_event = threading.Event()
        self._busy = False
        self._last_attempt = None
        self._updated = None
        self._matches = []
        self._espn_matches = []
        self._scorer_feed = ScoreboardScorers(_read)
        self._logos = {}
        self._fallback_logos = {}
        self.target_logo_size = 78
        for old_dir in ('ultraaudio-live-football-v2', 'ultraaudio-live-football-v3'):
            old_p = os.path.join(tempfile.gettempdir(), old_dir)
            if os.path.isdir(old_p):
                try:
                    for fn in os.listdir(old_p):
                        try:
                            os.unlink(os.path.join(old_p, fn))
                        except OSError:
                            pass
                    os.rmdir(old_p)
                except OSError:
                    pass
        self._logo_inflight = set()
        self._logo_queue = []
        self._logo_workers = 0
        self._ht_cache = {}
        self._details = {}
        self._detail_attempts = {}
        self._discovery_attempts = {}
        self._team_logo_url_cache = {}
        self._error = ''
        self._wanted = None
        self._wanted_page = []
        self._pending_page_req = None
        self._logo_attempts = {}
        self._rev = 0
        self._logo_rev = 0
        self._last_ui_notify = 0.0
        self._live_cache = {}
        self._view_cache = {}
        self.logger = None
        self.on_update = None
        self._last_note = None

    def note(self, message):
        if self._last_note == message:
            return
        self._last_note = message
        if self.logger:
            try:
                self.logger('LiveMatch: ' + message)
            except Exception:
                pass

    def _disk_logo_path(self, team):
        return os.path.join(LOGO_DIR, hashlib.sha256(to_text(team).encode('utf-8')).hexdigest() + '.png')

    def _disk_fallback_logo_path(self, team):
        return os.path.join(LOGO_DIR, 'fb_' + hashlib.sha256(to_text(team).encode('utf-8')).hexdigest()[:24] + '.png')

    def _notify_ui(self):
        cb = getattr(self, "on_update", None)
        if not callable(cb):
            return
        now = monotonic()
        if now - getattr(self, "_last_ui_notify", 0.0) < 0.35:
            return
        self._last_ui_notify = now
        try:
            from .engine import main_call
            main_call(cb)
        except Exception:
            pass

    def _bump_rev(self):
        self._rev += 1
        self._live_cache = {}
        self._view_cache = {}
        self._notify_ui()

    def _bump_logo_rev(self):
        self._logo_rev = getattr(self, "_logo_rev", 0) + 1
        self._view_cache = {}
        self._notify_ui()

    def _get_cached_logo(self, team):
        """Return real downloaded logo path from RAM or disk cache immediately without network IO."""
        if not team:
            return None
        p = self._logos.get(team)
        if p:
            return p
        disk_p = self._disk_logo_path(team)
        try:
            if os.path.isfile(disk_p) and os.path.getsize(disk_p) >= 57:
                self._logos[team] = disk_p
                return disk_p
        except OSError:
            pass
        return None

    def _get_fallback_logo(self, team, team_label, allow_generate=False):
        """Disabled per user preference: leave crest slot empty until the real club logo is downloaded."""
        return None

    def is_candidate(self, event):
        if not event or len(event) < 3 or excluded_card_event(event):
            return False
        titles = _event_titles(event)
        if not titles or _is_replay_event(event):
            return False
        cat_hint = to_text(event[6]) if len(event) > 6 and event[6] else ''
        alias_pairs, _ = _cached_event_meta(titles, cat_hint)
        return bool(alias_pairs)

    def warm_up(self):
        """Prefetch live fixtures and scoreboard details in the background."""
        now = monotonic()
        with self._lock:
            if self._busy or (self._updated is not None and 0 <= now - self._updated < POLL):
                return
            self._busy = True
            self._last_attempt = now
        try:
            start_thread(self._worker, args=(None, True), name='UltraAudioLiveScores')
        except Exception:
            with self._lock:
                self._busy = False

    def wait_ready(self, timeout=1.5):
        self._ready_event.wait(timeout)

    def _logo_worker_loop(self):
        try:
            while True:
                with self._lock:
                    if not self._logo_queue:
                        self._logo_workers = max(0, self._logo_workers - 1)
                        return
                    job = self._logo_queue.pop(0)
                try:
                    yield_to_ui()
                    self._download_logo(*job)
                except Exception:
                    with self._lock:
                        self._logo_inflight.discard(job[0])
        except Exception:
            with self._lock:
                self._logo_workers = max(0, self._logo_workers - 1)

    def _logo_request_live(self, event, match_id, team=None):
        """Use the card's exact live/freshness/replay gate, including for queued work."""
        current = self._live_match(event)
        if current is None or current.get('id') != match_id:
            return False
        return team is None or team in tuple(current.get('teams') or ()) + tuple(current.get('alt_teams') or ())

    def _spawn_logo_downloads(self, match, priority=False, event=None):
        """Queue non-blocking logo downloads using a bounded 2-worker priority queue to prevent socket flooding."""
        if not match or not self._logo_request_live(event, match.get('id')):
            return
        logo_urls = match.get('logo_urls') or {}
        alt_teams = list(match.get('alt_teams') or ())
        ld = match.get('lang_data') or {}
        en_ld = ld.get('en') or {}
        ar_ld = ld.get('ar') or {}
        team_names = (
            en_ld.get('home_name') or ar_ld.get('home_name') or '',
            en_ld.get('away_name') or ar_ld.get('away_name') or '',
        )
        ar_names = (
            ar_ld.get('home_name') or en_ld.get('home_name') or '',
            ar_ld.get('away_name') or en_ld.get('away_name') or '',
        )
        need_workers = 0
        with self._lock:
            for idx, team in enumerate(match['teams']):
                alt_id = alt_teams[idx] if idx < len(alt_teams) else ''
                t_name = team_names[idx] if idx < len(team_names) else ''
                a_name = ar_names[idx] if idx < len(ar_names) else ''
                if self._get_cached_logo(team):
                    continue
                if alt_id and self._get_cached_logo(alt_id):
                    self._logos[team] = self._logos[alt_id]
                    continue
                url = logo_urls.get(team, '') or (logo_urls.get(alt_id, '') if alt_id else '')
                job = (team, url, alt_id, t_name, a_name, event, match.get('id'))
                if team in self._logo_inflight:
                    for q_idx, existing in enumerate(self._logo_queue):
                        if existing[0] == team:
                            # The new request passed the live gate before this lock.
                            # Replace queued context so an older event cannot block it.
                            self._logo_queue.pop(q_idx)
                            self._logo_queue.insert(0 if priority else q_idx, job)
                            break
                    continue
                last_try = self._logo_attempts.get(team, -POLL)
                if monotonic() - last_try < 6:
                    continue
                self._logo_inflight.add(team)
                self._logo_attempts[team] = monotonic()
                if priority:
                    self._logo_queue.insert(0, job)
                else:
                    self._logo_queue.append(job)
            while self._logo_queue and self._logo_workers < _MAX_LOGO_WORKERS:
                self._logo_workers += 1
                need_workers += 1
        for _ in range(need_workers):
            try:
                start_thread(self._logo_worker_loop, args=(), name='UltraAudioLogo')
            except Exception:
                with self._lock:
                    self._logo_workers = max(0, self._logo_workers - 1)

    def ensure_page(self, current_event, page_events):
        """Non-blocking page request: defer all regex/alias matching and thread spawning off the GUI thread."""
        self._pending_page_req = (current_event, tuple(page_events or ()))
        if is_main_thread():
            if not self._busy:
                now = monotonic()
                with self._lock:
                    if not self._busy:
                        self._busy = True
                        fresh = self._updated is not None and 0 <= now - self._updated <= POLL
                        refresh = not fresh and (self._last_attempt is None or now - self._last_attempt >= 12)
                        if refresh:
                            self._last_attempt = now
                        try:
                            start_thread(self._worker, args=(current_event, refresh), name='UltraAudioLiveScores')
                        except Exception:
                            self._busy = False
            return
        self._ensure_page_bg(current_event, page_events)

    def _ensure_page_bg(self, current_event, page_events):
        """Resolve candidate events and queue logo downloads on the background worker thread."""
        yield_to_ui()
        valid_page = [ev for ev in (page_events or ()) if self.is_candidate(ev)]
        if current_event and self.is_candidate(current_event):
            if current_event not in valid_page:
                valid_page.insert(0, current_event)
        elif valid_page:
            current_event = valid_page[0]
        else:
            return None, []
        pri_match = None
        page_matches = []
        matches_snap = list(self._matches)
        with self._lock:
            self._wanted = current_event
            self._wanted_page = list(valid_page)
        if matches_snap:
            for ev in valid_page:
                yield_to_ui()
                m = match_event(ev, matches_snap)
                if m is not None:
                    if ev is current_event:
                        pri_match = m
                    else:
                        page_matches.append((m, ev))
        if pri_match is not None:
            self._spawn_logo_downloads(pri_match, priority=True, event=current_event)
        for m, ev in page_matches:
            self._spawn_logo_downloads(m, priority=False, event=ev)
        return current_event, valid_page

    def ensure(self, event):
        if not self.is_candidate(event):
            return
        self.ensure_page(event, [event])

    def _lookup_external_team_logos(self, *team_name_hints, **kwargs):
        """Query _KNOWN_TEAM_LOGO_MAP, FotMob suggest, SofaScore search, TheSportsDB, and ESPN search for a team's crest URLs."""
        allowed = kwargs.get('allowed', lambda: True)
        urls = _known_logo_urls(*team_name_hints)
        primary_hint = ''
        for h in team_name_hints:
            if h:
                primary_hint = h
                break
        q_name = english_search_name(primary_hint)
        if not q_name:
            return urls
        cache_key = team_name(q_name) or normalized(q_name)
        if cache_key:
            with self._lock:
                cached = self._team_logo_url_cache.get(cache_key)
                if cached:
                    for u in cached:
                        if u not in urls:
                            urls.append(u)
                    return urls

        target_aliases = set()
        for h in team_name_hints:
            if h:
                target_aliases.update(team_aliases(h))
        target_aliases.update(team_aliases(q_name))

        search_terms = [q_name]
        words = [w for w in q_name.split() if len(w) >= 3 and w.lower() not in _GENERIC_SHARED_WORDS and w.lower() not in _DROP_WORDS]
        if words and words[0] not in search_terms:
            search_terms.append(words[0])

        # 1. FotMob searchapi/suggest (handles both dict and list JSON responses, strips '|id' from text)
        for term in search_terms[:2]:
            try:
                u = FOTMOB_SUGGEST_ENDPOINT + '?term=' + quote(term.encode('utf-8'), safe=str('')) + '&lang=en'
                if not allowed():
                    return urls
                raw = _read(u, MAX_JSON, timeout=3)
                data = json.loads(raw.decode('utf-8'))
                for opt in _extract_fotmob_options(data):
                    payload = opt.get('payload') or {}
                    if payload.get('homeName'):
                        continue
                    tid = to_text(payload.get('id') or '').strip()
                    raw_tname = to_text(payload.get('name') or opt.get('text') or '').strip()
                    tname = raw_tname.split('|')[0].strip()
                    if tid.isdigit() and tname and teams_match(team_aliases(tname), target_aliases):
                        for cand in (FOTMOB_LOGO_HOST + tid + '.png', FOTMOB_LOGO_HOST + tid + '_small.png'):
                            if cand not in urls:
                                urls.append(cand)
                        break
                if urls:
                    break
            except Exception:
                continue

        # 2. SofaScore search API (https://api.sofascore.com/api/v1/search/all?q=...)
        for term in search_terms[:2]:
            try:
                u = SOFASCORE_SEARCH_ENDPOINT + '?q=' + quote(term.encode('utf-8'), safe=str('')) + '&page=0'
                if not allowed():
                    return urls
                raw = _read(u, MAX_JSON, timeout=3)
                data = json.loads(raw.decode('utf-8'))
                for item in (data.get('results') or []) if isinstance(data, dict) else []:
                    if not isinstance(item, dict) or item.get('type') not in ('team', None):
                        continue
                    ent = item.get('entity') if isinstance(item.get('entity'), dict) else item
                    sport = to_text((ent.get('sport') or {}).get('slug') or '').lower()
                    if sport and sport not in ('football', 'soccer'):
                        continue
                    tid = to_text(ent.get('id') or '').strip()
                    tname = to_text(ent.get('name') or ent.get('shortName') or '').strip()
                    if tid.isdigit() and tname and teams_match(team_aliases(tname), target_aliases):
                        for cand in (SOFASCORE_LOGO_HOST + tid + '/image', SOFASCORE_API_LOGO_HOST + tid + '/image'):
                            if cand not in urls:
                                urls.append(cand)
                        break
                if len(urls) >= 2:
                    break
            except Exception:
                continue

        # 3. TheSportsDB free API
        if not urls:
            for term in search_terms[:2]:
                try:
                    u = SPORTSDB_SEARCH_ENDPOINT + '?t=' + quote(term.encode('utf-8'), safe=str(''))
                    if not allowed():
                        return urls
                    raw = _read(u, MAX_JSON, timeout=3)
                    data = json.loads(raw.decode('utf-8'))
                    for item in (data.get('teams') or []) if isinstance(data, dict) else []:
                        if not isinstance(item, dict):
                            continue
                        sport = to_text(item.get('strSport') or '').lower()
                        if sport and sport not in ('soccer', 'football'):
                            continue
                        tname = to_text(item.get('strTeam') or item.get('strTeamShort') or '').strip()
                        badge = to_text(item.get('strBadge') or item.get('strTeamBadge') or '').strip()
                        if badge and tname and teams_match(team_aliases(tname), target_aliases):
                            for b_cand in (badge + '/preview', badge, badge + '/tiny'):
                                if b_cand not in urls:
                                    urls.append(b_cand)
                            break
                    if urls:
                        break
                except Exception:
                    continue

        # 4. ESPN search v2 API (rejecting default-team-logo placeholders)
        if not urls:
            try:
                u = ESPN_SEARCH_ENDPOINT + '?query=' + quote(q_name.encode('utf-8'), safe=str('')) + '&limit=6'
                if not allowed():
                    return urls
                raw = _read(u, MAX_JSON, timeout=3)
                data = json.loads(raw.decode('utf-8'))
                for grp in (data.get('results') or []) if isinstance(data, dict) else []:
                    if not isinstance(grp, dict) or grp.get('type') not in ('team', None):
                        continue
                    for item in grp.get('contents') or []:
                        if not isinstance(item, dict):
                            continue
                        sport = to_text(item.get('sport') or '').lower()
                        if sport and sport != 'soccer':
                            continue
                        dname = to_text(item.get('displayName') or item.get('name') or '').strip()
                        if dname and teams_match(team_aliases(dname), target_aliases):
                            for img in (item.get('images') or []):
                                if isinstance(img, dict):
                                    iurl = to_text(img.get('url') or '').strip()
                                    if iurl and 'default-team-logo' not in iurl.lower() and iurl not in urls:
                                        urls.append(iurl)
                        if urls:
                            break
                    if urls:
                        break
            except Exception:
                pass

        if urls and cache_key:
            with self._lock:
                self._team_logo_url_cache[cache_key] = tuple(urls)
        return urls

    def _download_logo(self, team, logo_url='', alt_team='', team_name_hint='', ar_name_hint='', event=None, match_id=None):
        allowed = lambda: self._logo_request_live(event, match_id, team)
        try:
            if not allowed():
                return
            with self._lock:
                if self._get_cached_logo(team):
                    return
                if alt_team and self._get_cached_logo(alt_team):
                    self._logos[team] = self._logos[alt_team]
                    return
            candidates = []
            lowres_bein = []
            t_str = to_text(team)
            if logo_url and 'default-team-logo' not in logo_url.lower():
                if logo_url.startswith(ESPN_LOGO_HOST) and '/i/teamlogos/' in logo_url:
                    rel_img = logo_url[len(ESPN_LOGO_HOST) - 1:]
                    candidates.append(ESPN_LOGO_HOST + 'combiner/i?img=' + rel_img + '&w=140&h=140')
                    candidates.append(logo_url)
                elif logo_url.startswith(FOTMOB_LOGO_HOST):
                    if logo_url.endswith('_small.png'):
                        candidates.append(logo_url)
                        candidates.append(logo_url[:-10] + '.png')
                    elif logo_url.endswith('.png'):
                        candidates.append(logo_url[:-4] + '_small.png')
                        candidates.append(logo_url)
                    else:
                        candidates.append(logo_url)
                elif logo_url.startswith(SOFASCORE_LOGO_HOST):
                    candidates.append(logo_url)
                    candidates.append(SOFASCORE_API_LOGO_HOST + logo_url[len(SOFASCORE_LOGO_HOST):])
                else:
                    if logo_url.endswith('.64.png'):
                        candidates.append(logo_url[:-7] + '.png')
                    candidates.append(logo_url)
            for check_id in (t_str, to_text(alt_team)):
                if check_id.startswith('fotmob_'):
                    raw_id = check_id[7:]
                    if raw_id.isdigit():
                        for u in (FOTMOB_LOGO_HOST + raw_id + '_small.png', FOTMOB_LOGO_HOST + raw_id + '.png'):
                            if u not in candidates:
                                candidates.append(u)
                elif check_id.startswith('sofa_'):
                    raw_id = check_id[5:]
                    if raw_id.isdigit():
                        for u in (SOFASCORE_LOGO_HOST + raw_id + '/image', SOFASCORE_API_LOGO_HOST + raw_id + '/image'):
                            if u not in candidates:
                                candidates.append(u)

            for ku in _known_logo_urls(team_name_hint, ar_name_hint):
                if ku not in candidates:
                    candidates.append(ku)

            if not t_str.startswith(('espn_', 'fotmob_', 'sofa_', 'epg_')):
                for u in (MEDIA + t_str + '.png', MEDIA + t_str + '.64.png?ver=03-06-2025', MEDIA + t_str + '.64.png'):
                    if u not in candidates:
                        lowres_bein.append(u)
            candidates.extend(lowres_bein)

            best_prep = None
            for u in candidates:
                try:
                    if not allowed():
                        return
                    raw = _read(u, MAX_PNG, timeout=3.5)
                    prep = _decode_and_prepare_logo(raw)
                    if prep:
                        if best_prep is None or (prep[3] * prep[4] > best_prep[3] * best_prep[4]):
                            best_prep = prep
                        if prep[3] >= 96 and prep[4] >= 96:
                            break
                except Exception:
                    continue

            if (best_prep is None or best_prep[3] < 96 or best_prep[4] < 96) and (team_name_hint or ar_name_hint):
                ext_urls = self._lookup_external_team_logos(team_name_hint, ar_name_hint, allowed=allowed)
                for ext_url in ext_urls:
                    if ext_url in candidates:
                        continue
                    ext_cands = [ext_url]
                    if ext_url.startswith(ESPN_LOGO_HOST) and '/i/teamlogos/' in ext_url:
                        rel_img = ext_url[len(ESPN_LOGO_HOST) - 1:]
                        ext_cands.insert(0, ESPN_LOGO_HOST + 'combiner/i?img=' + rel_img + '&w=180&h=180')
                    for u in ext_cands:
                        try:
                            if not allowed():
                                return
                            raw = _read(u, MAX_PNG, timeout=3.5)
                            prep = _decode_and_prepare_logo(raw)
                            if prep:
                                if best_prep is None or (prep[3] * prep[4] > best_prep[3] * best_prep[4]):
                                    best_prep = prep
                                if prep[3] >= 96 and prep[4] >= 96:
                                    break
                        except Exception:
                            continue
                    if best_prep is not None and best_prep[3] >= 96 and best_prep[4] >= 96:
                        break

            if not allowed() or not best_prep:
                return

            cropped_rgba, cw, ch, _, _ = best_prep
            target_px = max(16, int(getattr(self, 'target_logo_size', 78)))
            data = _render_prepared_logo(cropped_rgba, cw, ch, target_px)
            if not data:
                return

            path = self._disk_logo_path(team)
            _write_atomic_file(path, data)
            with self._lock:
                self._logos[team] = path
                if alt_team:
                    self._logos[alt_team] = path
                self._bump_logo_rev()
            try:
                files = [os.path.join(LOGO_DIR, n) for n in os.listdir(LOGO_DIR) if n.endswith('.png')]
                for old in sorted(files, key=os.path.getmtime)[:-256]:
                    if old != path and not old.startswith(path[:-4]):
                        try:
                            os.unlink(old)
                        except OSError:
                            pass
            except OSError:
                pass
        finally:
            with self._lock:
                self._logo_inflight.discard(team)

    def _merge_provider_matches(self, merged, provider_matches):
        """Merge ESPN, SofaScore, or FotMob matches into the master match dictionary."""
        for em in provider_matches:
            matched_existing = False
            for m in merged.values():
                if abs(em['kickoff'] - m['kickoff']) <= 14400:
                    same_order = (teams_match(em['names'][0], m['names'][0]) and teams_match(em['names'][1], m['names'][1]))
                    rev_order = (not same_order) and (teams_match(em['names'][0], m['names'][1]) and teams_match(em['names'][1], m['names'][0]))
                    if same_order or rev_order:
                        i0, i1 = (0, 1) if same_order else (1, 0)
                        m['names'][0].update(em['names'][i0])
                        m['names'][1].update(em['names'][i1])
                        m.setdefault('logo_urls', {})[m['teams'][0]] = (
                            m.get('logo_urls', {}).get(m['teams'][0]) or em.get('logo_urls', {}).get(em['teams'][i0], '')
                        )
                        m.setdefault('logo_urls', {})[m['teams'][1]] = (
                            m.get('logo_urls', {}).get(m['teams'][1]) or em.get('logo_urls', {}).get(em['teams'][i1], '')
                        )
                        if not m.get('alt_teams'):
                            m['alt_teams'] = (em['teams'][i0], em['teams'][i1])
                        if em.get('state') == 'post' or (m.get('state') == 'pre' and em.get('state') == 'in'):
                            m['state'] = em['state']
                            m['_observed_at'] = em.get('_observed_at') or monotonic()
                            eg = em.get('goals', (0, 0))
                            m['goals'] = (eg[i0], eg[i1])
                            m['score'] = '%d - %d' % (m['goals'][1], m['goals'][0])
                            m['clock'] = em.get('clock', 'LIVE')
                            m['minute'] = em.get('minute')
                        elif m.get('state') == 'in' and em.get('state') == 'in':
                            if m.get('clock') in ('LIVE', '') and em.get('clock') not in ('LIVE', ''):
                                m['clock'] = em['clock']
                                m['minute'] = em.get('minute')
                            eg = em.get('goals', (0, 0))
                            if sum(eg) > sum(m.get('goals', (0, 0))):
                                m['goals'] = (eg[i0], eg[i1])
                                m['score'] = '%d - %d' % (m['goals'][1], m['goals'][0])
                        if 'en' in (em.get('lang_data') or {}) and 'en' not in (m.get('lang_data') or {}):
                            en_src = em['lang_data']['en']
                            m.setdefault('lang_data', {})['en'] = {
                                'home_name': en_src.get('home_name' if same_order else 'away_name', ''),
                                'away_name': en_src.get('away_name' if same_order else 'home_name', ''),
                            }
                        matched_existing = True
                        break
            if not matched_existing:
                merged[em['id']] = em

    def _refresh_sources(self):
        """Publish fast results, then merge late results before releasing the worker."""
        results = {}
        espn_snap = [None]
        sofa_live = [[]]
        wall = _wall_now()
        now_utc = datetime.datetime.utcfromtimestamp(wall)
        date_str = now_utc.strftime('%Y-%m-%d')
        qatar_date_str = datetime.datetime.utcfromtimestamp(wall + 3 * 3600).strftime('%Y-%m-%d')
        day_compact = now_utc.strftime('%Y%m%d')

        bein_dates = [date_str]
        if qatar_date_str != date_str:
            bein_dates.append(qatar_date_str)
        elif now_utc.hour < 4:
            prev_date = (now_utc - datetime.timedelta(days=1)).strftime('%Y-%m-%d')
            bein_dates.append(prev_date)

        def fetch_bein_lang(language, lang_code):
            combined = {}
            last_exc = None
            for d_str in bein_dates:
                for is_live_flag in ('1', '0'):
                    try:
                        query = {
                            'desiredLanguage': language, 'eventDate': d_str,
                            'eventTime': '00:00:00', 'timezone': 'UTC', 'teamIds': '', 'section': 'calendar',
                            'favouriteTeamIds': '', 'competitionIds': '', 'isLive': is_live_flag
                        }
                        raw = _read(ENDPOINT + '?' + urlencode(query), MAX_JSON, timeout=4)
                        parsed = parse_payload(json.loads(raw.decode('utf-8')), lang_code)
                        for k, v in parsed.items():
                            if k not in combined or (v.get('state') == 'post' or (combined[k].get('state') == 'pre' and v.get('state') == 'in')):
                                combined[k] = v
                        if combined and is_live_flag == '1' and d_str == bein_dates[0]:
                            results[lang_code] = dict(combined)
                            try:
                                self._publish_source_results(dict(results), espn_snap[0], sofa_live[0])
                            except Exception:
                                pass
                    except Exception as exc:
                        last_exc = exc
            if combined:
                results[lang_code] = combined
            elif last_exc is not None:
                results[lang_code + '_err'] = last_exc

        def fetch_espn():
            try:
                espn_snap[0] = self._scorer_feed.refresh_day(day_compact)
            except Exception:
                pass

        def fetch_sofascore():
            try:
                raw = _read(SOFASCORE_LIVE_ENDPOINT, MAX_JSON, timeout=4)
                sofa_live[0] = _parse_sofascore_events(json.loads(raw.decode('utf-8')))
            except Exception:
                pass

        threads = [
            start_thread(fetch_bein_lang, args=('en-mena', 'en'), name='UltraAudioLive-en'),
            start_thread(fetch_bein_lang, args=('ar-mena', 'ar'), name='UltraAudioLive-ar'),
            start_thread(fetch_espn, args=(), name='UltraAudioLive-espn'),
            start_thread(fetch_sofascore, args=(), name='UltraAudioLive-sofa'),
        ]
        deadline = monotonic() + 5.5
        for t in threads:
            rem = max(0.05, deadline - monotonic())
            t.join(rem)

        # This method runs only on the score worker, never on the GUI thread.
        # Keep _busy held until child requests finish; no overlapping refreshes.
        pending = [thread for thread in threads if thread.is_alive()]
        if pending and (results.get('en') or results.get('ar') or espn_snap[0] or sofa_live[0]):
            try:
                self._publish_source_results(dict(results), espn_snap[0], sofa_live[0])
            except Exception as error:
                self.note('partial score refresh: ' + to_text(error))
        for thread in pending:
            thread.join()
        self._publish_source_results(dict(results), espn_snap[0], sofa_live[0])

    def _publish_source_results(self, results, espn_snapshot, sofa_matches):
        # Every source assigns its completed snapshot once. Merging happens on
        # the coordinator so late results cannot be silently abandoned.
        espn_snap = [espn_snapshot]
        sofa_live = [sofa_matches]
        merged = {}
        for lang_code in ('en', 'ar'):
            parsed = results.get(lang_code) or {}
            for key, value in parsed.items():
                if key in merged and value['teams'] == merged[key]['teams']:
                    for index in (0, 1):
                        merged[key]['names'][index].update(value['names'][index])
                    merged[key]['lang_data'].update(value.get('lang_data') or {})
                    merged[key].setdefault('logo_urls', {}).update(value.get('logo_urls') or {})
                    if value.get('state') == 'post' or (value.get('state') == 'in' and merged[key].get('state') == 'pre'):
                        merged[key]['state'] = value['state']
                        merged[key]['goals'] = value['goals']
                        merged[key]['score'] = value['score']
                        merged[key]['clock'] = value['clock']
                        merged[key]['minute'] = value['minute']
                    if value.get('ht_goals') is not None:
                        merged[key]['ht_goals'] = value['ht_goals']
                else:
                    merged[key] = value

        espn_live = []
        if espn_snap[0]:
            cached_parsed = espn_snap[0].get('_parsed_matches') if isinstance(espn_snap[0], dict) else None
            if cached_parsed is None:
                espn_live = extract_live_matches(espn_snap[0], team_name, aliases_fn=team_aliases)
                if isinstance(espn_snap[0], dict):
                    espn_snap[0]['_parsed_matches'] = espn_live
            else:
                espn_live = [dict(m, names=[set(m['names'][0]), set(m['names'][1])],
                                  logo_urls=dict(m.get('logo_urls') or {}),
                                  lang_data=dict(m.get('lang_data') or {})) for m in cached_parsed]
            self._merge_provider_matches(merged, espn_live)

        if sofa_live[0]:
            self._merge_provider_matches(merged, sofa_live[0])

        if not merged and not espn_live and not sofa_live[0] and ('en_err' in results or 'ar_err' in results):
            raise results.get('en_err') or results.get('ar_err')

        match_list = list(merged.values())
        for observed in match_list + espn_live + sofa_live[0]:
            observed.setdefault('_observed_at', monotonic())

        pri_match = None
        page_matches = []
        with self._lock:
            for key, val in merged.items():
                if val.get('ht_goals') is not None:
                    self._ht_cache[key] = val['ht_goals']
                elif key in self._ht_cache:
                    val['ht_goals'] = self._ht_cache[key]
            prev_by_id = dict((m['id'], m) for m in self._matches)
            for pm in prev_by_id.values():
                if not any(
                    (pm['id'] == nm['id']) or
                    (abs(pm['kickoff'] - nm['kickoff']) <= 14400 and
                     ((teams_match(pm['names'][0], nm['names'][0]) and teams_match(pm['names'][1], nm['names'][1])) or
                      (teams_match(pm['names'][0], nm['names'][1]) and teams_match(pm['names'][1], nm['names'][0]))))
                    for nm in match_list
                ):
                    if -3600 <= _wall_now() - pm.get('kickoff', 0) <= 4 * 3600:
                        match_list.append(pm)
            self._matches = match_list
            self._espn_matches = []
            self._updated = monotonic()
            self._error = ''
            self._bump_rev()
            if self._wanted:
                pri_match = match_event(self._wanted, self._matches)
            for ev in self._wanted_page:
                if ev is not self._wanted:
                    m = match_event(ev, self._matches)
                    if m is not None:
                        page_matches.append((m, ev))
        self._ready_event.set()
        self.note('refreshed %d fixtures' % len(match_list))

        if pri_match is not None:
            self._spawn_logo_downloads(pri_match, priority=True, event=self._wanted)
        for m, ev in page_matches:
            self._spawn_logo_downloads(m, priority=False, event=ev)

    def _discover_fotmob_match(self, event):
        """Query FotMob suggest API & SofaScore for an uncovered EPG match to get live score and team logos."""
        pairs = _event_pairs(event)
        if not pairs:
            return None
        en_title = event[4] if len(event) > 4 and event[4] else (event[0] if event else '')
        ar_title = event[5] if len(event) > 5 and event[5] else (event[0] if event else '')
        en_pair = extract_fixture_pair(en_title) or pairs[0]
        ar_pair = extract_fixture_pair(ar_title) or pairs[0]
        q_a = english_search_name(en_pair[0])
        q_b = english_search_name(en_pair[1])
        a_aliases = team_aliases(en_pair[0]) | team_aliases(ar_pair[0])
        b_aliases = team_aliases(en_pair[1]) | team_aliases(ar_pair[1])
        wall = _wall_now()
        start, end = event[1], event[2]

        queries = []
        if q_a and q_b:
            queries.append(q_a + ' ' + q_b)
        if q_a and q_a not in queries:
            queries.append(q_a)
        if q_b and q_b not in queries:
            queries.append(q_b)

        found_match = None
        team_ids = [None, None]

        for q in queries[:3]:
            try:
                u = FOTMOB_SUGGEST_ENDPOINT + '?term=' + quote(q.encode('utf-8'), safe=str('')) + '&lang=en'
                raw = _read(u, MAX_JSON, timeout=3.5)
                data = json.loads(raw.decode('utf-8'))
                for opt in _extract_fotmob_options(data):
                    p = opt.get('payload') or {}
                    if p.get('homeName') and p.get('awayName'):
                        h_name = to_text(p.get('homeName')).strip()
                        a_name = to_text(p.get('awayName')).strip()
                        h_al, a_al = team_aliases(h_name), team_aliases(a_name)
                        m_epoch = _parse_iso_epoch(to_text(p.get('matchDate') or ''))
                        if m_epoch is not None and abs(m_epoch - start) > 24 * 3600:
                            continue
                        same = teams_match(h_al, a_aliases) and (teams_match(a_al, b_aliases) or a_name.upper() in ('TBC', 'TBD'))
                        rev = (not same) and teams_match(h_al, b_aliases) and (teams_match(a_al, a_aliases) or a_name.upper() in ('TBC', 'TBD'))
                        if not same and not rev and h_name.upper() in ('TBC', 'TBD'):
                            if teams_match(a_al, b_aliases):
                                same = True
                            elif teams_match(a_al, a_aliases):
                                rev = True
                        if same or rev:
                            found_match = (p, same)
                    else:
                        tid = to_text(p.get('id') or '').strip()
                        raw_tname = to_text(p.get('name') or opt.get('text') or '').strip()
                        tname = raw_tname.split('|')[0].strip()
                        if tid.isdigit() and tname:
                            t_al = team_aliases(tname)
                            if team_ids[0] is None and teams_match(t_al, a_aliases):
                                team_ids[0] = tid
                            elif team_ids[1] is None and teams_match(t_al, b_aliases):
                                team_ids[1] = tid
            except Exception:
                continue

        if found_match:
            p, same = found_match
            h_name = to_text(p.get('homeName')).strip()
            a_name = to_text(p.get('awayName')).strip()
            if h_name.upper() in ('TBC', 'TBD'):
                h_name = en_pair[0] if same else en_pair[1]
            if a_name.upper() in ('TBC', 'TBD'):
                a_name = en_pair[1] if same else en_pair[0]
            ar_h, ar_a = (ar_pair[0], ar_pair[1]) if same else (ar_pair[1], ar_pair[0])
            t0_id = team_ids[0 if same else 1]
            t1_id = team_ids[1 if same else 0]
            home_key = ('fotmob_' + t0_id) if t0_id else ('fotmob_' + _slug(h_name)[:28])
            away_key = ('fotmob_' + t1_id) if t1_id else ('fotmob_' + _slug(a_name)[:28])
            logo_urls = {}
            if t0_id:
                logo_urls[home_key] = FOTMOB_LOGO_HOST + t0_id + '.png'
            if t1_id:
                logo_urls[away_key] = FOTMOB_LOGO_HOST + t1_id + '.png'
            h_sc = p.get('homeScore')
            a_sc = p.get('awayScore')
            home_g = int(_ascii_digits(h_sc)) if _valid_score_int(h_sc) else 0
            away_g = int(_ascii_digits(a_sc)) if _valid_score_int(a_sc) else 0
            m_epoch = _parse_iso_epoch(to_text(p.get('matchDate') or '')) or start
            ident = 'fotmob_' + to_text(p.get('id') or int(start))
            # Search suggestions can be replays, finished fixtures or previews.
            # Keep their crests/identity, but only a scoreboard may confirm live state.
            return {
                'id': ident,
                'match_id': ident,
                'state': 'pre',
                'teams': (home_key, away_key),
                'logo_urls': logo_urls,
                'names': [a_aliases | team_aliases(h_name) if same else b_aliases | team_aliases(h_name),
                          b_aliases | team_aliases(a_name) if same else a_aliases | team_aliases(a_name)],
                'goals': (home_g, away_g),
                'score': '%d - %d' % (away_g, home_g),
                'clock': '',
                'minute': None,
                'kickoff': m_epoch,
                'match_date': time.strftime('%Y-%m-%d', time.gmtime(m_epoch)),
                'lang_data': {
                    'en': {
                        'home_name': h_name,
                        'away_name': a_name,
                    },
                    'ar': {
                        'home_name': ar_h,
                        'away_name': ar_a,
                    },
                },
            }

        home_key = ('fotmob_' + team_ids[0]) if team_ids[0] else ('epg_' + hashlib.sha256(to_text(en_pair[0]).encode('utf-8')).hexdigest()[:12])
        away_key = ('fotmob_' + team_ids[1]) if team_ids[1] else ('epg_' + hashlib.sha256(to_text(en_pair[1]).encode('utf-8')).hexdigest()[:12])
        logo_urls = {}
        if team_ids[0]:
            logo_urls[home_key] = FOTMOB_LOGO_HOST + team_ids[0] + '.png'
        else:
            k0 = _known_logo_urls(en_pair[0], ar_pair[0])
            if k0:
                logo_urls[home_key] = k0[0]
        if team_ids[1]:
            logo_urls[away_key] = FOTMOB_LOGO_HOST + team_ids[1] + '.png'
        else:
            k1 = _known_logo_urls(en_pair[1], ar_pair[1])
            if k1:
                logo_urls[away_key] = k1[0]
        ident = 'epg_' + hashlib.sha256(to_text(en_title or ar_title).encode('utf-8')).hexdigest()[:12]
        return {
            'id': ident,
            'match_id': ident,
            'state': 'pre',
            'teams': (home_key, away_key),
            'logo_urls': logo_urls,
            'names': [a_aliases, b_aliases],
            'goals': (0, 0),
            'score': '0 - 0',
            'clock': 'LIVE',
            'minute': None,
            'kickoff': start,
            'match_date': time.strftime('%Y-%m-%d', time.gmtime(start)),
            'lang_data': {
                'en': {
                    'home_name': en_pair[0],
                    'away_name': en_pair[1],
                },
                'ar': {
                    'home_name': ar_pair[0],
                    'away_name': ar_pair[1],
                },
            },
        }

    def _process_current(self, event, priority=True):
        if not event or not self.is_candidate(event):
            return
        with self._lock:
            current = match_event(event, self._matches)
        if current is None or current.get('state') == 'pre':
            ev_key = to_text(event[0])
            now = monotonic()
            with self._lock:
                last_disc = self._discovery_attempts.get(ev_key, -POLL)
                do_disc = (now - last_disc >= 15)
                if do_disc:
                    self._discovery_attempts[ev_key] = now
            if do_disc:
                hint_text = ' '.join(_event_titles(event))
                leagues = infer_espn_leagues(hint_text)
                if leagues:
                    day_compact = datetime.datetime.utcfromtimestamp(_wall_now()).strftime('%Y%m%d')
                    snap = self._scorer_feed.refresh_leagues(leagues, day_compact)
                    if snap:
                        extra_espn = extract_live_matches(snap, team_name, aliases_fn=team_aliases)
                        if extra_espn:
                            for observed in extra_espn:
                                observed.setdefault('_observed_at', monotonic())
                            with self._lock:
                                by_id = dict((m['id'], m) for m in self._matches)
                                self._merge_provider_matches(by_id, extra_espn)
                                self._matches = list(by_id.values())
                                self._bump_rev()
                                current = match_event(event, self._matches)
                if current is None or current.get('state') == 'pre':
                    discovered = self._discover_fotmob_match(event)
                    if discovered:
                        discovered['_observed_at'] = monotonic()
                        with self._lock:
                            by_id = dict((m['id'], m) for m in self._matches)
                            self._merge_provider_matches(by_id, [discovered])
                            self._matches = list(by_id.values())
                            self._bump_rev()
                            current = match_event(event, self._matches)
        if not current:
            return
        self._spawn_logo_downloads(current, priority=priority, event=event)


    def _worker(self, event, refresh):
        try:
            yield_to_ui()
            req = getattr(self, '_pending_page_req', None)
            if req is not None:
                self._pending_page_req = None
                cur_ev, unused_page = self._ensure_page_bg(req[0], req[1])
                if cur_ev is not None:
                    event = cur_ev
            if refresh:
                yield_to_ui()
                self._refresh_sources()
            while True:
                req = getattr(self, '_pending_page_req', None)
                if req is not None:
                    self._pending_page_req = None
                    cur_ev, unused_page = self._ensure_page_bg(req[0], req[1])
                    if cur_ev is not None:
                        event = cur_ev
                processed = set()
                target = event
                while target is not None:
                    yield_to_ui()
                    key = to_text(target[0]) if target else ''
                    if not key or key in processed:
                        break
                    processed.add(key)
                    self._process_current(target, priority=True)
                    with self._lock:
                        wanted = self._wanted
                    if wanted and to_text(wanted[0]) not in processed:
                        target = wanted
                    else:
                        break
                if getattr(self, '_pending_page_req', None) is None:
                    break
        except Exception as exc:
            with self._lock:
                self._error = '%s: %s' % (type(exc).__name__, to_text(exc)[:180])
            self._ready_event.set()
            self.note('source/image unavailable: ' + self._error)
        finally:
            with self._lock:
                self._busy = False

    def _live_match(self, event):
        """A live badge/card needs a current provider state, not an EPG hint."""
        if not event or len(event) < 3:
            return None
        wall_now = _wall_now()
        if not event[1] <= wall_now < event[2]:
            return None
        cache_key = (event[0], event[1], event[2], self._rev, int(wall_now // 15))
        cached = self._live_cache.get(cache_key, False)
        if cached is not False:
            return cached
        if excluded_card_event(event) or _is_replay_event(event):
            self._live_cache[cache_key] = None
            return None
        now = monotonic()
        matches_snap = list(self._matches) + list(self._espn_matches)
        fresh_in = []
        fresh_post = []
        for match in matches_snap:
            seen = match.get('_observed_at')
            if seen is not None and 0 <= now - seen <= MAX_AGE:
                st = match.get('state')
                if st == 'in':
                    fresh_in.append(match)
                elif st == 'post':
                    fresh_post.append(match)
        if fresh_post and match_event(event, fresh_post, now=wall_now):
            res = None
        else:
            res = match_event(event, fresh_in, now=wall_now) if fresh_in else None
        live_cache = self._live_cache
        if len(live_cache) > 512:
            live_cache = {}
            self._live_cache = live_cache
        live_cache[cache_key] = res
        return res

    def is_live_cached(self, event):
        """Zero-lock, O(1) cache check for list row building so scrolling never blocks on regex/alias matching."""
        if not event or len(event) < 3:
            return False
        wall_now = _wall_now()
        if not event[1] <= wall_now < event[2]:
            return False
        cache_key = (event[0], event[1], event[2], self._rev, int(wall_now // 15))
        cached = self._live_cache.get(cache_key, False)
        if cached is not False:
            return cached is not None
        if self._updated is None and len(event) > 3 and event[3] is True:
            return not excluded_card_event(event)
        return False

    def is_live(self, event):
        """No IO: check live match snapshot, or official EPG live flag while initial scoreboard fetch is in flight."""
        if self._live_match(event) is not None:
            return True
        if self._updated is None and event and len(event) > 3 and event[3] is True:
            wall_now = _wall_now()
            if event[1] <= wall_now < event[2] and self.is_candidate(event):
                return True
        return False

    def _resolve_epg_arabic_names(self, event, match, en_home, en_away):
        """When a match came from an English-only feed (e.g. ESPN/SofaScore), extract Arabic team names from EPG."""
        ar_title = event[5] if len(event) > 5 and event[5] else (event[0] if event else '')
        en_title = event[4] if len(event) > 4 and event[4] else ''
        ar_pair = extract_fixture_pair(ar_title)
        if not ar_pair:
            return en_home, en_away
        en_pair = extract_fixture_pair(en_title) if en_title else None
        a0_aliases = team_aliases(ar_pair[0])
        if teams_match(a0_aliases, match['names'][0]):
            return ar_pair[0], ar_pair[1]
        if teams_match(a0_aliases, match['names'][1]):
            return ar_pair[1], ar_pair[0]
        if en_pair:
            e0_aliases = team_aliases(en_pair[0])
            if teams_match(e0_aliases, match['names'][1]):
                return ar_pair[1], ar_pair[0]
        return ar_pair[0], ar_pair[1]

    def view(self, event):
        if not event or len(event) < 3:
            return None
        code_lang = 'ar' if interface_language() == 'ar' else 'en'
        v_key = (event[0], event[1], event[2], self._rev, getattr(self, '_logo_rev', 0), int(_wall_now() // 15), code_lang)
        cached_v = self._view_cache.get(v_key, False)
        if cached_v is not False:
            return cached_v
        match = self._live_match(event)
        if match is None:
            self._view_cache[v_key] = None
            return None
        result = None
        to_download = None
        if True:
            if match is not None:
                home_id, away_id = match['teams']
                alt_teams = match.get('alt_teams') or ()
                ld = match.get('lang_data') or {}
                ar = ld.get('ar') or {}
                en = ld.get('en') or {}
                code = 'ar' if interface_language() == 'ar' else 'en'
                primary, fallback = (ar, en) if code == 'ar' else (en, ar)
                home_name = primary.get('home_name') or fallback.get('home_name') or ''
                away_name = primary.get('away_name') or fallback.get('away_name') or ''
                if code == 'ar' and not ar.get('home_name'):
                    home_name, away_name = self._resolve_epg_arabic_names(event, match, home_name, away_name)

                real_home_logo = (
                    self._get_cached_logo(home_id)
                    or (self._get_cached_logo(alt_teams[0]) if len(alt_teams) > 0 and alt_teams[0] else None)
                )
                real_away_logo = (
                    self._get_cached_logo(away_id)
                    or (self._get_cached_logo(alt_teams[1]) if len(alt_teams) > 1 and alt_teams[1] else None)
                )
                if not real_home_logo or not real_away_logo:
                    to_download = match

                home_logo = real_home_logo
                away_logo = real_away_logo

                home_g, away_g = match.get('goals', (0, 0))
                if code == 'ar':
                    paths = (away_logo, home_logo)
                    left_name, right_name = away_name, home_name
                    score_text = '%d - %d' % (away_g, home_g)
                else:
                    paths = (home_logo, away_logo)
                    left_name, right_name = home_name, away_name
                    score_text = '%d - %d' % (home_g, away_g)

                extra = {
                    'ui_language': code,
                    'left_name': left_name,
                    'right_name': right_name,
                }
                result = (match['id'], score_text, match['clock'], paths, extra)
                reason = 'matched ' + match['id']
            else:
                reason = 'no unique live match for guide: ' + to_text(event[0] if event else '')[:180]
        if to_download is not None:
            if is_main_thread():
                self.ensure_page(event, (event,))
            else:
                self._spawn_logo_downloads(to_download, priority=True, event=event)
        view_cache = self._view_cache
        if len(view_cache) > 256:
            view_cache = {}
            self._view_cache = view_cache
        view_cache[v_key] = result
        self.note(reason)
        return result


SCORES = Scores()
