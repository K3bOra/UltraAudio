# -*- coding: utf-8 -*-
"""Experimental beIN score reader. No audio/Enigma imports; no third-party plugin code.

The UI only consumes snapshots. All networking and PNG writes run on one daemon
worker, on demand while a current guide event is selected. Internal provider
endpoints have no availability guarantee. Never infer a score from missing data.
"""
from __future__ import unicode_literals
import calendar
import datetime
import hashlib
try:
    from html.parser import HTMLParser
except ImportError:
    from HTMLParser import HTMLParser
import json
import os
import re
import ssl
import struct
import tempfile
import threading
import time
import unicodedata
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote

from .compat import Request, urlopen, urlencode, to_text, monotonic, start_thread
from .i18n import lang as interface_language

ENDPOINT = 'https://prod-cmseventmanagement.beinsports.com/score/getScorePageList'
MEDIA = 'https://prod-media.beinsports.com/image/'
WEB_HOSTS = ('https://www.beinsports.com/', 'https://prod.beinsports.com/')
POLL = 60
MAX_AGE = 120
MAX_JSON = 4 * 1024 * 1024
MAX_HTML = 2 * 1024 * 1024
MAX_PNG = 256 * 1024
CA_BUNDLE = os.path.join(os.path.dirname(__file__), 'assets', 'certs', 'cacert.pem')
_BAD_PROGRAM = re.compile(r'highlights?|replay|repeat|preview|classic|ملخص|اعاد[ةه]|تسجيل|استوديو|تحليل', re.I)
_SPLIT = re.compile(r'\s+(?:vs?\.?|versus|ضد)\s+|\s*[×]\s*', re.I)
_DIGITS = dict((ord(a), ord(b)) for a, b in zip('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789'))

_AR_COMP_SLUGS = {
    'دوري-أبطال-آسيا-الثاني': ('كأس-الاتحاد-الآسيوي-للأندية', 'دوري-أبطال-آسيا-الثاني'),
    'دوري-أبطال-آسيا-2': ('كأس-الاتحاد-الآسيوي-للأندية', 'دوري-أبطال-آسيا-2'),
    'الدوري-الإسباني-لا-ليجا': ('la-liga', 'الدوري-الإسباني-لا-ليجا'),
    'الدوري-الإسباني': ('la-liga', 'الدوري-الإسباني'),
}

_STAGE_WORDS = (
    'دور المجموعات', 'ربع النهائي', 'نصف النهائي', 'ثمن النهائي', 'النهائي',
    'دور الـ 16', 'دور الـ 32', 'الدور الأول', 'الدور التمهيدي', 'الملحق',
    'Group Stage', 'Quarter-finals', 'Semi-finals', 'Round of 16', 'Round of 32', 'Final',
)


def _ascii_digits(value):
    return to_text(value or '').translate(_DIGITS)


def normalized(value):
    value = unicodedata.normalize('NFKC', to_text(value or '')).lower()
    value = re.sub('[\u064b-\u065f\u0670\u0640]', '', value)
    for a, b in [('أ', 'ا'), ('إ', 'ا'), ('آ', 'ا'), ('ى', 'ي')]:
        value = value.replace(a, b)
    value = ''.join(c for c in unicodedata.normalize('NFKD', value)
                    if not unicodedata.combining(c))
    return ' '.join(re.sub(r'[^\w]+', ' ', value, flags=re.UNICODE).split())


def team_name(value):
    """Discard EPG country tags/club initials, retaining identity qualifiers.

    Never remove women, reserve, youth ages or meaningful words such as City,
    United, Rovers. Both resulting full names must still match uniquely.
    """
    value = re.sub(r'\([A-Z]{3}\)', ' ', to_text(value or ''))
    value = normalized(value)
    words = value.split()
    initials = set(('fc', 'sc', 'cf'))
    while len(words) > 1 and words[0] in initials:
        words.pop(0)
    while len(words) > 1 and words[-1] in initials:
        words.pop()
    return ' '.join(words)


def _slug(value):
    s = unicodedata.normalize('NFKC', to_text(value or '')).strip().lower()
    s = re.sub(r'[^a-z0-9\u0600-\u06ff\s-]', '', s)
    return re.sub(r'[\s-]+', '-', s).strip('-')


def _valid_score_int(v):
    return not isinstance(v, bool) and isinstance(v, (int, float)) and int(v) == v and 0 <= int(v) <= 99


def _extract_ht_from_agg(info, raw):
    for container in (info, raw):
        if not isinstance(container, dict):
            continue
        agg = container.get('aggregate_score')
        if isinstance(agg, dict):
            ht = agg.get('ht')
            if isinstance(ht, dict):
                h, a = ht.get('home'), ht.get('away')
                if _valid_score_int(h) and _valid_score_int(a):
                    return (int(h), int(a))
    return None


def _derive_stage(round_str, group_str, lang_code):
    rnd = to_text(round_str or '').strip()
    grp = to_text(group_str or '').strip()
    generic = ('', '1', 'Round 1', 'الدور الأول', 'الدور الاول')
    if rnd and rnd not in generic:
        return rnd
    if grp or rnd in ('Round 1', 'الدور الأول', 'الدور الاول'):
        return 'دور المجموعات' if lang_code == 'ar' else 'Group Stage'
    return ''


def parse_payload(data, lang_code='en'):
    """Validate the provider contract; unfinished/suspended/missing fields hide."""
    if not isinstance(data, dict):
        raise ValueError('Invalid score response')
    out = {}
    for group in data.values():
        if not isinstance(group, dict):
            continue
        for raw in group.values():
            if not isinstance(raw, dict) or raw.get('event_status') != 'Playing':
                continue
            info = raw.get('match_info') or {}
            if not isinstance(info, dict):
                continue
            status = to_text(info.get('match_status') or raw.get('match_status') or '').upper()
            shown = to_text(info.get('combine_status_time') or raw.get('combine_status_time') or '').strip()
            minute_val = None
            # Only a documented-looking numeric minute or explicit half-time.
            if status == 'HT' or shown.upper() == 'HT':
                clock = 'HT'
            elif not status and re.match(r'^\d{1,3}(?:\s*\+\s*\d{1,2})?[\u2032\x27]?$', shown):
                minute_val = int(re.match(r'\d+', shown).group())
                if not 0 < minute_val <= 130:
                    continue
                clock = shown.rstrip("'\u2032") + "'"
            elif not status:
                live_t = info.get('live_time') if info.get('live_time') is not None else raw.get('live_time')
                inj_t = info.get('injury_time') if info.get('injury_time') is not None else raw.get('injury_time')
                if not isinstance(live_t, bool) and isinstance(live_t, int) and 0 < live_t <= 130:
                    minute_val = live_t
                    if not isinstance(inj_t, bool) and isinstance(inj_t, int) and 0 < inj_t <= 30:
                        clock = "%d+%d'" % (live_t, inj_t)
                    else:
                        clock = "%d'" % live_t
                else:
                    continue
            else:
                continue
            stamp = to_text(info.get('match_timestamp') or raw.get('match_timestamp') or '')
            try:
                kickoff = calendar.timegm(datetime.datetime.strptime(stamp, '%Y-%m-%dT%H:%M:%SZ').timetuple())
            except (ValueError, TypeError):
                continue
            ident = to_text(raw.get('match_opta_id') or '')
            home, away = to_text(raw.get('home_team_id') or ''), to_text(raw.get('away_team_id') or '')
            if not all(re.match(r'^[a-z0-9]{5,64}$', s) for s in (ident, home, away)) or home == away:
                continue
            scores = [raw.get('home_team_goals'), raw.get('away_team_goals')]
            if not all(_valid_score_int(v) for v in scores):
                continue
            home_goals, away_goals = int(scores[0]), int(scores[1])
            aliases = []
            for side in ('home', 'away'):
                name = team_name(raw.get(side + '_team_name'))
                if not name:
                    break
                aliases.append(set([name]))
            if len(aliases) != 2:
                continue
            # The provider's display name can be abbreviated ('Tampines'), while
            # its own complete fixture title says 'Tampines Rovers'. Both are
            # provider-declared aliases, not a guessed substring match.
            full_pair = _SPLIT.split(to_text(raw.get('match_name') or ''))
            if len(full_pair) == 2:
                for index, value in enumerate(full_pair):
                    alias = team_name(value)
                    if alias:
                        aliases[index].add(alias)
            home_disp = to_text(raw.get('home_team_name') or '').strip()
            away_disp = to_text(raw.get('away_team_name') or '').strip()
            if len(full_pair) == 2:
                if not home_disp:
                    home_disp = full_pair[0].strip()
                if not away_disp:
                    away_disp = full_pair[1].strip()
            comp_disp = to_text(raw.get('competition_name') or '').strip()
            round_disp = to_text(info.get('round') or raw.get('round') or '').strip()
            group_disp = to_text(info.get('group') or raw.get('group') or '').strip()
            stage_disp = _derive_stage(round_disp, group_disp, lang_code)
            ht_goals = _extract_ht_from_agg(info, raw)
            if ht_goals is None and clock == 'HT':
                ht_goals = (home_goals, away_goals)
            match_date = to_text(info.get('match_date') or raw.get('match_date') or '')[:10] or stamp[:10]
            out[ident] = {
                'id': ident,
                'match_id': to_text(raw.get('match_id') or ''),
                'teams': (home, away),
                'names': aliases,
                'goals': (home_goals, away_goals),
                'score': '%d - %d' % (away_goals, home_goals),
                'clock': clock,
                'minute': minute_val,
                'competition': comp_disp,
                'kickoff': kickoff,
                'match_date': match_date,
                'ht_goals': ht_goals,
                'lang_data': {
                    lang_code: {
                        'home_name': home_disp,
                        'away_name': away_disp,
                        'competition': comp_disp,
                        'round': round_disp,
                        'group': group_disp,
                        'stage': stage_disp,
                    }
                },
            }
    return out


class _TextExtractor(HTMLParser):
    def __init__(self):
        try:
            HTMLParser.__init__(self, convert_charrefs=True)
        except TypeError:
            HTMLParser.__init__(self)
        self._skip = 0
        self.lines = []
        self._buf = []
        self.next_data = None
        self._in_next = False
        self._next_buf = []
        self.ar_link = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'script':
            if a.get('id') == '__NEXT_DATA__':
                self._in_next = True
                self._next_buf = []
            else:
                self._skip += 1
        elif tag in ('style', 'noscript', 'svg'):
            self._skip += 1
        elif tag == 'link' and a.get('href') and '/ar-mena/' in a.get('href', ''):
            href = a.get('href', '')
            if href.startswith('https://www.beinsports.com/ar-mena/'):
                self.ar_link = href
        elif tag in ('div', 'p', 'li', 'tr', 'td', 'th', 'h1', 'h2', 'h3', 'h4', 'span', 'br', 'section', 'article'):
            self._flush()

    def handle_endtag(self, tag):
        if tag == 'script':
            if self._in_next:
                self._in_next = False
                self.next_data = ''.join(self._next_buf).strip()
            elif self._skip > 0:
                self._skip -= 1
        elif tag in ('style', 'noscript', 'svg') and self._skip > 0:
            self._skip -= 1
        elif tag in ('div', 'p', 'li', 'tr', 'td', 'th', 'h1', 'h2', 'h3', 'h4', 'span', 'br', 'section', 'article'):
            self._flush()

    def handle_data(self, data):
        if self._in_next:
            self._next_buf.append(data)
        elif not self._skip:
            self._buf.append(data)

    def _flush(self):
        if self._buf:
            text = re.sub(r'\s+', ' ', ''.join(self._buf)).strip()
            self._buf = []
            if text:
                self.lines.append(text)


def _team_side(team_text, match):
    """Map a team name from commentary or banner to 0 (home) or 1 (away)."""
    norm = team_name(team_text)
    if not norm:
        return None
    h_set, a_set = match['names']
    if norm in h_set:
        return 0
    if norm in a_set:
        return 1
    return None


def _parse_match_html(html_text, match, locale='ar'):
    """Extract HT score, stage, yellow/red cards, and goal scorers from a beIN match page."""
    parser = _TextExtractor()
    parser.feed(html_text)
    parser._flush()
    lines = parser.lines

    ht_goals = None
    stage = ''
    cards = [[0, 0], [0, 0]]  # [[home_yc, home_rc], [away_yc, away_rc]]
    goals_by_side = [[], []]  # [[(minute_str, player_name), ...], [...]]

    # 1. Check stage keywords near top of page (before Overview / ملخص)
    cutoff = len(lines)
    for idx, line in enumerate(lines[:120]):
        if line in ('ملخص', 'Overview', 'احصائيات', 'Statistics', 'تعليق', 'Play by Play'):
            cutoff = idx
            break
    for line in lines[:cutoff]:
        m_ht = re.search(r'\(\s*HT\s*(\d{1,2})\s*[-:]\s*(\d{1,2})\s*\)', _ascii_digits(line), re.I)
        if m_ht:
            # On ar-mena banner, left is away and right is home; verify with commentary below if available
            ht_goals = ((int(m_ht.group(2)), int(m_ht.group(1))) if locale == 'ar'
                        else (int(m_ht.group(1)), int(m_ht.group(2))))
        for sw in _STAGE_WORDS:
            if sw.lower() in line.lower() and len(line) <= 40:
                stage = line
                break

    # 2. Scan commentary for Half-time score, Goals, and Yellow/Red Cards
    card_events = [set(), set()]
    red_events = [set(), set()]
    last_min = ''
    min_pat = re.compile(r"^(\d{1,3}(?:'|\u2032)?(?:\s*\+\s*\d{1,2}(?:'|\u2032)?)?)$")

    for i, line in enumerate(lines):
        asc = _ascii_digits(line).strip()
        m_min = min_pat.match(asc)
        if m_min:
            raw_m = m_min.group(1).replace('\u2032', "'")
            if not raw_m.endswith("'"):
                raw_m = re.sub(r'^(\d+)', r"\1'", raw_m)
            last_min = raw_m
            continue

        # Half-time commentary line:
        # "الشوط الأول انتهى, أوروغواي 0, إسبانيا 1." or "First Half ends, Croatia 1, Ghana 0."
        m_ht_comm = re.search(
            r'(?:الشوط الأول انتهى|First Half ends)\s*[,،]\s*([^,،]+?)\s+(\d{1,2})\s*[,،]\s*([^.]+?)\s+(\d{1,2})',
            asc, re.I
        )
        if m_ht_comm:
            s1 = _team_side(m_ht_comm.group(1), match)
            s2 = _team_side(m_ht_comm.group(3), match)
            v1, v2 = int(m_ht_comm.group(2)), int(m_ht_comm.group(4))
            if s1 == 0 and s2 == 1:
                ht_goals = (v1, v2)
            elif s1 == 1 and s2 == 0:
                ht_goals = (v2, v1)

        # Goal commentary line:
        # Arabic: "هدف! أوروغواي 0, إسبانيا 1. أليكس بائينا (إسبانيا) تسديدة..."
        # English: "Goal! Croatia 2, Ghana 1. Nikola Vlasic (Croatia) header..."
        if asc.startswith('هدف!') or asc.lower().startswith('goal!'):
            m_goal = re.search(r'(?:هدف!|Goal!)\s*[^.]+\.\s*([^\n(]+?)\s*\(([^)]+)\)', asc, re.I)
            if m_goal and last_min:
                player = m_goal.group(1).strip()
                side = _team_side(m_goal.group(2).strip(), match)
                if side in (0, 1) and player:
                    goals_by_side[side].append((last_min, player))
            else:
                m_og = re.search(r'(?:هدف في مرماه بواسطة|Own Goal by)\s+([^\n,،.]+?)\s*[,،]\s*([^\n.]+)', asc, re.I)
                if m_og and last_min:
                    player = m_og.group(1).strip()
                    og_side = _team_side(m_og.group(2).strip(), match)
                    if og_side in (0, 1) and player:
                        # Own goal counts for the opposing team
                        beneficiary = 1 - og_side
                        goals_by_side[beneficiary].append((last_min, player))

        # Yellow / Red card commentary line:
        # Arabic: "نيكولاس دي لا كروز (أوروغواي) تحصّل على بطاقة صفراء"
        # English: "Ivan Perisic (Croatia) is shown the yellow card"
        m_card_ar = re.search(r'([^\n(]+?)\s*\(([^)]+)\)\s*تحصّل على بطاقة\s+(صفراء|حمراء)', asc)
        if m_card_ar:
            player = m_card_ar.group(1).strip()
            side = _team_side(m_card_ar.group(2).strip(), match)
            kind = m_card_ar.group(3)
            if side in (0, 1):
                if kind == 'حمراء':
                    red_events[side].add((last_min, player))
                else:
                    card_events[side].add((last_min, player))
        m_card_en = re.search(r'([^\n(]+?)\s*\(([^)]+)\)\s*is shown the\s+(yellow|red)\s+card', asc, re.I)
        if m_card_en:
            player = m_card_en.group(1).strip()
            side = _team_side(m_card_en.group(2).strip(), match)
            kind = m_card_en.group(3).lower()
            if side in (0, 1):
                if kind == 'red':
                    red_events[side].add((last_min, player))
                else:
                    card_events[side].add((last_min, player))

    for side in (0, 1):
        cards[side][0] = len(card_events[side])
        cards[side][1] = len(red_events[side])

    # 4. Fallback to banner scorer lines (before Overview / ملخص) if commentary goals were not present
    if not goals_by_side[0] and not goals_by_side[1]:
        banner_scorers = []
        scorer_pat = re.compile(r"^([^\d\n]{2,40}?)\s+(\d{1,3}'(?:\s*\+\s*\d{1,2})?(?:\s*,\s*\d{1,3}'(?:\s*\+\s*\d{1,2})?)*)$")
        for line in lines[:cutoff]:
            asc = _ascii_digits(line).strip()
            m_sc = scorer_pat.match(asc)
            if m_sc:
                banner_scorers.append((m_sc.group(2).strip(), m_sc.group(1).strip()))
        if banner_scorers:
            h_goals, a_goals = match['goals']
            if h_goals > 0 and a_goals == 0:
                goals_by_side[0] = banner_scorers
            elif a_goals > 0 and h_goals == 0:
                goals_by_side[1] = banner_scorers

    # Format scorers per side (chronological, grouping multiple goals by the same player)
    formatted_scorers = ['', '']
    for side in (0, 1):
        if not goals_by_side[side]:
            continue
        items = list(reversed(goals_by_side[side]))
        grouped_order = []
        grouped_mins = {}
        for mn, pl in items:
            if pl not in grouped_mins:
                grouped_order.append(pl)
                grouped_mins[pl] = []
            if mn not in grouped_mins[pl]:
                grouped_mins[pl].append(mn)
        scorer_lines = []
        # Incomplete or cancelled goal commentary must never invent a scorer.
        if len(set(goals_by_side[side])) != match['goals'][side]:
            continue
        for pl in grouped_order:
            mins = ', '.join(grouped_mins[pl])
            scorer_lines.append('%s  %s' % (pl, mins))
        formatted_scorers[side] = '\n'.join(scorer_lines)

    return {
        'ht_goals': ht_goals,
        'stage': stage,
        'cards': ((cards[0][0], cards[0][1]), (cards[1][0], cards[1][1])),
        'scorers': (formatted_scorers[0], formatted_scorers[1]),
        'ar_link': parser.ar_link,
    }


def match_event(event, matches, now=None):
    """Both complete team names and current EPG window must agree; no fuzzy guess."""
    now = time.time() if now is None else now
    if not event or len(event) < 3:
        return None
    title, start, end = event[:3]
    title = to_text(title or '')
    if not start <= now < end or _BAD_PROGRAM.search(title):
        return None
    # Provider guide titles append competition after ' - ' (never trim team hyphens).
    full_title = title
    title = title.split(' - ', 1)[0].strip()
    pair = _SPLIT.split(title)
    if len(pair) != 2:
        return None
    a, b = [team_name(s) for s in pair]
    found = []
    for m in matches:
        women = r'women|female|سيدات|نسائي'
        if bool(re.search(women, m.get('competition', ''), re.I)) != bool(re.search(women, full_title, re.I)):
            continue
        if not start - 900 <= m['kickoff'] < end or not 0 <= now - m['kickoff'] <= 5 * 3600:
            continue
        h, v = m['names']
        if (a in h and b in v) or (a in v and b in h):
            found.append(m)
    return found[0] if len(found) == 1 else None


def _read(url, limit, web=False):
    # Explicit private verified context; playback's compatibility SSL fallbacks
    # must never weaken this reader. No cookies, auth keys or impersonation.
    contexts = [ssl.create_default_context()]
    if os.path.isfile(CA_BUNDLE):
        contexts.append(ssl.create_default_context(cafile=CA_BUNDLE))
    headers = {
        'User-Agent': 'Mozilla/5.0' if web else 'UltraAudio-Live-Test/1.0',
        'Accept': 'text/html,application/json' if web else 'application/json,image/png',
    }
    last = None
    for context in contexts:
        try:
            req = Request(url, headers=headers)
            response = urlopen(req, timeout=7 if web else 10, context=context)
            try:
                final = response.geturl()
                allowed = (final.startswith(ENDPOINT + '?') or final.startswith(MEDIA) or
                           (web and any(final.startswith(h) for h in WEB_HOSTS)))
                if not allowed:
                    raise ValueError('Unexpected score redirect')
                data = response.read(limit + 1)
                if len(data) > limit:
                    raise ValueError('Score response too large')
                return data
            finally:
                response.close()
        except Exception as exc:
            reason = getattr(exc, 'reason', exc)
            if isinstance(reason, ssl.SSLError) and 'CERTIFICATE_VERIFY_FAILED' in to_text(reason).upper():
                last = exc
                continue
            raise
    raise last


def _png_valid(data):
    if len(data) < 33 or data[:8] != b'\x89PNG\r\n\x1a\n' or data[12:16] != b'IHDR':
        return False
    w, h = struct.unpack('>II', data[16:24])
    return 0 < w <= 512 and 0 < h <= 512


def _candidate_match_urls(match):
    """Build deterministic beIN Sports match page URLs (Arabic first, English fallback)."""
    urls = []
    ld = match.get('lang_data') or {}
    ar = ld.get('ar') or {}
    en = ld.get('en') or {}
    dates = []
    if match.get('match_date'):
        dates.append(match['match_date'])
    if match.get('kickoff'):
        for offset in (0, 3 * 3600, -3 * 3600):
            d = time.strftime('%Y-%m-%d', time.gmtime(match['kickoff'] + offset))
            if d not in dates:
                dates.append(d)

    # Arabic candidate URLs
    comp_ar = _slug(ar.get('competition', ''))
    home_ar = _slug(ar.get('home_name', ''))
    away_ar = _slug(ar.get('away_name', ''))
    if comp_ar and home_ar and away_ar:
        comp_slugs = _AR_COMP_SLUGS.get(comp_ar, (comp_ar,))
        for d in dates[:2]:
            for cs in comp_slugs:
                path = 'كرة-القدم/%s/%s-vs-%s-%s' % (cs, home_ar, away_ar, d)
                u = 'https://www.beinsports.com/ar-mena/' + quote(path.encode('utf-8'), safe='/-')
                if u not in urls:
                    urls.append(u)

    # English candidate URLs
    comp_en = _slug(en.get('competition', ''))
    home_en = _slug(en.get('home_name', ''))
    away_en = _slug(en.get('away_name', ''))
    if comp_en and home_en and away_en:
        for d in dates[:2]:
            u = 'https://www.beinsports.com/en-mena/football/%s/%s-vs-%s-%s' % (comp_en, home_en, away_en, d)
            if u not in urls:
                urls.append(u)
    return urls[:5]


class Scores(object):
    def __init__(self):
        self._lock = threading.Lock()
        self._busy = False
        self._last_attempt = None
        self._updated = None
        self._matches = []
        self._logos = {}
        self._ht_cache = {}
        self._details = {}
        self._detail_attempts = {}
        self._error = ''
        self._wanted = None
        self._logo_attempts = {}
        self.logger = None
        self._last_note = None

    def note(self, message):
        if self._last_note == message:
            return
        self._last_note = message
        if self.logger:
            try:
                self.logger('LiveMatch: ' + message)
            except Exception:
                pass

    def ensure(self, event):
        if not event or _BAD_PROGRAM.search(to_text(event[0])) or len(_SPLIT.split(to_text(event[0]))) != 2:
            return
        now = monotonic()
        with self._lock:
            self._wanted = event
            if self._busy:
                return
            fresh = self._updated is not None and 0 <= now - self._updated <= MAX_AGE
            match = match_event(event, self._matches) if fresh else None
            needs_logo = match and not all(t in self._logos for t in match['teams'])
            if needs_logo and now - self._logo_attempts.get(match['teams'], -POLL) < POLL:
                needs_logo = False
            needs_detail = False
            if match:
                det = self._details.get(match['id'])
                last_det = self._detail_attempts.get(match['id'], -POLL)
                if (det is None or det.get('goals') != match.get('goals')) and now - last_det >= POLL:
                    needs_detail = True
            if self._last_attempt is not None and now - self._last_attempt < POLL and not needs_logo and not needs_detail:
                return
            # A failed image must not be retried on every 1-second UI tick.
            if match and needs_detail and now - self._logo_attempts.get(match['teams'], -POLL) < POLL and not all(t in self._logos for t in match['teams']):
                return
            if self._last_attempt is not None and now - self._last_attempt < 5:
                return
            self._busy = True
            refresh = self._last_attempt is None or now - self._last_attempt >= POLL
            self._last_attempt = now
        try:
            start_thread(self._worker, args=(event, refresh), name='UltraAudioLiveScores')
        except Exception:
            with self._lock:
                self._busy = False

    def _fetch_details(self, current):
        """Fetch optional match-page details in each language separately.

        Never label Arabic scorer names as English (or vice versa).  The normal
        live-score endpoint already supplies bilingual team and league names.
        """
        ident = current['id']
        with self._lock:
            last = self._detail_attempts.get(ident, -POLL)
            existing = self._details.get(ident)
            if monotonic() - last < 20 and existing and existing.get('goals') == current.get('goals'):
                return
            self._detail_attempts[ident] = monotonic()

        # Retain the first trustworthy half-time and card values, while keeping
        # stage and scorer strings tied to the language of their own page.
        collected = {'lang_details': {}}
        any_page = False
        for url in _candidate_match_urls(current):
            locale = 'ar' if '/ar-mena/' in url else 'en'
            if locale in collected['lang_details']:
                continue
            try:
                raw_html = _read(url, MAX_HTML, web=True).decode('utf-8', 'replace')
                parsed = _parse_match_html(raw_html, current, locale)
            except Exception:
                continue
            # A successful HTTP response can still be a generic/404 page.
            if not any(parsed.get(k) for k in ('ht_goals', 'stage')) and not any(parsed.get('scorers', ())):
                if not any(any(side) for side in parsed.get('cards', ())):
                    continue
            any_page = True
            collected['lang_details'][locale] = {
                'stage': parsed.get('stage') or '',
                'scorers': parsed.get('scorers') or ('', ''),
            }
            if parsed.get('ht_goals') is not None:
                collected['ht_goals'] = parsed['ht_goals']
            cards = parsed.get('cards') or ((0, 0), (0, 0))
            old_cards = collected.get('cards') or ((0, 0), (0, 0))
            collected['cards'] = tuple(tuple(max(int(cards[i][j]), int(old_cards[i][j]))
                                             for j in (0, 1)) for i in (0, 1))
            if len(collected['lang_details']) == 2:
                break
        if any_page:
            collected['goals'] = current.get('goals')
            collected['updated'] = monotonic()
            with self._lock:
                self._details[ident] = collected
                if collected.get('ht_goals') is not None:
                    self._ht_cache[ident] = collected['ht_goals']

    def _worker(self, event, refresh):
        try:
            if refresh:
                merged = {}
                for language, lang_code in (('en-mena', 'en'), ('ar-mena', 'ar')):
                    query = {'desiredLanguage': language, 'eventDate': datetime.datetime.utcnow().strftime('%Y-%m-%d'),
                             'eventTime': '00:00:00', 'timezone': 'UTC', 'teamIds': '', 'section': 'calendar',
                             'favouriteTeamIds': '', 'competitionIds': '', 'isLive': '1'}
                    parsed = parse_payload(json.loads(_read(ENDPOINT + '?' + urlencode(query), MAX_JSON).decode('utf-8')), lang_code)
                    for key, value in parsed.items():
                        if key in merged and value['teams'] == merged[key]['teams']:
                            for index in (0, 1):
                                merged[key]['names'][index].update(value['names'][index])
                            merged[key]['lang_data'].update(value.get('lang_data') or {})
                            if value.get('ht_goals') is not None:
                                merged[key]['ht_goals'] = value['ht_goals']
                        else:
                            merged[key] = value
                with self._lock:
                    for key, val in merged.items():
                        if val.get('ht_goals') is not None:
                            self._ht_cache[key] = val['ht_goals']
                        elif key in self._ht_cache:
                            val['ht_goals'] = self._ht_cache[key]
                    self._matches = list(merged.values())
                    self._updated = monotonic()
                    self._error = ''
                self.note('refreshed %d live fixtures' % len(merged))
            with self._lock:
                current = match_event(event, self._matches)
            if current:
                with self._lock:
                    self._logo_attempts = {current['teams']: monotonic()}
                for team in current['teams']:
                    with self._lock:
                        cached = self._logos.get(team)
                    if cached and os.path.isfile(cached):
                        continue
                    data = _read(MEDIA + team + '.64.png?ver=03-06-2025', MAX_PNG)
                    if not _png_valid(data):
                        raise ValueError('Invalid team PNG')
                    root = os.path.join(tempfile.gettempdir(), 'ultraaudio-live-football')
                    if not os.path.isdir(root):
                        os.makedirs(root)
                    path = os.path.join(root, hashlib.sha256(team.encode('ascii')).hexdigest() + '.png')
                    fd, temporary = tempfile.mkstemp(prefix='download-', dir=root)
                    try:
                        with os.fdopen(fd, 'wb') as handle:
                            handle.write(data)
                        os.rename(temporary, path)
                    finally:
                        if os.path.exists(temporary):
                            os.unlink(temporary)
                    with self._lock:
                        self._logos[team] = path
                    # Bounded disk cache across GUI restarts, current file retained.
                    files = [os.path.join(root, n) for n in os.listdir(root) if n.endswith('.png')]
                    for old in sorted(files, key=os.path.getmtime)[:-48]:
                        if old != path:
                            try:
                                os.unlink(old)
                            except OSError:
                                pass
                # Best-effort fetch of rich match page details (cards/scorers/HT) off the GUI thread
                self._fetch_details(current)
        except Exception as exc:
            with self._lock:
                self._error = '%s: %s' % (type(exc).__name__, to_text(exc)[:180])
                # Stop showing previously successful data after a failed refresh.
                if refresh:
                    self._updated = None
            self.note('source/image unavailable: ' + self._error)
        finally:
            with self._lock:
                self._busy = False

    def is_live(self, event):
        """Badge truth is independent of image availability; no IO or logging."""
        if not event:
            return False
        now = monotonic()
        with self._lock:
            return bool(self._updated is not None and 0 <= now - self._updated <= MAX_AGE
                        and match_event(event, self._matches))

    def view(self, event):
        now = monotonic()
        result = None
        with self._lock:
            if self._updated is None or not 0 <= now - self._updated <= MAX_AGE:
                reason = 'waiting for fresh source data' if not self._error else self._error
            else:
                match = match_event(event, self._matches)
                if match is None:
                    reason = 'no unique live match for guide: ' + to_text(event[0] if event else '')[:180]
                else:
                    home_id, away_id = match['teams']
                    home_logo, away_logo = self._logos.get(home_id), self._logos.get(away_id)
                    if not (home_logo and os.path.isfile(home_logo) and away_logo and os.path.isfile(away_logo)):
                        reason = 'waiting for both team images: ' + match['id']
                    else:
                        ld = match.get('lang_data') or {}
                        ar = ld.get('ar') or {}
                        en = ld.get('en') or {}
                        det = self._details.get(match['id']) or {}

                        # Follow the actual UltraAudio interface language, not
                        # the order in which the two beIN responses arrived.
                        code = 'ar' if interface_language() == 'ar' else 'en'
                        primary, fallback = (ar, en) if code == 'ar' else (en, ar)
                        home_name = primary.get('home_name') or fallback.get('home_name') or ''
                        away_name = primary.get('away_name') or fallback.get('away_name') or ''
                        comp = primary.get('competition') or fallback.get('competition') or match.get('competition') or ''
                        details_for_lang = (det.get('lang_details') or {}).get(code) or {}
                        stage = details_for_lang.get('stage') or primary.get('stage') or ''
                        if not stage:
                            stage = comp
                            comp = ''
                        elif comp == stage:
                            comp = ''

                        ht_goals = match.get('ht_goals') or self._ht_cache.get(match['id']) or det.get('ht_goals')
                        minute_val = match.get('minute')
                        home_g, away_g = match.get('goals', (0, 0))
                        if ht_goals is None and minute_val is not None and minute_val > 45 and home_g == 0 and away_g == 0:
                            ht_goals = (0, 0)
                        if ht_goals is not None:
                            ht_text = ('(ش1 %d - %d)' if code == 'ar' else '(HT %d - %d)') % (ht_goals[1], ht_goals[0])
                        elif match['clock'] == 'HT':
                            ht_text = ('(ش1 %d - %d)' if code == 'ar' else '(HT %d - %d)') % (away_g, home_g)
                        elif minute_val is not None and minute_val > 45:
                            ht_text = 'الشوط الثاني' if code == 'ar' else '2nd Half'
                        else:
                            ht_text = 'الشوط الأول' if code == 'ar' else '1st Half'

                        cards = det.get('cards') or ((0, 0), (0, 0))
                        scorers = (details_for_lang.get('scorers') or ('', '')) if (det.get('goals') == match.get('goals') and now - det.get('updated', -MAX_AGE-1) <= MAX_AGE) else ('', '')

                        # Keep the card consistent with interface reading direction:
                        # English -> Home on the left, Away on the right.
                        # Arabic  -> Home on the right, Away on the left.
                        if code == 'ar':
                            paths = (away_logo, home_logo)
                            left_name, right_name = away_name, home_name
                            left_cards, right_cards = cards[1], cards[0]
                            left_scorers, right_scorers = scorers[1], scorers[0]
                            score_text = '%d - %d' % (away_g, home_g)
                            if ht_goals is not None:
                                ht_text = '(ش1 %d - %d)' % (ht_goals[1], ht_goals[0])
                            elif match['clock'] == 'HT':
                                ht_text = '(ش1 %d - %d)' % (away_g, home_g)
                        else:
                            paths = (home_logo, away_logo)
                            left_name, right_name = home_name, away_name
                            left_cards, right_cards = cards[0], cards[1]
                            left_scorers, right_scorers = scorers[0], scorers[1]
                            score_text = '%d - %d' % (home_g, away_g)
                            if ht_goals is not None:
                                ht_text = '(HT %d - %d)' % (ht_goals[0], ht_goals[1])
                            elif match['clock'] == 'HT':
                                ht_text = '(HT %d - %d)' % (home_g, away_g)

                        extra = {
                            'ui_language': code,
                            'left_name': left_name,
                            'right_name': right_name,
                            'ht_text': ht_text,
                            'stage': stage,
                            'competition': comp,
                            'left_yc': int(left_cards[0]),
                            'left_rc': int(left_cards[1]),
                            'right_yc': int(right_cards[0]),
                            'right_rc': int(right_cards[1]),
                            'left_scorers': left_scorers,
                            'right_scorers': right_scorers,
                        }
                        result = (match['id'], score_text, match['clock'], paths, extra)
                        reason = 'matched ' + match['id']
        self.note(reason)
        return result


SCORES = Scores()
