# -*- coding: utf-8 -*-
"""Offline starter channels bundled with the plugin, installed once per library."""
from __future__ import division
import os

from . import store
from .compat import new_id, open_text, parse_qsl, to_text, urlsplit
from .i18n import T

FOX_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "presets", "FoXFM.m3u")
FOX_VERSION = 1
RADIO_VERSION = 3
# Source URLs are community-listed streams; availability depends on the providers.
# Two non-working defaults were retired in revision 2. User edits are preserved.
RADIO_STATIONS = (
    (u"إذاعة القرآن الكريم - القاهرة", "https://stream.radiojar.com/8s5u5tpdtwzuv", False),
    (u"نجوم FM 100.6", "https://audio.nrpstream.com/listen/nogoumfm/radio.mp3", False),
    (u"ميجا FM 92.7", "https://megafm927.radioca.st/stream", False),
    (u"نغم FM 105.3", "https://ahmsamir.radioca.st/stream", False),
    (u"الراديو 9090", "https://9090streaming.mobtada.com/9090FMEGYPT", False),
    (u"راديو هيتس 88.2", "https://radiohits882.radioca.st/;", False),
    (u"شعبي FM 95", "https://radio95.radioca.st/;", False),
    (u"راديو أم كلثوم", "https://stream.zeno.fm/zsgrfxg71s8uv", False),
    (u"تسعينات FM", "https://eu1.fastcast4u.com/proxy/prontofm?mp=/1", False),
    (u"راديو عمرو دياب", "https://stream.zeno.fm/xa4yhh4k838uv", False),
    (u"راديو إليسا", "https://stream.zeno.fm/v7n499m8ckhvv", False),
)


def _identity(url, track=0):
    """HTTP fragments/default ports do not make an existing station a new one."""
    try:
        p = urlsplit(to_text(url))
        port = p.port or (443 if p.scheme.lower() == "https" else 80)
        return (p.scheme.lower(), (p.hostname or "").lower(), port, p.path or "/",
                tuple(sorted(parse_qsl(p.query, keep_blank_values=True))), int(track or 0))
    except (ValueError, TypeError):
        return (to_text(url), to_text(track))


def _radio_tree_streams(lib):
    """Streams under the bundled Radio root (Arabic, Quran and their subfolders)."""
    return [s for s in lib['streams'] if store.is_radio_folder(s.get('folder', ''), lib)]


def install_radio_folder_order():
    """Apply approved defaults once; later user reordering always wins."""
    from .ordering import RADIO_FOLDER_ORDER, RADIO_FOLDER_RANK
    legacy = ("radio_ar", "radio_quran", "radio_sayed_saeed", "radio_shaarawi", "radio_turkish")
    with store._lock:
        lib = store._load()
        markers = dict(lib.get("presets") or {})
        if markers.get("radio_folder_order") == 1:
            return {"skipped": True, "reordered": 0}
        root = next((f for f in lib["folders"] if f.get("preset") == "radio_root"), None)
        if root is None:
            return {"skipped": True, "reordered": 0}
        known = [f for f in lib["folders"] if f.get("parent") == root["id"] and f.get("preset") in RADIO_FOLDER_RANK]
        existing = tuple(f["preset"] for f in sorted(known, key=store.folder_key))
        present = set(existing)
        defaults = (tuple(key for key in legacy if key in present),
                    tuple(key for key in RADIO_FOLDER_ORDER if key in present))
        changed = 0
        if not any(f.get("order_user") for f in known) and existing in defaults:
            for folder in known:
                folder["order_auto"] = True
                changed += 1
        markers["radio_folder_order"] = 1
        lib["presets"] = markers
        store._save(lib)
        return {"skipped": False, "reordered": changed}


def install_provider_order():
    """Migrate only untouched bundled FoX order; preserve every owner-arranged folder."""
    from . import importer
    with store._lock:
        lib = store._load()
        installed = dict(lib.get("presets") or {})
        if installed.get("provider_order") == 1:
            return {"reordered": 0, "skipped": True}
        with open_text(FOX_FILE) as handle:
            wanted = importer.parse_m3u(handle.read())
        defaults = {}
        for entry in wanted:
            identity = _identity(entry.get("url", ""))
            if identity not in defaults:
                defaults[identity] = len(defaults) * 10
        changed = 0
        for folder in lib["folders"]:
            normalized = store.clean_text(folder.get("name"), 60).lower().replace(" ", "")
            if folder.get("preset") != "foxfm" and normalized != "foxfm":
                continue
            siblings = [s for s in lib["streams"] if s.get("folder") == folder["id"]]
            bundled = [s for s in siblings if s.get("preset") == "foxfm"]
            if not bundled or any(s.get("order_user") for s in siblings):
                continue
            # Old builds assigned the exact M3U position as order. Any different
            # explicit value is evidence of an owner choice and blocks migration.
            if any("order" in s and (s.get("preset") != "foxfm" or
                   s.get("order") != defaults.get(_identity(s.get("url", ""), s.get("audio_track", 0))))
                   for s in siblings):
                continue
            for stream in bundled:
                stream["order_auto"] = True
                changed += 1
        installed["provider_order"] = 1
        lib["presets"] = installed
        store._save(lib)
        return {"reordered": changed, "skipped": False}


def install_foxfm(force=False):
    """Add missing starter stations, preserving every existing link/offset/icon.

    The marker travels with the library and its backups. A later restart or
    package update never brings back stations the user intentionally deleted.
    An explicit Add FoX FM action can add the missing stations again.
    """
    from . import importer
    with store._lock:
        lib = store._load()
        installed = lib.get("presets")
        installed = dict(installed) if isinstance(installed, dict) else {}
        if not force and installed.get("foxfm") == FOX_VERSION:
            return {"added": 0, "existing": 0, "total": 0, "folder": None, "skipped": True}
        with open_text(FOX_FILE) as f:
            entries = importer.parse_m3u(f.read())
        entries = [e for e in entries if store.valid_url(e.get("url")) and store.clean_text(e.get("name"), 80)]
        if not entries:
            raise ValueError(T("No http/https links found in the source"))
        # De-duplicate the bundled file before touching user data.
        wanted, seen = [], set()
        for e in entries:
            key = _identity(e["url"])
            if key not in seen:
                seen.add(key)
                wanted.append(e)
        by = {_identity(s.get("url", ""), s.get("audio_track", 0)): s for s in lib["streams"]}
        target = next((f for f in lib["folders"] if f.get("preset") == "foxfm"), None)
        if target is None:
            target = next((f for f in lib["folders"] if not f.get("parent")
                           and store.clean_text(f.get("name"), 60).lower().replace(" ", "") == "foxfm"), None)
        ids = {x["id"] for x in lib["folders"] + lib["streams"]}

        def unique_id():
            while True:
                value = new_id()
                if value not in ids:
                    ids.add(value)
                    return value

        added, existing = 0, 0
        for index, e in enumerate(wanted):
            key = _identity(e["url"])
            if key in by:
                existing += 1
                continue
            if target is None:
                target = {"id": unique_id(), "parent": "", "name": "FoX FM", "provider": "foxfm",
                          "source": None, "updated": 0, "preset": "foxfm"}
                lib["folders"].append(target)
            stream = store._normalize({"name": e["name"], "url": e["url"], "provider": "foxfm"})
            stream.update(id=unique_id(), folder=target["id"], preset="foxfm", order=index * 10, order_auto=True)
            lib["streams"].append(stream)
            by[key] = stream
            added += 1
        installed["foxfm"] = FOX_VERSION
        lib["presets"] = installed
        store._save(lib)
        return {"added": added, "existing": existing, "total": len(wanted),
                "folder": target["id"] if target is not None else None, "skipped": False}


# Only exact original unedited presets are removed; user's edits are never deleted.
RETIRED_RADIO_PRESETS = (
    (u"ON Sport FM", "https://carina.streamerr.co:2020/stream/OnSportFM"),
    (u"إذاعة الأغاني المصرية 105.8", "https://www.maspero.eg/stream/13"),
)


def install_radio(force=False):
    """Seed the 12 usable stations; upgrade old Radio1/2 libraries safely.

    On 1 -> 2 upgrades, remove only the two exact bundled defective entries;
    preserve all remaining preset edits, additions, moves, deletions and IDs.
    Never bring back deleted channels during automatic package upgrades.
    """
    with store._lock:
        lib = store._load()
        installed = dict(lib.get("presets") or {})
        old_version = installed.get("radio")
        if not force and old_version == RADIO_VERSION:
            return {"added": 0, "folder": None, "skipped": True}
        removed = 0
        if not force and old_version == 1:
            retired = set(RETIRED_RADIO_PRESETS)
            before = len(lib["streams"])
            lib["streams"] = [s for s in lib["streams"] if not (
                s.get("preset") == "radio" and (to_text(s.get("name")), s.get("url")) in retired)]
            removed = before - len(lib["streams"])
        # Radio1/2/3 migration: never re-add user-deleted streams.
        upgrade_only = not force and old_version in (1, 2)
        root = next((f for f in lib["folders"] if f.get("preset") == "radio_root"), None)
        if root is None:
            root = next((f for f in lib["folders"] if not f.get("parent") and
                         to_text(f.get("name", "")).lower() == "radio"), None)
        ids = {e["id"] for e in lib["folders"] + lib["streams"]}

        def unique_id():
            while True:
                value = new_id()
                if value not in ids:
                    ids.add(value)
                    return value

        if root is None:
            root = {"id": unique_id(), "parent": "", "name": "Radio", "provider": "radio",
                    "source": None, "updated": 0, "preset": "radio_root"}
            lib["folders"].append(root)
        else:
            root["preset"] = "radio_root"
            root["provider"] = "radio"
        arabic = next((f for f in lib["folders"] if f.get("parent") == root["id"] and
                       (f.get("preset") == "radio_ar" or to_text(f.get("name", "")).lower() in
                        (u"arabic", u"عربي"))), None)
        if arabic is None:
            arabic = {"id": unique_id(), "parent": root["id"], "name": "Arabic",
                      "provider": "radio", "source": None, "updated": 0, "preset": "radio_ar", "order_auto": True}
            lib["folders"].append(arabic)
        else:
            arabic["preset"] = "radio_ar"
            arabic["provider"] = "radio"
        quran = next((f for f in lib["folders"] if f.get("parent") == root["id"] and
                      (f.get("preset") == "radio_quran" or to_text(f.get("name")) in
                       (u"Quran", u"القرآن الكريم"))), None)
        if quran is None:
            quran = {"id": unique_id(), "parent": root["id"], "name": "Quran",
                     "provider": "radio", "source": None, "updated": 0, "preset": "radio_quran", "order_auto": True}
            lib["folders"].append(quran)
        else:
            quran["provider"] = "radio"
            quran["preset"] = "radio_quran"
        if upgrade_only:
            installed["radio"] = RADIO_VERSION
            lib["presets"] = installed
            store._save(lib)
            return {"added": 0, "removed": removed, "folder": root["id"],
                    "quran_folder": quran["id"], "upgraded": True, "skipped": False}
        existing = {_identity(s.get("url", ""), s.get("audio_track", 0))
                    for s in lib["streams"] if s.get("folder") == arabic["id"]}
        added = 0
        for idx, (name, url, pending) in enumerate(RADIO_STATIONS):
            if _identity(url) in existing:
                continue
            s = store._normalize({"name": name, "url": url, "kind": "radio", "provider": "radio"})
            s.update(id=unique_id(), folder=arabic["id"], preset="radio", order=idx * 10)
            if pending:
                s["needs_stream_url"] = True
            lib["streams"].append(s)
            existing.add(_identity(url))
            added += 1
        installed["radio"] = RADIO_VERSION
        lib["presets"] = installed
        store._save(lib)
        return {"added": added, "folder": root["id"], "subfolder": arabic["id"],
                "total": len(RADIO_STATIONS), "pending_urls": 0, "skipped": False,
                "quran_folder": quran["id"]}


# Direct-stream reciter presets from MP3Quran's published Arabic radio catalog.
# Egyptian reciters FIRST, followed by other nationalities. One stream per reader.
# These are listed source links, not a claim of on-device live-audio validation.
QURAN_DIRECT_VERSION = 1
QURAN_STREAMS = (
    (u"عبد الباسط عبد الصمد", "https://backup.qurango.net/radio/abdulbasit_abdulsamad_mojawwad"),
    (u"محمود خليل الحصري", "https://backup.qurango.net/radio/mahmoud_khalil_alhussary_mojawwad"),
    (u"محمد صديق المنشاوي", "https://backup.qurango.net/radio/mohammed_siddiq_alminshawi_mojawwad"),
    (u"مصطفى إسماعيل", "https://backup.qurango.net/radio/mustafa_ismail"),
    (u"محمود علي البنا", "https://backup.qurango.net/radio/mahmoud_ali__albanna_mojawwad"),
    (u"محمد الطبلاوي", "https://backup.qurango.net/radio/mohammad_altablaway"),
    (u"أحمد نعينع", "https://backup.qurango.net/radio/ahmad_nauina"),
    (u"محمد جبريل", "https://backup.qurango.net/radio/mohammed_jibreel"),
    (u"أحمد عامر", "https://qurango.net/radio/ahmed_amer"),
    (u"محمود الشيمي", "https://backup.qurango.net/radio/mahmood_alsheimy"),
    (u"مصطفى اللاهوني", "https://backup.qurango.net/radio/mustafa_allahoni"),
    # Other reciters
    (u"مشاري راشد العفاسي", "https://backup.qurango.net/radio/mishary_alafasi"),
    (u"ماهر المعيقلي", "https://qurango.net/radio/maher"),
    (u"عبد الرحمن السديس", "https://backup.qurango.net/radio/abdulrahman_alsudaes"),
    (u"سعود الشريم", "https://backup.qurango.net/radio/saud_alshuraim"),
    (u"سعد الغامدي", "https://backup.qurango.net/radio/saad_alghamdi"),
    (u"ياسر الدوسري", "https://backup.qurango.net/radio/yasser_aldosari"),
    (u"فارس عباد", "https://backup.qurango.net/radio/fares_abbad"),
    (u"ناصر القطامي", "https://backup.qurango.net/radio/nasser_alqatami"),
    (u"محمد أيوب", "https://backup.qurango.net/radio/mohammed_ayyub"),
    (u"صلاح بو خاطر", "https://backup.qurango.net/radio/slaah_bukhatir"),
    (u"عبد الله بصفر", "https://backup.qurango.net/radio/abdullah_basfer"),
    (u"إبراهيم الأخضر", "https://backup.qurango.net/radio/ibrahim_alakdar"),
    (u"إدريس أبكر", "https://backup.qurango.net/radio/idrees_abkr"),
    (u"أبو بكر الشاطري", "https://backup.qurango.net/radio/shaik_abu_bakr_al_shatri"),
    (u"خالد الجليل", "https://backup.qurango.net/radio/khalid_aljileel"),
    (u"هاني الرفاعي", "https://backup.qurango.net/radio/hani_arrifai"),
    (u"بندر بليلة", "https://backup.qurango.net/radio/bandar_balilah"),
    (u"عبد الله عواد الجهني", "https://backup.qurango.net/radio/abdullah_aljohany"),
    (u"عمر القزابري", "https://backup.qurango.net/radio/omar_alqazabri"),
    (u"عبد الرشيد صوفي", "https://backup.qurango.net/radio/abdulrasheed_soufi_khalaf"),
    (u"الزين محمد أحمد", "https://backup.qurango.net/radio/alzain_mohammad_ahmad"),
    (u"هزاع البلوشي", "https://backup.qurango.net/radio/hazza"),
    (u"العيون الكوشي", "https://backup.qurango.net/radio/aloyoon_alkoshi"),
    (u"أحمد خضر الطرابلسي", "https://backup.qurango.net/radio/ahmad_khader_altarabulsi"),
    (u"صلاح الهاشم", "https://backup.qurango.net/radio/salah_alhashim"),
    (u"عادل الكلباني", "https://backup.qurango.net/radio/adel_alkhalbany"),
    (u"عبد الله خياط", "https://backup.qurango.net/radio/abdullah_khayyat"),
    (u"محمد اللحيدان", "https://backup.qurango.net/radio/mohammed_allohaidan"),
    (u"علي الحذيفي", "https://backup.qurango.net/radio/ali_alhuthaifi_qalon"),
)

# The two additional Egyptian music-radio stations requested previously.
RADIO_EXTRAS_VERSION = 1
RADIO_EXTRAS = (
    (u"NRJ Egypt 92.1", "https://nrjstreaming.ahmed-melege.com/nrjegypt"),
)


def install_quran_direct():
    """Populate Quran directly on first V1 Radio5 start, with no Web scan.

    Version markers prevent reseeding deleted streams on later starts.
    Upgrades from empty Radio4 receive the stations automatically. Existing
    scanner-imported or user-customised stations are not overwritten.
    """
    from .quranradio import normalize as normalize_name
    with store._lock:
        lib = store._load()
        installed = dict(lib.get('presets') or {})
        need_quran = installed.get('quran_direct') != QURAN_DIRECT_VERSION
        need_extras = installed.get('radio_extras') != RADIO_EXTRAS_VERSION
        if not (need_quran or need_extras):
            return {'skipped': True, 'quran_added': 0, 'arabic_added': 0}

        root = next((f for f in lib['folders'] if f.get('preset') == 'radio_root'), None)
        if not root:
            return {'skipped': True, 'quran_added': 0, 'arabic_added': 0, 'error': 'Radio folder missing'}
        quran = next((f for f in lib['folders'] if f.get('parent') == root['id']
                      and f.get('preset') == 'radio_quran'), None)
        arabic = next((f for f in lib['folders'] if f.get('parent') == root['id']
                       and f.get('preset') == 'radio_ar'), None)
        if need_quran and not quran:
            # For restored Radio3 libraries lacking this folder.
            quran = {'id': new_id(), 'parent': root['id'], 'name': 'Quran',
                     'provider': 'radio', 'source': None, 'updated': 0, 'preset': 'radio_quran', 'order_auto': True}
            lib['folders'].append(quran)
        if need_extras and not arabic:
            arabic = {'id': new_id(), 'parent': root['id'], 'name': 'Arabic',
                      'provider': 'radio', 'source': None, 'updated': 0, 'preset': 'radio_ar', 'order_auto': True}
            lib['folders'].append(arabic)
        ids = {x['id'] for x in lib['folders'] + lib['streams']}

        def unique_id():
            while True:
                sid = new_id()
                if sid not in ids:
                    ids.add(sid)
                    return sid

        def seed(folder, entries, preset, order_start=0):
            # Match both displayed reciter names and direct links across hosts
            # (qurango.net vs backup.qurango.net). Preserve owner changes.
            station_list = [s for s in lib['streams'] if s.get('folder') == folder['id']]
            name_keys = {normalize_name(s.get('name', '')) for s in station_list}
            urls = {_identity(s.get('url', '')) for s in station_list}
            radio_slugs = {urlsplit(to_text(s.get('url', ''))).path.rsplit('/', 1)[-1].lower()
                           for s in station_list if '/radio/' in urlsplit(to_text(s.get('url', ''))).path}
            added = 0
            for index, (name, url) in enumerate(entries):
                if not store.valid_url(url):
                    continue
                key = normalize_name(name)
                slug = urlsplit(to_text(url)).path.rsplit('/', 1)[-1].lower()
                if key in name_keys or _identity(url) in urls or ('/radio/' in url and slug in radio_slugs):
                    continue
                entry = store._normalize({'name': name, 'url': url, 'provider': 'radio', 'kind': 'radio'})
                entry.update(id=unique_id(), folder=folder['id'], preset=preset, kind='radio',
                             order=order_start + index * 10)
                lib['streams'].append(entry)
                name_keys.add(key)
                urls.add(_identity(url))
                radio_slugs.add(slug)
                added += 1
            return added

        n_quran, n_arabic = 0, 0
        if need_quran and quran:
            n_quran = seed(quran, QURAN_STREAMS, 'quran_direct')
            installed['quran_direct'] = QURAN_DIRECT_VERSION
        if need_extras and arabic:
            n_arabic = seed(arabic, RADIO_EXTRAS, 'radio_extra', order_start=1000)
            installed['radio_extras'] = RADIO_EXTRAS_VERSION
        lib['presets'] = installed
        store._save(lib)
        return {'skipped': False, 'quran_added': n_quran, 'arabic_added': n_arabic}


# Radio16: additions decoded to non-silent PCM during build review.
# Availability/geo restrictions remain controlled by each station.
RADIO_EXPANSION_VERSION = 2
QURAN_ADDITIONS = (
    (u'علي جابر', 'https://backup.qurango.net/radio/ali_jaber'),
    (u'صلاح البدير', 'https://backup.qurango.net/radio/salah_albudair'),
    (u'عبدالله المطرود', 'https://backup.qurango.net/radio/abdullah_almattrod'),
    (u'خالد القحطاني', 'https://backup.qurango.net/radio/khaled_alqahtani'),
    (u'توفيق الصايغ', 'https://backup.qurango.net/radio/tawfeeq_assayegh'),
    (u'أحمد الحواشي', 'https://backup.qurango.net/radio/ahmad_alhawashi'),
    (u'عبدالمحسن القاسم', 'https://backup.qurango.net/radio/abdulmohsen_alqasim'),
    (u'عبدالبارئ الثبيتي', 'https://backup.qurango.net/radio/abdelbari_altoubayti'),
    (u'خليفة الطنيجي', 'https://backup.qurango.net/radio/khalifa_altunaiji'),
    (u'يحيى حوا', 'https://backup.qurango.net/radio/yahya_hawwa'),
    (u'وليد النائحي', 'https://backup.qurango.net/radio/waleed_alnaehi'),
    (u'عادل ريان', 'https://backup.qurango.net/radio/adel_ryyan'),
    (u'حاتم فريد الواعر', 'https://backup.qurango.net/radio/hatem_fareed_alwaer'),
    (u'نبيل الرفاعي', 'https://backup.qurango.net/radio/nabil_al_rifay'),
    (u'مصطفى رعد العزاوي', 'https://backup.qurango.net/radio/mustafa_raad_alazawy'),
    (u'سهل ياسين', 'https://backup.qurango.net/radio/sahl_yassin'),
)
RETIRED_RADIO16_STATIONS = (
    (u'BBC World Service — أخبار عالمية', 'https://stream.live.vc.bbcmedia.co.uk/bbc_world_service', 'news'),
    (u'مونت كارلو الدولية — أخبار بالعربية', 'https://montecarlodoualiya128k.ice.infomaniak.ch/mc-doualiya.mp3', 'news'),
    (u'France Info — أخبار وسياسة', 'https://icecast.radiofrance.fr/franceinfo-midfi.mp3', 'news'),
    (u'France Culture — ثقافة وحوار', 'https://icecast.radiofrance.fr/franceculture-midfi.mp3', 'news'),
    (u'France Inter — حوار ومنوعات', 'https://icecast.radiofrance.fr/franceinter-midfi.mp3', 'news'),
    (u'talkSPORT — رياضة', 'https://radio.talksport.com/stream', 'sports'),
    (u'talkSPORT 2 — رياضة', 'https://radio.talksport.com/stream2', 'sports'),
    (u'Radio Swiss Jazz — جاز', 'https://stream.srg-ssr.ch/m/rsj/mp3_128', 'music'),
    (u'Radio Swiss Classic — موسيقى كلاسيكية', 'https://stream.srg-ssr.ch/m/rsc_de/mp3_128', 'music'),
)

QURAN_MORE = (
    (u'علي حجاج السويسي', 'https://backup.qurango.net/radio/ali_hajjaj_alsouasi'),
    (u'صابر عبدالحكم', 'https://backup.qurango.net/radio/saber_abdulhakm'),
    (u'سيد رمضان', 'https://backup.qurango.net/radio/sayeed_ramadan'),
    (u'أحمد خليل شاهين', 'https://backup.qurango.net/radio/ahmad_shaheen'),
    (u'عبدالرحمن الشحات', 'https://backup.qurango.net/radio/a_alshahhat'),
    (u'محمود الرفاعي', 'https://backup.qurango.net/radio/mahmood_al_rifai'),
    (u'أحمد العجمي', 'https://backup.qurango.net/radio/ahmad_alajmy'),
    (u'عبدالعزيز سحيم', 'https://backup.qurango.net/radio/a_sheim'),
)

ARABIC_ADDITIONS = (
    (u'مونت كارلو الدولية', 'https://montecarlodoualiya128k.ice.infomaniak.ch/mc-doualiya.mp3'),
    (u'راديو مصر على الهوا', 'http://onair.egonair.com/8004/stream'),
    (u'راديو الغد', 'https://alghad.fm/radio-stream2'),
)


def install_radio_expansion():
    """Seed only new stations once; never restore an old user-deleted preset."""
    from .quranradio import normalize
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        previous = int(markers.get('radio_expansion') or 0)
        if previous == RADIO_EXPANSION_VERSION:
            return {'skipped': True, 'added': 0}
        root = next((f for f in lib['folders'] if f.get('preset') == 'radio_root'), None)
        quran = next((f for f in lib['folders'] if f.get('preset') == 'radio_quran'), None)
        arabic = next((f for f in lib['folders'] if f.get('preset') == 'radio_ar'), None)
        if not root or not quran or not arabic:
            return {'skipped': True, 'added': 0, 'error': 'Radio/Arabic/Quran folder missing'}
        removed_folders = {f['id'] for f in lib['folders']
                           if f.get('preset') in ('radio_news', 'radio_sports', 'radio_music')}
        retired = {_identity(url) for name, url, category in RETIRED_RADIO16_STATIONS}
        lib['streams'] = [e for e in lib['streams'] if not
                          (e.get('preset') == 'radio_expansion' and _identity(e.get('url', '')) in retired)]
        # Preserve owner-created/edited links while removing the unwanted categories.
        for entry in lib['streams']:
            if entry.get('folder') in removed_folders:
                entry['folder'] = arabic['id']
        lib['folders'] = [f for f in lib['folders'] if f['id'] not in removed_folders]
        for folder in lib['folders']:
            if folder.get('parent') in removed_folders:
                folder['parent'] = arabic['id']
        ids = {e['id'] for e in lib['folders'] + lib['streams']}

        def unique_id():
            while True:
                sid = new_id()
                if sid not in ids:
                    ids.add(sid)
                    return sid
        folders = {'quran': quran, 'arabic': arabic}
        # Both URL identities and reciter names prevent duplicates across backup hosts.
        urls = {_identity(e.get('url', ''), e.get('audio_track', 0)) for e in _radio_tree_streams(lib)}
        names = {normalize(e.get('name', '')) for e in lib['streams'] if e.get('folder') == quran['id']}
        readers = (QURAN_ADDITIONS if previous < 1 else ()) + QURAN_MORE
        wanted = [(name, url, 'quran') for name, url in readers]
        wanted += [(name, url, 'arabic') for name, url in ARABIC_ADDITIONS]
        added = 0
        for index, (name, url, category) in enumerate(wanted):
            if _identity(url) in urls or (category == 'quran' and normalize(name) in names):
                continue
            entry = store._normalize({'name': name, 'url': url, 'provider': 'radio', 'kind': 'radio'})
            entry.update(id=unique_id(), folder=folders[category]['id'], preset='radio_expansion',
                         kind='radio', order=1000 + index * 10)
            lib['streams'].append(entry)
            urls.add(_identity(url))
            if category == 'quran':
                names.add(normalize(name))
            added += 1
        markers['radio_expansion'] = RADIO_EXPANSION_VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'added': added, 'folders_removed': len(removed_folders)}


RADIO_LINK_REPAIR_VERSION = 1
RADIO_LINK_REPAIRS = (
    (u'نجوم FM 100.6', 'https://stream.zeno.fm/qb1zvsykm98uv',
     'https://audio.nrpstream.com/listen/nogoumfm/radio.mp3'),
    (u'أحمد عامر', 'https://backup.qurango.net/radio/ahmed_amer', 'https://qurango.net/radio/ahmed_amer'),
    (u'ماهر المعيقلي', 'https://backup.qurango.net/radio/maher', 'https://qurango.net/radio/maher'),
)
# Repeated source tests returned 401/404 and no working replacement was found.
# Retire only exact unedited bundled defaults; never another owner's station.
UNAVAILABLE_DEFAULTS = (
    (u'راديو عبد الحليم حافظ', 'https://stream.zeno.fm/8a4eqkd0pnhvv'),
    (u'Mix FM 87.8', 'https://stream-29.zeno.fm/na3vpvn10qruv'),
    (u'نورين محمد صديق', 'https://backup.qurango.net/radio/nourin_siddig'),
)


def install_radio_link_repairs():
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        if markers.get('radio_link_repair') == RADIO_LINK_REPAIR_VERSION:
            return {'skipped': True, 'updated': 0, 'retired': 0}
        repairs = {(name, _identity(old)): new for name, old, new in RADIO_LINK_REPAIRS}
        retired = {(name, _identity(url)) for name, url in UNAVAILABLE_DEFAULTS}
        updated, removed, kept = 0, 0, []
        for entry in lib['streams']:
            key = (to_text(entry.get('name')), _identity(entry.get('url', '')))
            bundled = entry.get('preset') in ('radio', 'radio_extra', 'quran_direct') and not entry.get('user_folder')
            if bundled and key in retired:
                removed += 1
                continue
            if bundled and key in repairs:
                entry['url'] = repairs[key]
                updated += 1
            kept.append(entry)
        lib['streams'] = kept
        markers['radio_link_repair'] = RADIO_LINK_REPAIR_VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'updated': updated, 'retired': removed}


# Ultra Audio 1.0.6-test2: radio cleanup / myTuner cross-check (25 Oct 2026).
# Only raw audio endpoints can be shipped.  A third-party player page alone is
# not a stream and must never become a selectable but dead radio station.
# Keep the previously seeded direct links; do not auto-import uncertain listings.
RADIO_107_VERSION = 2
RADIO_107_STATIONS = (
    (u"ON Sport FM", "https://carina.streamerr.co:2020/stream/OnSportFM", False),
    (u"Nile FM", "https://audio.nrpstream.com/listen/nile_fm/radio.mp3", False),
    (u"راديو مارس", "https://radiomars.ice.infomaniak.ch/radiomars-128.mp3", False),
    (u"العربية FM", "https://fm.alarabiya.net/fm/myStream/playlist.m3u8", False),
)
# Version 1 seeded these six placeholder entries with website URLs rather than
# playable audio. Remove only the pristine bundled rows with needs_stream_url;
# edits to a real direct link and all manually created stations always survive.
RADIO_107_PLACEHOLDERS = (
    (u"راديو مصر", "https://www.maspero.eg/"),
    (u"البرنامج العام", "https://www.maspero.eg/stream/10"),
    (u"الشرق الأوسط", "https://www.maspero.eg/"),
    (u"صوت العرب", "https://www.maspero.eg/"),
    (u"الشباب والرياضة", "https://www.maspero.eg/"),
    (u"MBC FM", "https://shahid.mbc.net/ar/livestream/MBC-FM/livechannel-388567"),
)


def install_radio_107():
    """Versioned radio seed and migration; never restore user-deleted defaults.

    On the 1->2 migration remove only untouched dead placeholders. Place the
    built-in ON Sport FM station first, preserving every other station's
    relative order; do not override future owner-driven reordering.
    """
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        previous = markers.get('radio_107')
        if previous == RADIO_107_VERSION:
            return {'skipped': True, 'added': 0, 'removed': 0}
        arabic = next((x for x in lib['folders'] if x.get('preset') == 'radio_ar'), None)
        if not arabic:
            return {'skipped': True, 'added': 0, 'removed': 0, 'error': 'Radio/Arabic folder missing'}
        pristine = {(name, _identity(url)) for name, url in RADIO_107_PLACEHOLDERS}
        removed = 0
        kept = []
        for entry in lib['streams']:
            is_unusable_original = (entry.get('preset') == 'radio_107' and
                bool(entry.get('needs_stream_url')) and
                (to_text(entry.get('name')), _identity(entry.get('url', ''))) in pristine)
            if is_unusable_original:
                removed += 1
            else:
                kept.append(entry)
        lib['streams'] = kept
        ids = {x['id'] for x in lib['folders'] + lib['streams']}
        # Only stations already inside Radio count as duplicates. The same link
        # imported into a commentary folder (Orange, SatFamily...) is not radio.
        in_radio = _radio_tree_streams(lib)
        urls = {_identity(x.get('url', ''), x.get('audio_track', 0)) for x in in_radio}
        names = {to_text(x.get('name', '')).strip().lower() for x in in_radio}
        added = 0
        # A version-1 upgrade does NOT restore stations manually deleted by owner.
        if previous not in (1,):
            for index, (name, url, pending) in enumerate(RADIO_107_STATIONS):
                if _identity(url) in urls or to_text(name).strip().lower() in names:
                    continue
                if not store.valid_url(url):
                    continue
                sid = new_id()
                while sid in ids:
                    sid = new_id()
                ids.add(sid)
                stream = store._normalize({'name': name, 'url': url,
                                           'provider': 'radio', 'kind': 'radio'})
                stream.update(id=sid, folder=arabic['id'], preset='radio_107',
                              kind='radio', order=3000 + 10 * index)
                lib['streams'].append(stream)
                urls.add(_identity(url))
                names.add(to_text(name).strip().lower())
                added += 1
        # Only prioritize our built-in station in the intended Arabic radio list.
        # Never overwrite an unrelated station's name/link or move a user station.
        siblings = [s for s in lib['streams'] if s.get('folder') == arabic['id']]
        onsport_url = _identity(RADIO_107_STATIONS[0][1])
        chosen = next((s for s in siblings if to_text(s.get('name')) == u'ON Sport FM' and
                       _identity(s.get('url', '')) == onsport_url and
                       s.get('preset') == 'radio_107'), None)
        reordered = False
        if chosen is not None:
            others = sorted((s for s in siblings if s['id'] != chosen['id']), key=store.stream_key)
            for n, item in enumerate([chosen] + others):
                item['order'] = n * 10
            reordered = True
        markers['radio_107'] = RADIO_107_VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'added': added, 'removed': removed,
                'onsport_first': reordered}


# 1.0.8-test4: one-time completeness pass for libraries that missed stations.
# Older seeds treated a link anywhere in the library (e.g. ON Sport FM inside an
# imported commentary folder) as "already present", and radio_107 v1 libraries
# were never given the v2 stations. Fill the gaps once inside Radio only; the
# marker then guarantees later deletions by the owner are respected.
RADIO_COMPLETE_VERSION = 1


def _bundled_arabic():
    rows = [(n, u) for n, u, _ in RADIO_107_STATIONS]
    rows += [(n, u) for n, u, _ in RADIO_STATIONS]
    rows += list(RADIO_EXTRAS) + list(ARABIC_ADDITIONS)
    return rows


def _bundled_quran():
    return list(QURAN_STREAMS) + list(QURAN_ADDITIONS) + list(QURAN_MORE)


def install_radio_complete():
    from .quranradio import normalize as normalize_name
    from .compat import integer_types
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        if markers.get('radio_complete') == RADIO_COMPLETE_VERSION:
            return {'skipped': True, 'added': 0}
        arabic = next((f for f in lib['folders'] if f.get('preset') == 'radio_ar'), None)
        quran = next((f for f in lib['folders'] if f.get('preset') == 'radio_quran'), None)
        if not arabic and not quran:
            return {'skipped': True, 'added': 0, 'error': 'Radio folders missing'}
        blocked = {_identity(u) for _, u in UNAVAILABLE_DEFAULTS}
        blocked |= {_identity(u) for _, u, _ in RETIRED_RADIO16_STATIONS}
        blocked |= {_identity(u) for _, u in RADIO_107_PLACEHOLDERS}
        in_radio = _radio_tree_streams(lib)
        urls = {_identity(s.get('url', ''), s.get('audio_track', 0)) for s in in_radio}
        names = {to_text(s.get('name', '')).strip().lower() for s in in_radio}
        reciters = {normalize_name(s.get('name', '')) for s in in_radio}
        slugs = {urlsplit(to_text(s.get('url', ''))).path.rstrip('/').rsplit('/', 1)[-1].lower()
                 for s in in_radio if '/radio/' in urlsplit(to_text(s.get('url', ''))).path}
        ids = {x['id'] for x in lib['folders'] + lib['streams']}

        def unique_id():
            while True:
                value = new_id()
                if value not in ids:
                    ids.add(value)
                    return value

        added, onsport = [], None
        plan = []
        if arabic:
            plan += [(arabic, n, u, 'radio_complete', False) for n, u in _bundled_arabic()]
        if quran:
            plan += [(quran, n, u, 'quran_complete', True) for n, u in _bundled_quran()]
        for index, (folder, name, url, preset, is_quran) in enumerate(plan):
            key = _identity(url)
            slug = urlsplit(to_text(url)).path.rstrip('/').rsplit('/', 1)[-1].lower()
            if key in blocked or key in urls or not store.valid_url(url):
                continue
            if to_text(name).strip().lower() in names:
                continue
            if is_quran and (normalize_name(name) in reciters or ('/radio/' in to_text(url) and slug in slugs)):
                continue
            stream = store._normalize({'name': name, 'url': url, 'provider': 'radio', 'kind': 'radio'})
            stream.update(id=unique_id(), folder=folder['id'], preset=preset,
                          kind='radio', order=5000 + 10 * index)
            lib['streams'].append(stream)
            urls.add(key)
            names.add(to_text(name).strip().lower())
            reciters.add(normalize_name(name))
            slugs.add(slug)
            added.append(to_text(name))
            if to_text(name) == u'ON Sport FM':
                onsport = stream
        if onsport is not None:
            # Show the restored ON Sport FM first without reshuffling anything else.
            orders = [s['order'] for s in lib['streams'] if s.get('folder') == arabic['id']
                      and s['id'] != onsport['id'] and isinstance(s.get('order'), integer_types)]
            onsport['order'] = (min(orders) - 10) if orders else 0
        markers['radio_complete'] = RADIO_COMPLETE_VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'added': len(added), 'names': added}


SAYED_SAEED_VERSION = 1


def install_sayed_saeed():
    """Add the ordered recordings once, preserving edits and later deletions.

    This is an offline library migration, after Radio has been initialized.
    The saved marker also travels with backups, so restarting cannot restore
    recordings or folders the owner deliberately removed or reordered.
    """
    from .sayedsaeed import RECORDINGS
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        if markers.get('sayed_saeed') == SAYED_SAEED_VERSION:
            return {'skipped': True, 'added': 0}
        root = next((f for f in lib['folders'] if f.get('preset') == 'radio_root'), None)
        if not root:
            return {'skipped': True, 'added': 0, 'error': 'Radio folder missing'}
        ids = {x['id'] for x in lib['folders'] + lib['streams']}

        def unique_id():
            while True:
                value = new_id()
                if value not in ids:
                    ids.add(value)
                    return value

        target = next((f for f in lib['folders'] if f.get('preset') == 'radio_sayed_saeed'), None)
        if target is None:
            target = next((f for f in lib['folders'] if f.get('parent') == root['id']
                           and to_text(f.get('name')) == u'الشيخ السيد سعيد'), None)
        if target is None:
            siblings = sorted((f for f in lib['folders'] if f.get('parent') == root['id']),
                              key=store.folder_key)
            target = {'id': unique_id(), 'parent': root['id'], 'name': u'الشيخ السيد سعيد',
                      'provider': 'radio', 'source': None, 'updated': 0, 'preset': 'radio_sayed_saeed', 'order_auto': True}
            lib['folders'].append(target)
            # Append after Arabic / Quran, retaining the existing visible order.
            for index, folder in enumerate(siblings + [target]):
                folder['order'] = index * 10
        else:
            target['preset'] = 'radio_sayed_saeed'
        urls = {_identity(s.get('url', ''), s.get('audio_track', 0))
                for s in lib['streams'] if s.get('folder') == target['id']}
        added = 0
        for index, (name, url) in enumerate(RECORDINGS):
            identity = _identity(url)
            if identity in urls or not store.valid_url(url):
                continue
            stream = store._normalize({'name': name, 'url': url, 'provider': 'radio',
                                       'kind': 'radio', 'icon_choice': 'folders/quran'})
            stream.update(id=unique_id(), folder=target['id'], preset='sayed_saeed',
                          kind='radio', order=index * 10)
            lib['streams'].append(stream)
            urls.add(identity)
            added += 1
        markers['sayed_saeed'] = SAYED_SAEED_VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'added': added, 'folder': target['id']}


SHAARAWI_VERSION = 2


def install_shaarawi():
    """Keep live radio and tafsir in one folder; flatten the first seed safely."""
    from .shaarawi import LIVE_NAME, LIVE_URL, RECORDINGS
    with store._lock:
        lib = store._load()
        markers = dict(lib.get('presets') or {})
        previous = markers.get('shaarawi')
        if previous == SHAARAWI_VERSION:
            return {'skipped': True, 'added': 0}
        root = next((f for f in lib['folders'] if f.get('preset') == 'radio_root'), None)
        if root is None:
            return {'skipped': True, 'added': 0, 'error': 'Radio folder missing'}
        ids = {x['id'] for x in lib['folders'] + lib['streams']}

        def unique_id():
            while True:
                value = new_id()
                if value not in ids:
                    ids.add(value)
                    return value

        def folder(parent, name, preset):
            target = next((f for f in lib['folders'] if f.get('preset') == preset), None)
            if target is None:
                target = next((f for f in lib['folders'] if f.get('parent') == parent
                               and to_text(f.get('name')) == to_text(name)), None)
            if target is not None:
                target['preset'] = preset
                return target
            siblings = sorted((f for f in lib['folders'] if f.get('parent') == parent),
                              key=store.folder_key)
            target = {'id': unique_id(), 'parent': parent, 'name': name,
                      'provider': 'radio', 'source': None, 'updated': 0, 'preset': preset, 'order_auto': True}
            lib['folders'].append(target)
            for index, item in enumerate(siblings + [target]):
                item['order'] = index * 10
            return target

        target = next((f for f in lib['folders'] if f.get('preset') == 'radio_shaarawi'), None)
        if target is None and previous == 1:
            # A previously installed folder was deliberately deleted. Do not recreate it.
            markers['shaarawi'] = SHAARAWI_VERSION
            lib['presets'] = markers
            store._save(lib)
            return {'skipped': False, 'added': 0, 'moved': 0, 'removed_folders': 0}
        target = target or folder(root['id'], u'الشيخ محمد متولي الشعراوي', 'radio_shaarawi')
        legacy_ids = {f['id'] for f in lib['folders']
                      if f.get('preset') == 'radio_shaarawi_tafsir' and f.get('parent') == target['id']}
        # Move, never delete, the owner's recordings and any custom children.
        moved = 0
        for stream in lib['streams']:
            if stream.get('folder') in legacy_ids:
                stream['folder'] = target['id']
                moved += 1
        for item in lib['folders']:
            if item.get('parent') in legacy_ids:
                item['parent'] = target['id']
        lib['folders'] = [f for f in lib['folders'] if f['id'] not in legacy_ids]

        def seed(destination, entries, preset):
            urls = {_identity(s.get('url', ''), s.get('audio_track', 0))
                    for s in lib['streams'] if s.get('folder') == destination['id']}
            added = 0
            for index, (name, url) in enumerate(entries):
                identity = _identity(url)
                if identity in urls or not store.valid_url(url):
                    continue
                stream = store._normalize({'name': name, 'url': url, 'provider': 'radio',
                                           'kind': 'radio', 'icon_choice': 'folders/quran'})
                stream.update(id=unique_id(), folder=destination['id'], preset=preset,
                              kind='radio', order=index * 10)
                lib['streams'].append(stream)
                urls.add(identity)
                added += 1
            return added

        added = 0
        if previous != 1:
            added = seed(target, ((LIVE_NAME, LIVE_URL),), 'shaarawi_live')
            added += seed(target, RECORDINGS, 'shaarawi_tafsir')
        # Pin the existing built-in live entry first, then the ordered recordings.
        # Apply once so future owner-driven ordering remains untouched.
        siblings = sorted((s for s in lib['streams'] if s.get('folder') == target['id']),
                          key=store.stream_key)
        live = [s for s in siblings if s.get('preset') == 'shaarawi_live'
                or _identity(s.get('url', ''), s.get('audio_track', 0)) == _identity(LIVE_URL)]
        live_ids = {s['id'] for s in live}
        recordings = [s for s in siblings if s['id'] not in live_ids and s.get('preset') == 'shaarawi_tafsir']
        others = [s for s in siblings if s['id'] not in live_ids and s.get('preset') != 'shaarawi_tafsir']
        for index, stream in enumerate(live + recordings + others):
            stream['order'] = index * 10
        markers['shaarawi'] = SHAARAWI_VERSION
        lib['presets'] = markers
        store._save(lib)
        return {'skipped': False, 'added': added, 'folder': target['id'],
                'moved': moved, 'removed_folders': len(legacy_ids)}


TURKISH_RADIO_VERSION = 1

def install_turkish_radio():
    from .turkishradio import install
    return install()
