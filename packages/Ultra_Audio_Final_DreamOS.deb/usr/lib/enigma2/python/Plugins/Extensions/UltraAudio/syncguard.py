# -*- coding: utf-8 -*-
"""Conservative picture-delay policy. Pure observations; no receiver calls here.

This preserves a manually chosen distance behind live. It cannot infer the
content alignment of two independently delivered broadcasts.
"""
from __future__ import division
from collections import deque

from .compat import isfinite

WARMUP = 15.0
WINDOW = 10.0
MIN_SPAN = 7.0
EVALUATE = 6.0
TOLERANCE = 2.0
MAX_STEP = 3.0
COOLDOWN = 30.0
MAX_CORRECTIONS = 6
BUDGET_WINDOW = 600.0


class DelayGuard(object):
    def __init__(self):
        self.corrections = deque()
        self.not_before = 0.0
        self.reset(0.0)

    def reset(self, now, clear_budget=False):
        self.samples = deque()
        self.previous = None
        self.position_at = self.edge_at = now
        self.target = None
        self.direction = self.confirmations = 0
        self.next_evaluation = now + WARMUP
        self.not_before = max(self.not_before, now + WARMUP)
        if clear_budget:
            self.corrections.clear()
            self.not_before = now + WARMUP

    def corrected(self, now):
        self.corrections.append(now)
        self.reset(now)
        self.not_before = now + COOLDOWN

    def observe(self, now, position, length, current, target):
        values = (now, position, length, current, target)
        if (not all(isfinite(x) for x in values) or target <= 0
                or position < 0 or length <= 0 or position > length + 0.25):
            self.reset(now)
            return None
        previous = self.previous
        if previous is not None and now - previous[0] < 0.45:
            return None
        if previous is not None:
            dt, dp, dl = now - previous[0], position - previous[1], length - previous[2]
            # A discontinuity is not a fresh reference delay. Discard its
            # observations, then measure the SAME requested target afresh.
            if (dt > 1.5 or dt <= 0 or dp < -0.25 or dl < -0.25
                    or dp > dt + 2.0 or dl > dt + 4.0 or target != self.target):
                self.reset(now)
            if dp > 0.02:
                self.position_at = now
            if dl > 0.02:
                self.edge_at = now
        self.previous = (now, position, length)
        self.target = target
        if now - self.position_at > 2.5 or now - self.edge_at > 8.0:
            self.samples.clear()
            self.direction = self.confirmations = 0
            self.not_before = max(self.not_before, now + WARMUP)
            return None
        self.samples.append((now, current, position, length))
        while self.samples and now - self.samples[0][0] > WINDOW:
            self.samples.popleft()
        if now < self.not_before or now < self.next_evaluation:
            return None
        self.next_evaluation = now + EVALUATE
        span = now - self.samples[0][0]
        if len(self.samples) < 10 or span < MIN_SPAN:
            return None
        start = self.samples[0]
        picture_rate = (position - start[2]) / span
        edge_rate = (length - start[3]) / span
        delays = sorted(s[1] for s in self.samples)
        # Cached counters, decoder freezes and noisy live-edge estimates must
        # never provoke a seek. Require BOTH counters to advance normally.
        if (not 0.75 <= picture_rate <= 1.25 or not 0.65 <= edge_rate <= 1.35
                or delays[-1] - delays[0] > 0.8):
            self.direction = self.confirmations = 0
            return None
        error = delays[len(delays) // 2] - target
        direction = 1 if error > TOLERANCE else -1 if error < -TOLERANCE else 0
        self.confirmations = self.confirmations + 1 if direction and direction == self.direction else (1 if direction else 0)
        self.direction = direction
        while self.corrections and now - self.corrections[0] >= BUDGET_WINDOW:
            self.corrections.popleft()
        if self.confirmations < 3 or len(self.corrections) >= MAX_CORRECTIONS:
            return None
        delta = max(-MAX_STEP, min(MAX_STEP, error))
        # Stay inside recorded media; never ask the receiver to jump to live
        # or behind the beginning of a short buffer.
        if (delta > 0 and length - position < delta + 0.5) or (delta < 0 and position < -delta + 0.5):
            return None
        return delta
