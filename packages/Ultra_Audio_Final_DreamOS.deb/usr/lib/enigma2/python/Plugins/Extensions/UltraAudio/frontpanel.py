# -*- coding: utf-8 -*-
"""Static plugin identity on Enigma2's own front-display summary stack."""
from __future__ import division
import os
from xml.sax.saxutils import escape

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import getDesktop
from .compat import native, skin_scale_attr, ui_pixmap_path
from .uifont import face as ui_face


_ICON = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugin.png")


def _display_geometry():
    try:
        desktop = getDesktop(1)
        size = desktop.size() if desktop is not None else None
        width = int(size.width()) if size is not None else 0
        height = int(size.height()) if size is not None else 0
        if width > 0 and height > 0:
            return width, height
    except Exception:
        pass
    return 132, 64


def _summary_skin(width, height):
    width, height = max(1, int(width)), max(1, int(height))
    screen = ('<screen name="UltraAudioFrontSummary" position="0,0" size="%d,%d" '
              'backgroundColor="#000000" flags="wfNoBorder">') % (width, height)
    if width >= 220 and height >= 100 and os.path.isfile(_ICON):
        factor = min(1.0, (width * 0.90) / 400.0, (height * 0.75) / 160.0)
        logo_w, logo_h = max(1, int(400 * factor)), max(1, int(160 * factor))
        icon_path = ui_pixmap_path(_ICON, logo_w, logo_h)
        screen += ('<widget name="logo" position="%d,%d" size="%d,%d" '
                   'pixmap="%s" alphatest="blend"%s transparent="1"/>') % (
                       (width - logo_w) // 2, (height - logo_h) // 2,
                       logo_w, logo_h, escape(icon_path, {'"': '&quot;'}), skin_scale_attr())
    else:
        margin = 2 if width > 8 else 0
        content_w = width - 2 * margin
        font = max(1, min(18, height - 2, int(content_w / 6.5)))
        screen += ('<widget name="title" position="%d,0" size="%d,%d" '
                   'font="Regular;%d" halign="center" valign="center" '
                   'foregroundColor="#FFFFFF" backgroundColor="#000000" noWrap="1"/>') % (
                       margin, content_w, height, font)
    return native((screen + '</screen>').replace('font="Regular;', 'font="%s;' % ui_face()))


class UltraAudioFrontSummary(Screen):
    """The session restores its previous summary when UltraAudio closes."""

    def __init__(self, session, parent):
        self.skin = _summary_skin(*_display_geometry())
        Screen.__init__(self, session)
        if 'name="logo"' in str(self.skin):
            self["logo"] = Pixmap()
        else:
            self["title"] = Label(native("UltraAudio"))
