# -*- coding: utf-8 -*-
"""Stable, bundled icon identities shared by the web picker and receiver list."""
from __future__ import division
import os
import re
from .compat import lru_cache, string_types, to_text

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
_KEY = re.compile(r"^(logos|folders)/([a-z0-9_-]+)$")


def resolve(key, scale=1.0):
    """Resolve a catalog identity, never a user-supplied filesystem path."""
    if not isinstance(key, string_types) or not _KEY.match(to_text(key)):
        return None
    family, stem = to_text(key).split("/")
    # Preserve saved choices while retiring their numbered artwork.
    if family == "logos":
        stem = {"shasha1": "shasha", "shasha2": "shasha",
                "alrabiaa1": "alrabiaa", "alrabiaa2": "alrabiaa"}.get(stem, stem)
        if stem == "mbcmasr2":
            return None
    base = os.path.join(ASSETS, family, stem + ".png")
    if not os.path.isfile(base):
        return None
    if scale >= 2.8:
        suffixes = ("@4x", "@2x")
    elif scale >= 1.4:
        suffixes = ("@2x",)
    elif scale >= 1.15:
        suffixes = ("@wqhd", "@2x")
    elif scale < 0.85:
        suffixes = ("@hd",)
    else:
        suffixes = ()
    for suffix in suffixes:
        sharp = os.path.join(ASSETS, family, stem + suffix + ".png")
        if os.path.isfile(sharp):
            return sharp
    return base


def key_for_path(path):
    if not path or not path.startswith(ASSETS + os.sep):
        return None
    rel = os.path.relpath(path, ASSETS).replace(os.sep, "/")
    key = re.sub(r"(?:@(?:hd|wqhd|[24]x))?\.png$", "", rel)
    return key if resolve(key) else None


def label(key):
    stem = to_text(key).split("/")[-1]
    names = {"radio": "RADIO", "quran": "QURAN", "satfamily": "SAT FAMILY", "foxfm": "FOX FM",
             "anis": "Anis", "best": "BEST", "orange": "ORANGE", "generic": "Ultra Audio",
             "live": "LIVE", "event": "EVENT", "match": "MATCH", "shahid": "Shahid",
             "starzplay": "STARZPLAY", "mbcaction": "MBC ACTION", "shasha": "Shasha", "alrabiaa": "Al Rabiaa"}
    if stem in names:
        return names[stem]
    match = re.match(r"^([a-z]+)([0-9]+)$", stem)
    if match:
        family, number = match.groups()
        title = {"bein": "beIN SPORTS", "xtra": "beIN SPORTS XTRA", "max": "beIN SPORTS MAX",
                 "en": "beIN SPORTS ENGLISH", "fr": "beIN SPORTS FRENCH", "alkass": "Al Kass",
                 "thmanyah": "Thmanyah", "ssc": "SSC", "ad": "Abu Dhabi SPORTS",
                 "mbcmasr": "MBC MASR", "shasha": "Shasha", "alrabiaa": "Al Rabiaa"}.get(family, family.upper())
        return "%s %s" % (title, number)
    return stem.upper()


@lru_cache(maxsize=1)
def catalog():
    choices = []
    for family in ("logos", "folders"):
        directory = os.path.join(ASSETS, family)
        try:
            files = os.listdir(directory)
        except EnvironmentError:
            continue
        for name in files:
            if not re.match(r"^[a-z0-9_-]+\.png$", name):
                continue
            if family == "logos" and name[:-4] in ("shasha1", "shasha2", "alrabiaa1", "alrabiaa2", "mbcmasr2"):
                continue
            key = family + "/" + name[:-4]
            if resolve(key):
                choices.append((key, label(key)))

    def order(choice):
        key, title = choice
        natural = re.sub(r"\d+", lambda m: m.group().zfill(5), title.lower())
        return (key.startswith("folders/"), natural, key)
    return tuple(sorted(choices, key=order))
