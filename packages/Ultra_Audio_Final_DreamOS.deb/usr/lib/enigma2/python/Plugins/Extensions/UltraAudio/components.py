# -*- coding: utf-8 -*-
"""Standalone installation probes. --imports bootstraps without optional imports.

Supports both Python 2.7 (DreamOS OE2.5/OE2.6) and Python 3.x images.
Never opens/mutes a sound device. Decode fixtures are generated test tones.
No packages are installed by this module; deps.sh owns the image feed operations.
"""
from __future__ import print_function, division

import os
import struct
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
PY2 = sys.version_info[0] == 2

PY2_MODULE_ALIASES = {
    'socketserver': 'SocketServer',
    'http.client': 'httplib',
    'http.server': 'BaseHTTPServer',
    'urllib.request': 'urllib2',
    'urllib.error': 'urllib2',
    'urllib.parse': 'urlparse',
    'queue': 'Queue',
    'html.parser': 'HTMLParser',
}


def _which(cmd):
    for d in os.environ.get('PATH', '').split(os.pathsep) + ['/usr/local/bin', '/usr/sbin', '/usr/bin', '/sbin', '/bin']:
        if d:
            p = os.path.join(d, cmd)
            if os.path.isfile(p) and os.access(p, os.X_OK):
                return p
    return None


def import_probe():
    missing = []
    with open(os.path.join(ROOT, 'components.map')) as handle:
        for line in handle:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            name = line.split('|', 1)[0]
            actual = PY2_MODULE_ALIASES.get(name, name) if PY2 else name
            try:
                __import__(actual)
            except Exception as exc:
                missing.append(name)
                print('missing:' + name)
                print('detail:%s: %s' % (name, str(exc).replace('\n', ' ')[:160]))
    print('imports:' + ('missing' if missing else 'ok'))
    return 2 if missing else 0


def package_candidates(name):
    mapping = {}
    with open(os.path.join(ROOT, 'components.map')) as handle:
        for line in handle:
            if line.strip() and not line.startswith('#'):
                key, packages = line.strip().split('|', 1)
                mapping[key] = packages.split(',')
    packages = mapping.get(name, [])
    version = sys.version_info[:2]
    if PY2:
        packages = [p.replace('python3-', 'python-') for p in packages]
    else:
        core_first = ((name == 'glob' and version >= (3, 13)) or
                      (name in ('shutil', 'zlib') and version >= (3, 8)) or
                      (name == 'fcntl' and version >= (3, 13)))
        if name == 'zlib' and version < (3, 8):
            packages = ['python3-compression', 'python3-core']
        elif core_first and 'python3-core' in packages:
            packages.remove('python3-core')
            packages.insert(0, 'python3-core')
    print(','.join(packages))
    return 0 if packages else 2


def environment():
    import json
    import platform
    import re
    import subprocess
    import sysconfig
    info = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
            'abi': sysconfig.get_config_var('SOABI') or '', 'architecture': platform.machine(),
            'bits': 64 if sys.maxsize > 2 ** 32 else 32, 'image': ''}
    for path in ['/etc/image-version', '/etc/os-release', '/etc/issue']:
        try:
            with open(path) as f:
                info['image'] += f.read(4096).strip() + '\n'
        except EnvironmentError:  # Python 2 raises IOError for a missing file (e.g. no /etc/image-version on DreamOS)
            pass
    embedded = set()
    try:
        p = subprocess.Popen(['pidof', 'enigma2'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, _ = p.communicate()
        pids = out.decode('utf-8', 'replace').split()
        for pid in pids:
            with open('/proc/%s/maps' % pid) as f:
                embedded.update(re.findall(r'libpython([23]\.[0-9]+)', f.read()))
    except Exception:
        pass
    info['enigma_python'] = sorted(embedded)
    print('environment:' + json.dumps(info, ensure_ascii=True, sort_keys=True))
    if embedded and '%d.%d' % sys.version_info[:2] not in embedded:
        print('environment:error: interpreter differs from running Enigma2')
        return 2
    return 0


def audio_probe():
    import glob
    import json
    import re
    import subprocess
    import threading
    needs, messages = [], []
    devnull = getattr(subprocess, 'DEVNULL', None) or open(os.devnull, 'r+b')
    py_prefix = 'python-' if PY2 else 'python3-'

    def run(args, timeout=8):
        try:
            p = subprocess.Popen(args, stdin=devnull, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            box = {}

            def talk():
                try:
                    box['out'] = p.communicate()
                except Exception as e:
                    box['err'] = e

            t = threading.Thread(target=talk)
            t.daemon = True
            t.start()
            t.join(timeout)
            if t.is_alive():
                try:
                    p.kill()
                except OSError:
                    pass
                return False, b'', 'probe timed out'
            out, err = box.get('out', (b'', b''))
            return p.returncode == 0, out, err.decode('utf-8', 'replace').strip()[:240]
        except OSError as exc:
            return False, b'', str(exc)[:240]

    def has_samples(pcm, fmt='s16le'):
        if fmt == 'wav':
            pos = 12
            while pos + 8 <= len(pcm):
                tag = pcm[pos:pos + 4]
                size = struct.unpack('<I', pcm[pos + 4:pos + 8])[0]
                if tag == b'data':
                    pcm = pcm[pos + 8:]
                    break
                pos += 8 + size + (size % 2)
            else:
                return False
        return len(pcm) >= 4096 and any(bytearray(pcm[:8192]))

    def need(key, packages):
        if key not in [n[0] for n in needs]:
            needs.append((key, packages))

    pywriter = run([sys.executable, '-E', '-s', os.path.join(ROOT, 'pcmplay.py'), '--check'])[0]
    aplay = _which('aplay')
    aplay_ok = bool(aplay and run([aplay, '--version'])[0])
    from audiohw import playback_devices
    has_alsa_device = bool(playback_devices() or os.path.exists('/dev/dsp'))
    has_dvb_device = bool(glob.glob('/dev/dvb/adapter*/audio*'))
    inspect_dvb = _which('gst-inspect-1.0')
    dvb_sink = bool(inspect_dvb and run([inspect_dvb, 'dvbaudiosink'], 8)[0])
    need_dvb = has_dvb_device and not has_alsa_device
    ff = _which('ffmpeg')
    ff_ok, ff_error, formats = False, '', {}
    if ff:
        ok, out, err = run([ff, '-version'])
        if not ok:
            ff_error = err or out.decode('utf-8', 'replace')[:240]
        else:
            ok, out, err = run([ff, '-hide_banner', '-formats'])
            if ok:
                for line in out.decode('utf-8', 'replace').splitlines():
                    parts = line.split(None, 2)
                    if len(parts) >= 2 and re.match(r'^[DEd.]+$', parts[0]):
                        for name in parts[1].split(','):
                            formats[name] = (bool('D' in parts[0]), bool('E' in parts[0]))
            ok, proto, err = run([ff, '-hide_banner', '-protocols'])
            protocols = set(proto.decode('utf-8', 'replace').split()) if ok else set()
            fmt = next((f for f in ('s16le', 'wav') if formats.get(f, (0, 0))[1]), None)
            ff_ok = bool(fmt and {'http', 'https'} <= protocols and
                         all(formats.get(f, (0, 0))[0] for f in ('hls', 'mpegts')))
            if ff_ok:
                for ext in ('aac', 'mp3'):
                    args = [ff, '-hide_banner', '-loglevel', 'error', '-nostdin',
                            '-i', os.path.join(ROOT, 'assets', 'checks', 'audio.' + ext),
                            '-map', '0:a:0', '-vn', '-af',
                            'aformat=channel_layouts=stereo,volume=0.5,aresample=48000,aformat=sample_fmts=s16:channel_layouts=stereo',
                            '-ac', '2', '-ar', '48000', '-c:a', 'pcm_s16le', '-f', fmt, 'pipe:1']
                    ok, pcm, err = run(args)
                    if not ok or not has_samples(pcm, fmt):
                        ff_ok, ff_error = False, '%s decode/PCM: %s' % (ext, err or 'no PCM samples')
                        break
            elif not ff_error:
                ff_error = 'missing PCM muxer, HTTP/HTTPS or HLS/TS demuxer'
    else:
        ff_error = 'not installed'
    direct_ff = bool(formats.get('alsa', (0, 0))[1])
    ff_ready = ff_ok and (pywriter or aplay_ok or direct_ff)
    gst_ready, gi_ready = False, None
    if not ff_ready:
        gst = _which('gst-launch-1.0')
        inspect = _which('gst-inspect-1.0')
        catalogue = {}

        def has(element):
            if element not in catalogue:
                catalogue[element] = bool(inspect and run([inspect, element], 5)[0])
            return catalogue[element]

        def element(name, packages):
            if not has(name):
                need(name, packages)
                return False
            return True

        gst_runs = bool(gst and run([gst, '--version'])[0])
        if not gst_runs or not inspect:
            need('gstreamer-tools', 'gstreamer1.0-tools,gstreamer1.0')
        common = [
            ('decodebin', 'gstreamer1.0-plugins-base-playback,gstreamer1.0-plugins-base'),
            ('uridecodebin', 'gstreamer1.0-plugins-base-playback,gstreamer1.0-plugins-base'),
            ('audioconvert', 'gstreamer1.0-plugins-base-audioconvert,gstreamer1.0-plugins-base'),
            ('audioresample', 'gstreamer1.0-plugins-base-audioresample,gstreamer1.0-plugins-base'),
            ('fdsink', 'gstreamer1.0-plugins-base-coreelements,gstreamer1.0'),
            ('filesrc', 'gstreamer1.0-plugins-base-coreelements,gstreamer1.0'),
            ('capsfilter', 'gstreamer1.0-plugins-base-coreelements,gstreamer1.0'),
            ('souphttpsrc', 'gstreamer1.0-plugins-good-souphttpsrc,gstreamer1.0-plugins-good-soup,gstreamer1.0-plugins-good'),
            ('aacparse', 'gstreamer1.0-plugins-bad-audioparsers,gstreamer1.0-plugins-good-audioparsers,gstreamer1.0-plugins-bad,gstreamer1.0-plugins-good'),
            ('mpegaudioparse', 'gstreamer1.0-plugins-good-audioparsers,gstreamer1.0-plugins-good'),
            ('tsdemux', 'gstreamer1.0-plugins-bad-mpegtsdemux,gstreamer1.0-plugins-bad'),
            ('qtdemux', 'gstreamer1.0-plugins-good-isomp4,gstreamer1.0-plugins-good'),
            ('typefind', 'gstreamer1.0-plugins-base-coreelements,gstreamer1.0')]
        present = [element(name, packages) for name, packages in common]
        if not (has('hlsdemux') or has('hlsdemux2')):
            need('hlsdemux', 'gstreamer1.0-plugins-bad-hls,gstreamer1.0-plugins-good-adaptivedemux2,gstreamer1.0-plugins-bad')
            present.append(False)
        if not any(has(e) for e in ('avdec_aac', 'avdec_aac_fixed', 'faad', 'fdkaacdec')):
            need('aac-decoder', 'gstreamer1.0-libav,gstreamer1.0-plugins-bad-faad,gstreamer1.0-plugins-bad-fdkaac,gstreamer1.0-plugins-bad')
            present.append(False)
        if not any(has(e) for e in ('mpg123audiodec', 'avdec_mp3', 'avdec_mp3float', 'mad')):
            need('mp3-decoder', 'gstreamer1.0-libav,gstreamer1.0-plugins-ugly-mpg123,gstreamer1.0-plugins-ugly-mad,gstreamer1.0-plugins-ugly')
            present.append(False)
        try:
            import audioop
            soft_gain = True
        except ImportError:
            soft_gain = False
        if not soft_gain:
            present.append(element('volume', 'gstreamer1.0-plugins-base-volume,gstreamer1.0-plugins-base'))
        sink = pywriter or aplay_ok or has('alsasink')
        if not sink:
            need('alsa-library', 'libasound2,alsa-lib')
            need('alsa-output', 'alsa-utils-aplay,alsa-utils,gstreamer1.0-plugins-base-alsa')
        gst_ready = bool(gst_runs and all(present) and sink)
        if gst_ready:
            for ext in ('aac', 'mp3'):
                args = [gst, '-q', 'filesrc', 'location=' + os.path.join(ROOT, 'assets', 'checks', 'audio.' + ext),
                        '!', 'decodebin', 'caps=audio/x-raw', 'expose-all-streams=false', '!',
                        'audioconvert', '!', 'audioresample', '!',
                        'audio/x-raw,format=S16LE,rate=48000,channels=2,layout=interleaved', '!', 'fdsink', 'fd=1', 'sync=false']
                ok, pcm, err = run(args)
                if not ok or not has_samples(pcm):
                    gst_ready = False
                    messages.append('GStreamer %s decode failed: %s' % (ext, err or 'no PCM samples'))
                    need('gst-codecs', 'gstreamer1.0-libav')
                    break
        try:
            data_dir = os.environ.get('ULTRAAUDIO_DATA', '/etc/enigma2/ultraaudio')
            with open(os.path.join(data_dir, 'library.json')) as f:
                streams = json.load(f).get('streams', [])
            tracks_needed = any(int(s.get('audio_track', 0)) > 0 for s in streams)
        except Exception:
            tracks_needed = False
        if tracks_needed:
            gi_ready = run([sys.executable, '-E', '-s', os.path.join(ROOT, 'gstplay.py'), '--check'])[0]
            if not gi_ready:
                gst_ready = False
                need('python-gst-bindings', '%spygobject,%spygobject-core,%sgst-1.0,python-gi' % (py_prefix, py_prefix, py_prefix))
    if not ff_ok:
        need('ffmpeg', 'ffmpeg')
    if ff_ok and not (pywriter or aplay_ok or direct_ff):
        need('alsa-library', 'libasound2,alsa-lib')
        need('alsa-output', 'alsa-utils-aplay,alsa-utils')
    dvb_launcher = _which('gst-launch-1.0')
    # On DVB-only receivers (like Dreambox), either GStreamer dvbaudiosink OR FFmpeg PES direct writer satisfies DVB output.
    dvb_pes_ok = has_dvb_device and ff_ok
    ready = (ff_ready or gst_ready) and (not need_dvb or (dvb_sink and dvb_launcher) or dvb_pes_ok)
    if need_dvb and not dvb_sink and not dvb_pes_ok:
        need('dvb-output', 'gst-plugin-dvbmediasink,gstreamer1.0-plugin-dvbmediasink,ffmpeg')
    if need_dvb and not dvb_pes_ok and (not inspect_dvb or not dvb_launcher):
        need('dvb-tools', 'gstreamer1.0')
    recommends = []
    if need_dvb and inspect_dvb:
        if not any(run([inspect_dvb, e], 5)[0] for e in ('rawaudioparse', 'wavparse')):
            recommends.append(('dvb-pcm-parse', 'gstreamer1.0-plugins-base-rawparse,gstreamer1.0-plugins-bad-rawparse,gstreamer1.0-plugins-good-wavparse'))
        if not any(run([inspect_dvb, e], 5)[0] for e in ('avenc_mp2', 'avenc_aac', 'twolamemp2enc', 'lamemp3enc')):
            recommends.append(('dvb-gst-encoder', 'gstreamer1.0-libav'))
        if not run([sys.executable, '-E', '-s', os.path.join(ROOT, 'gstplay.py'), '--check'])[0]:
            recommends.append(('python-gst-bindings', '%spygobject,%spygobject-core,%sgst-1.0' % (py_prefix, py_prefix, py_prefix)))
    data = {'python': '%d.%d' % sys.version_info[:2], 'ready': bool(ready),
            'pipeline': 'ffmpeg' if ff_ready and ready else 'gstreamer' if gst_ready and ready else 'none',
            'ffmpeg_pcm_test': bool(ff_ok), 'ffmpeg_error': ff_error,
            'python_alsa_writer': bool(pywriter), 'aplay': bool(aplay_ok),
            'gstreamer_pcm_test': bool(gst_ready), 'gi_track_selection': gi_ready,
            'dvb_audio_required': need_dvb, 'dvb_sink': dvb_sink or dvb_pes_ok,
            'hardware_audio_tested': False, 'messages': messages}
    print('audio:' + json.dumps(data, ensure_ascii=True, sort_keys=True))
    if not ready:
        for key, packages in needs:
            print('need:' + key + '|' + packages)
    for key, packages in recommends:
        print('recommend:' + key + '|' + packages)
    print('pipeline:' + data['pipeline'])
    return 0 if ready else 2


def runtime_probe():
    sys.path.insert(0, os.path.dirname(ROOT))
    package = os.path.basename(ROOT)
    failed = False
    for module in ('compat', 'store', 'engine', 'guide', 'importer', 'updater', 'webui'):
        try:
            __import__(package + '.' + module)
        except Exception as exc:
            print('runtime:missing:%s: %s' % (module, str(exc).replace('\n', ' ')[:200]))
            failed = True
    print('runtime:' + ('failed' if failed else 'ok'))
    return 2 if failed else 0


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else '--imports'
    if mode == '--candidates' and len(sys.argv) == 3:
        sys.exit(package_candidates(sys.argv[2]))
    action = {'--imports': import_probe, '--environment': environment,
              '--audio': audio_probe, '--runtime': runtime_probe}.get(mode)
    if action is None:
        sys.exit(64)
    sys.exit(action())
