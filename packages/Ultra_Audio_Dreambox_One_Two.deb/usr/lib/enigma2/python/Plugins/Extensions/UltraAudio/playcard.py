# -*- coding: utf-8 -*-
"""Geometry of the vertical mini playback card (bottom-right corner).

Plain Python with no Enigma2 imports: the on-box screen (playbackbar.py) and the offline artwork
generator both read these numbers, so the baked PNGs and the live widgets always line up.
All boxes are FHD design pixels, (x, y, w, h), relative to the card's top-left corner.
"""
from __future__ import division
import math

GLOW = 18                                   # transparent margin around the card for the baked glow/shadow
CARD_W, CARD_H = 392, 662
SCREEN_W, SCREEN_H = CARD_W + 2 * GLOW, CARD_H + 2 * GLOW
MARGIN_RIGHT, MARGIN_BOTTOM = GLOW, GLOW    # tucked into the bottom-right corner: only the glow margin is left
PAD = 22
INNER_W = CARD_W - 2 * PAD
RADIUS = 26

BRAND = (PAD, 18, 180, 32)                   # the theme's own ULTRA AUDIO mark, in the theme colour
CLOCK = (CARD_W - PAD - 140, 6, 140, 44)        # raised a little: digits have no descenders to fill the box
HAIR_Y = 60
ICON = ((CARD_W - 160) // 2, 72, 160, 96)    # the TV channel's picon (5:3, like 220x132 picons)
ICON_FALLBACK = ((CARD_W - 160) // 2, 76, 160, 88)   # the stream's bundled 160x88 icon when no picon is found
NAME = (PAD, 172, INNER_W, 32)
EQ_W, EQ_H, EQ_GAP = 96, 40, -6                # three animated equalizer frames side by side under the name
EQ = tuple(((CARD_W - 3 * EQ_W - 2 * EQ_GAP) // 2 + i * (EQ_W + EQ_GAP), 208, EQ_W, EQ_H) for i in range(3))

EVENT = (PAD, 258, INNER_W, 116)
EVENT_RADIUS = 16
TIME = (PAD + 14, 268, INNER_W - 28, 23)
GUIDE = ((PAD + 14, 298, INNER_W - 28, 26), (PAD + 14, 324, INNER_W - 28, 26))
BAR = (PAD + 14, 360, INNER_W - 28, 8)

TILE_W, TILE_H = 168, 200
TILE_RADIUS = 18
TILES = (('picture', (PAD, 386)), ('audio', (PAD + 180, 386)))
# inside one tile
T_CAPTION = (0, 8, TILE_W, 22)
T_DASH = ((TILE_W - 28) // 2, 33, 28, 3)
T_DIAL = ((TILE_W - 104) // 2, 40, 104, 104)
T_VALUE = (8, 70, TILE_W - 16, 32)
T_UNIT = (8, 102, TILE_W - 16, 18)
T_PILLS = ((8, 152, 72, 36), (88, 152, 72, 36))          # minus, plus
T_NUM = (4, 2, 32, 32)                                   # remote number icon inside a pill
FOCUS_GLOW = 10

FOOTER = (('freeze', (PAD, 598, 168, 46)), ('stop', (PAD + 180, 598, 168, 46)))
F_ICON = (14, 11, 24, 24)
F_CAPTION = (44, 0, 112, 46)

KEY_COLORS = {'picture': '#FFD24A', 'audio': '#3FA9FF', 'freeze': '#2FE08A', 'stop': '#FF4D5E'}

# dial: 270 degree sweep from bottom-left (PIL angles: 0 = three o'clock, clockwise)
DIAL_START, DIAL_SWEEP = 135.0, 270.0
DIAL_FRAMES = 32
BAR_FRAMES = 40
DIAL_CENTER = 52
DIAL_ARC_R, DIAL_ARC_W = 43.0, 4.0
DIAL_TICK_R = (47.0, 51.0)
DIAL_DISK_R = 37.0


def tile_box(kind, box):
    """A box inside a tile -> card coordinates."""
    ox, oy = dict(TILES)[kind]
    return (ox + box[0], oy + box[1], box[2], box[3])


def placement(desktop_w, desktop_h):
    """(x, y, w, h, scale) of the whole screen (card + glow margin) for this desktop."""
    scale = min(desktop_w / 1920.0, desktop_h / 1080.0)
    n = lambda v: max(1, int(round(v * scale)))
    w, h = n(SCREEN_W), n(SCREEN_H)
    x = desktop_w - n(MARGIN_RIGHT) - n(CARD_W) - n(GLOW)
    y = desktop_h - n(MARGIN_BOTTOM) - n(CARD_H) - n(GLOW)
    return max(0, x), max(0, y), w, h, scale


def dial_frame(kind, value):
    """Arc frame for a delay: grows quickly for small delays and keeps moving for long ones, never wraps."""
    try:
        v = max(0.0, float(value or 0))
    except (TypeError, ValueError):
        v = 0.0
    if v <= 0:
        return 0
    span = 20.0 if kind == 'picture' else 8000.0      # seconds / milliseconds that fill ~63% of the arc
    return max(1, min(DIAL_FRAMES, int(round((1.0 - math.exp(-v / span)) * DIAL_FRAMES))))


def bar_frame(done):
    return max(0, min(BAR_FRAMES, int(round(max(0.0, min(1.0, done)) * BAR_FRAMES))))
