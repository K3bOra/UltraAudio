# -*- coding: utf-8 -*-
"""On-box screen: slim top bar, list of folders / audio links on the left (flush between the bars), slim key bar at the
bottom. The rest is transparent so the TV picture stays visible.

The Classic theme is the available layout."""
from __future__ import division
import os
import time

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.MultiContent import MultiContentEntryText
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from enigma import RT_HALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eListboxPythonMultiContent, eTimer, getDesktop, gFont

try:
    from enigma import BT_ALIGN_CENTER, BT_KEEP_ASPECT_RATIO, BT_SCALE
    _PIX_FLAGS = BT_SCALE | BT_KEEP_ASPECT_RATIO | BT_ALIGN_CENTER
    _PIX_STRETCH = BT_SCALE
except ImportError:  # old images
    _PIX_FLAGS = 0
    _PIX_STRETCH = 0

from . import ctl, guide, store, themes, webui
from . import uifont
from .receiverimage import receiver_image_label
from .motion import PlaybackMarker, visible_row
from .compat import (connect_timer, lru_cache, mark_user_input, mc_pixmap, native,
                     skin_scale_attr, string_types, to_text, ui_pixmap_path, user_input_idle)
from .i18n import T, lang
from .menu import MenuOverlay, skin_parts as menu_skin
from .footballcard import FootballCard, skin_parts as football_skin
from .livefootball import SCORES as LIVE_SCORES

UI = os.path.join(store.ASSETS, "ui")
MINT, GOLD, RED, MUTED, TEXT, WHITE = "#00FF88", "#FFE29A", "#FF5E66", "#D1DDD7", "#FFFFFF", "#FFFFFF"
_STATE_COLORS = {"playing": MINT, "starting": GOLD, "retrying": GOLD, "stopping": GOLD, "error": RED, "idle": WHITE}
# Same bar + key dashes as the plugin's footer: a 1840x64 bar whose PNG has 1 transparent row top and bottom, so the
# top bar at y=1 and the bottom bar at y=1015 leave exactly 2 px free at the screen edges.
TOP_X, TOP_Y, BAR_W, BAR_H = 40, 1, 1840, 64
DOCK_Y = 1015
LIST_Y, LIST_W = TOP_Y + BAR_H - 1, 600
# TV channel name in the top bar: up to 560px, centred on the screen (960); the live equalizer sits midway between the
# folder path and it. _place_marker sizes the path, the name and the equalizer to the texts actually shown.
HSTATE_X, HSTATE_W = 680, 560
EQ_W, EQ_H, EQ_GAP, CRUMB_X = 96, 40, 14, 330
LIST_H = (DOCK_Y + 1) - LIST_Y                 # rounded PNG insets leave a subpixel seam beside each bar
ROW_W, ROW_H, ROWS = LIST_W - 24, 104, 9       # big 160x88 icons: 9 rows fill the panel
ICON_W, ICON_H = 160, 88
GRID_COLS, GRID_ROWS = 2, 5
GRID_X, GRID_Y = TOP_X + 12, LIST_Y + 12
GRID_GAP, GRID_PITCH_Y, GRID_TILE_H = 8, 160, 150
GRID_PITCH_X = (ROW_W + GRID_GAP) // GRID_COLS
GRID_TILE_W = GRID_PITCH_X - GRID_GAP
GRID_GUIDE_Y = GRID_Y + GRID_ROWS * GRID_PITCH_Y + 9
GRID_GUIDE_H = DOCK_Y - GRID_GUIDE_Y - 12
GRID_GUIDE_ICON_W, GRID_GUIDE_ICON_H = 108, 59
GRID_LABELS = ("grid_guide_tag", "grid_guide_title", "grid_guide_time")
_pix_cache = {}
AUDIO_SETTLE = 0.55         # a short rest after the last 4 / 6 press, then the new audio delay is applied (live)
PICTURE_SETTLE = 0.85        # 1 / 3 add up the same way: the picture moves once, after the presses rest


def state_label(state):
    """Status word of the top bar, in capitals (Arabic has no capitals)."""
    return {"idle": lambda: T("Idle"), "starting": lambda: T("Starting"), "playing": lambda: T("Playing"),
            "retrying": lambda: T("Reconnecting"), "stopping": lambda: T("Stopping"),
            "error": lambda: T("Error")}.get(state, lambda: str(state))().upper()
_last_cwd = ""
_resume_menu = None          # the MENU row to open again after the screen reopened itself (theme / language change)
_resume_cwd = None           # Preserve navigation only for an internal UI/font rebuild.
_resume_selection = None     # folder cursor positions, consumed by the replacement screen only


def active_stream_location():
    """Return the actually playing audio folder and stream, not just the last visited folder.

    Never persist stale UI navigation as the current stream; a closed audio player
    must open at the Library root. Avoid restoring a deleted/moved channel.
    """
    try:
        st = ctl.get().engine.status()
        if st.get("state") not in ("playing", "starting", "retrying"):
            return None
        sid = st.get("stream_id")
        s = (store.get_stream_readonly(sid) if hasattr(store, "get_stream_readonly") else store.get_stream(sid)) if sid else None
        if not s:
            return None
        fid = s.get("folder", "") or ""
        if fid and not (store.get_folder_readonly(fid) if hasattr(store, "get_folder_readonly") else store.get_folder(fid)):
            fid = ""
        return fid, sid
    except Exception:
        return None


@lru_cache(maxsize=512)
def _bundled_scaled_pixmap(path, w, h):
    resolved = ui_pixmap_path(path, w, h) if (w and h and path) else path
    return _bundled_pixmap(resolved) if resolved else None


def _pixmap(path, w=None, h=None):
    if path and path.startswith(store.ASSETS + os.sep):
        return _bundled_scaled_pixmap(path, w, h)
    resolved = ui_pixmap_path(path, w, h) if (w and h and path) else path
    if resolved and resolved.startswith(store.ASSETS + os.sep):
        return _bundled_pixmap(resolved)
    try:
        key = (resolved, os.path.getmtime(resolved))
    except EnvironmentError:
        return None
    if key not in _pix_cache:
        _pix_cache[key] = LoadPixmap(native(resolved))
    return _pix_cache[key]


@lru_cache(maxsize=512)
def _frame_path(path, w, h):
    folder, name = os.path.split(path)
    tw, th = max(1, int(w)), max(1, int(h))
    sized = os.path.join(folder, "%dx%d" % (tw, th), name)
    if os.path.isfile(sized):
        return sized
    if tw < 200:
        hd_sized = os.path.join(folder, "165x9", name)
        if os.path.isfile(hd_sized):
            return hd_sized
    elif tw > 280:
        wqhd_sized = os.path.join(folder, "331x18", name)
        if os.path.isfile(wqhd_sized):
            return wqhd_sized
    return path


@lru_cache(maxsize=512)
def _bundled_pixmap(path):
    # Package artwork is immutable until GUI restart; no stat per row.
    return LoadPixmap(native(path))


def _playing_key(pixels):
    name = "identity_%d.png" % pixels
    return name if os.path.isfile(os.path.join(UI, name)) else "identity.png"


def _number_key(key, pixels):
    """Use a prefiltered ring at the actual widget size, avoiding receiver PNG scaling artifacts."""
    if pixels == 48:
        return "num_%s.png" % key
    name = "num_%s_%d.png" % (key, pixels)
    return name if os.path.isfile(os.path.join(UI, name)) else "num_%s.png" % key


KEY_TWIN_S = 0.6          # another GREEN / RED ... within this time (make + repeat) is the same press
PROGRESS_STEPS = 32
# The logo's own saturated green (0x00DA7F) holds for the first half of the match, then turns through amber and
# orange into the logo's red (0xEF041D), mixed in OKLCH at full chroma (a plain mix goes muddy, a hue sweep from the
# start goes rainbow). Indexed by the position along the WHOLE track.
PROGRESS_RAMP = (0x00DA7F,) * 17 + (0x06DA79, 0x1CD866, 0x22D62F, 0x6CCB14, 0x8FBD09, 0xA4B000, 0xB2A313, 0xBC9703,
                                    0xC38B11, 0xCA7D00, 0xD16F07, 0xD95E00, 0xE14B06, 0xEC2C00, 0xF00B13, 0xEF041D)


def _progress_tone(t):
    t = max(0.0, min(1.0, t))
    return PROGRESS_RAMP[int(round(t * (len(PROGRESS_RAMP) - 1)))]


def _live_card(width, height):
    """The red LIVE card with its word (LIVE / مباشر / CANLI / DIRECT) baked in, at native pixels when available."""
    code = lang() if lang() in ("ar", "tr", "fr") else "en"
    return ui_pixmap_path(os.path.join(store.ASSETS, "ui", "live_pill_%s.png" % code), width, height)


PLAYING_RED = 0xE65A60    # the list's colour for the playing stream's guide; the grid uses it for the name
LASER_BG = 0x1E2A26       # the list panel behind the line: the laser's halo fades towards it


def _mix(a, b, t):
    """Mix two 0xRRGGBB colours (t = 0 -> a, 1 -> b)."""
    return sum(int(round(((a >> sh) & 255) + (((b >> sh) & 255) - ((a >> sh) & 255)) * t)) << sh for sh in (16, 8, 0))


def build_skin(k, th=None, grid=False):
    """Skin in FHD design coordinates, multiplied by k for other desktop sizes.

    Layout: slim top bar 2px from the top edge, slim key bar 2px from the bottom edge, and the list panel filling
    everything between them on the left (flush with both bars). The rest of the screen stays transparent so the
    TV picture shows through."""
    th = th or themes.get("classic")

    def n(v):
        return int(round(v * k))

    scale_attr = skin_scale_attr()

    def box(x, y, w, h):
        return 'position="%d,%d" size="%d,%d"' % (n(x), n(y), max(1, n(w)), max(1, n(h)))

    def pix(name, x, y, w, h, z=1):
        # the theme's own picture when it has one (Neon), else the Classic one; pre-sized for WQHD
        resolved = ui_pixmap_path(themes.pic(th, name), max(1, n(w)), max(1, n(h)))
        return '<ePixmap %s pixmap="%s" alphatest="blend" transparent="1"%s zPosition="%d"/>' % (box(x, y, w, h), resolved, scale_attr, z)

    def lab(name, x, y, w, h, size, color=TEXT, align="left", z=3, wrap=False):
        return ('<widget name="%s" %s font="Regular;%d" foregroundColor="%s" halign="%s" valign="center" '
                'transparent="1" %s zPosition="%d"/>' % (
                    name, box(x, y, w, h), n(size), color, align, '' if wrap else 'noWrap="1"', z))

    parts = ['<screen name="UltraAudioScreen" position="0,0" size="%d,%d" flags="wfNoBorder" backgroundColor="transparent">'
             % (n(1920), n(1080))]
    # Identity | breadcrumb | TV channel | fixed Web address | image release | clock.
    # Neon: soft light around the bars and the list, drawn under them (static pictures, nothing animated)
    parts += [pix(name, x, y, w, h, 0) for name, x, y, w, h in th.get("glows", ())]
    parts += [pix("bar.png", TOP_X, TOP_Y, BAR_W, BAR_H),
              pix(_playing_key(n(44)), 66, TOP_Y + 10, 44, 44, 2),
              pix("brand.png", 120, TOP_Y + 16, 180, 32, 2),
              lab("crumb", CRUMB_X, TOP_Y + 12, 500, 42, 20, WHITE),
              lab("hstate", HSTATE_X, TOP_Y + 12, HSTATE_W, 42, 22, WHITE, "center"),
              lab("hname", 1240, TOP_Y + 12, 320, 42, 19, WHITE, "right"),
              lab("imageinfo", 1570, TOP_Y + 12, 185, 42, 19, th["pal"]["accent"], "center"),
              lab("clock", 1770, TOP_Y + 12, 84, 42, 20, WHITE, "right")]
    # Rounded panel and focus have genuinely transparent corners. The native
    # list selection is disabled in start(), so it cannot paint a square under
    # our moving rounded frame. The list itself remains transparent.
    if grid:
        palette = th["pal"]
        badge_w, badge_h = 104, 42
        badge_x = GRID_X + 62 - badge_w // 2
        badge_y = GRID_GUIDE_Y + (GRID_GUIDE_H - badge_h) // 2
        badge_asset = ui_pixmap_path(themes.pic(th, "grid_now.png"), n(badge_w), n(badge_h))
        parts += [
            pix("panel_list.png", TOP_X, LIST_Y, LIST_W, LIST_H),
            '<widget name="list" position="%d,%d" size="%d,%d" foregroundColor="#FFFFFF" '
            'foregroundColorSelected="#FFFFFF" scrollbarMode="showNever" transparent="1" zPosition="3"/>' %
            (n(GRID_X), n(GRID_Y), n(ROW_W), GRID_ROWS * n(GRID_PITCH_Y)),
            '<widget name="selbar" %s pixmap="%s" alphatest="blend" transparent="1"%s zPosition="2"/>' %
            (box(GRID_X, GRID_Y, GRID_TILE_W, GRID_TILE_H),
             ui_pixmap_path(themes.pic(th, "grid_focus.png"), n(GRID_TILE_W), n(GRID_TILE_H)), scale_attr),
            pix("grid_guide.png", GRID_X, GRID_GUIDE_Y, ROW_W, GRID_GUIDE_H, 2),
            '<widget name="grid_guide_badge" %s pixmap="%s" alphatest="blend" '
            'transparent="1"%s zPosition="3"/>' % (box(badge_x, badge_y, badge_w, badge_h), badge_asset, scale_attr),
            lab("grid_guide_tag", badge_x, badge_y, badge_w, badge_h,
                21 if lang() == "fr" else 28, "#111315", "center", 4),
            '<widget name="grid_guide_icon" %s alphatest="blend" transparent="1"%s zPosition="3"/>' %
            (box(GRID_X + 62 - GRID_GUIDE_ICON_W // 2, GRID_GUIDE_Y + (GRID_GUIDE_H - GRID_GUIDE_ICON_H) // 2,
                 GRID_GUIDE_ICON_W, GRID_GUIDE_ICON_H), scale_attr),
            lab("grid_guide_title", GRID_X + 124, GRID_GUIDE_Y + 14, ROW_W - 144, 53, 23,
                palette["row_accent"], wrap=True),
            lab("grid_guide_time", GRID_X + 124, GRID_GUIDE_Y + 70, 165, 24, 17, palette["row_muted"]),
            '<widget name="grid_guide_progress" %s backgroundColor="#303335" foregroundColor="%s" '
            'borderWidth="0" zPosition="3"/>' %
            (box(GRID_X + 282, GRID_GUIDE_Y + 81, ROW_W - 302, 4), palette["row_accent"]),
        ]
    else:
        cm = th.get("cursor_margin", 0)      # Neon: the cursor picture carries a halo this many px around the row
        parts += [pix("panel_list.png", TOP_X, LIST_Y, LIST_W, LIST_H),
                  # DreamOS rejects itemHeight in XML; setItemHeight() below owns it.
                  '<widget name="list" position="%d,%d" size="%d,%d" foregroundColor="#FFFFFF" foregroundColorSelected="#FFFFFF" scrollbarMode="showNever" transparent="1" '
                  'zPosition="3"/>' % (n(TOP_X + 12), n(LIST_Y + 10), max(1, n(ROW_W)), ROWS * n(ROW_H) + 4),
                  # Classic's ring is hollow and sits over the row; Neon's cursor is a solid glass piece, so it goes
                  # under the (transparent) list and the row's picon and text are drawn on top of it
                  '<widget name="selbar" %s pixmap="%s" alphatest="blend" transparent="1"%s zPosition="%d"/>'
                  % (box(TOP_X + 12 - cm, LIST_Y + 10 - cm, ROW_W + 2 * cm, ROW_H + 2 * cm),
                     ui_pixmap_path(themes.pic(th, "select.png"), max(1, n(ROW_W + 2 * cm)), max(1, n(ROW_H + 2 * cm))),
                     scale_attr, 2 if th.get("cursor_under") else 4)]
    # live equalizer (mint and coral bars, as on the web page) sits in the top bar midway between the folder path
    # and the TV channel's name, so it never covers a row's guide or progress bar; see _place_marker
    eq_scale = '' if (max(1, n(EQ_W)), max(1, n(EQ_H))) in ((64, 27), (96, 40), (128, 53)) else scale_attr
    parts.append('<widget name="playmark" %s alphatest="blend"%s transparent="1" zPosition="5"/>'
                 % (box(HSTATE_X + HSTATE_W // 2 - EQ_W - EQ_GAP, TOP_Y + 12, EQ_W, EQ_H), eq_scale))
    # bottom bar, laid out like the plugin's footer: hint left, four key dashes with their word, numbers right
    parts += [pix("bar.png", TOP_X, DOCK_Y, BAR_W, BAR_H)]
    ky = DOCK_Y + 11
    # keys right after the page info; the whole right side shows the picture / audio delays (with their number keys)
    for key, x, name, w in (("red", 330, "kred", 110), ("green", 500, "kgreen", 120), ("yellow", 680, "kyellow", 190),
                            ("blue", 930, "kblue", 170)):
        if key in ("yellow", "blue"):      # the audio keys only show while a commentary plays (see audio_keys)
            k_resolved = ui_pixmap_path(os.path.join(UI, "key_%s.png" % key), max(1, n(56)), max(1, n(42)))
            parts.append('<widget name="kdash_%s" %s pixmap="%s" alphatest="blend"%s transparent="1" zPosition="25"/>'
                         % (key, box(x, ky, 56, 42), k_resolved, scale_attr))
        else:
            parts.append(pix("key_%s.png" % key, x, ky, 56, 42, 25))
        parts.append(lab(name, x + 58, ky, w, 42, 20, "#ffffff", "left", 26))
    parts += [lab("kok", 66, ky, 255, 42, 20, WHITE, "left", 26),
              ]
    # Static ring keys flank the current values. Step amounts remain in MENU;
    # the footer keeps only the useful current picture/audio delay readouts.
    for x0, keys, cap, val in ((1176, ("1", "3"), "pcap", "pv"),
                                (1530, ("4", "6"), "acap", "pva")):
        parts += [pix(_number_key(keys[0], n(48)), x0 + 8, DOCK_Y + 6, 48, 48, 25),
                  lab(cap, x0 + 64, DOCK_Y + 2, 190, 22, 15, th["pal"]["muted"], "center", 26),
                  lab(val, x0 + 64, DOCK_Y + 23, 190, 38, 27, WHITE, "center", 26),
                  pix(_number_key(keys[1], n(48)), x0 + 262, DOCK_Y + 6, 48, 48, 25)]
    parts.append(football_skin(k, th))
    parts.append(menu_skin(k, th))    # the MENU card (hidden until MENU is pressed)
    parts.append("</screen>")
    return "\n".join(parts).replace('font="Regular;', 'font="%s;' % themes.face("UltraAudioUI"))


class UltraAudioScreen(Screen):
    def createSummary(self):
        from .frontpanel import UltraAudioFrontSummary
        return UltraAudioFrontSummary

    def __init__(self, session, ip="RECEIVER-IP"):
        global _resume_selection, _resume_cwd
        self.k = max(0.5, getDesktop(0).size().width() / 1920.0)
        self.th = themes.get()
        self.pal = self.th["pal"]
        self.grid = store.get_settings().get("library_view") == "grid"
        self.cols = GRID_COLS if self.grid else 1
        self.per_page = GRID_COLS * GRID_ROWS if self.grid else ROWS
        self._lang = lang()            # Stadium / Daylight pick their fonts by language: reopen when it changes
        self._font = uifont.selected()
        self.skin = native(build_skin(self.k, self.th, self.grid))
        Screen.__init__(self, session)
        try:
            self.setTitle(native("UltraAudio"))
        except Exception:
            pass
        self.ip = ip
        self._image_label = receiver_image_label()
        active = active_stream_location()
        # When no audio is playing, always reopen at Library root.
        # With active audio, navigate directly to that exact stream, regardless
        # of where the user previously browsed before closing the screen.
        resuming = _resume_cwd is not None
        self.cwd = (_resume_cwd if not _resume_cwd or store.get_folder(_resume_cwd) else "") if resuming else (active[0] if active else "")
        self._sel = dict(_resume_selection or {}) if resuming or active else {}
        if active and not resuming:
            folders, streams = store.children(self.cwd)
            for i, s in enumerate(streams):
                if s["id"] == active[1]:
                    self._sel[self.cwd] = len(folders) + i
                    break
        _resume_selection = None
        _resume_cwd = None
        self._colors = {}
        self._texts = {}
        self._shown = None
        self._library_shown = None
        self._view_shown = None
        self._crumb = ""
        self.entries = []              # the folder's items: dicts with payload, icon, title, sub, playing
        self._row_pairs = {}
        self._can_invalidate = False
        self._lazy_rows = self._selection_events = False
        self._guide_streams = []
        self._guide_shown = ()
        self._guide_rev_shown = -1
        self._last_guide_ensure = 0.0
        self._guide_ensure_pending = False
        self._minute_shown = None
        self.lidx = 0                  # list mode: index of the focused item (explicit 9-row page slicing)
        self._list_page_start = None
        self.gidx = 0                  # stadium / daylight: index of the focused item
        self._page_shown = None
        self._state_colors = {"playing": self.pal["accent"], "starting": self.pal["warn"], "retrying": self.pal["warn"],
                              "stopping": self.pal["warn"], "error": self.pal["error"], "idle": self.pal["idle"]}
        self["list"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        if self.grid:
            self["list"].l.setFont(0, gFont(native(themes.face("UltraAudioUI")), int(round(24 * self.k))))
            self["list"].l.setFont(1, gFont(native(themes.face("UltraAudioUI")), int(round(15 * self.k))))
            self["list"].l.setItemHeight(int(round(GRID_PITCH_Y * self.k)))
        else:
            # Match the settings names: same Regular face, size and pure white.
            self["list"].l.setFont(0, gFont(native(themes.face("UltraAudioUI")), int(24 * self.k)))
            self["list"].l.setFont(1, gFont(native(themes.face("UltraAudioUI")), int(17 * self.k)))
            self["list"].l.setFont(2, gFont(native(themes.face("UltraAudioUI")), int(15 * self.k)))
            self["list"].l.setFont(3, gFont(native(themes.face("UltraAudioUI")), int(round(20 * self.k))))
            self["list"].l.setItemHeight(int(round(ROW_H * self.k)))
        for name in ("crumb", "clock", "hname", "imageinfo", "hstate", "pv", "pva", "pcap", "acap", "kred", "kgreen", "kyellow", "kblue", "kok") + tuple(self.th["extra"]):
            self[name] = Label(native(""))
        if self.grid:
            for name in GRID_LABELS:
                self[name] = Label(native(""))
            self["grid_guide_progress"] = ProgressBar()
            self["grid_guide_badge"] = Pixmap()
            self["grid_guide_icon"] = Pixmap()
            self._guide_percent = -1
            self._guide_icon_path = False
        self["selbar"] = Pixmap()
        self["playmark"] = Pixmap()
        self._marker = None
        self._marker_visible = True
        self._bar_at = self._bar_visible = self._audio_keys_visible = None
        self["kdash_yellow"] = Pixmap()
        self["kdash_blue"] = Pixmap()
        if not self.grid:
            try:
                self["list"].onSelectionChanged.append(self.page_info)
                self["list"].onSelectionChanged.append(self.place_bar)
                self._selection_events = True
            except Exception:
                pass
        self.football = FootballCard(self)
        self.menu = MenuOverlay(self, ip)
        self.apply_language()
        self._key_at = {}
        self["actions"] = ActionMap(
            # Not "ShortcutActions": on many images it maps the colour keys again on key RELEASE, so one GREEN press froze the picture
            # and the release un-froze it (the official plugin, and the web page, never had this).
            ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions"],
            {"ok": self.key_ok, "menu": self.menu.toggle, "cancel": self.key_cancel, "red": self._once("red", self.key_red),
             "green": self._once("green", self.key_green), "0": self.key_pic_reset, "1": lambda: self.key_pic(-1), "3": lambda: self.key_pic(1),
             "4": lambda: self.key_audio(-1), "6": lambda: self.key_audio(1), "blue": self._once("blue", self.key_audio_reset),
            "yellow": self._once("yellow", self.key_pic_reset),
             "left": lambda: self.key_side(-1), "right": lambda: self.key_side(1),
             "up": lambda: self.key_vert(-1), "down": lambda: self.key_vert(1)}, -2)
        # CH+ / CH-: while the MENU card is open they flip its pages; otherwise they are not ours (returning 0 passes
        # them on, so they keep flipping the channel list as before)
        self["chactions"] = ActionMap(["ChannelSelectBaseActions"],
                                      {"nextBouquet": lambda: self.key_ch(-1), "prevBouquet": lambda: self.key_ch(1)}, -2)
        self._timer_connections = []
        self.timer = self._timer(self.refresh)
        self._nav_settle_timer = self._timer(self._on_nav_settled)
        self._audio_pending = None            # audio delay (ms) chosen with 4 / 6, applied once the keys rest
        self._audio_target = None
        self.audio_timer = self._timer(self.apply_audio)
        self._pic_busy_until = 0.0            # the delays show green while a change is being applied
        self._aud_busy_until = 0.0
        self._pic_pending = None              # picture delay (s) chosen with 1 / 3, applied once the keys rest
        self._pic_target = None
        self.pic_timer = self._timer(self.apply_pic)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._stop_timers)
        self.onClose.append(self._remember)
        for attr, fn in (("onShow", self._marker_show), ("onHide", self._marker_hide),
                         ("onExecBegin", self._marker_show), ("onExecEnd", self._marker_hide)):
            callbacks = getattr(self, attr, None)
            if callbacks is not None:
                callbacks.append(fn)

    def _once(self, name, handler):
        """Run a colour key once per press: a held key repeats, and a toggle (GREEN) must not flip back. Every copy
        restarts the quiet time, and so does the end of the handler (starting timeshift can take a while)."""
        def run():
            now = time.time()
            last = self._key_at.get(name, 0.0)
            self._key_at[name] = now
            if 0.0 <= now - last < KEY_TWIN_S:
                return
            try:
                handler()
            finally:
                self._key_at[name] = time.time()
        return run

    def _timer(self, callback):
        timer = eTimer()
        # Keep DreamOS signal connections alive for the lifetime of the screen.
        connect_timer(timer, callback, self._timer_connections)
        return timer

    def _stop_timers(self):
        self._marker_visible = False
        if self._marker is not None:
            self._marker.close()
        self.timer.stop()
        if hasattr(self, "_nav_settle_timer"):
            self._nav_settle_timer.stop()
        self.audio_timer.stop()
        self.pic_timer.stop()
        # EXIT / a language reopen may happen before the debounce timers fire.
        # Apply only this playback's final values; never carry a pending edit to another stream.
        c = ctl.get()
        st = c.engine.status()
        current_target = (st["stream_id"], st.get("generation"))
        secs, self._pic_pending = self._pic_pending, None
        picture, self._pic_target = self._pic_target, None
        ms, self._audio_pending = self._audio_pending, None
        audio, self._audio_target = self._audio_target, None
        if secs is not None and picture == current_target:
            c.set_video_delay(secs, *picture)
        if ms is not None and audio == current_target:
            c.set_audio_delay(ms, *audio)
        self._timer_connections = []

    def apply_language(self):
        """Static texts in the chosen language (also called again when the menu changed the language)."""
        self._text("kred", T("Stop"))
        self._text("kgreen", T("Freeze"))
        self._text("kyellow", T("Reset picture"))
        self._text("kblue", T("Reset audio"))
        self._shown_page = None
        self.page_info()

    def reopen(self, menu_row=None):
        """Close and open the screen again (its skin is built when it opens): plugin.main reopens on "reopen"."""
        global _resume_menu, _resume_selection, _resume_cwd
        self._save_index()
        _resume_selection = dict(self._sel)
        _resume_cwd = self.cwd
        _resume_menu = menu_row
        self.close("reopen")

    # ------------------------------------------------------------ cursor (classic: the listbox's; the others: ours)
    def _count(self):
        return len(self.entries)

    def _index(self):
        total = len(self.entries)
        if not total:
            return 0
        i = self.gidx if self.grid else getattr(self, "lidx", 0)
        return max(0, min(total - 1, i))

    def _cursor_native(self):
        """Keep a usable selection if the custom PNG/widget cannot be drawn."""
        self._custom_cursor = False
        self["selbar"].hide()
        self._bar_visible = False
        try:
            instance = self["list"].instance
            if instance is not None:
                instance.setSelectionEnable(1)
        except Exception:
            pass


    def _configure_cursor(self):
        self._bar_at = None
        try:
            cm = self.th.get("cursor_margin", 0)
            width, height = (GRID_TILE_W, GRID_TILE_H) if self.grid else (ROW_W + 2 * cm, ROW_H + 2 * cm)
            w, h = (max(1, int(round(size * self.k))) for size in (width, height))
            artwork = "grid_focus.png" if self.grid else "select.png"
            path = ui_pixmap_path(themes.pic(self.th, artwork), w, h)
            pixmap = _bundled_pixmap(path) if path else None
            frame, listing = self["selbar"].instance, self["list"].instance
            if pixmap is None or frame is None or listing is None:
                return self._cursor_native()
            if hasattr(frame, "setScale"):
                try:
                    frame.setScale(1)
                except Exception:
                    pass
            frame.setPixmap(pixmap)
            listing.setSelectionEnable(0)
            self._custom_cursor = True
        except Exception:
            self._cursor_native()


    def _mark_nav(self):
        mark_user_input()
        if hasattr(self, "_nav_settle_timer"):
            self._nav_settle_timer.start(420, True)

    def _on_nav_settled(self):
        if not user_input_idle(0.38):
            self._nav_settle_timer.start(220, True)
            return
        if getattr(self, "_guide_ensure_pending", False) and self._guide_streams:
            self._guide_ensure_pending = False
            self._last_guide_ensure = time.time()
            guide.ensure(self._guide_streams, lang())
        self.refresh()

    def _goto(self, i):
        total = len(self.entries)
        if not total:
            return
        i = max(0, min(total - 1, i))
        if self.grid:
            self.gidx = i
            self._render_page()
            self._refresh_grid_guide()
        else:
            self.lidx = i
            self._render_list_page()
        self.page_info()
        self.place_bar()

    def _entry_row(self, i, focused=False):
        e = self.entries[i]
        separator = i + 1 < len(self.entries) and (i + 1) % ROWS != 0
        return self._row(e["payload"], self._entry_icon(e), e["title"], e["sub"], e["playing"],
                         separator=separator, event=e.get("event"), focused=False, entry=e)

    def _entry_icon(self, entry):
        if "icon" not in entry:
            kind, obj = entry["payload"]
            lookup = store.folder_icon if kind == "folder" else store.stream_icon
            entry["icon"] = lookup(obj, scale=self.k, lib=getattr(self, "_entry_library", None))
        return entry["icon"]

    def _build_visible_row(self, index):
        return self._cached_entry_row(index)

    def refresh_match_rows(self, first, badges):
        grid_changed = False
        for i, live in enumerate(badges, first):
            if i >= len(self.entries):
                break
            entry = self.entries[i]
            previous = entry.get("live_badge")
            entry["live_badge"] = live
            if live != bool(previous):
                if self.grid:
                    grid_changed = True
                else:
                    self._row_pairs.pop(i, None)
                    if self._can_invalidate:
                        self._invalidate_row(i, False)
                    else:
                        self._shown = None
        if grid_changed and first == (self._index() // self.per_page) * self.per_page:
            self._page_shown = None
            self._render_page()

    def _invalidate_row(self, i, focused=False):
        first = getattr(self, "_list_page_start", None)
        if first is None:
            first = (self._index() // ROWS) * ROWS
        local_i = i - first
        if 0 <= local_i < len(getattr(self, "_rows", ())):
            if not self._lazy_rows:
                self._rows[local_i] = self._cached_entry_row(i)
            if self._can_invalidate:
                try:
                    self["list"].l.invalidateEntry(local_i)
                except Exception:
                    self._can_invalidate = False
                    self._render_list_page(force=True)

    def _cached_entry_row(self, i, focused=False):
        cached = self._row_pairs.get(i)
        if cached is not None:
            return cached
        built = self._entry_row(i)
        self._row_pairs[i] = built
        return built

    def _relight(self, idx):
        self._lit = idx

    def place_bar(self):
        """Put the focus frame on the focused row / card (the list flips whole pages, so it is index % page)."""
        if getattr(self, "_filling_list", False):
            return
        try:
            bar = self["selbar"]
            visible = getattr(self, "_custom_cursor", True) and self._count() > 0
            if visible != self._bar_visible:
                bar.show() if visible else bar.hide()
                self._bar_visible = visible
            if not visible:
                return
            idx = self._index()
            if not self.grid:
                self._relight(idx)
            if self.grid:
                pos = idx % self.per_page
                col, row = pos % self.cols, pos // self.cols
                at = (int(round(GRID_X * self.k)) + int(round(col * GRID_PITCH_X * self.k)),
                      int(round(GRID_Y * self.k)) + row * int(round(GRID_PITCH_Y * self.k)))
            else:
                cm = self.th.get("cursor_margin", 0)
                row = idx % ROWS
                at = (int(round((TOP_X + 12 - cm) * self.k)),
                      int(round((LIST_Y + 10) * self.k)) - int(round(cm * self.k))
                      + row * int(round(ROW_H * self.k)))
            if at != self._bar_at and bar.instance is not None:
                from enigma import ePoint
                bar.instance.move(ePoint(*at))
                self._bar_at = at
        except Exception:
            self._cursor_native()
        finally:
            if hasattr(self, "football"):
                self.football.selection_changed()

    def _marker_show(self):
        self._marker_visible = True
        self._sync_marker()

    def _marker_hide(self):
        self._marker_visible = False
        self.football.hide()
        if self._marker is not None:
            self._marker.stop()

    def _marker_move(self, row):
        pass        # its place follows the TV channel's name (see _place_marker), not a list row

    def _place_marker(self):
        """Lay out the middle of the top bar. The TV channel's name gets its full width (up to HSTATE_W) centred on the
        screen; the folder path / status message takes what is left on its left, and the equalizer sits in the gap
        between them. A long path pushes the name to the right (never past the Web address), and only when even that
        is not enough is the path cut. Only runs when one of those two texts changes."""
        crumb, name = self._texts.get("crumb") or "", self._texts.get("hstate") or ""
        if (crumb, name) == getattr(self, "_marker_for", None):
            return
        try:
            from enigma import ePoint, eSize
            k = self.k

            def n(v):
                return int(round(v * k))
            y, hgt = n(TOP_Y + 12), n(42)
            cx, eq, gap = n(CRUMB_X), n(EQ_W), n(EQ_GAP)
            lo, hi = n(HSTATE_X), n(HSTATE_X + HSTATE_W)
            hs, cr = self["hstate"].instance, self["crumb"].instance
            # measure both texts in their widest boxes
            hs.move(ePoint(lo, y))
            hs.resize(eSize(hi - lo, hgt))
            cr.resize(eSize(hi - cx, hgt))
            full = hs.calculateSize().width() + n(10) if name else 0
            nw = min(full, hi - lo)
            cw = cr.calculateSize().width() if crumb else 0
            room = hi - cx - eq - 2 * gap
            if cw + nw > room:                                   # both long: share the bar, at least half for the name
                nw = min(nw, max(room - cw, room // 2))
            try:                                                 # a cut name keeps its start, not its middle
                from enigma import eLabel
                hs.setHAlign(eLabel.alignCenter if full <= nw else eLabel.alignLeft)
            except Exception:
                pass
            left = (lo + hi) // 2 - nw // 2                      # centred on the screen
            left = max(left, min(cx + cw + eq + 2 * gap, hi - nw))  # pushed right by a long path
            crumb_w = max(n(120), left - eq - 2 * gap - cx)
            cr.resize(eSize(crumb_w, hgt))
            if name:
                hs.move(ePoint(left, y))
                hs.resize(eSize(nw, hgt))
            end = cx + min(cw, crumb_w)
            x = max(end + gap, (end + left - eq) // 2)
            self["playmark"].instance.move(ePoint(x, y))
            self._marker_for = (crumb, name)
        except Exception:
            pass

    def _start_marker(self):
        # Predecode the eight small equalizer frames (9 bars, 96x40) once; the skin scales them.
        ew, eh = int(round(EQ_W * self.k)), int(round(EQ_H * self.k))
        frames = tuple(_bundled_pixmap(_frame_path(themes.pic(self.th, 'eq_%d.png' % i), ew, eh)) for i in range(8))
        frames = frames if all(frame is not None for frame in frames) else ()
        still = _bundled_pixmap(_frame_path(themes.pic(self.th, 'eq_idle.png'), ew, eh))
        engine = ctl.get().engine
        def playback_state():
            # Lock-free atomic attribute reads: never skip animation frames when the audio worker holds engine.lock.
            stream = engine.stream
            return {'state': engine.state, 'stream_id': stream.get('id') if isinstance(stream, dict) else None}
        widget = self["playmark"]
        widget.hide()
        self._marker = PlaybackMarker(self._timer, frames, still, playback_state,
                                      widget.instance.setPixmap, self._marker_move, widget.show, widget.hide)

    def _sync_marker(self, state=None):
        if self._marker is None:
            return
        if not self._marker_visible:
            return self._marker.stop()
        state = ctl.get().engine.status() if state is None else state
        row = 0 if state.get('stream_id') else None   # one spot in the top bar, in the list and the grid alike
        self._marker.update(row, state.get('state'), state.get('stream_id'), self._marker_visible)

    def page_info(self):
        """Bottom-left: 'Page 2 / 5   43 files' of the folder on screen; follows the cursor."""
        if getattr(self, "_filling_list", False):
            return
        total = self._count()
        if not total:
            self._shown_page = None
            return self._text("kok", "")
        idx = self._index()
        nf = getattr(self, "_folder_count", 0)
        page_sig = (self.cwd, idx // self.per_page, total, nf, lang())
        if getattr(self, "_shown_page", None) == page_sig:
            return
        self._shown_page = page_sig
        ns = total - nf
        parts = [T("Page %d / %d", idx // self.per_page + 1, (total - 1) // self.per_page + 1)]
        if nf:
            parts.append(T("%d folders", nf))
        if ns:
            parts.append(T("%d files", ns))
        self._text("kok", u"   \u00b7   ".join(parts))

    def audio_keys(self, on):
        """Show picture/audio reset keys only while commentary plays and the menu is closed."""
        if on == self._audio_keys_visible:
            return
        self._audio_keys_visible = on
        for name in ("kdash_blue", "kblue", "kdash_yellow", "kyellow"):
            try:
                self[name].show() if on else self[name].hide()
            except Exception:
                pass

    # While the MENU card is open the keys drive the card; otherwise they drive the list as before.
    def key_ok(self):
        self._mark_nav()
        self.menu.activate() if self.menu.is_open else self.ok()

    def key_cancel(self):
        self._mark_nav()
        self.menu.close() if self.menu.is_open else self.back()

    def key_red(self):
        self._mark_nav()
        self.menu.close() if self.menu.is_open else self.stop()

    def key_green(self):
        self._mark_nav()
        self.menu.activate() if self.menu.is_open else ctl.get().toggle_pause()

    def key_ch(self, d):
        if not self.menu.is_open:
            if not self.grid:
                return 0
            self._mark_nav()
            self.page_shift(d)
            return 1
        self._mark_nav()
        self.menu.page(d)
        return 1

    def key_side(self, d):
        """LEFT / RIGHT: flip a page of the list (like the plugin); on the cards: the next / previous card. Inside the
        MENU card they change the value."""
        self._mark_nav()
        if self.menu.is_open:
            return self.menu.step(d)
        if self.grid:
            return self.move_by(d)
        self.page_shift(d)

    def key_pic(self, d):
        """1 / 3: each press moves the PENDING picture delay by one 'Picture step' (MENU); the picture moves once, when the
        keys rest for PICTURE_SETTLE seconds (the same way 4 / 6 work for the audio)."""
        if self.menu.is_open:
            return
        c = ctl.get()
        st = c.control_status()
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        target = (st["stream_id"], st.get("generation"))
        if self._pic_target != target:
            self._pic_pending = None
        self._pic_target = target
        v = st["video"]
        if self._pic_pending is not None:
            base = self._pic_pending
        elif v["state"] in ("off", "error"):
            memo = store.recall_channel(ctl.get()._service_key())
            base = float(memo.get("video_s") or 0.0) if memo else 0.0
        elif v["state"] == "paused":
            base = v["current_s"] if v["current_s"] is not None else v["target_s"]
        else:
            # Always step from target_s when filling or running so key-frame jitter in current_s never swallows a press!
            base = v["target_s"] if v.get("target_s") is not None else (v["current_s"] or 0.0)
        step = float(store.get_settings()["step_video_s"])
        self._pic_pending = round(max(0.0, min(600.0, base + (step if d > 0 else -step))), 1)
        self.pic_timer.start(int(PICTURE_SETTLE * 1000), True)
        self._show_delays(st, v)

    def key_pic_reset(self):
        """YELLOW / 0: return the picture to live without changing the commentary."""
        if self.menu.is_open:
            return
        st = ctl.get().engine.status()
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        self.pic_timer.stop()
        self._pic_pending, self._pic_target = None, None
        ctl.get().reset_picture(st["stream_id"], st.get("generation"))
        self._pic_busy_until = time.time() + 1.5
        self._refresh_delays()

    def apply_pic(self):
        secs, self._pic_pending = self._pic_pending, None
        target, self._pic_target = self._pic_target, None
        c = ctl.get()
        st = c.engine.status()
        if secs is not None and target == (st["stream_id"], st.get("generation")):
            c.set_video_delay(secs, *target)
            self._pic_busy_until = time.time() + 2.0
        self._refresh_delays()

    def key_vert(self, d):
        """UP / DOWN with a clean wrap: DOWN on the last item goes to the first, UP on the first goes to the last.
        Stadium (one strip of cards): a page of cards. Daylight (grid): the card above / below."""
        self._mark_nav()
        if self.menu.is_open:
            return self.menu.move(d)
        if self.grid:
            return self.move_rows(d)
        total = len(self.entries)
        if total <= 0:
            return
        self._goto((self._index() + d) % total)

    def move_by(self, d):
        """One card left / right, wrapping from the last card to the first and back."""
        total = self._count()
        if total:
            self._goto((self._index() + d) % total)

    def move_rows(self, d):
        """Grid: the card above / below. Below the last line it wraps to the first line (same column), above the first
        line to the last one; a column the last line does not have lands on its last card."""
        total = self._count()
        if not total:
            return
        cols = self.cols
        idx = self._index()
        col = idx % cols
        last_line = ((total - 1) // cols) * cols
        target = idx + d * cols
        if target > total - 1:
            target = col if idx >= last_line else total - 1
        elif target < 0:
            target = last_line + col
        self._goto(max(0, min(total - 1, target)))

    def page_shift(self, d):
        """Same row on the next / previous page; at the outer edge it lands on the first / last item (the plugin's paging rule)."""
        total = self._count()
        if total <= 0:
            return
        per = self.per_page
        idx = self._index()
        page, row = divmod(idx, per)
        last_page = (total - 1) // per
        if d < 0:
            target = (page - 1) * per + row if page > 0 else 0
        else:
            target = min(total - 1, (page + 1) * per + row) if page < last_page else total - 1
        self._goto(target)

    def menu_closed(self):
        self.apply_language()
        self.refresh()

    def language_changed(self, menu_row=None):
        """True when the screen reopens for it (Stadium / Daylight pick their fonts by language when they open)."""
        if themes.uses_own_fonts(self.th):
            self.reopen(menu_row)
            return True
        self.apply_language()
        self._shown = None            # list rows are rebuilt on the next refresh, in the new language
        self.refresh()
        return False

    # ------------------------------------------------------------ list
    def start(self):
        global _resume_menu
        if not self.grid:
            content = self["list"].l
            content.setItemHeight(int(round(ROW_H * self.k)))
            self._lazy_rows = False
        self.menu.bind()
        self.football.hide()
        self._start_marker()
        self._configure_cursor()
        self.fill()
        if _resume_menu is not None:
            self.menu.idx, _resume_menu = _resume_menu, None
            self.menu.open()
        self.refresh()
        self.timer.start(1000, False)

    def _remember(self):
        global _last_cwd
        _last_cwd = self.cwd

    def _row(self, payload, icon, title, sub, playing=False, separator=True, event=None, focused=False, entry=None):
        k = self.k
        n = lambda v: int(v * k)
        if entry is not None and "live_badge" in entry:
            live = entry["live_badge"]
        else:
            live = bool(event and (LIVE_SCORES.is_live_cached(event) if hasattr(LIVE_SCORES, "is_live_cached") else LIVE_SCORES.is_live(event)))
            if entry is not None:
                entry["live_badge"] = live
        title_w = n(264 if live else 382)
        tw = n(382)                                 # the animated marker lives in the top bar now
        P = self.pal
        hexc = lambda key: int(P[key][1:], 16)
        # Only the active audio guide turns red; other guides remain green.
        # Live-match badges always stay red. Focus never changes these colours.
        accent = hexc("accent_hi" if focused else "row_accent")
        muted = hexc("muted_hi" if focused else "row_muted")
        title_color = accent if playing else (0xFFFFFF if focused else hexc("title_dim"))
        guide_color = 0xE65A60 if playing else accent
        custom = isinstance(icon, string_types) and not to_text(icon).startswith(to_text(store.ASSETS))   # a user's picture or a channel's picon: any size
        exact_bundled = not custom and isinstance(icon, string_types) and (
            (abs(k - 1.0) <= 0.01 and not icon.endswith(("@wqhd.png", "@2x.png", "@4x.png", "@hd.png")))
            or (icon.endswith("@wqhd.png") and (n(ICON_W), n(ICON_H)) == (213, 117))
            or (icon.endswith("@2x.png") and (n(ICON_W), n(ICON_H)) == (320, 176))
            or (icon.endswith("@hd.png") and (n(ICON_W), n(ICON_H)) == (106, 58))
        )
        cells = [payload,
                 mc_pixmap(pos=(n(12), n(8)), size=(n(ICON_W), n(ICON_H)), png=_pixmap(icon, n(ICON_W), n(ICON_H)),
                                                   # built-in icons at native resolution are drawn 1:1; custom picons scale
                                                   flags=0 if exact_bundled else (_PIX_FLAGS if (custom or abs(k - 1.0) > 0.01) else 0)),
                 ]
        if self.th.get("picon_separator"):
            sw, sh = max(1, n(2)), max(1, n(70))
            sep = ui_pixmap_path(themes.pic(self.th, "picon_separator.png"), sw, sh)
            cells.append(mc_pixmap(pos=(n(176), n(17)), size=(sw, sh), png=_pixmap(sep), flags=0))
        cells += [
                 MultiContentEntryText(pos=(n(186), n(10 if event else 18 if sub else 34)), size=(title_w, n(36)), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                       text=native(title), color=title_color, color_sel=title_color),
                 ]
        if live:
            # A small red LIVE card like the grid's NOW card; its word is baked in, centred, in the UI language.
            pw, ph = max(1, n(70)), max(1, n(26))
            pill = _live_card(pw, ph)
            cells.append(mc_pixmap(pos=(n(462), n(15)), size=(pw, ph), png=_pixmap(pill),
                                   flags=0 if pill.endswith("_%dx%d.png" % (pw, ph)) or (pw, ph) == (70, 26) else _PIX_STRETCH))
        if event:
            cells.append(MultiContentEntryText(pos=(n(186), n(46)), size=(tw, n(24)), font=1,
                                               flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=native(event[0]),
                                               color=guide_color, color_sel=guide_color))
            clock = to_text(time.strftime("%H:%M", time.localtime(event[1]))) + u" \u2013 " + to_text(time.strftime("%H:%M", time.localtime(event[2])))
            cells.append(MultiContentEntryText(pos=(n(186), n(73)), size=(n(118), n(21)), font=2,
                                               flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=native(clock),
                                               color=muted, color_sel=muted))
            # How far the match has run, as on the web page: two plain filled rectangles (no picture, no timer of its
            # own); the list is rebuilt once a minute by the existing refresh, so the bar moves with the clock.
            span = max(1.0, float(event[2] - event[1]))
            done = max(0.02, min(1.0, (time.time() - event[1]) / span))
            # One cached, pre-rendered rail per visible row. No runtime bitmap
            # generation, segment loops or extra timer; existing minute refresh.
            bx, bw = n(186) + n(124), max(n(40), tw - n(124) - n(10))
            state = max(0, min(64, int(round(done * 64))))
            prog_h = max(1, n(14))
            prog_p = _frame_path(
                themes.pic(self.th, os.path.join("progress", "p_%02d.png" % state)),
                bw, prog_h)
            cells.append(mc_pixmap(
                pos=(bx, n(76)), size=(bw, prog_h),
                png=_bundled_pixmap(prog_p),
                flags=0 if "/%dx%d/" % (bw, prog_h) in prog_p else _PIX_STRETCH))
        elif sub:
            # Only when there IS a sub line: an empty text cell still paints the row's selection background over whatever lies
            # under it, and that was cutting the lower half of the one-line titles on the focused row.
            # Same rule as the guide line: red while this radio / channel is playing, green otherwise.
            sub_color = guide_color
            sub_color_sel = sub_color
            cells.append(MultiContentEntryText(pos=(n(186), n(56)), size=(tw, n(26)), font=1, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                                               text=native(sub), color=sub_color, color_sel=sub_color_sel))
        if separator:
            sep_w, sep_h = n(370), max(1, n(4))
            sep_path = ui_pixmap_path(themes.pic(self.th, "row_separator.png"), sep_w, sep_h)
            cells.append(mc_pixmap(pos=(n(186), n(ROW_H - 4)), size=(sep_w, sep_h),
                                                           png=_pixmap(sep_path),
                                                           flags=0 if sep_path.endswith("_%dx%d.png" % (sep_w, sep_h)) else _PIX_STRETCH))
        return cells

    def _cell(self, entry, x0):
        def n(value):
            return int(round(value * self.k))

        width, height = n(GRID_TILE_W), n(GRID_TILE_H)
        tile = themes.pic(self.th, "grid_tile.png")
        ix = (GRID_TILE_W - ICON_W) // 2
        icon_size = (int(ICON_W * self.k), int(ICON_H * self.k))
        # The playing stream's name is red in the grid, so the one you hear stands out at a glance.
        title = PLAYING_RED if entry["playing"] else int(self.pal["text"][1:], 16)
        cells = [
            mc_pixmap(pos=(n(x0), 0), size=(width, height),
                      png=_pixmap(tile, width, height), flags=_PIX_STRETCH),
            mc_pixmap(pos=(n(x0 + ix), n(10)), size=icon_size,
                      png=_pixmap(self._entry_icon(entry), *icon_size), flags=_PIX_FLAGS),
            MultiContentEntryText(pos=(n(x0 + 10), n(103)), size=(n(GRID_TILE_W - 20), n(38)),
                                  font=0, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
                                  text=native(entry["title"]), color=title, color_sel=title),
        ]
        live = entry.get("live_badge")
        if live is None:
            live = LIVE_SCORES.is_live_cached(entry.get("event"))
        if live and entry["payload"][0] == "stream":
            # small, in the tile's top-right corner, clear of the channel logo
            pw, ph = n(52), n(20)
            pill = _live_card(pw, ph)
            cells.append(mc_pixmap(pos=(n(x0 + GRID_TILE_W - 8 - 52), n(8)), size=(pw, ph), png=_pixmap(pill),
                                   flags=0 if pill.endswith("_%dx%d.png" % (pw, ph)) else _PIX_STRETCH))
        return cells

    def _render_page(self):
        """Stadium / Daylight: the page holding the cursor, one listbox row per line of cards (only when the page changed)."""
        per = self.per_page
        page = self._index() // per
        if page == self._page_shown:
            return
        items = self.entries[page * per:(page + 1) * per]
        rows = []
        for r in range(0, len(items), self.cols):
            cells = [("line", r)]
            for c, e in enumerate(items[r:r + self.cols]):
                cells += self._cell(e, c * GRID_PITCH_X)
            rows.append(cells)
        self["list"].setList(rows)
        self._page_shown = page

    def _render_list_page(self, force=False):
        """List mode: slice the active 9-row page explicitly (like MenuOverlay) so C++ eListbox never desyncs."""
        total = len(self.entries)
        if not total:
            self._list_page_start = None
            self._rows = []
            self._lit = 0
            self._filling_list = True
            try:
                self["list"].setList([])
            finally:
                self._filling_list = False
            return
        idx = self._index()
        first = (idx // ROWS) * ROWS
        row = idx - first
        self._lit = idx
        if force or first != self._list_page_start:
            self._list_page_start = first
            end = min(first + ROWS, total)
            self._rows = [self._cached_entry_row(i) for i in range(first, end)]
            self._filling_list = True
            try:
                self["list"].setList(self._rows)
                if not getattr(self, "_custom_cursor", True) and hasattr(self["list"], "moveToIndex"):
                    self["list"].moveToIndex(row)
            finally:
                self._filling_list = False
        elif not getattr(self, "_custom_cursor", True) and hasattr(self["list"], "moveToIndex"):
            self._filling_list = True
            try:
                self["list"].moveToIndex(row)
            finally:
                self._filling_list = False

    def fill(self):
        revision = store.library_revision()
        get_f = store.get_folder_readonly if hasattr(store, "get_folder_readonly") else store.get_folder
        if self.cwd and get_f(self.cwd) is None:
            self.cwd = ""
        lib_snapshot = store.readonly_library() if hasattr(store, "readonly_library") else store._load()
        folders, streams = store.children(self.cwd, lib_snapshot)
        language = lang()
        radio_flags = [store.is_radio_stream(s, lib_snapshot) for s in streams]
        self._guide_streams = [s for s, is_radio in zip(streams, radio_flags) if not is_radio]
        self._guide_ensure_pending = bool(self._guide_streams)
        self._guide_shown = tuple(guide.view(s, language) for s in self._guide_streams)
        self._guide_rev_shown = guide.revision() if hasattr(guide, "revision") else -1
        self._minute_shown = int(time.time() // 60)
        st = ctl.get().engine.status()
        playing_id = st["stream_id"] if st["state"] in ("starting", "playing", "retrying") else None
        self._entry_library = lib_snapshot
        entries = []
        for f in folders:
            entries.append({"payload": ("folder", f), "title": store.display_folder_name(f, language),
                            "sub": T("%d channels", f["count"]), "playing": False})
        guide_rows = iter(self._guide_shown)
        for s, is_radio in zip(streams, radio_flags):
            guide_key, event, loading = (None, None, False) if is_radio else next(guide_rows)
            title, duration = store.stream_display(s, lib_snapshot)
            missing_url = store.needs_radio_url(s)
            sub = (T("Radio · add direct stream URL in Web") if missing_url
                   else T("Internet radio") if is_radio else to_text(s.get("tag", "")).upper())
            if duration and not missing_url:
                sub = to_text(sub) + u" \u00b7 " + to_text(duration)
            if guide_key and event is None:
                sub = T("Loading guide...") if loading else T("Guide unavailable")
            entries.append({"payload": ("stream", s), "title": title,
                            "sub": sub, "event": event, "playing": s["id"] == playing_id})
        if store.streams_first(self.cwd, lib_snapshot):
            entries = entries[len(folders):] + entries[:len(folders)]
        self.entries = entries
        self._stream_rows = {e["payload"][1]["id"]: i for i, e in enumerate(entries) if e["payload"][0] == "stream"}
        self._folder_count = len(folders)
        idx = self._sel.get(self.cwd, 0)
        idx = idx if 0 <= idx < len(entries) else 0
        if self.grid:
            self.gidx = idx
            if self._guide_icon_path:
                self._guide_icon_path = False
            self._page_shown = None
            self._render_page()
        else:
            self.lidx = idx
            self._can_invalidate = hasattr(self["list"].l, "invalidateEntry")
            self._row_pairs = {}
            self._render_list_page(force=True)
        path = store.folder_path(self.cwd)
        self._crumb = u"  \u203a  ".join([to_text(T("Library"))] + [to_text(store.display_folder_name(p, language)) for p in path])
        self._text("crumb", self._crumb)
        self._color("crumb", WHITE)
        if "ftitle" in self:
            where = store.display_folder_name(path[-1], language) if path else T("Library")
            count = T("%d channels", len(streams)) if streams or not folders else T("%d folders", len(folders))
            self._text("ftitle", u"%s   \u00b7   %s" % (to_text(where).upper(), to_text(count).upper()))
        self._shown = (self.cwd, playing_id)
        self._library_shown = revision
        self._view_shown = (language,)
        self.page_info()
        self.place_bar()
        if self.grid:
            self._refresh_grid_guide()
        if self._guide_ensure_pending and hasattr(self, "_nav_settle_timer"):
            self._nav_settle_timer.start(350, True)

    def _update_guide_rows_inplace(self, new_guide_shown):
        old_shown = self._guide_shown
        self._guide_shown = new_guide_shown
        lib_snapshot = getattr(self, "_entry_library", None)
        first = (self._index() // ROWS) * ROWS
        changed_visible = False
        for idx_g, (s, new_g) in enumerate(zip(self._guide_streams, new_guide_shown)):
            if idx_g < len(old_shown) and old_shown[idx_g] == new_g:
                continue
            row_i = self._stream_rows.get(s["id"])
            if row_i is None or row_i >= len(self.entries):
                continue
            guide_key, event, loading = new_g
            entry = self.entries[row_i]
            unused_title, duration = store.stream_display(s, lib_snapshot)
            missing_url = store.needs_radio_url(s)
            sub = (T("Radio · add direct stream URL in Web") if missing_url
                   else to_text(s.get("tag", "")).upper())
            if duration and not missing_url:
                sub = to_text(sub) + u" · " + to_text(duration)
            if guide_key and event is None:
                sub = T("Loading guide...") if loading else T("Guide unavailable")
            if entry.get("event") != event or entry.get("sub") != sub:
                entry["event"] = event
                entry["sub"] = sub
                entry.pop("live_badge", None)
                self._row_pairs.pop(row_i, None)
                if first <= row_i < first + ROWS:
                    self._invalidate_row(row_i, row_i == self._lit)
                    changed_visible = True
        if changed_visible and hasattr(self, "football"):
            self.football.selection_changed()

    def _refresh_grid_guide(self, now=None):
        entry = self.entries[self._index()] if self.entries else {}
        event = entry.get("event")
        tag, title, clock = "", T("Guide unavailable"), ""
        percent = None
        if event:
            title, begin, end = event[:3]
            tag = T("Now").upper()
            clock = u"%s \u2013 %s" % tuple(time.strftime("%H:%M", time.localtime(t)) for t in (begin, end))
            now = guide.guide_now() if now is None else now
            percent = max(0, min(100, int(100 * (now - begin) / max(1, end - begin))))
        elif entry:
            title = entry["title"]
            kind, stream = entry["payload"]
            if kind == "folder" or store.is_radio_stream(stream, self._entry_library):
                clock = entry["sub"]
            else:
                clock = T("Loading guide...") if entry["sub"] == T("Loading guide...") else T("Guide unavailable")
        for name, value in zip(GRID_LABELS, (tag, title, clock)):
            self._text(name, value)
        self._color("grid_guide_title", self.pal["row_accent" if event else "text"])
        self._show_grid_guide_icon(self._entry_icon(entry) if entry and not event else None)
        if percent != self._guide_percent:
            has_event = percent is not None
            if has_event != (self._guide_percent is not None) or self._guide_percent == -1:
                for name in ("grid_guide_badge", "grid_guide_tag", "grid_guide_progress"):
                    widget = self[name]
                    widget.show() if has_event else widget.hide()
            self._guide_percent = percent
            if has_event:
                self["grid_guide_progress"].setValue(percent)

    def _show_grid_guide_icon(self, path):
        widget = self["grid_guide_icon"]
        if self._guide_icon_path == path:
            return
        if not path:
            widget.hide()
            self._guide_icon_path = None
            return
        if widget.instance is None:
            return
        width = int(round(GRID_GUIDE_ICON_W * self.k))
        height = int(round(GRID_GUIDE_ICON_H * self.k))
        pixmap = _pixmap(path, width, height)
        frame = widget.instance
        if hasattr(frame, "setScale"):
            frame.setScale(1)
        else:
            # DreamOS skins without pixmap scaling require a decoded icon at the widget size.
            try:
                from enigma import ePicLoad
                decoder = ePicLoad()
                decoder.setPara((width, height, 1, 1, 0, 1, "#00000000"))
                if decoder.startDecode(native(path), 0, 0, False) == 0:
                    pixmap = decoder.getData() or pixmap
            except (ImportError, AttributeError, TypeError, RuntimeError):
                pass
        if pixmap is None:
            widget.hide()
            return
        frame.setPixmap(pixmap)
        self._guide_icon_path = path
        widget.show()

    def _current(self):
        if not self.entries:
            return None
        return self.entries[self._index()]["payload"]

    def _save_index(self):
        try:
            self._sel[self.cwd] = self._index()
        except Exception:
            pass

    def ok(self):
        cur = self._current()
        if not cur:
            return
        kind, obj = cur
        if kind == "folder":
            self._save_index()
            self.cwd = obj["id"]
            self._sel.pop(self.cwd, None)        # entering a folder always starts on its first item
            return self.fill()
        if store.needs_radio_url(obj):
            try:
                from Screens.MessageBox import MessageBox
                self.session.open(MessageBox, native(T("This radio needs a direct streaming URL. Edit it on the Web page.")), MessageBox.TYPE_INFO, timeout=6)
            except Exception:
                pass
            return
        c = ctl.get()
        # Test3: OK on the playing one starts its audio again from the beginning (fresh connection) and keeps the
        # picture delay / timeshift as it is; RED is the only key that stops. On any other one it plays that one.
        c.play(obj["id"])
        self.refresh()

    def up(self):
        f = store.get_folder(self.cwd)
        self._save_index()
        self.cwd = f.get("parent", "") if f else ""
        self.fill()

    def back(self):
        if self.cwd:
            self.up()
        else:
            self.close()

    def stop(self):
        ctl.get().stop()
        self.refresh()

    def update_sources(self):
        """Settings action: refresh every saved URL source, regardless of the open folder."""
        if getattr(self, "_updating", False):
            return
        fids = [f["id"] for f in store.list_folders() if (f.get("source") or {}).get("type") == "url"]
        if not fids:
            self._text("kok", T("No saved URL sources to update"))
            return
        self._updating = True
        self._text("kok", T("Updating from the source..."))

        def work():
            from . import importer
            added = updated = removed = 0
            errors = []
            for fid in fids:
                try:
                    r = importer.refresh_folder(fid)
                    added, updated, removed = added + r["added"], updated + r["updated"], removed + r["removed"]
                except Exception as e:
                    f = store.get_folder(fid) or {}
                    errors.append(u"%s: %s" % (to_text(f.get("name", "?")), to_text(e)))
            text = T("Updated: +%d new, %d changed, %d removed", added, updated, removed)
            if errors:
                text = (text + "   " if len(errors) < len(fids) else "") + T("Update failed: %s", errors[0])[:110]
            ctl.main_call(self._update_done, text)
        from .compat import start_thread
        start_thread(work, name="UltraAudio-update")

    def _update_done(self, text):
        self._updating = False
        try:
            self.fill()
            self._text("kok", text)
        except Exception:
            pass

    def key_audio_reset(self):
        """BLUE: the commentary back to its own timing (no audio delay at all)."""
        if self.menu.is_open:
            return
        st = ctl.get().engine.status()
        if st["state"] not in ("starting", "playing", "retrying") or not st["audio_delay_supported"]:
            return
        ctl.get().video.suspend_monitor()
        self.audio_timer.stop()
        self._audio_pending, self._audio_target = None, None
        ctl.get().set_audio_delay(0, st["stream_id"], st.get("generation"))
        self._aud_busy_until = time.time() + 0.35
        self._refresh_delays()

    def key_audio(self, d):
        """4 / 6: each press moves the PENDING audio delay by one step; it is applied (live, no reconnect) once the
        keys rest for AUDIO_SETTLE seconds, so a quick run of presses is one change."""
        if self.menu.is_open:
            return
        st = ctl.get().control_status()
        if st["state"] not in ("starting", "playing", "retrying") or not st["audio_delay_supported"]:
            return
        target = (st["stream_id"], st.get("generation"))
        if getattr(self, "_audio_target", None) != target:
            self._audio_pending = None
        self._audio_target = target
        base = self._audio_pending if self._audio_pending is not None else st["audio_delay_ms"]
        step = int(store.get_settings()["step_audio_ms"])
        self._audio_pending = max(0, min(60000, base + (step if d > 0 else -step)))
        # a live delay is applied after a short rest; the old pipeline restarts for each change: wait for the last press
        self.audio_timer.start(int((AUDIO_SETTLE if st.get("audio_delay_live") else 1.0) * 1000), True)
        self._show_delays(st, st["video"])

    def apply_audio(self):
        ms, self._audio_pending = self._audio_pending, None
        target, self._audio_target = getattr(self, "_audio_target", None), None
        c = ctl.get()
        st = c.control_status()
        if ms is not None and target == (st["stream_id"], st.get("generation")):
            prev_ms = int(st.get("audio_delay_ms") or 0)
            c.set_audio_delay(ms, *target)
            self._aud_busy_until = time.time() + (0.35 if ms <= prev_ms else 1.0)
        self._refresh_delays()

    def _refresh_delays(self):
        st = ctl.get().control_status()
        self._show_delays(st, st["video"])

    def adj(self, what, direction):
        c = ctl.get()
        st = c.engine.status()
        if st["state"] not in ("starting", "playing", "retrying"):
            return
        if what == "audio" and not st["audio_delay_supported"]:
            return
        (c.adjust_video if what == "video" else c.adjust_audio)(direction)

    # ----------------------------------------------------------- status
    def _color(self, name, color):
        if self._colors.get(name) == color:
            return                       # setting the same colour again still repaints the label
        self._colors[name] = color
        try:
            from skin import parseColor
            self[name].instance.setForegroundColor(parseColor(native(color)))
        except Exception:
            pass

    def _text(self, name, text):
        if self._texts.get(name) != text:
            self._texts[name] = text
            self[name].setText(native(text))

    def refresh(self):
        if not user_input_idle(0.42):
            if hasattr(self, "_nav_settle_timer"):
                self._nav_settle_timer.start(380, True)
            return
        self.football.refresh()
        if self._font != uifont.selected() and getattr(self, "execing", True):
            return self.reopen(self.menu.idx if self.menu.is_open else None)
        self._refresh_body()
        if self.menu.is_open:
            self.menu.refresh()           # the key words belong to the MENU card while it is open

    def _delay_text(self, st, v):
        """(picture value, audio value, picture busy?, audio busy?): busy = a change is waiting or being applied."""
        vcur = v["current_s"] if v["current_s"] is not None else v["target_s"]
        now = time.time()
        ppend = self._pic_pending
        if ppend is not None:
            ptxt = to_text(T("%+.1f s", ppend)) + u" \u2026"
        elif v["state"] == "filling":
            ptxt = to_text(T("%+.1f s", v["target_s"])) + u" \u2026"
        else:
            shown_v = 0.0 if v["state"] in ("off", "error") else (v["target_s"] if v.get("busy") else vcur)
            ptxt = to_text(T("%+.1f s", shown_v))
        pbusy = ppend is not None or now < self._pic_busy_until or v.get("busy") or v["state"] in ("filling", "paused")
        pend = self._audio_pending
        atxt = to_text(T("%+.1f s", (st["audio_delay_ms"] if pend is None else pend) / 1000.0)) + (u" \u2026" if pend is not None else u"")
        abusy = pend is not None or now < self._aud_busy_until or bool(st.get("audio_settling")) or st["state"] == "starting"
        return ptxt, atxt, pbusy, abusy

    def _delay_frame(self):
        """Current-delay captions; per-key step captions are intentionally omitted."""
        self._text("pcap", T("Picture").upper())
        self._text("acap", T("Audio").upper())

    def _show_delays(self, st, v):
        ptxt, atxt, pbusy, abusy = self._delay_text(st, v)
        self._delay_frame()
        self._text("pv", ptxt)
        self._text("pva", atxt)
        self._color("pv", self.pal["accent"] if pbusy else WHITE)
        self._color("pva", self.pal["accent"] if abusy else WHITE)

    def _refresh_body(self):
        self._text("clock", time.strftime("%H:%M"))
        self._text("imageinfo", self._image_label)
        self._color("imageinfo", self.pal["accent"])
        self._text("hname", "%s  http://%s:%d" % (T("Web"), self.ip, webui.PORT))
        self._color("hname", WHITE)
        c = ctl.get()
        st = c.status()
        self._text("hstate", (st.get('tv_channel') or {}).get('name') or "")
        self._color("hstate", WHITE)
        self._place_marker()
        self._sync_marker(st)
        target = (st["stream_id"], st.get("generation"))
        if self._audio_target is not None and self._audio_target != target:
            self._audio_pending, self._audio_target = None, None
            self.audio_timer.stop()
        if self._pic_target is not None and self._pic_target != target:
            self._pic_pending, self._pic_target = None, None
            self.pic_timer.stop()
        v = st["video"]
        language = lang()
        now_wall = time.time()
        if self._guide_streams and now_wall - self._last_guide_ensure >= 30.0:
            self._last_guide_ensure = now_wall
            guide.ensure(self._guide_streams, language)
        cur_min = int(now_wall // 60)
        cur_grev = guide.revision() if hasattr(guide, "revision") else -1
        new_guide_shown = None
        if self._guide_streams and (cur_grev != self._guide_rev_shown or cur_min != self._minute_shown or language != self._view_shown[0]):
            self._guide_rev_shown = cur_grev
            new_guide_shown = tuple(guide.view(s, language) for s in self._guide_streams)
            guide_changed = new_guide_shown != self._guide_shown
        else:
            guide_changed = False
        view = (language,)
        playing_id = st["stream_id"] if st["state"] in ("starting", "playing", "retrying") else None
        inplace_guide_ok = (guide_changed and self._shown is not None and self.cwd == self._shown[0]
                            and store.library_revision() == self._library_shown and view == self._view_shown
                            and not self.grid and self._can_invalidate)
        if inplace_guide_ok:
            self._update_guide_rows_inplace(new_guide_shown)
            guide_changed = False
        if (self._shown is None or self.cwd != self._shown[0]
                or store.library_revision() != self._library_shown or view != self._view_shown or guide_changed
                or (not self._can_invalidate and playing_id != self._shown[1])
                or (not self._can_invalidate and self._guide_streams and not self.grid and cur_min != self._minute_shown)):
            self._save_index()
            self.fill()
        elif not self.grid:
            if playing_id != self._shown[1]:
                for sid, playing in ((self._shown[1], False), (playing_id, True)):
                    i = self._stream_rows.get(sid)
                    if i is not None:
                        self.entries[i]["playing"] = playing
                        self._row_pairs.pop(i, None)
                        self._invalidate_row(i, i == self._lit)
                self._shown = (self.cwd, playing_id)
            if self._can_invalidate and self._guide_streams and cur_min != self._minute_shown:
                self._minute_shown = cur_min
                for i in list(self._row_pairs):
                    if i < len(self.entries) and self.entries[i].get("event"):
                        self._row_pairs.pop(i)
                first = (self._index() // ROWS) * ROWS
                for i in range(first, min(first + ROWS, len(self.entries))):
                    if self.entries[i].get("event"):
                        self._invalidate_row(i, i == self._lit)
        if self.grid:
            self._refresh_grid_guide()
        if st["state"] == "idle":
            self._delay_frame()
            self._text("pv", T("%+.1f s", 0.0))
            self._text("pva", T("%+.1f s", 0.0))
            self._color("pv", WHITE)
            self._color("pva", WHITE)
            self._text("kgreen", T("Freeze"))
            self._text("kyellow", T("Reset picture"))
            self.audio_keys(False)
            self._text("crumb", self._crumb)
            self._color("crumb", WHITE)
            return
        msg = ((st["message"] or "")[:60] if st["state"] in ("error", "retrying", "starting")
               else v.get("note", "") or st.get("audio_delay_note", ""))
        self._text("crumb", msg or self._crumb)
        self._color("crumb", (self.pal["error"] if st["state"] == "error" else self.pal["warn"]) if msg else WHITE)
        self._place_marker()
        self._show_delays(st, v)
        self._text("kgreen", T("Resume") if v["state"] == "paused" else T("Freeze"))
        self._text("kyellow", T("Reset picture"))
        self._text("kblue", T("Reset audio") if st["audio_delay_supported"] else T("Audio N/A"))
        self.audio_keys(not self.menu.is_open)

    def _refresh_cards(self, st, v):
        """Stadium / Daylight: the "now playing" block, the state chip and the status line (web address or message)."""
        P = self.pal
        web = "%s  http://%s:%d" % (T("Web"), self.ip, webui.PORT)
        if st["state"] == "idle":
            self._text("hstate", state_label("idle"))
            self._color("hstate", P["idle"])
            self._text("nphead", T("Ready").upper())
            self._color("nphead", P["muted"])
            self._text("pv", "")
            self._text("web", web)
            self._color("web", P["muted"])
            self._text("kgreen", T("Freeze"))
            self._text("kyellow", T("Reset picture"))
            self.audio_keys(False)
            return
        self._text("hstate", "" if st["state"] == "playing" else self.th.get("dot", u"\u25cf") + u" " + state_label(st["state"]))
        self._color("hstate", self._state_colors.get(st["state"], P["idle"]))
        self._text("nphead", T("Now playing").upper())
        self._color("nphead", P["accent"])
        msg = ((st["message"] or "")[:60] if st["state"] in ("error", "retrying", "starting")
               else v.get("note", "") or st.get("audio_delay_note", ""))
        self._text("web", msg or web)
        self._color("web", (P["error"] if st["state"] == "error" else P["warn"]) if msg else P["muted"])
        self._show_delays(st, v)
        self._text("kgreen", T("Resume") if v["state"] == "paused" else T("Freeze"))
        self._text("kyellow", T("Reset picture"))
        self._text("kblue", T("Reset audio") if st["audio_delay_supported"] else T("Audio N/A"))
        self.audio_keys(not self.menu.is_open)
