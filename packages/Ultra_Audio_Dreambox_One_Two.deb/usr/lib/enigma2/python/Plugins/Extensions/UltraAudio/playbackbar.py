# -*- coding: utf-8 -*-
"""Mini playback card: one vertical card in the bottom-right corner, shared by every theme.

The glass, dials and buttons are neutral graphite and white; the selected theme only colours what the list colours
too (the ULTRA AUDIO mark, the stream name and its guide). The equalizer runs through every theme's colour.
All artwork is pre-rendered at native pixels in assets/playcard."""
import os
import time
from xml.sax.saxutils import escape

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer, getDesktop, gFont

from . import ctl, guide, playcard, store, themes, tvchannel
from .compat import lru_cache, native, skin_scale_attr, ui_pixmap_path
from .engine import log
from .i18n import T, lang
from .motion import PlaybackMarker
from .cardlayout import guide_lines

ACTIVE = ('starting', 'playing', 'retrying')
KEY_TWIN_S = 0.6
CARD_DIR = os.path.join(store.ASSETS, 'playcard')
WHITE, MUTED, TEXT = '#FFFFFF', '#A9AFB6', '#F2F5F5'
CLOCK_FONT = ('UltraAudioClock', os.path.join(store.ASSETS, 'fonts', 'Cairo-SemiBold.ttf'))
PICON_DIRS = ('/media/hdd/picon', '/media/usb/picon', '/media/mmc/picon', '/usr/share/enigma2/picon', '/picon',
              '/data/picon', '/media/cf/picon')
_dialog = None
_clock_face = []


def clock_face():
    """A crisp semi-bold face for the big clock; the plugin's UI face when it cannot be registered."""
    if not _clock_face:
        name, path = CLOCK_FONT
        face = themes.face('UltraAudioUI')
        if os.path.isfile(path):
            try:
                from enigma import addFont
                try:
                    addFont(native(path), native(name), 100, 0)
                except TypeError:
                    addFont(native(path), native(name), 100, 0, 0)
                face = name
            except Exception:
                pass
        _clock_face.append(face)
    return _clock_face[0]


def theme_accent(theme):
    """The list's guide colour for this theme: the card's name, guide, LIVE and delay values use it."""
    pal = theme.get('pal') or {}
    return pal.get('row_accent') or pal.get('accent') or WHITE


def channel_picon(st):
    """The playing TV channel's own picon from the usual picon folders, else None."""
    channel = st.get('tv_channel') or {}
    reference, name = channel.get('reference') or '', channel.get('name') or ''
    if not reference and not name:
        return None
    for folder in PICON_DIRS:
        if os.path.isdir(folder):
            try:
                path = tvchannel.picon_file(reference, name, directory=folder)
            except Exception:
                path = None
            if path:
                return path
    return None


def context(st):
    return st.get('stream_id'), st.get('generation'), st.get('tv_service')


@lru_cache(maxsize=160)
def _asset_pixmap(path):
    return LoadPixmap(native(path))


def _asset(name, width, height):
    """assets/playcard/<name>.png (FHD) or its pre-sized twin <name>_<w>x<h>.png / <name>_<w>.png."""
    return ui_pixmap_path(os.path.join(CARD_DIR, name + '.png'), width, height)


def _frame(folder, name, width, height):
    """Animation / value frames: assets/playcard/<folder>/<name>.png is FHD, <folder>/<w>x<h>/<name>.png the rest."""
    sized = os.path.join(CARD_DIR, folder, '%dx%d' % (width, height), name + '.png')
    return sized if os.path.isfile(sized) else os.path.join(CARD_DIR, folder, name + '.png')


_logo_cache = {}


def _logo_pixmap(path):
    """Bundled icons never change; a custom picon is reloaded when its file changes."""
    try:
        key = (path, os.path.getmtime(path))
    except EnvironmentError:
        return None
    if key not in _logo_cache:
        if len(_logo_cache) > 32:
            _logo_cache.clear()
        _logo_cache[key] = LoadPixmap(native(path))
    return _logo_cache[key]


def _label(name, box, size, color, align, face, n, g):
    x, y, w, h = box
    return ('<widget name="%s" position="%d,%d" size="%d,%d" font="%s;%d" foregroundColor="%s" halign="%s" '
            'valign="center" transparent="1" noWrap="1" zPosition="6"/>' % (
                name, n(g + x), n(g + y), n(w), n(h), face, n(size), color, align))


def build_skin(width, height, theme):
    pc = playcard
    x, y, w, h, scale = pc.placement(width, height)
    n = lambda v: max(1, int(round(v * scale)))
    g = pc.GLOW
    scale_attr = skin_scale_attr()
    face = themes.face('UltraAudioUI')
    align = 'right' if lang() == 'ar' else 'left'
    accent = theme_accent(theme)

    def pix(name, box, path=None, z=4):
        bx, by, bw, bh = box
        extra = ' pixmap="%s"' % escape(path) if path else ''
        return '<widget name="%s" position="%d,%d" size="%d,%d"%s alphatest="blend" transparent="1"%s zPosition="%d"/>' % (
            name, n(g + bx), n(g + by), n(bw), n(bh), extra, scale_attr, z)

    def still(path, box, z):
        bx, by, bw, bh = box
        return '<ePixmap position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" transparent="1"%s zPosition="%d"/>' % (
            n(g + bx), n(g + by), n(bw), n(bh), escape(path), scale_attr, z)

    parts = ['<screen name="UltraAudioPlaybackCard" position="%d,%d" size="%d,%d" flags="wfNoBorder" '
             'backgroundColor="transparent" title="Ultra Audio" zPosition="10">' % (x, y, w, h)]
    parts.append('<ePixmap position="0,0" size="%d,%d" pixmap="%s" alphatest="blend" transparent="1"%s zPosition="0"/>' % (
        w, h, escape(_asset('panel', w, h)), scale_attr))
    brand = ui_pixmap_path(themes.pic(theme, 'brand.png'), n(pc.BRAND[2]), n(pc.BRAND[3]))
    parts.append(still(brand, pc.BRAND, 2))
    parts.append(pix('logo', pc.ICON, z=3))
    parts.append(pix('logo_fallback', pc.ICON_FALLBACK, z=3))
    for name, box in zip(('marker', 'marker_second', 'marker_third'), pc.EQ):
        parts.append(pix(name, box, z=3))
    parts.append(pix('evbar', pc.BAR, z=3))
    fg = pc.FOCUS_GLOW
    fw, fh = pc.TILE_W + 2 * fg, pc.TILE_H + 2 * fg
    for kind, (tx, ty) in pc.TILES:
        parts.append(pix(kind + '_focus', (tx - fg, ty - fg, fw, fh), _asset('focus', n(fw), n(fh)), z=1))
        parts.append(pix(kind + '_dial', pc.tile_box(kind, pc.T_DIAL), z=3))
        keys = ('1', '3') if kind == 'picture' else ('4', '6')
        for suffix, key, (px, py, pw, ph) in zip(('_minus', '_plus'), keys, pc.T_PILLS):
            nx, ny, nw, nh = pc.T_NUM
            parts.append(pix(kind + suffix, pc.tile_box(kind, (px + nx, py + ny, nw, nh)), _asset('num' + key, n(nw), n(nh)), z=5))
        parts.append(_label(kind + '_caption', pc.tile_box(kind, pc.T_CAPTION), 17, WHITE, 'center', face, n, g))
        parts.append(_label(kind + '_value', pc.tile_box(kind, pc.T_VALUE), 26, accent, 'center', face, n, g))
        parts.append(_label(kind + '_unit', pc.tile_box(kind, pc.T_UNIT), 13, MUTED, 'center', face, n, g))
    for kind, (bx, by, bw, bh) in pc.FOOTER:
        cx, cy, cw, ch = pc.F_CAPTION
        parts.append(_label(kind + '_caption', (bx + cx, by + cy, cw, ch), 18, WHITE, 'center', face, n, g))
    parts.append(_label('clock', pc.CLOCK, 34, accent, 'right', clock_face(), n, g))
    for name, box, size, color, alignment in (
            ('name', pc.NAME, 25, accent, 'center'),
            ('time', pc.TIME, 15, MUTED, align),
            ('guide', pc.GUIDE[0], 18, accent, align),
            ('guide_second', pc.GUIDE[1], 18, accent, align)):
        parts.append(_label(name, box, size, color, alignment, face, n, g))
    return ''.join(parts) + '</screen>'


def open_bar(session):
    """Called only by the InfoBar's 0 / 2 action; never opens the main plugin screen."""
    global _dialog
    if _dialog is not None:
        return 0
    st = ctl.get().status()
    if st.get('state') not in ACTIVE or not st.get('stream_id'):
        return 0
    try:
        def closed(*args):
            global _dialog
            _dialog = None
        _dialog = session.openWithCallback(closed, PlaybackBar)
        return 1
    except Exception as error:
        log('playback card: %r' % error)
        return 0


class PlaybackBar(Screen):
    LABELS = ('name', 'guide', 'guide_second', 'time', 'clock', 'picture_caption', 'audio_caption', 'freeze_caption',
              'stop_caption', 'picture_value', 'audio_value', 'picture_unit', 'audio_unit')
    PIXMAPS = ('marker', 'marker_second', 'marker_third', 'picture_minus', 'picture_plus', 'audio_minus', 'audio_plus',
               'logo', 'logo_fallback', 'evbar', 'picture_dial', 'audio_dial', 'picture_focus', 'audio_focus')
    GUIDE_SIZES = (18, 17, 16, 15, 14)

    def createSummary(self):
        from .frontpanel import UltraAudioFrontSummary
        return UltraAudioFrontSummary

    def __init__(self, session):
        desktop = getDesktop(0).size()
        self._scale = playcard.placement(desktop.width(), desktop.height())[4]
        theme = themes.get()
        self._accent = theme_accent(theme)
        self.skin = build_skin(desktop.width(), desktop.height(), theme)
        Screen.__init__(self, session)
        self._connections, self._texts, self._colors = [], {}, {}
        self._key_at = {}
        self._pending = {'picture': None, 'audio': None}
        self._closed, self._visible, self._ready = False, False, False
        self._marker = None
        self._companion_frames = {}
        self._guide_key = None
        self._delay_values = None
        self._shown_frames = {}
        self._logo_path = None
        self._focused = None
        self._target = context(ctl.get().status())
        for name in self.LABELS:
            self[name] = Label('')
        for name in self.PIXMAPS:
            self[name] = Pixmap()
        self['actions'] = ActionMap(['NumberActions', 'OkCancelActions', 'ColorActions'],
            {'0': self.close, '2': self.close, 'cancel': self.close,
             'yellow': self._once('yellow', lambda: self.reset('picture')),
             'blue': self._once('blue', lambda: self.reset('audio')),
             'green': self._once('green', self.freeze),
             'red': self._once('red', self.stop),
             '1': lambda: self.adjust('picture', -1), '3': lambda: self.adjust('picture', 1),
             '4': lambda: self.adjust('audio', -1), '6': lambda: self.adjust('audio', 1)}, -2)
        self._refresh_timer = self._timer(self.refresh)
        self._picture_timer = self._timer(lambda: self.apply('picture'))
        self._audio_timer = self._timer(lambda: self.apply('audio'))
        self.onLayoutFinish.append(self._layout_ready)
        self.onExecBegin.append(self._resume)
        self.onExecEnd.append(self._suspend)
        self.onHide.append(self._suspend)
        self.onClose.append(self._cleanup)

    def _n(self, v):
        return max(1, int(round(v * self._scale)))

    def _once(self, name, handler):
        # Same make/repeat guard as the main screen: held GREEN must not toggle back.
        def run():
            now = time.time()
            last = self._key_at.get(name, 0.0)
            self._key_at[name] = now
            if 0.0 <= now - last < KEY_TWIN_S:
                return
            try:
                handler()
            finally:
                self._key_at[name] = time.time()
        return run

    def freeze(self):
        if self._valid(ctl.get().status()):
            ctl.get().toggle_pause()
            self.refresh()

    def stop(self):
        if self._valid(ctl.get().status()):
            ctl.get().stop()
            self.close()

    def _timer(self, callback):
        timer = eTimer()
        if hasattr(timer, 'callback'):
            timer.callback.append(callback)
        else:
            self._connections.append(timer.timeout.connect(callback))
        return timer

    def _layout_ready(self):
        self._ready = True
        n = self._n
        for name in ('picture_focus', 'audio_focus', 'evbar', 'logo', 'logo_fallback'):
            self[name].hide()
        w, h = n(playcard.EQ_W), n(playcard.EQ_H)
        sets = [tuple(_asset_pixmap(_frame('eq/p%d' % part, 'eq_%d' % i, w, h)) for i in range(8)) for part in range(3)]
        stills = [_asset_pixmap(_frame('eq/p%d' % part, 'eq_idle', w, h)) for part in range(3)]
        frames, still = sets[0], stills[0]
        # Three frames side by side read as one wide spectrum: each third keeps its own colours of the gradient
        # and runs a few steps behind its neighbour.
        if all(frames) and all(sets[1]) and all(sets[2]):
            self._companion_frames = dict((id(frame), (sets[1][(i + 3) % 8], sets[2][(i + 6) % 8]))
                                          for i, frame in enumerate(frames))
        else:
            frames = ()
        if still is not None:
            self._companion_frames[id(still)] = (stills[1] or still, stills[2] or still)
        self._marker = PlaybackMarker(self._timer, frames, still,
            self._marker_status, self._paint_markers, lambda row: None,
            self._show_markers, self._hide_markers)
        self._resume()

    def _paint_markers(self, pixmap):
        second, third = self._companion_frames.get(id(pixmap), (pixmap, pixmap))
        self['marker'].instance.setPixmap(pixmap)
        self['marker_second'].instance.setPixmap(second)
        self['marker_third'].instance.setPixmap(third)

    def _show_markers(self):
        for name in ('marker', 'marker_second', 'marker_third'):
            self[name].show()

    def _hide_markers(self):
        for name in ('marker', 'marker_second', 'marker_third'):
            self[name].hide()

    def _measure(self, name, text, font_size):
        label = self[name]
        label.setText(native(text))
        try:
            size = label.instance.calculateSize()
            return max(0, size.width()), max(0, size.height())
        except Exception:
            return int(len(text) * font_size * 0.65), font_size

    def _update_guide(self, text, scale):
        text = text or ''
        key = (text, lang(), scale)
        if key == self._guide_key:
            return
        self._guide_key = key
        face = themes.face('UltraAudioUI')
        width = max(1, int(round(playcard.GUIDE[0][2] * scale)))
        lines = ()
        font_size = max(1, int(round(self.GUIDE_SIZES[0] * scale)))
        # Keep two static lines. Fit once per event; never page or scroll.
        for design_size in self.GUIDE_SIZES:
            font_size = max(1, int(round(design_size * scale)))
            self['guide'].instance.setFont(gFont(face, font_size))
            lines = guide_lines(text, lambda t: self._measure('guide', t, font_size)[0], width)
            if len(lines) <= 2:
                break
        first = lines[0] if lines else ''
        second = lines[1] if len(lines) > 1 else ''
        if len(lines) > 2:
            while second and self._measure('guide', second + u'…', font_size)[0] > width:
                second = second[:-1]
            second += u'…'
        for name in ('guide', 'guide_second'):
            self[name].instance.setFont(gFont(face, font_size))
            self._texts.pop(name, None)
        self._text('guide', first)
        self._text('guide_second', second)

    def _fit(self, name, design, max_w, max_h, smallest):
        n = self._n
        face = themes.face('UltraAudioUI')
        size = n(design)
        self[name].instance.setFont(gFont(face, size))
        measured, high = self._measure(name, self._texts.get(name) or '', size)
        if measured > n(max_w) or high > n(max_h):
            fit = min(float(n(max_w)) / max(1, measured), float(n(max_h)) / max(1, high))
            self[name].instance.setFont(gFont(face, max(n(smallest), int(size * fit))))

    def _place_delays(self):
        values = (self._texts.get('picture_value'), self._texts.get('audio_value'), lang(), themes.face('UltraAudioUI'))
        if values == self._delay_values:
            return
        self._delay_values = values
        for kind in ('picture', 'audio'):
            # Fit inside the dial's dark disk (not the whole tile), so a long word such as "En direct" stays in it.
            self._fit(kind + '_value', 26, int(playcard.DIAL_DISK_R * 2) - 4, playcard.T_VALUE[3], 12)

    def _marker_status(self):
        # Lock-free atomic attribute reads: never skip animation frames due to worker lock contention
        engine = ctl.get().engine
        stream = engine.stream
        return {'state': engine.state, 'stream_id': stream.get('id') if isinstance(stream, dict) else None}

    def _resume(self):
        if self._closed or not self._ready:
            return
        self._visible = True
        self.refresh()
        if not self._closed:
            self._refresh_timer.start(750, False)

    def _suspend(self):
        self._visible = False
        for timer in (self._refresh_timer, self._picture_timer, self._audio_timer):
            timer.stop()
        pic_val, aud_val = self._pending.get('picture'), self._pending.get('audio')
        self._pending = {'picture': None, 'audio': None}
        if pic_val is not None or aud_val is not None:
            try:
                controller = ctl.get()
                st = controller.status()
                if st.get('state') in ACTIVE and context(st) == self._target:
                    if pic_val is not None:
                        controller.set_video_delay(pic_val, self._target[0], self._target[1])
                    if aud_val is not None:
                        controller.set_audio_delay(aud_val, self._target[0], self._target[1])
            except Exception as err:
                log('playback card flush on close: %r' % err)
        if self._marker is not None:
            self._marker.stop()

    def _cleanup(self):
        self._closed = True
        self._suspend()
        if self._marker is not None:
            self._marker.close()
        self._connections = []

    def _valid(self, st):
        return (self._visible and not self._closed and st.get('state') in ACTIVE
                and context(st) == self._target)

    def _text(self, name, value):
        if self._texts.get(name) != value:
            self._texts[name] = value
            self[name].setText(native(value))

    def refresh(self):
        try:
            self._refresh_body()
        except Exception as error:
            log('playback card refresh: %r' % error)
            self.close()

    def _refresh_body(self):
        if not self._visible or self._closed:
            return
        st = ctl.get().status()
        if not self._valid(st):
            return self.close()
        stream = store.get_stream_readonly(st['stream_id']) if hasattr(store, 'get_stream_readonly') else store.get_stream(st['stream_id'])
        if not stream:
            return self.close()
        library = store.readonly_library() if hasattr(store, 'readonly_library') else store._load()
        name, duration = store.stream_display(stream, library)
        if self._texts.get('name') != name:
            self._text('name', name)
            self._fit('name', 25, playcard.NAME[2], playcard.NAME[3], 14)
        self._show_logo(st, stream, library)
        event = None
        if not store.is_radio_stream(stream, library):
            guide.ensure([stream], lang())
            event = guide.view(stream, lang())[1]
        self._update_guide(event[0] if event else '', self._scale)
        self._text('time', (time.strftime('%H:%M', time.localtime(event[1])) + u' – ' +
                           time.strftime('%H:%M', time.localtime(event[2]))) if event else (duration or ''))
        self._show_progress(event)
        self._text('clock', time.strftime('%H:%M'))
        self._text('stop_caption', T('Stop'))
        self._text('picture_caption', T('Picture'))
        self._text('audio_caption', T('Audio'))
        video = st.get('video') or {}
        self._text('freeze_caption', T('Resume') if video.get('state') == 'paused' else T('Freeze'))
        self._show_delays(st, video)
        self._place_delays()
        if self._marker is not None:
            self._marker.update(0, st['state'], st['stream_id'], visible=True)

    def _show_logo(self, st, stream, library):
        """The TV channel's picon (scaled to its box); the stream's pre-sized icon only when no picon exists."""
        picon = channel_picon(st)
        if picon:
            key = ('picon', picon)
        else:
            try:
                key = ('icon', store.stream_icon(stream, scale=self._scale, lib=library))
            except Exception:
                key = ('icon', None)
        if key == self._logo_path:
            return
        self._logo_path = key
        shown, hidden = ('logo', 'logo_fallback') if key[0] == 'picon' else ('logo_fallback', 'logo')
        self[hidden].hide()
        pixmap = self._picon_pixmap(key[1]) if key[0] == 'picon' else (_logo_pixmap(key[1]) if key[1] else None)
        if pixmap is not None and self[shown].instance is not None:
            self[shown].instance.setPixmap(pixmap)
            self[shown].show()
        else:
            self[shown].hide()

    def _picon_pixmap(self, path):
        """Picons come in any size: scale on images that can, decode at the box size on DreamOS."""
        frame = self['logo'].instance
        pixmap = _logo_pixmap(path)
        if frame is None:
            return pixmap
        if hasattr(frame, 'setScale'):
            try:
                frame.setScale(1)
                return pixmap
            except Exception:
                pass
        try:
            from enigma import ePicLoad
            width, height = self._n(playcard.ICON[2]), self._n(playcard.ICON[3])
            decoder = ePicLoad()
            decoder.setPara((width, height, 1, 1, 0, 1, '#00000000'))
            if decoder.startDecode(native(path), 0, 0, False) == 0:
                pixmap = decoder.getData() or pixmap
        except Exception:
            pass
        return pixmap

    def _show_progress(self, event):
        if event and event[2] > event[1]:
            done = (time.time() - event[1]) / float(event[2] - event[1])
            self._set_frame('evbar', 'bar', 'b_%02d' % playcard.bar_frame(done), playcard.BAR[2], playcard.BAR[3])
            self['evbar'].show()
        else:
            self['evbar'].hide()

    def _set_frame(self, name, folder, frame, box_w, box_h):
        path = _frame(folder, frame, self._n(box_w), self._n(box_h))
        if self._shown_frames.get(name) == path:
            return
        pixmap = _asset_pixmap(path) if os.path.isfile(path) else None
        if pixmap is not None and self[name].instance is not None:
            self[name].instance.setPixmap(pixmap)
            self._shown_frames[name] = path

    def _focus(self, kind):
        if kind == self._focused:
            return
        self._focused = kind
        for other in ('picture', 'audio'):
            if other == kind:
                self[other + '_focus'].show()
            else:
                self[other + '_focus'].hide()

    def _delay_state(self, st, video):
        picture = self._pending['picture']
        if picture is None:
            if video.get('state') in ('off', 'error'):
                picture = 0.0
            elif video.get('state') == 'filling' or video.get('busy'):
                picture = video.get('target_s') if video.get('target_s') is not None else (video.get('current_s') or 0.0)
            else:
                picture = video.get('current_s')
                if picture is None:
                    picture = video.get('target_s') or 0.0
        audio = self._pending['audio']
        if audio is None:
            audio = st.get('audio_delay_ms') or 0
        p_busy = self._pending['picture'] is not None or video.get('busy') or video.get('state') in ('filling', 'paused')
        a_busy = self._pending['audio'] is not None or bool(st.get('audio_settling'))
        return float(picture or 0.0), audio, p_busy, a_busy

    def _show_delays(self, st, video):
        picture, audio, p_busy, a_busy = self._delay_state(st, video)
        moving = self._pending['picture'] is not None or video.get('state') == 'filling' or video.get('busy')
        if picture <= 0.0 and not moving:
            p_value, p_unit = T('Live'), u''
        else:
            p_value, p_unit = u'%.1f' % picture, T('sec')
        supported = st.get('audio_delay_supported')
        if supported:
            a_value, a_unit = u'%.1f' % (audio / 1000.0), T('sec')
        else:
            a_value, a_unit = T('N/A'), u''
        self._text('picture_value', p_value)
        self._text('picture_unit', p_unit)
        self._text('audio_value', a_value)
        self._text('audio_unit', a_unit)
        # Values (and LIVE) wear the theme's guide colour; one still on its way takes its tile's key colour
        # (YELLOW picture, BLUE audio) until it is applied.
        try:
            from skin import parseColor
            for name, busy, color in (('picture_value', p_busy, playcard.KEY_COLORS['picture']),
                                      ('audio_value', a_busy, playcard.KEY_COLORS['audio'])):
                color = color if busy else self._accent
                if self._colors.get(name) != color:
                    self[name].instance.setForegroundColor(parseColor(native(color)))
                    self._colors[name] = color
        except Exception:
            pass
        size = playcard.T_DIAL[2]
        self._set_frame('picture_dial', 'dial', 'd_%02d' % playcard.dial_frame('picture', picture), size, size)
        self._set_frame('audio_dial', 'dial', 'd_%02d' % playcard.dial_frame('audio', audio if supported else 0), size, size)

    def _control_status(self):
        controller = ctl.get()
        return getattr(controller, 'control_status', controller.status)()

    def reset(self, kind):
        controller = ctl.get()
        st = self._control_status()
        if not self._valid(st) or (kind == 'audio' and not st.get('audio_delay_supported')):
            return
        timer = self._picture_timer if kind == 'picture' else self._audio_timer
        timer.stop()
        self._pending[kind] = None
        try:
            if kind == 'picture':
                controller.reset_picture(self._target[0], self._target[1])
            else:
                controller.video.suspend_monitor()
                controller.set_audio_delay(0, self._target[0], self._target[1])
        except Exception as error:
            log('playback card reset: %r' % error)
        st = self._control_status()
        self._show_delays(st, st['video'])
        self._focus(kind)

    def adjust(self, kind, direction):
        st = self._control_status()
        if not self._valid(st) or (kind == 'audio' and not st.get('audio_delay_supported')):
            return
        settings = store.get_settings()
        value = self._pending[kind]
        if kind == 'picture':
            video = st.get('video') or {}
            if value is None:
                if video.get('state') in ('off', 'error'):
                    memo = store.recall_channel(st.get('tv_service')) or {}
                    value = float(memo.get('video_s') or 0)
                elif video.get('state') == 'paused':
                    value = video.get('current_s')
                    if value is None:
                        value = video.get('target_s') or 0.0
                else:
                    value = video.get('target_s')
                    if value is None:
                        value = video.get('current_s') or 0.0
            self._pending[kind] = round(max(0.0, min(600.0, value + direction * float(settings['step_video_s']))), 1)
            self._picture_timer.start(850, True)
        else:
            value = st.get('audio_delay_ms', 0) if value is None else value
            self._pending[kind] = max(0, min(60000, value + direction * int(settings['step_audio_ms'])))
            self._audio_timer.start(550 if st.get('audio_delay_live') else 1000, True)
        self._show_delays(st, st['video'])
        self._focus(kind)

    def apply(self, kind):
        value, self._pending[kind] = self._pending[kind], None
        st = self._control_status()
        if value is None or not self._valid(st):
            return
        controller = ctl.get()
        try:
            if kind == 'picture':
                controller.set_video_delay(value, self._target[0], self._target[1])
            else:
                controller.set_audio_delay(value, self._target[0], self._target[1])
        except Exception as error:
            log('playback card adjustment: %r' % error)
        st = self._control_status()
        if self._valid(st):
            self._show_delays(st, st['video'])
