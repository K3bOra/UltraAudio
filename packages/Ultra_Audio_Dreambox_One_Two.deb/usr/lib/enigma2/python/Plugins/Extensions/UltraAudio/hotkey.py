# -*- coding: utf-8 -*-
"""A long press on the remote's AUDIO key opens Ultra Audio while watching TV.

On DreamOS (opendreambox 2.6) and some Enigma2 images, InfoBarAudioSelection binds KEY_AUDIO with flags='m' (make),
which opens the AudioSelection dialog immediately on key-down before a long press ('l') can fire on the InfoBar.
To make long AUDIO work reliably on all images (DreamOS, OpenATV, OpenPLi, Vu+):
1. We bind KEY_AUDIO make ('m'), long ('l'), and break ('b') at priority -10 on the InfoBar.
2. When 'long_audio' is enabled:
   - 'make' is consumed (deferring the normal AudioSelection menu until key release).
   - 'long' opens Ultra Audio immediately and suppresses the short-press AudioSelection menu.
   - 'break' (short press release without 'long') opens the receiver's normal AudioSelection menu.
3. As a fallback, if AudioSelection was opened by another handler on key-down, a long press ('l') inside AudioSelection
   closes AudioSelection and opens Ultra Audio.
"""
from __future__ import division
import os

from . import store
from .compat import monotonic, native
from .engine import log

KEYMAP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keymap.xml")
CONTEXT, ACTION, NAME = "UltraAudioActions", "openUltraAudio", "UltraAudioLongAudio"
QUIET = 1.5                  # seconds after our long press during which the receiver's audio menu stays shut

_state = {
    "installed": False,
    "last_long": 0.0,
    "last_make": 0.0,
    "long_fired": False,
    "allow_short": False,
    "open": None,
    "base_sel": None,
}


def _load_keymap():
    try:
        from Components.ActionMap import loadKeymap as load       # OpenATV / newer OpenPLi
    except ImportError:
        from keymapparser import readKeymap as load               # older images / DreamOS
    load(native(KEYMAP))


def _on_make():
    if not store.get_settings().get("long_audio", True):
        return 0
    _state["last_make"] = monotonic()
    _state["long_fired"] = False
    return 1


def _on_long():
    if not store.get_settings().get("long_audio", True):
        return 0                                   # not handled: the receiver's own long AUDIO action runs
    now = monotonic()
    if now - _state["last_long"] < 0.8:
        return 1
    _state["last_long"] = now
    _state["long_fired"] = True
    try:
        from Screens.InfoBar import InfoBar
        ib = InfoBar.instance
        if ib is not None and _state["open"]:
            log("long AUDIO pressed: opening Ultra Audio")
            _state["open"](ib.session)
    except Exception as e:
        log("long AUDIO: opening failed: %r" % e)
    return 1


def _on_break():
    if not store.get_settings().get("long_audio", True):
        return 0
    now = monotonic()
    if _state["long_fired"] or (now - _state["last_long"] < QUIET):
        _state["long_fired"] = False
        return 1
    # Short press released without reaching 'long': open normal AudioSelection menu
    try:
        from Screens.InfoBar import InfoBar
        ib = InfoBar.instance
        if ib is not None and _state["base_sel"] is not None:
            _state["allow_short"] = True
            try:
                _state["base_sel"](ib)
            finally:
                _state["allow_short"] = False
            return 1
    except Exception as e:
        log("short AUDIO passthrough failed: %r" % e)
    return 0


def _on_bar(pressed_key="0"):
    # Returning zero leaves the receiver's normal 0 / 2 action intact when not selected or while idle.
    try:
        chosen = str(store.get_settings().get("bar_key", "0"))
        if chosen not in ("0", "2"):
            chosen = "0"
        if str(pressed_key) != chosen:
            return 0
        from Screens.InfoBar import InfoBar
        from .playbackbar import open_bar
        ib = InfoBar.instance
        return open_bar(ib.session) if ib is not None else 0
    except Exception as error:
        log("playback bar key: %r" % error)
        return 0


def _attach(ib):
    from Components.ActionMap import ActionMap
    bar_name = "UltraAudioPlaybackBarKey"
    if bar_name not in ib:
        bar = ActionMap([CONTEXT], {
            "openUltraAudioBar": lambda: _on_bar("0"),
            "openUltraAudioBar0": lambda: _on_bar("0"),
            "openUltraAudioBar2": lambda: _on_bar("2"),
        }, -2)
        ib[bar_name] = bar
        if getattr(ib, "execing", False):
            bar.execBegin()
    if NAME in ib:
        return
    am = ActionMap([CONTEXT], {
        "openUltraAudioMake": _on_make,
        ACTION: _on_long,
        "openUltraAudioBreak": _on_break,
    }, -10)
    ib[NAME] = am
    if getattr(ib, "execing", False):              # the InfoBar already runs (plugin reloaded): bind now
        am.execBegin()


def _attach_audio_selection():
    """Fallback for images where AudioSelection still opens on KEY_AUDIO make: holding KEY_AUDIO inside AudioSelection
    closes AudioSelection and opens Ultra Audio."""
    try:
        from Screens.AudioSelection import AudioSelection
        from Components.ActionMap import ActionMap
        base_as_init = AudioSelection.__init__

        def as_init(self, session, *args, **kwargs):
            base_as_init(self, session, *args, **kwargs)
            try:
                if NAME not in self:
                    def _from_audio_dialog():
                        if not store.get_settings().get("long_audio", True):
                            return 0
                        _state["last_long"] = monotonic()
                        _state["long_fired"] = True
                        try:
                            self.close()
                        except Exception:
                            pass
                        try:
                            if _state["open"]:
                                log("long AUDIO inside AudioSelection: opening Ultra Audio")
                                _state["open"](session)
                        except Exception as e:
                            log("long AUDIO from AudioSelection failed: %r" % e)
                        return 1
                    am = ActionMap([CONTEXT], {ACTION: _from_audio_dialog}, -10)
                    self[NAME] = am
                    if getattr(self, "execing", False):
                        am.execBegin()
            except Exception as e:
                log("AudioSelection hook failed: %r" % e)

        AudioSelection.__init__ = as_init
    except Exception as e:
        log("AudioSelection hook unavailable: %r" % e)


def install(open_plugin):
    """Called at session start, before the InfoBar exists. Never raises."""
    if _state["installed"]:
        return
    _state["open"] = open_plugin
    try:
        _load_keymap()
        from Screens.InfoBar import InfoBar
        from Screens.InfoBarGenerics import InfoBarAudioSelection
    except Exception as e:
        log("long AUDIO key not available: %r" % e)
        return

    base_init = InfoBar.__init__

    def init(self, *args, **kwargs):
        base_init(self, *args, **kwargs)
        try:
            _attach(self)
        except Exception as e:
            log("long AUDIO key: %r" % e)
    InfoBar.__init__ = init

    base_sel = InfoBarAudioSelection.audioSelection
    _state["base_sel"] = base_sel

    def audioSelection(self, *args, **kwargs):
        now = monotonic()
        if now - _state["last_long"] < QUIET:
            return None                            # the release of our long press: no audio menu on top of ours
        if store.get_settings().get("long_audio", True) and not _state["allow_short"] and (now - _state["last_make"] < 0.7):
            return None                            # wait for break or long press
        return base_sel(self, *args, **kwargs)
    InfoBarAudioSelection.audioSelection = audioSelection

    _attach_audio_selection()

    try:
        if InfoBar.instance is not None:
            _attach(InfoBar.instance)
    except Exception as e:
        log("long AUDIO key: %r" % e)
    _state["installed"] = True
    log("long AUDIO key ready")
