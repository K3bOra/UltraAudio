# -*- coding: utf-8 -*-
"""Read-only ALSA discovery, including older Broadcom receiver kernels and Amlogic DreamOS."""
from __future__ import division
import glob
import os
import re


def _card_id(asound, card):
    try:
        with open(os.path.join(asound, "card%d" % card, "id")) as handle:
            return handle.read().strip()
    except EnvironmentError:
        return ""


def _is_dummy_aml_pcm(asound, card, dev):
    """On Amlogic AMLAUGESOUND (Dreambox One/Two), only pcm0p (TDM-B i2s2hdmi) outputs PCM to HDMI/TV.
    pcm1p is SPDIF held by eDVBAudio, and pcm2p+ (TDM-A-dummy-alsaPORT-pcm) is a silent dummy/BT port."""
    if _card_id(asound, card).upper() == "AMLAUGESOUND" and dev >= 1:
        return True
    try:
        with open(os.path.join(asound, "card%d" % card, "pcm%dp" % dev, "info")) as handle:
            info = handle.read().lower()
        if "alsaport-pcm" in info or "tdm-a-dummy" in info:
            return True
    except EnvironmentError:
        pass
    return False


def playback_devices(asound="/proc/asound", snd="/dev/snd"):
    """Return (card, device) pairs without opening or claiming any audio device."""
    found = set()
    for path in glob.glob(os.path.join(asound, "card*", "pcm*p")):
        match = re.search(r"/card(\d+)/pcm(\d+)p$", path)
        if match:
            found.add(tuple(int(x) for x in match.groups()))
    try:
        with open(os.path.join(asound, "pcm")) as handle:
            for line in handle:
                match = re.match(r"\s*(\d+)-(\d+):", line)
                if match and re.search(r"\bplayback\s+[1-9]\d*", line):
                    found.add(tuple(int(x) for x in match.groups()))
    except EnvironmentError:
        pass
    for path in glob.glob(os.path.join(snd, "pcmC*D*p")):
        match = re.search(r"/pcmC(\d+)D(\d+)p$", path)
        if match:
            found.add(tuple(int(x) for x in match.groups()))
    filtered = [pair for pair in sorted(found) if not _is_dummy_aml_pcm(asound, pair[0], pair[1])]
    return filtered or sorted(found)
