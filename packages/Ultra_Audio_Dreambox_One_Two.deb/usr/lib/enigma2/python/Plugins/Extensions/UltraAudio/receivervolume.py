# -*- coding: utf-8 -*-
"""Receiver master volume; callers dispatch these operations to Enigma2's main loop."""
from __future__ import division


def snapshot():
    try:
        from enigma import eDVBVolumecontrol
        control = eDVBVolumecontrol.getInstance()
        return {"available": True, "value": max(0, min(100, int(control.getVolume()))),
                "muted": bool(control.isMuted())}
    except Exception:
        return {"available": False, "value": None, "muted": False}


def apply(value):
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 100:
        raise ValueError("Volume must be an integer between 0 and 100")
    try:
        from enigma import eDVBVolumecontrol
        control = eDVBVolumecontrol.getInstance()
        control.setVolume(value, value)
        # Keep the receiver's normal volume setting in step with the hardware.
        # Leave mute ownership and playback processes untouched.
        try:
            from Components.config import config
            config.audio.volume.value = value
        except (ImportError, AttributeError):
            pass
        return snapshot()
    except Exception:
        return {"available": False, "value": None, "muted": False}


# ------------------------------------------------------------- commentary follows the remote's volume
# On Dreambox One / Two (DreamOS and OpenATV alike) the remote's volume is applied by dreamaudiod / the decoder path,
# while the commentary is written straight to the ALSA card, so the VOL keys never reached it. There the receiver
# volume is applied to the commentary by our relay. Elsewhere Enigma2's volume is the ALSA mixer the commentary
# already plays through, so nothing is added (it would lower it twice). Setting "follow_volume": auto | on | off.
_follow = [None]


def _read(path):
    try:
        with open(path) as handle:
            return handle.read()
    except (EnvironmentError, UnicodeDecodeError):
        return ""


def _volume_bypasses_commentary():
    import os
    if os.path.exists("/dev/dvb/adapter0/dreamaudio0"):
        return True
    names = [_read(p).strip().lower() for p in ("/proc/stb/info/model", "/proc/stb/info/boxtype")]
    for line in _read("/etc/image-version").splitlines():
        if line.lower().startswith(("box_type=", "machinebuild=", "machine_name=")):
            names.append(line.split("=", 1)[1].strip().lower())
    if any(n in ("dreamone", "dreamtwo", "one", "two") for n in names):
        return True
    cards = (_read("/proc/asound/cards") + " " + _read("/proc/asound/card0/id")).lower()
    return "dreamone" in cards or "amlaugesound" in cards


def follows(setting="auto"):
    if setting in ("on", "off"):
        return setting == "on"
    if _follow[0] is None:
        try:
            _follow[0] = bool(_volume_bypasses_commentary())
        except Exception:
            _follow[0] = False
    return _follow[0]


def commentary_gain(mute_mode="decoder", muted_by_us=False):
    """Receiver volume as a gain for the commentary (main thread only): 0.0..1.0, straight from the remote's volume.

    Volume 0 is silence, exactly like the TV sound: the commentary goes quiet with it and comes back when VOL+ is
    pressed. (Before, 0 jumped back to full volume and 1..24 were stuck at 25%.)
    The receiver's MUTE state is not read here: on Dreambox One/Two, eDVBVolumecontrol mute also serves to silence
    the TV decoder path while the commentary plays on ALSA."""
    try:
        from enigma import eDVBVolumecontrol
        control = eDVBVolumecontrol.getInstance()
        value = max(0, min(100, int(control.getVolume())))
        return value / 100.0
    except Exception:
        return None
